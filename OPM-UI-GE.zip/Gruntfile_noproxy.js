/**
 * Created by 212677088 on 6/19/2018.
 */
module.exports = function(grunt) {
    'use strict';


    grunt.initConfig({
        pkg: grunt.file.readJSON('package.json'),

        jshint: {
            files: ['Gruntfile.js', 'step_definitions/*.js'],
            options: {
                globals: {
                    jQuery: true,
                    console: true,
                    module: true,
                    document: true,
                },
                esversion: 6
            }

        },
        execute: {
            target: {
                src:['./node_modules/proui-utils/updateChromeDriver.js']
            }
        },

        shell: {
            options: {
                stdout:true
            },
            disableSSL:
            {
                command:'set NODE_TLS_REJECT_UNAUTHORIZED=0'
            },
            npm_install: {
                command: 'npm install --only=dev'
            },
            npm_update: {
                command: 'npm update --only=dev'
            },
            protractor_version: {
                command: 'node ./node_modules/protractor/bin/protractor --version'
            },
            protractor_install: {
                command: 'node ./node_modules/protractor/bin/webdriver-manager update --ignore_ssl'
            }
        },
        protractor: {

            default: {
                options: {
                    keepAlive: true,
                    configFile: 'Test_modules/Dashboard/Conf/protractor.cucumber.dashboard.conf.js',
                    args: {suite: 'dashboard',
                        username: ''}
                }
            },
            test: {
                options: {
                    keepAlive: true,
                    configFile: grunt.option('conf'),
                    args: { suite: grunt.option('suite') }
                }
            },

            browser:{
                options: {
                    keepAlive: true,
                    configFile: grunt.option('conf'),
                    args: {cucumberOpts:grunt.option('spec'),suite: grunt.option('suite'), browser: grunt.option('browser'),
                        baseUrl:grunt.option('baseUrl'),
                        username:grunt.option('username'),
                        password:grunt.option('password')}
                }
            },

            noSuite: {
                options: {
                    keepAlive: true,
                    configFile: grunt.option('conf')
                }
            },
            singlerun: {},
            auto: {
                keepAlive: true,
                options: {
                    args: {
                        seleniumPort: 4444
                    }
                }
            }
        }


    });

    var target = grunt.option('target') || 'def';

    grunt.loadNpmTasks('grunt-contrib-jshint');

    grunt.loadNpmTasks('grunt-execute');

    grunt.loadNpmTasks('grunt-shell-spawn');

    grunt.loadNpmTasks('grunt-protractor-runner');

    grunt.registerTask('default', ['jshint', 'execute:target','shell','protractor:default']);

    grunt.registerTask('default',  function(arg) {
        try {
            grunt.task.run('jshint');
            grunt.task.run('execute:target');
            grunt.task.run('shell');
        } catch(e) {
            // Something went wrong.
            grunt.verbose.or.write(msg).error().error(e.message);
            grunt.fail.warn('Something went wrong.');
        }
    });

    grunt.registerTask('test',  function(arg) {
        try {
            grunt.task.run('jshint');
            grunt.task.run('execute:target');
            grunt.task.run('shell:protractor_install');
            grunt.task.run('protractor:test');
        } catch(e) {
            grunt.verbose.or.write(msg).error().error(e.message);
            grunt.fail.warn('Something went wrong.');
        }
    });
    grunt.registerTask('noSuite', ['jshint', 'execute:target','shell','protractor:noSuite']);


    grunt.registerTask('browser', ['jshint','shell','protractor:browser']);

    var protractorperf = require('protractor-perf');
    grunt.registerTask('performance', function() {
        var donerun = this.async();
        var argv = {
            selenium: 'http://localhost:54321/wd/hub',
            seleniumPort: 54321,
            suite: grunt.option('suite')

        };
        protractorperf.run(grunt.option('conf'), donerun, argv); // config file
    });

    grunt.registerTask('run', ['protractorperf']);
};
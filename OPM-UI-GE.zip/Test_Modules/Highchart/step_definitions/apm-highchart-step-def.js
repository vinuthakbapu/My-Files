var myStepDefinitionsWrapper;
myStepDefinitionsWrapper = function () {
    'use strict';

    this.Given(/^The application is correctly logged in$/, function (callback) {

        //Using login page object method to check if user has logged in.
        //perfRunner.start();

        loginPage.checkHomePage().then(function (completed) {

            //Calling logger to write specific details
            Logger.info("Asserting if logged in\n");

            // Using the promise returned from checkHomePage as a parameter in TestHelper class to assert if true
            TestHelper.assertTrue(completed, 'Not logged in');
            apmlandingPage.selectDashboard().then(function () {
                callback()
            })
            //Callback once test is complete
        });
    });

    this.When(/^I go to the dashboard and select a chart from E2E edison$/, function (callback) {
        apmHighChartPage.navigateToChart().then(function () {
            apmHighChartPage.setChart();
            apmHighChartPage.isChartVisibile().then(function (result) {
                Logger.info("Asserting if chart is visible\n");
                TestHelper.assertTrue(result, 'Chart is not available');
                callback();
            });
        });

    });

    this.Then(/^I should be able to see all the chart's details$/, function (callback) {
        //apmHighChartPage.checkChartPage().then(function () {
        console.log("Header loaded. Proceeding to set chart");
        // Setting the Highchart to retrieve information from it

        console.log("After setting section")
       // apmHighChartPage.getData();


        //expect(wideElement.getText()).toEqual('Three');

        apmHighChartPage.isChartVisibile().then(function (result) {
            var wideElement = element(by.js(function() {
                console.log("yea its me")
                var spans = document.querySelectorAll('span');
                for (var i = 0; i < spans.length; ++i) {
                    if (spans[i].offsetWidth > 100) {
                        return spans[i];
                        console.log("executed")
                    }
                    console.log("executed")
                }
                console.log("executed")
            }));
            Logger.info("Asserting if chart is visible\n");

            // TestHelper.assertTrue(result, 'Chart is not available');

             //Retrieving the X-Axis Labels
            apmHighChartPage.getXAxisLabels().then(function (xlabels) {
                Logger.info('x-axis labels : ' + xlabels + '\n' + 'There are ' + xlabels.length + ' labels');
                console.info('x-axis labels : ' + xlabels + '\n' + 'There are ' + xlabels.length + ' labels');
                // Asserting if there are 4 labels on the X-Axis
                TestHelper.assertEqual(xlabels.length, 4, callback);
                //callback();

            //Retrieving Y-Axis Labels
            apmHighChartPage.getYAxisLabels().then(function (ylabels) {
                Logger.info('y-axis labels : ' + ylabels + '\n' + 'There are ' + ylabels.length + ' labels');
                console.info('y-axis labels : ' + ylabels + '\n' + 'There are ' + ylabels.length + ' labels');

                // Asserting if there are 4 labels on the Y-Axis
                TestHelper.assertEqual(ylabels.length, 1, callback);
                callback();
            });
            });
        });
    });
    // });
};
module.exports = myStepDefinitionsWrapper;
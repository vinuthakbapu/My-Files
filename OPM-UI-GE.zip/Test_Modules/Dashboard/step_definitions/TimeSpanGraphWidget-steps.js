
module.exports = function() {
    // this.setDefaultTimeout(60000);

    this.Then(/^I should see "([^"]*)" label in widget configuration page$/, function (arg1, callback) {
        TimeSpanPage.checkTimeSpanLabel().then(function(Yes){
            console.log("time span label is present: ",Yes);
            callback();
        })
    });
    this.Then(/^I should see TimeSpan DropDown field in widget configuration page$/, function (callback) {
        console.log('check TimeSpan drop down field in Widget configuration page');
        TimeSpanPage.checkTimeSpanDropDown().then(function(dropDownField) {
            console.log("DropDown field is: " + dropDownField);
            callback();
        });
    });
    this.Then(/^I should see "([^"]*)" by default in TimeSpan field in widget configuration page$/, function (arg1, callback) {
        console.log('expected default value is = ' + arg1);
        TimeSpanPage.getTimeSpanDropDownDefaultValue().then(function(actualValueFromList) {
            console.log("actual value = " + actualValueFromList);
            expect(actualValueFromList).to.be.equal(arg1);
            callback();
        });
    });
    this.Then(/^I should see "([^"]*)" in TimeSpan field in widget configuration page$/, function (arg1, callback) {
        console.log('check element of TimeSpan list: ' + arg1);
        TimeSpanPage.checkElementOfTimeSpanDropDownList(arg1).then(function(actualValueFromList) {
            expect(actualValueFromList).to.be.equal(arg1);
            callback();
        });
    });
    this.Then(/^I should see TimeSpan Footer container with all options in widget configuration page$/, function (callback) {
        console.log('check TimeSpan Footer in Widget configuration page');
        TimeSpanPage.checkTimeSpanFooterInEditPage().then(function(footerValue) {
            console.log('Footer value is : ' + footerValue);
            callback();
        });
    });
    this.Then(/^Option "([^"]*)" should be highlighted bold in TimeSpan Footer container in widget configuration page$/, function (arg1, callback) {
        TimeSpanPage.getDefaultValueOfTimeSpanFooterInEditPage().then(function(defaultOptionField) {
            console.log('Selected Footer value on chart is : ' + defaultOptionField);
            expect(defaultOptionField).to.be.equal(arg1);
            callback();
        });
    });
    this.Then(/^I select "([^"]*)" from TimeSpan field in widget configuration page$/, function (option1, callback) {
        //WCP = Widget Configuration Page
        browser.sleep(1000).then(function() {
            TimeSpanPage.clickOnTimeSpanDropDownList().then(function() {
                TimeSpanPage.selectItemFromTimeSpanInWCP(option1).click().then(function() {
                    TimeSpanPage.getTimeSpanDropDownDefaultValue().then(function(selectedValue) {
                        console.log("selected timeSpan value: " + selectedValue);
                        callback();
                    });
                });
            });
        })
    });
    this.Then(/^I should see TimeSpan Footer container with all options in widget in a card$/, function(callback) {
        TimeSpanPage.checkTimeSpanFooterContainerInWidget().then(function(returnedValue) {
            console.log('TimeSpan Footer Container is present: ' + returnedValue);
            callback();
        });
    });
    this.Then(/^Option "([^"]*)" should be highlighted bold in TimeSpan Footer container in widget in a card$/, function(arg1, callback) {
        TimeSpanPage.getDefaultValueInTimeSpanFooterContainerInWidget().then(function(returnedValue) {
            console.log('Bold TimeSpan Footer value: ' + returnedValue);
            expect(returnedValue).to.be.equal(arg1);
            callback();
        });
    });
    this.Then(/^I click on "([^"]*)" option in TimeSpan footer in widget$/, function(arg1, callback) {
        console.log('Clicking on this option on TimeSpan Footer: ' + arg1);
        TimeSpanPage.clickTimeSpanFooterInWidgetPage(arg1).then(function() {
            callback();
        });
    });
    this.Then(/^Option "([^"]*)" should be highlighted bold in TimeSpan Footer container in widget$/, function(arg1, callback) {
        browser.sleep(2000).then(function() {
            TimeSpanPage.getDefaultValueInTimeSpanFooterContainerInWidget().then(function(returnedValue) {
                console.log('Bold TimeSpan Footer value: ' + returnedValue);
                expect(returnedValue).to.be.equal(arg1);
                callback();
            });
        });
    });
    this.Then(/^I should see Data Operation label in widget config page$/, function(callback) {
        TimeSpanPage.getDataOperationLabel().then(function(returnedValue) {
            console.log('Data Operation label is present ' + returnedValue);
            callback();
        });
    });
    this.Then(/^I should see "([^"]*)" option in the data operation dropDown$/, function(arg1, callback) {
        TimeSpanPage.getDataOperationDropDownValue(arg1).then(function(returnedValue) {
            console.log('Data Operation dropDown has this value: ' + returnedValue);
            expect(returnedValue).to.be.equal(true);
            callback();
        });
    });
    this.Then(/^I should see "([^"]*)" as default value in data operation dropDown$/, function(arg1, callback) {
        TimeSpanPage.getDefaultValueFromOperationDropDown().then(function(returnedValue) {
            console.log('Current value of Data Operation dropDown is: ' + returnedValue);
            expect(returnedValue).to.be.equal(arg1);
            callback();
        });
    });
    this.Then(/^I select "([^"]*)" data operation value in widget configuration page$/, function(arg1, callback) {
        //WCP = Widget Configuration Page
        browser.sleep(1000).then(function() {
            TimeSpanPage.clickOnDataOperationDropDownList().then(function() {
                TimeSpanPage.selectItemFromDataOperationInWCP(arg1).click().then(function() {
                    TimeSpanPage.getDefaultValueFromOperationDropDown().then(function(selectedValue) {
                        console.log("selected data operation value: " + selectedValue);
                        callback();
                    });
                });
            });
        })
    });
    this.Then(/^The range of timeSeries on Horizontal axis should reflect the change for "([^"]*)" for "([^"]*)"$/, function(arg1, arg2, callback) {
        var monthArray = ["January","February","March","April","May","June","July","August","September","October","November","December"];
        var monthArrayAbbr = ["Jan","Feb","Mar","Apr","May","Jun","Jul","Aug","Sep","Oct","Nov","Dec"];
        var monthDisplayedWholeText;
        var assertionString = "interactive";
        if (!arg2.includes(assertionString)) {
            if (arg1 === "1H") {
            } else if (arg1 === "1D") {
                callback();
            } else if (arg1 === "1W") {
                callback();
            } else if (arg1 === "1M") {
                callback();
            } else if (arg1 === "3M") {
                    var indexCounter3M = 0;
                    var previousDateIndexValue = -1;
                    var step3 = function (i, done) {
                        if (i < done) {
                            browser.sleep(100).then(function () {
                                TimeSpanPage.getTimeSeriesForXAxis(i).then(function (tempValueOfTimeSeriesOnXAxis3) {
                                    //tempMonth = {Jan, Feb, Mar,...}
                                    //tempDateIndexValue = {0, 1, 2,...}
                                    //var tempMonth = tempValueOfTimeSeriesOnXAxis3.split(" ", 2)[0];
                                    var tempMonth = tempValueOfTimeSeriesOnXAxis3.split(":", 2)[0];
                                    var tempDateIndexValue = monthArrayAbbr.indexOf(tempMonth);
                                    if (tempDateIndexValue === -1) {
                                        //ie., on x-Axis, one of the element is "2017"
                                        console.log("This 3M item on X-axis is not a month: " + tempMonth + ":::" + tempDateIndexValue);
                                        previousDateIndexValue = -1;
                                    } else if (tempDateIndexValue < previousDateIndexValue) {
                                        previousDateIndexValue = tempDateIndexValue;
                                    } else if (tempDateIndexValue > previousDateIndexValue) {
                                        console.log("Month ::: Index = " + tempMonth + ":::" + tempDateIndexValue);
                                        indexCounter3M += 1;
                                        previousDateIndexValue = tempDateIndexValue;
                                    }
                                    if (i === (done - 1)) {
                                        console.log("Number of months listed on X-axis = " + indexCounter3M);
                                        expect(indexCounter3M).to.be.greaterThan(2);
                                        expect(indexCounter3M).to.be.lessThan(5);
                                        callback();
                                    }
                                });
                            });
                            step3(i + 1, done);
                        } else {
                            callback();
                        }
                    }
                    step3(0, 13);
            } else if (arg1 === "6M") {
                    var indexCounter6M = 0;
                    var previousDateIndexValue6M = -1;
                    var step6 = function (i, done) {
                    if (i < done) {
                        monthDisplayedWholeText = false;
                        /* determine if month text is displayed in full (January) or in Abbreviated value (Jan) */
                        if ( i === 0 ) {
                           function testMonth () {
                                var monthIsDisplayedAsWholeText = false;
                                var deferred = protractor.promise.defer();
                                protractor.promise.controlFlow().execute(function () {
                                    var j = i + 1;
                                    var k = i + 4;
                                    browser.sleep(100).then(function () {
                                        TimeSpanPage.getTimeSeriesForXAxis(j).then(function (stTempValueOfTimeSeriesOnXAxis6) {
                                            var tempMonthLen1 = stTempValueOfTimeSeriesOnXAxis6.split(":", 2).length;
                                            browser.sleep(100).then(function () {
                                                TimeSpanPage.getTimeSeriesForXAxis(k).then(function (ndTempValueOfTimeSeriesOnXAxis6) {
                                                    var tempMonthLen2 = ndTempValueOfTimeSeriesOnXAxis6.split(":", 2).length;
                                                    if ((tempMonthLen1 === 1) && (tempMonthLen2 === 1)) {
                                                        monthIsDisplayedAsWholeText = true;
                                                        deferred.fulfill(monthIsDisplayedAsWholeText);
                                                    } else {
                                                        monthIsDisplayedAsWholeText = false;
                                                        deferred.fulfill(monthIsDisplayedAsWholeText);
                                                    }
                                                });
                                            });
                                        });
                                    });
                                });
                                return deferred;
                           };
                           testMonth().then(function(monthDisplayedWholeTextValue) {
                               monthDisplayedWholeText = monthDisplayedWholeTextValue;
                           })
                        }
                        browser.sleep(100).then(function () {
                            TimeSpanPage.getTimeSeriesForXAxis(i).then(function (tempValueElementOnXAxis6M) {
                                //tempMonth = {January, February, March,...}
                                //tempDateIndexValue = {0, 1, 2,...}
                                var tempDateIndexValue;
                                if (monthDisplayedWholeText) {
                                    tempDateIndexValue = monthArray.indexOf(tempValueElementOnXAxis6M);
                                } else {
                                    tempDateIndexValue = monthArrayAbbr.indexOf(tempValueElementOnXAxis6M);
                                }
                                if (tempDateIndexValue === -1) {
                                    //ie., on x-Axis, one of the element is "2017"
                                    previousDateIndexValue6M = -1;
                                    console.log("This 6M item on X-axis is not a month: " + tempValueElementOnXAxis6M + ":::" + tempDateIndexValue);
                                } else if (tempDateIndexValue < previousDateIndexValue6M) {
                                    previousDateIndexValue6M = tempDateIndexValue;
                                } else if (tempDateIndexValue > previousDateIndexValue6M) {
                                    console.log("Month ::: Index = " + tempValueElementOnXAxis6M + ":::" + tempDateIndexValue);
                                    indexCounter6M += 1;
                                    previousDateIndexValue6M = tempDateIndexValue;
                                }
                                if (i === (done - 1)) {
                                    console.log("Number of months listed on X-axis = " + indexCounter6M);
                                    expect(indexCounter6M).to.be.greaterThan(3);
                                    callback();
                                }
                            });
                        });
                        step6(i + 1, done);
                    } else {
                        callback();
                    }}
                step6(0, 6);
            } else if (arg1 === "1Y") {
                var indexCounter = 0;
                var previousIndex = -1;
                var step = function (i, done) {
                if (i < done) {
                    browser.sleep(100).then(function () {
                        TimeSpanPage.getTimeSeriesForXAxis(i).then(function (tempValueOfTimeSeriesOnXAxis) {
                            var currentIndex = monthArray.indexOf(tempValueOfTimeSeriesOnXAxis);
                            if (currentIndex === -1) {
                                //ie., on x-Axis, one of the element is "2017"
                                previousIndex = -1;
                                console.log("This 1Y item on X-axis is not a month: " + tempValueOfTimeSeriesOnXAxis + ":::" + currentIndex);
                                previousIndex = -1;
                            } else if (currentIndex < previousIndex) {
                                previousIndex = currentIndex;
                            } else if (currentIndex > previousIndex) {
                                console.log("Month ::: Index = " + tempValueOfTimeSeriesOnXAxis + ":::" + currentIndex);
                                indexCounter += 1;
                                previousIndex = currentIndex;
                            }
                            if (i === (done - 1)) {
                                console.log("Number of months listed on X-axis = " + indexCounter);
                                expect(indexCounter).to.be.greaterThan(6);
                                callback();
                            }
                        });
                    });
                    step(i + 1, done);
                } else {
                    callback();
                }}
                step(0, 12);
            }
        }
        /************************************************************************************************/
        else {
            if (arg1 === "1H") {
            } else if (arg1 === "1D") {
                callback();
            } else if (arg1 === "1W") {
                callback();
            } else if (arg1 === "1M") {
                callback();
            } else if (arg1 === "3M") {
                    var indexCounter3Mi = 0;
                    var previousDateIndexValue3Mi = -1;
                    var step3i = function (i, done) {
                        if (i < done) {
                            browser.sleep(100).then(function () {
                                TimeSpanPage.getTimeSeriesForXAxisInteractive(i).then(function (tempValueOfTimeSeriesOnXAxis3) {
                                    //tempMonth = {Jan, Feb, Mar,...}
                                    //tempDateIndexValue = {0, 1, 2,...}
                                    var tempMonth = tempValueOfTimeSeriesOnXAxis3.split(" ", 2)[1];
                                    var tempDateIndexValue = monthArrayAbbr.indexOf(tempMonth);
                                    if (tempDateIndexValue === -1) {
                                        //ie., on x-Axis, one of the element is "2017"
                                        console.log("This 3M item on X-axis is not a month: " + tempMonth + ":index:" + tempDateIndexValue);
                                        previousDateIndexValue3Mi = -1;
                                    } else if (tempDateIndexValue < previousDateIndexValue3Mi) {
                                        previousDateIndexValue3Mi = tempDateIndexValue;
                                    } else if (tempDateIndexValue > previousDateIndexValue3Mi) {
                                        console.log(tempMonth + ":index:" + tempDateIndexValue);
                                        indexCounter3Mi += 1;
                                        previousDateIndexValue3Mi = tempDateIndexValue;
                                    }
                                    if (i === (done - 1)) {
                                        console.log("Number of months listed on X-axis = " + indexCounter3Mi);
                                        expect(indexCounter3Mi).to.be.greaterThan(2);
                                        callback();
                                    }
                                });
                            });
                            step3i(i + 1, done);
                        } else {
                            callback();
                        }
                    }
                    step3i(0, 13);
            }
            else if (arg1 === "6M") {
                indexCounter6Mi = 0;
                previousDateIndexValue6Mi = -1;
                var DecToJanCounter = 0;
                var step6i = function (i, done) {
                    if (i < done) {
                        browser.sleep(100).then(function () {
                            TimeSpanPage.getTimeSeriesForXAxisInteractive(i).then(function (tempValueElementOnXAxis6M) {
                                //tempMonth = {Oct, Nov, Mar,...}
                                //tempDateIndexValue = {0, 1, 2,...}
                                var tempMonthValue = tempValueElementOnXAxis6M.split(" ", 2)[1];
                                var tempDateIndexValue = monthArrayAbbr.indexOf(tempMonthValue);
                                if (tempDateIndexValue === -1) {
                                    //ie., on x-Axis, one of the element is "2017"
                                    previousDateIndexValue6M = -1;
                                    console.log("This 6M item on X-axis is not a month: " + tempMonthValue + ":index:" + tempDateIndexValue);
                                } else if ((tempDateIndexValue < previousDateIndexValue6Mi) && (DecToJanCounter === 0)) {
                                    console.log(tempMonthValue + ":index:" + tempDateIndexValue);
                                    indexCounter6Mi += 1;
                                    previousDateIndexValue6Mi = tempDateIndexValue;
                                    DecToJanCounter += 1;
                                } else if (tempDateIndexValue > previousDateIndexValue6Mi) {
                                    console.log(tempMonthValue + ":index:" + tempDateIndexValue);
                                    indexCounter6Mi += 1;
                                    previousDateIndexValue6Mi = tempDateIndexValue;
                                }
                                if (i === (done - 1)) {
                                    console.log("Number of months listed on X-axis = " + indexCounter6Mi);
                                    expect(indexCounter6Mi).to.be.greaterThan(3);
                                    callback();
                                }
                            });
                        });
                        step6i(i + 1, done);
                    } else {
                        callback();
                    }
                }
                step6i(0, 13);
            } else if (arg1 === "1Y") {
                indexCounter = 0;
                previousIndex = -1;
                var step1y = function (i, done) {
                    if (i < done) {
                        browser.sleep(100).then(function () {
                            TimeSpanPage.getTimeSeriesForXAxisInteractive(i).then(function (tempValueOfTimeSeriesOnXAxis) {
                                var tempMonthValue = tempValueOfTimeSeriesOnXAxis.split(" ", 2)[0];
                                var currentIndex = monthArrayAbbr.indexOf(tempMonthValue);
                                if (currentIndex === -1) {
                                    //ie., on x-Axis, one of the element is "2017"
                                    console.log("This 1Y item on X-axis is not a month: " + tempMonthValue + ":index:" + currentIndex);
                                    previousIndex = -1;
                                } else if (currentIndex < previousIndex) {
                                    previousIndex = currentIndex;
                                } else if (currentIndex > previousIndex) {
                                    console.log(tempMonthValue + ":index:" + currentIndex);
                                    indexCounter += 1;
                                    previousIndex = currentIndex;
                                }
                                if (i === (done - 1)) {
                                    console.log("Number of months listed on X-axis = " + indexCounter);
                                    expect(indexCounter).to.be.greaterThan(6);
                                    callback();
                                }
                            });
                        });
                        step1y(i + 1, done);
                    } else {
                        callback();
                    }
                }
                step1y(0, 12);
            }
        }
    });

};

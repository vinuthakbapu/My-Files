/**
 * Created by 212677088 on 9/17/2018.
 */
module.exports = function () {
    var delay = 12000;
    var util = require("util");
    var data = require('../TestData/OPMAPIEndpoints.json').data.env[browser.params.environment];
    var results;
    var histCount = [];
    var errCount = [];
    var countArray =[];

    this.Given(/^I run timeseries4 fetch query for (.*) with (.*) and (.*) to get (.*)$/, function (params, startTime, endTime, op, callback) {
        var tagNames;
        var URL;
        if(params === "controllerConfiguration"){
            URL = data.fetchQuery.controllerurl;
            tagNames = data[params];
        }else{
            URL = data.fetchQuery.url;
            tagNames = data[params];
        }
        console.log("tagnames-->" + tagNames);
        var startTime = new Date();
        startTime.setDate(startTime.getDate()-1);
        startTime = startTime.toISOString().split('T')[0];
        startTime = startTime + 'T00:00:00Z';
        console.log('startTime-->',startTime);
        var endTime = new Date();
        endTime.setDate(endTime.getDate()-2);
        endTime = endTime.toISOString().split('T')[0];
        endTime = endTime + 'T00:00:00Z';
        console.log('endTime-->',endTime);

        var URL = util.format(URL, op, tagNames, endTime, startTime);
        console.log("URL-->" + URL);
        multiForecastRestPO.getQueryResults(URL).then(function (serviceData) {
            results = serviceData;
            callback();
        });
    });

    this.Given(/^I verify the Manipulated variable header name$/, function (callback) {
        loopDashboardPO.getElement('manipulatedVariable').getText().then(function (val) {
            console.log("manipulatedVariable Title:" + val);
            TestHelper.assertEqual(val, 'Manipulated Variable [%]');
            callback();
        });
    });
    this.Then(/^I verify the Total and Average MV header name$/, function (callback) {
        loopDashboardPO.getElement('totalMV').getText().then(function (val) {
            console.log("totalMV Title:" + val);
            TestHelper.assertEqual(val, 'Total MV Movement | Average MV Change [%]');
            callback();
        });
    });
    this.Then(/^I verify the Oscillation count and amplitude header name$/, function (callback) {
        loopDashboardPO.getElement('mvOscillation').getText().then(function (val) {
            console.log("mvOscillation Title:" + val);
            TestHelper.assertEqual(val, 'MV Oscillation Count [#] | Average oscillation amplitude [%]');
            callback();
        });
    });
    this.Then(/^I verify the MV saturation header name$/, function (callback) {
        loopDashboardPO.getElement('mvSaturation').getText().then(function (val) {
            console.log("mvSaturation Title:" + val);
            TestHelper.assertEqual(val, 'MV Saturation [%]');
            callback();
        });
    });
    this.Then(/^I verify the Duration not utilized header name$/, function (callback) {
        loopDashboardPO.getElement('durationNot').getText().then(function (val) {
            console.log("durationNot Title:" + val);
            TestHelper.assertEqual(val, 'Duration Not Utilized [%]');
            callback();
        });
    });
    this.Given(/^I verify Manipulated variable value$/, function (callback) {
        loopDashboardPO.getElement('manipulatedVariableVal').getText().then(function (val) {
            console.log("manipulatedVariableVal Value:" + val);
            var expectedVal = 0;
            results.forEach(function (obj) {
                if (obj.tagId === "Loop1.Percentage Controller Output") {
                    console.log("postman value-->" + obj.data[0].v);
                    expectedVal = parseFloat(obj.data[0].v, 10);
                    expectedVal = loopDashboardPO.roundDecimalPoints(expectedVal);
                }
            });
            console.log('expectedVal:' + expectedVal);
            TestHelper.assertEqual(parseFloat(val, 10), expectedVal);
            callback();
        });
    });
    this.Then(/^I verify MV Total and Average value$/, function (callback) {
        loopDashboardPO.getElement('totalMVval').getText().then(function (val) {
            console.log("totalMode Value:" + val);
            var movementIndex, controlAmp, expectedVal;
            results.forEach(function (obj) {
                if (obj.tagId === "Loop1.Movement Index") {
                    if (0 != Object.keys(obj.data).length) {
                        console.log("postman value-->" + obj.data[0].v);
                        movementIndex = parseFloat(obj.data[0].v, 10);
                        movementIndex = loopDashboardPO.roundDecimalPoints(movementIndex);
                        console.log('movementIndex:' + movementIndex);
                    } else
                        movementIndex = '';
                } else if (obj.tagId === "Loop1.Control Amplitude") {
                    if (0 != Object.keys(obj.data).length) {
                        console.log("postman value-->" + obj.data[0].v);
                        controlAmp = parseFloat(obj.data[0].v, 10);
                        controlAmp = loopDashboardPO.roundDecimalPoints(controlAmp);
                        console.log('controlAmp:' + controlAmp);
                    } else
                        controlAmp = ' ';
                }
            });
            expectedVal = movementIndex + ' | ' + controlAmp;
            console.log('expectedVal:' + expectedVal);
            TestHelper.assertEqual(val, expectedVal);
            callback();
        });
    });
    this.Then(/^I verify Oscillation count and average value$/, function (callback) {
        loopDashboardPO.getElement('mvOscillationval').getText().then(function (val) {
            console.log("mvOscillationval Value:" + val);
            var reversalAmp, mvOscillation, expectedVal;
            results.forEach(function (obj) {
                if (obj.tagId === "Loop1.Reversal Amplitude") {
                    if (0 != Object.keys(obj.data).length) {
                        console.log("postman value-->" + obj.data[0].v);
                        reversalAmp = parseFloat(obj.data[0].v, 10);
                        reversalAmp = loopDashboardPO.roundDecimalPoints(reversalAmp);
                        console.log('reversalAmp:' + reversalAmp);
                    } else
                        reversalAmp = ' ';
                } else if (obj.tagId === "Loop1.MV Oscillation Count") {
                    if (0 != Object.keys(obj.data).length) {
                        console.log("postman value-->" + obj.data[0].v);
                        mvOscillation = parseFloat(obj.data[0].v, 10);
                        mvOscillation = loopDashboardPO.roundDecimalPoints(mvOscillation);
                        console.log('mvOscillation:' + mvOscillation);
                    } else
                        mvOscillation = '';
                }
            });
            expectedVal = mvOscillation + '| ' + reversalAmp;
            console.log('expectedVal:' + expectedVal);
            TestHelper.assertEqual(val.trim(), expectedVal);
            callback();
        });
    });
    this.Then(/^I verify MV saturation value$/, function (callback) {
        loopDashboardPO.getElement('mvSaturationval').getText().then(function (val) {
            console.log("mvSaturationval Value:" + val);
            var expectedVal = 0;
            results.forEach(function (obj) {
                if (obj.tagId === "Loop1.Percentage MV Saturation") {
                    if (0 != Object.keys(obj.data).length) {
                        console.log("postman value-->" + obj.data[0].v);
                        expectedVal = parseFloat(obj.data[0].v, 10);
                        expectedVal = loopDashboardPO.roundDecimalPoints(expectedVal);
                    }
                }
            });
            console.log('expectedVal:' + expectedVal);
            TestHelper.assertEqual(parseFloat(val, 10), expectedVal);
            callback();
        });
    });
    this.Then(/^I verify Duration not utilized value$/, function (callback) {
        loopDashboardPO.getElement('durationNotval').getText().then(function (val) {
            console.log("durationNotval Value:" + val);
            var expectedVal = 0;
            results.forEach(function (obj) {
                if (obj.tagId === "Loop1.Percentage Not Utlized") {
                    console.log("postman value-->" + obj.data[0].v);
                    expectedVal = parseFloat(obj.data[0].v, 10);
                    expectedVal = loopDashboardPO.roundDecimalPoints(expectedVal);
                }
            });
            console.log('expectedVal:' + expectedVal);
            TestHelper.assertEqual(parseFloat(val, 10), expectedVal);
            callback();
        });
    });
};
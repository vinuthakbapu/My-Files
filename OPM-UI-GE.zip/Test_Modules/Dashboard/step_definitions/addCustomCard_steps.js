/**
 * Created by 212340705 on May 4th 2016.
 */

module.exports = function() {
    // this.setDefaultTimeout(60000);
    var currentpage = 'DashboardAppPages';

    this.Then(/^I should see thumbnail image for custom card in card library$/, function ( callback) {
        console.log('verify custom card thumbnail is present in card library page');
        browser.sleep(5000);
        customcardpage.getCustomCardThumbnail().isPresent().then(function(present){
                expect(present).to.equal(true);
                console.log('custom card thumbnail is present on card library page');
                callback();
            });
    });
    this.Then(/^I should see add button for custom card in card library$/, function ( callback) {
        console.log('verify add button for custom card is present in card library page');
        customcardpage.getCustomcardAddBtn().then(function(present){
                expect(present).to.equal(true);
                console.log('add button for custom card is present on card library page');
                callback();
            });
    });
    this.Then(/^I should see preview button for custom card in card library$/, function ( callback) {
        console.log('verify preview button for custom card is present in card library page');
        customcardpage.getCustomcardPreviewBtn().isPresent().then(function(present){
                expect(present).to.equal(true);
                console.log('preview button for custom card is present on card library page');
                callback();
            });
    });
    this.Then(/^click on preview button for custom card$/, function (callback) {
        console.log('about to click on preview button for custom card');
        customcardpage.getCustomCardThumbnail().isPresent().then(function(present) {
            expect(present).to.equal(true);
            customcardpage.getCustomcardPreviewBtn().click().then(function () {
                console.log('clicked on preview button for custom card');
                callback();
            });
        });
    });
    this.Then(/^click on card thumbnail for custom card$/, function (callback) {
        console.log('about to click on thumbnail image for custom card in card library');

        customcardpage.getCustomCardThumbnail().isPresent().then(function(present){
                expect(present).to.equal(true);
                customcardpage.getCustomCardThumbnail().click().then(function(){
                    console.log('custom card thumbnail image is clicked on card library page');
                    callback();
                });
            });
    });

    this.When(/^create a new dashboard "([^"]*)" with custom card$/, function (name, callback) {
        console.log('About to create a new dashboard named: ' + name + ' with a custom card');
        var today = new Date();
        var curdate = (today.getMonth()+1)+'/'+today.getDate();
        customcardpage.createDashboardWithCustomCard(curdate+name).then(function(){
            console.log('added a new dashboard : ' + name + ' with a custom card');
            callback();
        });
    });

    this.When(/^I should see "([^"]*)" plus signs for adding a vertical and horizontal tiles$/, function (num,callback) {
        console.log('verify '+ num + ' plus sign buttons are visible on custom card to add Row and Column tiles');
        var tile1 = customcardpage.getTile1InRow1();
        browser.actions().mouseMove(tile1).perform().then(function(){
            browser.sleep(2000);
            console.log('mouseover done: ');
            customcardpage.getAllAddTilePlusSign().count().then(function(cnt){
                expect(cnt).to.equal(Number(num));
                console.log('expected number of plus signs: ' + num + ' Actual number of plus signs displayed:  ' + cnt );
                callback();
            });
        });
    });

    this.When(/^I should not see a plus sign button to add vertical tile when 3 tiles exist already$/, function (callback) {
        console.log('verify no plus sign buttons are visible on custom card to add Row and Column tiles when 3 tiles exist');
        var tile3 = customcardpage.getTile3InRow1();
        browser.actions().mouseMove(tile3).perform().then(function(){
            //browser.sleep(2000);
            console.log('mouseover done: ');
            customcardpage.getVerticalTilePlusSign().isDisplayed()
                .then(function(present){
                    expect(present).to.equal(false);
                    console.log('plus sign is not displayed' );
                    callback();
                });
        });
    });

    this.Then(/^the widget with title "([^"]*)" is added to Custom card$/, function (widgetTitle, callback) {
        console.log('Verifying widget ' + widgetTitle + ' is added to the custom card');
        customcardpage.getWidgetTitleOnCard(widgetTitle).then(function(present){
            expect(present).to.equal(true);
            callback();
        });
    });

    this.When(/^I should see total "([^"]*)" widget tiles in edit mode$/, function (num,callback) {
        console.log('verify total number of widget tiles on the card: ' + num );
        customcardpage.getAllTileCountInEditMode()
            .then(function(cnt){
                expect(cnt).to.equal(Number(num));
                console.log('expected number of widget tiles on the card: ' + num + ' Actual number of widget tiles on the card:  ' + cnt );
                callback();
            });
    });
    this.When(/^I should see total "([^"]*)" widget tiles in save mode$/, function (num,callback) {
        console.log('verify total number of widget tiles on the card: ' + num );
        customcardpage.getAllTileCountInSaveMode()
            .then(function(cnt){
                expect(cnt).to.equal(Number(num));
                console.log('expected number of widget tiles on the card: ' + num + ' Actual number of widget tiles on the card:  ' + cnt );
                callback();
            });
    });
    this.When(/^I add a vertical tile to a new custom card$/, function (callback) {
        console.log('about to add first vertical tile to a new custom card');
        var tile1 = customcardpage.getTile1InRow1();
        browser.actions().mouseMove(tile1).perform().then(function(){
            //browser.sleep(3000);
            console.log('mouseover done: ');
            customcardpage.getVerticalTilePlusSign().click()
                .then(function(){
                    console.log('clicked on plus sign to add vertical tile' );
                    callback();
                });
        });
    });
    this.When(/^I add another vertical tile to a card with two existing tiles$/, function (callback) {
        console.log('about to add another vertical tile to a card with two existing tiles');
        var tile2 = customcardpage.getTile2InRow1();
        browser.actions().mouseMove(tile2).perform().then(function(){
            //browser.sleep(2000);
            console.log('mouseover done: ');
            customcardpage.getAllAddTilePlusSign().get(0).click()
                .then(function () {
                    console.log('clicked on plus sign to add second vertical tile');
                    callback();
                });
        });
    });
    this.When(/^I click on "([^"]*)" plus sign to add a horizontal tile$/, function (num, callback) {
        console.log('about to add horizontal/row tile to a custom card');
        var tile2 = customcardpage.getTile2InRow1();
        browser.actions().mouseMove(tile2).perform().then(function(){
            customcardpage.getAddTilePlusSignCount().then(function(cnt){
                customcardpage.getAllAddTilePlusSign().get(cnt-1).click().then(function(){
                    console.log('clicked on horizontal plus sign to add a new row tile: ');
                    callback();
                });
            });
        });
    });
    this.When(/^I click on last plus sign to add a horizontal tile$/, function (callback) {
        console.log('about to add horizontal/row tile to a custom card');
        var tile2 = customcardpage.getTile2InRow1();
        browser.actions().mouseMove(tile2).perform().then(function(){
            customcardpage.getAddTilePlusSignCount().then(function(cnt){
                customcardpage.getAllAddTilePlusSign().get(cnt-1).click().then(function(){
                    console.log('clicked on last plus sign to add a new row tile ');
                    callback();
                });
            });
        });
    });

    this.Then(/^I should see Widget Library page$/, function ( callback) {
        console.log('verify widget library page opens up');
        customcardpage.getWidgetLibraryPageHeader()
            .then(function(present){
                expect(present).to.equal(true);
                console.log('Widget Library page opened up');
                callback();
            });
    });
    this.Then(/^I should see Cancel button on widget library page$/, function ( callback) {
        console.log('verify Cancel button on widget library page');
        customcardpage.getCancelBtnWidgetLibrary()
            .then(function(present){
                expect(present).to.equal(true);
                console.log('Cancel button on widget library page is present');
                callback();
            });
    });
    this.Then(/^I should see Back button on widget library page$/, function ( callback) {
        console.log('verify Back button on widget library page');
        customcardpage.getBackBtnWidgetLibrary()
            .then(function(present){
                expect(present).to.equal(true);
                console.log('Back button on widget library page is present');
                callback();
            });
    });
    this.Then(/^I should see Widget Container with all the widgets on widget library page$/, function ( callback) {
        console.log('verify Widget Container with all the widgets on widget library page is present');
        customcardpage.getWidgetContainerWidgetLibrary().then(function(present){
                console.log('Widget Container with all the widgets on widget library page is present: ', present);
                expect(present).to.equal(true);
                callback();
            });
    });
    this.Then(/^I should see "([^"]*)" addwidget button to navigate to widget library page$/, function (num, callback) {
        console.log('about to click on add widget button number: ' + num );
        addcardpage.getAddWidgetButton(Number(num)-1).then(function(){
            console.log('clicked on add widget button number: ' + num );
            callback();
        });
    });
    this.Then(/^I click on "([^"]*)" addwidget button to navigate to widget library page$/, function (num, callback) {
        console.log('about to click on add widget button number: ' + num );
        addcardpage.clickAddWidgetButton(Number(num)-1).then(function(){
            console.log('clicked on add widget button number: ' + num );
            browser.sleep(2000).then(function(){
                callback();
            });
        });
    });
    this.Then(/^I click on back button on widget library page$/, function ( callback) {
        console.log('about to click on Back button on widget library page');
        customcardpage.clickBackBtnWidgetLibrary()
            .then(function(){
                //browser.sleep(1000);
                console.log('Clicked Back button on widget library page');
                callback();
            });
    });
    this.When(/^I should see more than "([^"]*)" "([^"]*)" on widget library page$/, function (num, elements, callback) {
        console.log('verify total number of ' + elements + ' on widget library page is > ' + num );
        var WidLibEle;
        switch (elements){
            case "AddButtons":
                WidLibEle = customcardpage.getAddButtonWidgetLib();
                break;
            case "ThumbImages":
                WidLibEle = customcardpage.GetThumbImageWidgetLib();
                break;
            case "WidgetTitles":
                WidLibEle = customcardpage.GetThumbTitleWidgetLib();
                break;
            case "WidgetDescriptions":
                WidLibEle = customcardpage.GetDescriptionWidgetLib();
                break;
        }
        WidLibEle.count()
            .then(function(cnt){
                expect(cnt).to.above(Number(num));
                console.log('Expected number of '+ elements + ' should be > ' + num + ' Actual number:  ' + cnt );
                callback();
            });
    });

    this.When(/^widget number "([^"]*)" title should be "([^"]*)"$/, function (num, title, callback) {
        console.log('verify the title of the widget number ' + num + '  is : ' + title );
        customcardpage.GetThumbTitleWidgetLib().get(Number(num)-1).getText()
            .then(function(txt){
                expect(txt).to.equal(title);
                console.log('The title of the widget number ' + num + '  is : ' + title);
                callback();
            });
    });
    this.When(/^widget number "([^"]*)" description should be "([^"]*)"$/, function (num, desc, callback) {
        console.log('verify the description of the widget number ' + num + '  is : ' + desc );
        customcardpage.GetDescriptionWidgetLib().get(Number(num)-1).getText()
            .then(function(txt){
                expect(txt).to.equal(desc);
                console.log('The description of the widget number ' + num + '  is : ' + desc);
                callback();
            });
    });
    this.Then(/^I click on add button number "([^"]*)" on widget library page to add "([^"]*)"$/, function (num, widget, callback) {
        console.log('about to click on add widget button' );
        customcardpage.clickAddButtonWidgetLib(widget.trim()).then(function(){
            console.log('clickAddButtonWidgetLib for ' + widget);
            browser.sleep(4000).then(function(){
                callback();
            });
            // expect(element(by.css(widget)).isPresent()).to.eventually.be.eql(true).notify(callback);

        });
    });

    this.Then(/^I click on add button in widget library for "([^"]*)" using widget title$/, function ( widgetTitle, callback) {
        console.log('about to click on add widget button:'+widgetTitle );
        customcardpage.clickAddBtnInWidgetLib(widgetTitle.trim()).then(function(){
            console.log('clickAddButtonWidgetLib for ' + widgetTitle);
            browser.sleep(4000).then(function(){
                callback();
            });
        });
    });

    this.Then(/^I click on save button on custom card page$/, function ( callback) {
        console.log('about to click on Save button on custom card page');
        browser.sleep(2000).then(function() {
        customcardpage.clickCustomcardSaveBtn().then(function() {
            console.log('Clicked Save button on custom card page');
            callback();
        });
        });
    });

    this.Then(/^the widget "([^"]*)" is added to Custom card$/, function (widgetTitle, callback) {
        console.log('Verifying widget ' + widgetTitle + ' is added to the custom card');
        customcardpage.getWidgetOnCard(widgetTitle).then(function(present){
            expect(present).to.equal(true);
            callback();
        });
    });


    this.Then(/^the current widget "([^"]*)" is added to Custom card$/, function (widgetTitle, callback) {
        console.log('Verifying widget title ' + widgetTitle + ' is added to the custom card');
        customcardpage.getCurrentWidgetOnCard(widgetTitle).then(function(present){
            expect(present).to.equal(true);
            callback();
        });
    });


    this.Then(/^the KPI widget "([^"]*)" is added to Custom card$/, function (widgetTitle, callback) {
        console.log('Verifying widget title ' + widgetTitle + ' is added to the custom card');
        customcardpage.getKPIWidgetOnCard(widgetTitle).then(function(present){
            expect(present).to.equal(true);
            callback();
        });
    });


    this.Then(/^I check to verify the added widget header is "([^"]*)"$/, function (widgetTitle, callback) {
        console.log('Verifying widget ' + widgetTitle + ' is added to the custom card');
        customcardpage.getWidgetOnCard(widgetTitle).then(function(present){
            expect(present).to.equal(true);
            callback();
        });
    });

    this.Then(/^I add a generic interactive graph widget$/, function ( callback) {
        console.log('about to click on generic interactive graph widget ');
        customcardpage.clickAddButtonWidgetLib('graph-widget-interactive').then(function(){
            console.log('clicked on add widget on interactive widget' );
            callback();
        });
    });

    this.Then(/^I should STOP$/, function (callback) {
        browser.pause();
    });

    this.Then(/^I should see title "([^"]*)" in widget library page$/, function (widgetTitle, callback) {
        console.log('Verifying widget title ' + widgetTitle + ' is displayed in widget library page');
        customcardpage.getWidgetInWidgetLib(widgetTitle).then(function(present){
            console.log("Widget Title is present " + widgetTitle);
            expect(present).to.equal(true);
            callback();
        });
    });

    this.Then(/^I should see image "([^"]*)" in widget library page$/, function (widgetImage, callback) {
        console.log('Verifying widget ' + widgetImage + ' image is displayed in widget library page');
        customcardpage.getWidgetImageInWidgetLib(widgetImage).then(function(){
            console.log("Widget Image is present");
            browser.sleep(4000).then(function(){
                callback();
            });
        });
    });

    this.Then(/^The connected status icon should be displayed$/, function (callback) {
        console.log('Verifying connected status icon is displayed');
        customcardpage.getHMIstatusIcon().then(function(present){
            expect(present).to.equal(true);
            callback();
        });
    });

    this.Then(/^I should see HMI Widget Canvas in the widget tile$/, function (callback) {
        console.log('Verifying HMI Widget Canvas is displayed');
        customcardpage.getHMICanvas().then(function(present){
            expect(present).to.equal(true);
            callback();
        });
    });

};


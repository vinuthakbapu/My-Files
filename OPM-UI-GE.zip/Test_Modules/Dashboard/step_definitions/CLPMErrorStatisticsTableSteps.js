/**
 * Created by 212677088 on 9/17/2018.
 */
module.exports = function () {
    var delay = 12000;
    var util = require("util");
    var data = require('../TestData/OPMAPIEndpoints.json').data.env[browser.params.environment];
    var results;
    var histCount = [];
    var errCount = [];
    var countArray =[];

    this.Given(/^I run timeseries6 fetch query for (.*) with (.*) and (.*) to get (.*)$/, function (params, startTime, endTime, op, callback) {
        var tagNames;
        var URL;
        if(params === "controllerConfiguration"){
            URL = data.fetchQuery.controllerurl;
            tagNames = data[params];
        }else{
            URL = data.fetchQuery.url;
            tagNames = data[params];
        }
        console.log("tagnames-->" + tagNames);
        var startTime = new Date();
        startTime.setDate(startTime.getDate()-1);
        startTime = startTime.toISOString().split('T')[0];
        startTime = startTime + 'T00:00:00Z';
        console.log('startTime-->',startTime);
        var endTime = new Date();
        endTime.setDate(endTime.getDate()-2);
        endTime = endTime.toISOString().split('T')[0];
        endTime = endTime + 'T00:00:00Z';
        console.log('endTime-->',endTime);

        var URL = util.format(URL, op, tagNames, endTime, startTime);
        console.log("URL-->" + URL);
        multiForecastRestPO.getQueryResults(URL).then(function (serviceData) {
            results = serviceData;
            callback();
        });
    });

    this.Given(/^I verify the Integrated Error header name$/, function (callback) {
        loopDashboardPO.getElement('integratedError').getText().then(function (val) {
            console.log("integratedError Title:" + val);
            TestHelper.assertEqual(val, 'Integrated Error');
            callback();
        });
    });
    this.Then(/^I verify the Avearage Error header name$/, function (callback) {
        loopDashboardPO.getElement('averageError').getText().then(function (val) {
            console.log("averageError Title:" + val);
            TestHelper.assertEqual(val, 'Average Error');
            callback();
        });
    });
    this.Then(/^I verify the Avearge Absolute Error header name$/, function (callback) {
        loopDashboardPO.getElement('absoluteError').getText().then(function (val) {
            console.log("absoluteError Title:" + val);
            TestHelper.assertEqual(val, 'Average Absolute Error');
            callback();
        });
    });
    this.Then(/^I verify the PV Error Standard deviation header name$/, function (callback) {
        loopDashboardPO.getElement('errorStandard').getText().then(function (val) {
            console.log("errorStandard Title:" + val);
            TestHelper.assertEqual(val, 'PV Error Standard Deviation');
            callback();
        });
    });
    this.Given(/^I verify Integrated Error value$/, function (callback) {
        loopDashboardPO.getElement('integratedErrorval').getText().then(function (val) {
            console.log("integratedErrorval Value:" + val);
            var expectedVal = 0;
            results.forEach(function (obj) {
                if (obj.tagId === "Loop1.Integrated Sum") {
                    console.log("postman value-->" + obj.data[0].v);
                    expectedVal = parseFloat(obj.data[0].v, 10);
                    expectedVal = loopDashboardPO.roundDecimalPoints(expectedVal);
                }
            });
            console.log('expectedVal:' + expectedVal);
            TestHelper.assertEqual(parseFloat(val, 10), expectedVal);
            callback();
        });
    });
    this.Then(/^I verify Avearage Error value$/, function (callback) {
        loopDashboardPO.getElement('averageErrorval').getText().then(function (val) {
            console.log("averageErrorval Value:" + val);
            var expectedVal = 0;
            results.forEach(function (obj) {
                if (obj.tagId === "Loop1.PV Error Average") {
                    console.log("postman value-->" + obj.data[0].v);
                    expectedVal = parseFloat(obj.data[0].v, 10);
                    expectedVal = loopDashboardPO.roundDecimalPoints(expectedVal);
                }
            });
            console.log('expectedVal:' + expectedVal);
            TestHelper.assertEqual(parseFloat(val, 10), expectedVal);
            callback();
        });
    });
    this.Then(/^I verify Avearage Absolute Error value$/, function (callback) {
        loopDashboardPO.getElement('absoluteErrorval').getText().then(function (val) {
            console.log("absoluteErrorval Value:" + val);
            var expectedVal = 0;
            results.forEach(function (obj) {
                if (obj.tagId === "Loop1.PV Error Absolute Average") {
                    console.log("postman value-->" + obj.data[0].v);
                    expectedVal = parseFloat(obj.data[0].v, 10);
                    expectedVal = loopDashboardPO.roundDecimalPoints(expectedVal);
                }
            });
            console.log('expectedVal:' + expectedVal);
            TestHelper.assertEqual(parseFloat(val, 10), expectedVal);
            callback();
        });
    });
    this.Then(/^I verify PV Error Standard deviation value$/, function (callback) {
        loopDashboardPO.getElement('errorStandardval').getText().then(function (val) {
            console.log("errorStandardval Value:" + val);
            var expectedVal = 0;
            results.forEach(function (obj) {
                if (obj.tagId === "Loop1.PV Error Standard Deviation") {
                    console.log("postman value-->" + obj.data[0].v);
                    expectedVal = parseFloat(obj.data[0].v, 10);
                    expectedVal = loopDashboardPO.roundDecimalPoints(expectedVal);
                }
            });
            console.log('expectedVal:' + expectedVal);
            TestHelper.assertEqual(parseFloat(val, 10), expectedVal);
            callback();
        });
    });
};
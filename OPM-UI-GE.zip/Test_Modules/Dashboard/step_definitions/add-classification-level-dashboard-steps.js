/**
 * Created by 502661197 on 9/2/16.
 */

var currentpage = 'DashboardAppPages';
module.exports = function() {
    // this.setDefaultTimeout(60000);

    this.Then(/^I check class selection chevron is present$/, function (callback) {
        createviewpage.checkClassSelectionChevron().then(function(yes){
            console.log('classification selection chevron is present: ', yes);
            expect(yes).to.equal(true);
            callback();
        });
    });

    this.Then(/^I should not see class selection chevron/, function (callback) {
        createviewpage.checkClassSelectionChevron().then(function(yes){
            console.log('classification selection chevron is present: ', yes);
            expect(yes).to.equal(false);
            callback();
        });
    });

    this.Then(/^I click on chevron to open class selection menu$/, function (callback) {
        createviewpage.clickClassSelectionChevron().then(function(){
            console.log('clicked classification selection chevron');
            createviewpage.getClassificationDropdown().then(function(present){
                expect(present).to.equal(true);
                console.log('classification selection dropdown is present', present);
                callback();
            });
        });
    });

    this.Then(/^I should see "([^"]*)" "([^"]*)" in the class menu$/, function (arg1, arg2, callback) {
        console.log('check the '+ arg1 + ' : '+ arg2 + ' is displayed in class selection menu');
        createviewpage.getNameFromClassmenu(arg1).then(function(name){
            console.log('Actual: '+ name + ', Expected: ' + arg2);
            var isNameMatching = name.indexOf(arg2) !== -1;
            expect(isNameMatching).to.equal(true);
            callback();
        });
    });

    this.Then(/^I select classification name "([^"]*)" from class menu$/, function (arg1, callback) {
        createviewpage.selectClassificationName().then(function(){
            console.log('clicked on '+ arg1 + ' to select it');
            callback();
        });
    });

    this.Then(/^I check to see "([^"]*)" "([^"]*)" selected$/, function (arg1, arg2, callback) {
        console.log('check the '+ arg1 + ' : '+ arg2 + ' is showing as selected.');
        createviewpage.getSelectedClassificationValue().then(function(selectedname){
            console.log('Actual: '+ selectedname + ', Expected: ' + arg2);
            var isSelectedMatching = selectedname.indexOf(arg2) !== -1;
            expect(isSelectedMatching).to.equal(true);
            console.log(arg1 + ' : ' + selectedname + ' is selected');
            callback();
        });
    });

    this.When(/^create a new class dashboard "([^"]*)" with custom card$/, function (name, callback) {
        console.log('About to create a new class dashboard named: ' + name + ' with a custom card');
        createviewpage.createClassDashboardWithCard(name).then(function(){
                console.log('added a new class dashboard : ' + name + ' with a custom card');
                callback();
            });
    });


    this.Given(/^I should click on set as default dashboard link in dashboard menu$/, function (callback) {
        console.log("about to click to set as default dashboard");
        createviewpage.clickCardActionMenuBtn().then(function () {
            console.log("clicked on card action menu button");
            dem.findElement(currentpage, 'dropdown').getAttribute('hidden').then(function(visible){
                if(visible) {
                    console.log("card action menu popup is open");
                    addcardpage.clickSetDefaultDashboardLink().then(function () {
                        console.log("clicked on set as default dashboard link");
                        callback();
                    });
                }
            })
        });
    });

        this.Given(/^I should see a check mark displayed next to set as default dashboard option in dashboard menu$/, function (callback) {
            createviewpage.clickCardActionMenuBtn().then(function () {
                console.log("clicked on card action menu button");
                dem.findElement(currentpage, 'dropdown').getAttribute('hidden').then(function(visible){
                    if(visible) {
                        console.log("card action menu popup is open : " + visible);
                        createviewpage.chkSetDefaultDashboardCheck().then(function (present) {
                            expect(present).to.equal(true);
                            console.log("check mark is displayed next to set as default dashboard option :" + present);
                            callback();
                        });
                    }
                })
            });
        });

    this.Given(/^I should see default dashboard "([^"]*)" is opened$/, function (dbname, callback) {
        console.log("about to check selected dashboard is :" + dbname);
        browser.sleep(10000).then(function() {
            createviewpage.getSelectedDashboardName().then(function (txt) {
                expect(txt).to.equal(dbname);
                console.log('expected view name: ' + dbname + ', Actual view name: ' + txt);
                callback();
            });
        });
    });

    this.Given(/^I should see default dashboard "([^"]*)" is listed on the top$/, function (dbname, callback) {
        console.log('about to verify top listed dashboard name in view selector dropdown is :' + dbname);
        createviewpage.chkViewSelectorDropdown().then(function(yeah) {
            console.log('view selector present: ' + yeah);
            if(yeah){
                createviewpage.clickViewSelectorDropdown().then(function() {
                    createviewpage.getFirstDashboardInDeck().then(function (txt) {
                        expect(txt).to.equal(dbname);
                        console.log('expected view name: ' + dbname + ', Actual view name: ' + txt);
                        callback();
                    });
                });
            }
        });
    });

    this.Given(/^I should click on set as default dashboard link once again in dashboard menu to uncheck$/, function (callback) {
        console.log("about to click to set as default dashboard");
        createviewpage.clickCardActionMenuBtn().then(function () {
            console.log("clicked on card action menu button");
            dem.findElement(currentpage, 'dropdown').getAttribute('hidden').then(function(visible){
                if(visible) {
                    console.log("card action menu popup is open");
                    addcardpage.clickSetDefaultDashboardLink().then(function () {
                        console.log("clicked on set as default dashboard link to uncheck");
                        callback();
                    });
                }
            })
        });
    });

    this.Given(/^I should not see the check next to set as default dashboard in dashboard menu$/, function (callback) {
        createviewpage.clickCardActionMenuBtn().then(function () {
            console.log("clicked on card action menu button");
            dem.findElement(currentpage, 'dropdown').getAttribute('hidden').then(function(visible){
                if(visible) {
                    console.log("card action menu popup is open : " + visible);
                    // createviewpage.chkSetDefaultDashboardNotCheck().then(function (present) {
                    //     expect(present).to.equal(false);
                    //     console.log("check mark is not displayed next to set as default dashboard option :" + present);
                    //     callback();
                    // })

                    element.all(by.css('#viewMenuList #makeDefault i.fa-check')).then(function(items) {
                        if(items.length > 0) {
                            console.log("check mark is displayed next to set as default dashboard option :" + items.length);
                            callback();
                        }else{
                            console.log("check mark is not displayed next to set as default dashboard option :" + items.length);
                            callback();
                        }
                    });

                }
            })
        });
    });




//  //CardWidgetInteractivity-TimeControl.feature steps :


    this.Then(/^I click on Time Control link in edit card menu$/, function (callback) {
        console.log('about to click on Time Control link');
        addcardpage.chkEditCardMenuDropdownOpen().then(function(visible) {
            if (visible) {
                addcardpage.clickTimeControlLink().then(function () {
                    console.log('clicked on Time Control link');
                    callback();
                });
            } else {
                addcardpage.clickEditCardMenu().then(function() {
                    console.log('again clicked on edit card menu');
                    addcardpage.chkEditCardMenuDropdownOpen().then(function (visible) {
                        if (visible) {
                            addcardpage.clickTimeControlLink().then(function () {
                                console.log('clicked on Time Control link');
                                callback();
                            });
                        }
                    });
                });
            }
        });
    });

    this.Then(/^I should see the check mark next to time control option in edit card menu$/, function (callback) {
        console.log('about to check, check mark is present next to time control link');
        addcardpage.clickEditCardMenu().then(function(){
            console.log('clicked on edit card menu');
            addcardpage.chkEditCardMenuDropdownOpen().then(function(visible) {
                if (visible) {
                    console.log("edit card menu popup is open : " + visible);
                    addcardpage.chkTimeControlCheckmark().then(function (present) {
                        expect(present).to.equal(true);
                        console.log("check mark is displayed next to time control link :" + present);
                        callback();
                    });
                }
            });
        });
    });

    this.Then(/^I should see Time Control Menu on the card$/, function (callback) {
        console.log('about to check, Time Control Menu is present on card');
        addcardpage.chkTimeControl().isPresent().then(function (present) {
            expect(present).to.equal(true);
            console.log("Time Control Menu is displayed on card :" + present);
            callback();
        });
    });

    this.Then(/^I should see Resume button on time control banner$/, function (callback) {
        console.log('about to check, Resume button present on Time Control');
        addcardpage.chkTimeControlResumeButton().then(function (present) {
            expect(present).to.equal(true);
            console.log("Resume button is displayed on Time Control :" + present);
            callback();
        });
    });

    this.Then(/^I should see Date Selector drop down menu$/, function (callback) {
        console.log('about to check, Date Selector drop down present on Time Control');
        addcardpage.chkDateSelectorChevron().then(function (present) {
            expect(present).to.equal(true);
            console.log("Date Selector Chevron is displayed on Time Control :" + present);
            callback();
        });
    });

    this.Then(/^I click on Date Selector drop down menu$/, function (callback) {
        console.log('about to click on Date Selector chevron');
        browser.sleep(5000);
        addcardpage.clickDateSelectorChevron().then(function(){
            console.log('clicked on Date Selector drop down chevron');
            addcardpage.chkDateSelectorDropdownOpen().then(function(visible) {
                if(visible){
                    console.log('Date Selector drop down is open : ' + visible);
                    callback();
                }else{
                    browser.sleep(5000);
                    console.log('Date Selector drop down is Not open : ' + visible);
                    addcardpage.clickDateSelectorChevron().then(function(){
                        console.log('clicked again on Date Selector drop down chevron');
                        callback();
                    });
                }


            });
        });
    });

    this.Then(/^I should see "([^"]*)" option$/, function (option, callback) {
        console.log('about to check Date Selector drop down is open');
        addcardpage.chkDateSelectorDropdownOpen().then(function(visible){
            expect(visible).to.equal(true);
            console.log('Date Selector drop down is open : ' + visible);
            console.log('About to check "' + option + '" option is present in Date Selector drop down');
            addcardpage.getDateSelectorOptions(option).isPresent().then(function(present){
                expect(present).to.equal(true);
                console.log(option + ' option is present in Date Selector drop down : ' + present);
                callback();
            });
        });
    });

    this.Then(/^I select "([^"]*)" option from time control drop down menu$/, function (option, callback) {
        console.log('about to check Date Selector drop down is open');
        addcardpage.chkDateSelectorDropdownOpen().then(function(visible){
            expect(visible).to.equal(true);
            console.log('Date Selector drop down is open : ' + visible);
            console.log('About to click "' + option + '" option in Date Selector drop down');
            addcardpage.getDateSelectorOptions(option).click().then(function(){
                console.log('Clicked on ' + option + ' option in Date Selector drop down');
                callback();
            });
        });
    });

    this.Then(/^I should see date time field$/, function (callback) {
        console.log('about to check Date-time fields are present on Time Control banner ');
       // browser.pause()
        addcardpage.chkDateSelectorDateTimeFields().then(function(visible){
            expect(visible).to.equal(true);
            console.log('Date-time fields are present on Time Control banner : ' + visible);
            callback();
        });
    });

    this.Then(/^I should see 2 date time fields on the time control banner$/, function (callback) {
        console.log('about to check 2 date-time fields are present on Time Control banner ');
        addcardpage.chkDateSelectorDateTimeFields().then(function(visible){
            expect(visible).to.equal(true);
            console.log(' From date-time fields are present on Time Control banner : ' + visible);
                addcardpage.chkDateSelectorDateTimeToFields().then(function(present) {
                    expect(present).to.equal(true);
                    console.log(' To date-time fields are present on Time Control banner : ' + present);
                    callback();
                });
        });
    });

    var getFormatedToday = function () {
        var today = new Date();
        // var dd = today.getDate();
        // var mm = today.getMonth()+1; //January is 0!
        // var yyyy = today.getFullYear();

        var dd = today.getUTCDate();
        var mm = today.getUTCMonth()+1; //January is 0!
        var yyyy = today.getUTCFullYear();

        if(dd<10){
            dd='0'+dd
        }
        if(mm<10){
            mm='0'+mm
        }
        return today = mm+'/'+dd+'/'+yyyy;
    };
    var getFormatedTimestamp = function () {
        var today = new Date();

        var hh = today.getUTCHours();
        var mm = today.getUTCMinutes();
        var ss = today.getUTCSeconds();

        return today = hh+':'+mm+':'+ss;
    };

    this.Then(/^Date time field should display current system time$/, function (callback) {
        console.log('about to check Date time field display current system date ');

        element.all(by.css(".text-input--bare.apm-field")).then(function(ele){
            ele[0].getAttribute('value').then(function (value) {
                console.log("Calendar value : " + value);
                var today = getFormatedToday();
                console.log("Today's date : " + today);
                if(value == today){
                    console.log('Date time field display current system date ');
                    callback();
                }
            });
        });
    });

    this.Then(/^I should see current time stamp is displayed in UTC$/, function (callback) {
        console.log('about to check current time stamp is displayed');
        console.log('time stamp: ' + getFormatedTimestamp());
        addcardpage.chkDateTimePickerTimestamp().then(function(visible){
            expect(visible).to.equal(true);
            console.log('current time stamp is displayed : ' + visible);
            callback();
        });
    });
    this.Then(/^I click on date time field from time control banner$/, function (callback) {
        console.log('about to click on Date-time fields');
        addcardpage.clickDateSelectorDateTimeFields().then(function(){
            console.log('clicked on Date-time fields');
            callback();
        });
    });

    this.Then(/^I should see calendar object opened$/, function (callback) {
        console.log('about to check calendar object opened');
        addcardpage.chkDateSelectorDateTimePicker().then(function(visible){
            expect(visible).to.equal(true);
            console.log('calendar object opened : ' + visible);
            callback();
        });
    });

    this.Then(/^I should see range calendar object opened$/, function (callback) {
        console.log('about to check range calendar object opened');
        addcardpage.chkCustomDateTimePicker().then(function(visible){
            expect(visible).to.equal(true);
            console.log('range calendar object opened : ' + visible);
            callback();
        });
    });

    this.Then(/^I should see current day is selected$/, function (callback) {
        console.log('about to check current day');
        addcardpage.getDateTimePickerSelectedToday().isPresent().then(function(present){
            if(present){
                console.log('day is selected');
                addcardpage.getDateTimePickerSelectedToday().getText().then(function(today) {
                    var currentDay = new Date().getUTCDate();
                    console.log('Today : ' + today + ',  Day : ' + currentDay);
                    if(today == currentDay){
                        console.log('current day '+ today +' is selected');
                        callback();
                    }
                });
            }
        });
    });

    this.Then(/^I should see yesterday's date is selected in calendar$/, function (callback) {
        console.log('about to check yesterdays date is selected in calendar');
        addcardpage.getDateTimePickerSelectedDay().isPresent().then(function(present){
            if(present){
                console.log('day is selected');
                addcardpage.getDateTimePickerSelectedDay().getText().then(function(today) {
                    var yesterday = (new Date().getUTCDate()) - 1;
                    console.log('Today : ' + today + ',  Day : ' + yesterday);
                    if(today == yesterday){
                        console.log('current day '+ today +' is selected');
                        callback();
                    }
                });
            }
        });
    });

    this.Then(/^I should see Cancel button on calendar object$/, function (callback) {
        console.log('about to check Cancel button present on calendar object');
        addcardpage.chkDateTimePickerCancelBtn().then(function(visible){
            expect(visible).to.equal(true);
            console.log('Cancel button present on calendar object : ' + visible);
            callback();
        });
    });

    this.Then(/^I should see Apply button on calendar object$/, function (callback) {
        console.log('about to check Apply button present on calendar object');
        addcardpage.chkDateTimePickerApplyBtn().then(function(visible){
            expect(visible).to.equal(true);
            console.log('Apply button present on calendar object : ' + visible);
            callback();
        });
    });

    this.Then(/^I click on Apply button on calendar object$/, function (callback) {
        console.log('about to click on Apply button on calendar object');
        addcardpage.clickDateTimePickerApplyBtn().then(function(){
            console.log('clicked on Apply button on calendar object');
            callback();
        });
    });

    this.Then(/^I click on Apply button on range calendar object$/, function (callback) {
        console.log('about to click on Apply button on range calendar object');
        addcardpage.clickCustomPickerApplyBtn().then(function(){
            console.log('clicked on Apply button on range calendar object');
            callback();
        });
    });

    this.Then(/^I click on resume button on time control banner$/, function (callback) {
        console.log('about to click on resume button on time control banner');
        addcardpage.clickTimeControlResumeButton().then(function(){
            console.log('clicked on resume button on time control banner');
            callback();
        });
    });

    this.Then(/^I should see transparent overlay on "([^"]*)"$/, function (widgetID, callback) {
        console.log('about to check transparent overlay on widget ' + widgetID);
        addcardpage.getWidgetOverlayWidgetByID(widgetID).then(function(visible){
            if(visible) {
                console.log('transparent overlay on widget at ' + widgetID + ' is present : ' + visible);
                callback();
            } else {
                console.log('transparent overlay on widget at '+ widgetID +' is not present : ' + visible);
                callback();
            }
        });
    });

    this.Then(/^Time control banner should go away$/, function (callback) {
        console.log('about to check, Time Control Menu is not present on card');
        addcardpage.chkTimeControl().getAttribute().then(function (present) {
            console.log("Time Control banner go away :" + present);
            if(present == null) {
                console.log("Time Control banner gone away ");
                callback();
            }
        });
    });

    this.Then(/^transparent overlay should go away from all static widgets$/, function (callback) {
        console.log('about to check transparent overlay on widgets');
        element.all(by.css('.overlay-widget.custom-card')).then(function (overlays) {
            console.log('overlays : ' + overlays.length);
            if(overlays.length <= 0) {
                console.log('no overlays' + overlays);
                callback();
            }
        });
    });

    this.Then(/^select date which is current date minus (\d+) days$/, function (daysBefore, callback) {
        var setDay = (new Date().getUTCDate()) - daysBefore;
        console.log('current day : '+ new Date().getUTCDate()) ;
        console.log('set day : ' + setDay);

        addcardpage.getDayBeforeToday(setDay).isPresent().then(function (present) {
            console.log("element present : " + present);
            addcardpage.getDayBeforeToday(setDay).click().then(function () {
                console.log('Clicked on day : ' + setDay);
                callback();
            });
        });
    });

    // this.Then(/^select date which is current date minus (\d+) days$/, function (daysBefore, callback) {
    //     var setDay = (new Date().getUTCDate()) - daysBefore;
    //     TestHelperPO.isElementPresent(element.all(by.css(".apm-calendar-cell > button")).get(0)).then(function(){
    //     element.all(by.css(".apm-calendar-cell > button")).then(function(elements){
    //     element.all(by.css(".apm-calendar-cell > button")).then(function(elements){
    //         var j;
    //         var getElement = function(el){
    //             // console.log(el);
    //             el.getAttribute('value').then(function(value){
    //
    //                 if (value*1 == setDay){
    //                     console.log("calendar value " + value);
    //                     el.click();
    //                     console.log('Day : ' + setDay);
    //                     callback();
    //                 }
    //             });
    //         }
    //         for(j= 0; j < elements.length; j++){
    //             getElement(elements[j]);
    //         }
    //     });
    //     })
    // });

    this.Then(/^I should verify time series data displayed for selected dates$/, function (callback) {
        var today = new Date().getUTCDate();
        var arr, arrLength, firstEl, lastEl, firstDate, lastDate, rawStDate, rawEndDate, stDateNum, endDateNum;
        console.log('Today : ' + today);
        // Timestamp, Tagname, needVerify, startx, starty, endx, rollrange, rolldirection
        // startx, starty, endx, index_data, rollrange, rolldirection
        createviewpage.getChartFile(358, 420, 887, '', 0, "up").then(function(data){
            arr = data.split("\n");
            console.log("date Array " +arr);
            arrLength = arr.length;
            console.log("length "+ arrLength);
            firstEl = arr[0];
            console.log('firstEl '+ firstEl);
            lastEl = arr[arrLength -2];
            console.log("lastEl "+lastEl);

            firstDate = firstEl.split(",")[0];
            console.log('firstDate '+ firstDate);
            rawStDate = firstDate.split(" | ")[1];
            console.log('rawStDate ' + rawStDate);
            stDateNum = rawStDate.split(" ")[0];
            console.log("stDateNum " +stDateNum);

            lastDate = lastEl.split(",")[0];
            console.log("lastDate " +lastDate);
            rawEndDate = lastDate.split(" | ")[1];
            console.log("rawEndDate " + rawEndDate);
            endDateNum = rawEndDate.split(" ")[0];
            console.log("endDateNum "+endDateNum);

            if(endDateNum - stDateNum == 7){
                console.log("7 days varified");
                callback();
            }
        });
    });

    this.Then(/^I click on refresh data option from dashboard menu$/, function (callback) {
        console.log('about to click on refresh data link');
        createviewpage.clickCardActionMenuBtn().then(function () {
            console.log("clicked on card action menu button");
            dem.findElement(currentpage, 'dropdown').getAttribute('hidden').then(function(visible){
                if(visible) {
                    console.log("card action menu popup is open : " + visible);
                    element(by.css('#viewMenuList #refreshDashboard')).click().then(function(){
                        console.log('clicked on refresh data link from dashboard menu');
                        callback();
                    });
                }
            })
        });
    });

    this.Then(/^I should see time span option "([^"]*)" on time control banner$/, function (timespan, callback) {
        console.log('About to check date time span "' + timespan + '" option is present on time control banner');
        addcardpage.getDateTimeSpanByText(timespan).isPresent().then(function(present){
            expect(present).to.equal(true);
            console.log(timespan + ' option is present on time control banner : ' + present);
            callback();
        });
    });

    this.Then(/^I click on time span option "([^"]*)" on time control banner$/, function (timespan, callback) {
        console.log('About to click "' + timespan + '" option on time control banner');
        addcardpage.getDateTimeSpanByText(timespan).click().then(function(){
            console.log('Clicked on ' + timespan + ' option on time control banner');
            callback();
        });
    });

    this.Then(/^I should see PRESETS menu next to the calendar object$/, function (callback) {
        console.log('About to check PRESETS menu next to the calendar object');
        addcardpage.chkPresets().then(function(present){
            expect(present).to.equal(true);
            console.log( 'PRESETS menu is present next to the calendar object : ' + present);
            callback();
        });
    });

    this.Then(/^I should see "([^"]*)" in PRESETS menu$/, function (option, callback) {
        console.log('About to check "' + option + '" in PRESETS menu');
        addcardpage.getPresetsOption(option).isPresent().then(function (present){
            expect(present).to.equal(true);
            console.log(option + 'is present in PRESETS menu :' + present);
            callback();
        });
    });

    this.Then(/^I click on "([^"]*)" in PRESETS menu$/, function (option, callback) {
        console.log('About to click "' + option + '" in PRESETS menu');
        addcardpage.getPresetsOption(option).click().then(function(){
            console.log('Clicked on ' + option + ' in PRESETS menu');
            callback();
        });
    });

    this.Then(/^Then I should see the time series chart plotted for one day only$/, function (callback) {
        console.log('About to check time series chart plotted for one day only');

            callback();
    });

};
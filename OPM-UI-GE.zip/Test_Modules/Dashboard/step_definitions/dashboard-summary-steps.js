var currentpage = 'DashboardAppPages';
var dash_cnt = 0;
var name = "";

module.exports = function() {
    // this.setDefaultTimeout(60000);

    this.Given(/^Dashboard Summary toggle button should be displayed in select classification banner$/, function (callback) {
        dashboardSummaryPage.chkDashboardSummaryToggle().then(function (present) {
            console.log('dashboard summary toggle is present: '+ present);
            expect(true).to.equal(present);
            callback();
        });
    });
    this.Given(/^I click on Dashboard summary toggle button$/, function (callback) {
        dashboardSummaryPage.clickDashboardSummaryToggle().then(function(yeah){
            console.log('clicked on dashboard summary toggle: ' + yeah);
            expect(true).to.equal(yeah);
            callback();
        });
    });
    this.Given(/^Dashboard summary toggle should be off$/, function (callback) {
        dashboardSummaryPage.chkDashboardSummaryToggleChk().then(function (check) {
            console.log('dashboard summary toggle is selected: '+ check);
            expect(false).to.equal(check);
            callback();
        });
    });
    this.Given(/^wait for (\d+) milliseconds$/, function (num, callback) {
        browser.sleep(Number(num)).then(function(){
            console.log('waiting ........');
            callback();
        });
    });
    this.Given(/^Dashboard summary toggle should be ON$/, function (callback) {
        console.log('able to check the toggle state');
        dashboardSummaryPage.chkDashboardSummaryToggleChk().then(function (check) {
            console.log('dashboard summary toggle is selected: '+ check);
            expect(true).to.equal(check);
            callback();
        });
    });

    this.Given(/^check the dashboard summary label is displayed next to toggle button$/, function (callback) {
        dashboardSummaryPage.chkDashboardSummaryLabel().then(function (present) {
            console.log('dashboard summary label is displayed: '+ present);
            expect(present).to.equal(true);
            if(present){
                dashboardSummaryPage.getDashboardSummaryLabelTxt().then(function(name){
                    console.log('dashboard summary card label: ' + name);
                    expect(name).to.equal('Dashboard Summary');
                    callback();
                })
            }
        });
    });
    this.Given(/^I should see dashboard summary card section displayed on top of the dashboard$/, function (callback) {
        dashboardSummaryPage.chkDashboardSummaryCard().then(function (present) {
            console.log('dashboard summary card section displayed on top of the dashboard: '+ present);
            expect(present).to.equal(true);
            callback();
        });
    });
    this.Given(/^I should not see dashboard summary card section displayed on top of the dashboard$/, function (callback) {
        console.log('Checking dashboard summary card section is not be displayed on top of the dashboard ');
        dashboardSummaryPage.chkDashboardSummaryCard().then(function (present) {
            console.log('dashboard summary card section displayed on top of the dashboard: '+ present);
            expect(present).to.equal(false);
            callback();
        });
    });
    this.Given(/^I should see configure dashboard summary button displayed in the middle of the summary card section$/, function (callback) {
        dashboardSummaryPage.chkConfigureDashboardSummaryButton().then(function (present) {
            console.log('configure dashboard summary button displayed: '+ present);
            expect(present).to.equal(true);
            callback();
        });
    });
    this.Given(/^I click on configure dashboard summary button displayed in the middle of the summary card section$/, function (callback) {
        dashboardSummaryPage.clickConfigureDashboardSummaryButton().then(function (yeah) {
            console.log('clicked on dashboard summary Card: '+ yeah);
            callback();
        });
    });
    this.Given(/^I should see Configure Dashboard Summary option in dashboard kebab menu enabled$/, function (callback) {
        dashboardSummaryPage.IsEnabledConfigureDashboardLink().then(function (yeah) {
            console.log('Configure Summary option in dashboard kebab menu is enabled: '+ yeah);
            expect(yeah).to.equal(true);
            callback();
        });
    });
    this.Given(/^I should see Configure Dashboard Summary option in dashboard kebab menu$/, function (callback) {
        dashboardSummaryPage.chkConfigureDashboardLink().then(function (present) {
            console.log('Configure Summary option in dashboard kebab menu: '+ present);
            expect(present).to.equal(true);
            callback();
        });
    });
    this.Given(/^I should see Configure Dashboard Summary option disabled in dashboard kebab menu$/, function (callback) {
        dashboardSummaryPage.chkConfigureDashboardDisabled().then(function (present) {
            console.log('Configure Summary option in dashboard kebab menu is disabled: '+ present);
            expect(present).to.equal(true);
            callback();
        });
    });
    this.Given(/^I check dashboard summary card is in edit mode$/, function (callback) {
        dashboardSummaryPage.ChkSumryCardInEditMode().then(function (present) {
            console.log('check dashboard summary card is in edit mode: '+ present);
            expect(present).to.equal(true);
            callback();
        });
    });
    this.Given(/^I click on Configure Dashboard Summary option in dashboard kebab menu$/, function (callback) {
        dashboardSummaryPage.clickConfigureDashboardLink().then(function (yes) {
            console.log('click on Configure Dashboard Summary option in dashboard kebab menu: '+ yes);
            expect(yes).to.equal(true);
            browser.sleep(5000).then(function(){callback();});
        });
    });

    this.Given(/^I should see (\d+) tiles displayed in summary card section$/, function (widTiles, callback) {
        dashboardSummaryPage.chkNumberofTilesInSummaryCard().then(function (tiles) {
            console.log('tiles displayed in summary card section: ' + tiles);
            expect(Number(tiles)).to.equal(Number(widTiles));
            callback();
        });
    });
    this.Given(/^I should see (\d+) add widget buttons in summary card section$/, function (widBtns, callback) {
        dashboardSummaryPage.chkAddWidgetButtonsInSummaryCard().then(function (buttons) {
            console.log('Add widget buttons displayed in summary card section: ' + buttons);
            expect(Number(buttons)).to.equal(Number(widBtns));
            callback();
        });
    });
    this.Given(/^There should be (\d+) delete icons on summary card widgets$/, function (dltIcns, callback) {
        dashboardSummaryPage.getSumryDltWidgetIconCount().then(function (icons) {
            console.log('delete icons on summary card widgets: ' + icons);
            expect(Number(icons)).to.equal(Number(dltIcns));
            callback();
        });
    });
    this.Given(/^I click on delete widget icon number (\d+) in summary card$/, function (num, callback) {
        console.log('about to mouse over the widget tile to click on delete widget icon');
        browser.actions().mouseMove(dashboardSummaryPage.getSumryCardInnerTile(Number(num)-1)).perform().then(function(){
            console.log('mouse move done on delete widget x icon');
            dashboardSummaryPage.clickSumryDltWidgetIcon(Number(num)-1).then(function () {
                console.log('clicked on delete widget icon number: ' + num);
                callback();
            });
        });
    });
    this.Given(/^There should be (\d+) edit icons on summary card widgets$/, function (dltIcns, callback) {
        dashboardSummaryPage.getSumryEditWidgetIconCount().then(function (icons) {
            console.log('edit icons on summary card widgets: ' + icons);
            expect(Number(icons)).to.equal(Number(dltIcns));
            callback();
        });
    });
    this.Given(/^There should be (\d+) footer messages on summary card widgets$/, function (msgs, callback) {
        dashboardSummaryPage.getSumryFooterMsgCount().then(function (cnt) {
            console.log('footer messages on summary card widgets: ' + cnt);
            expect(Number(cnt)).to.equal(Number(msgs));
            callback();
        });
    });
    this.Given(/^I should see (\d+) widget holders with widgets in summary card$/, function (wdgts, callback) {
        dashboardSummaryPage.getWidgetsCountInSummaryCard().then(function (cnt) {
            console.log('widget holders with widgets in summary card: ' + cnt);
            expect(Number(cnt)).to.equal(Number(wdgts));
            callback();
        });
    });
    this.Given(/^check footer message (\d+) should say "([^"]*)" in summary card$/, function (num, msg, callback) {
        dashboardSummaryPage.getSumryCardFooterText(Number(num)-1).then(function (message) {
            console.log('summary card footer message number: ' + num + ' says: ' + message );
            expect(msg.trim()).to.equal(message.trim());
            callback();
        });
    });
    this.Given(/^I click on edit widget icon number (\d+) in summary card$/, function (num, callback) {
        console.log('about to mouse over the widget tile to click on edit widget icon');
        browser.actions().mouseMove(dashboardSummaryPage.getSumryCardInnerTile(Number(num)-1)).perform().then(function(){
            dashboardSummaryPage.clickSumryEditWidgetIcon(Number(num)-1).then(function () {
                console.log('clicked on edit widget icon number: ' + num);
                callback();
            });
        });
    });
    this.Given(/^I should see plus sign to add more tiles to the summary card$/, function ( callback) {

        browser.actions().mouseMove(dashboardSummaryPage.getSummaryCardLandingSection()).perform().then(function(){
            console.log('mouse over on landing section is done. going to look for plus sign now');
            browser.sleep(2000).then(function(){
                dashboardSummaryPage.ChkSumryCardAddTilePlusSign().then(function(yeah){
                    console.log('Plus sign is displayed on dashboard summary card: ' + yeah);
                    expect(yeah).to.equal(true);
                    callback();
                })
            })

        });
    });
    this.Given(/^I should not see plus sign to add more tiles to the summary card$/, function ( callback) {

        browser.actions().mouseMove(dashboardSummaryPage.getSummaryCardLandingSection()).perform().then(function(){
            console.log('mouse over on landing section is done. I should not see the plus sign now');
            browser.sleep(2000).then(function(){
                dashboardSummaryPage.ChkSumryCardAddTilePlusSign().then(function(yeah){
                    console.log('Plus sign is present on dashboard summary card: ' + yeah);
                    expect(yeah).to.equal(false);
                    callback();
                });
            })
        });
    });
    this.When(/^I click on plus sign in dashboard summary card$/, function (callback){
        browser.actions().mouseMove(dashboardSummaryPage.getSummaryCardLandingSection()).perform().then(function(){
            console.log('mouse over on landing section is done. going to look for plus sign now');
            browser.sleep(1000).then(function(){
                dashboardSummaryPage.clickSumryCardAddTilePlusSign().then(function(){
                    console.log('clicked on plus sign ');
                    callback();
                });
            });
        });
    });
    this.Given(/^I should see Cancel button in summary card section$/, function ( callback) {
        dashboardSummaryPage.chkSumryCardCancelButton().then(function(yeah){
            console.log('Cancel button in summary card section: ' + yeah);
            expect(yeah).to.equal(true);
            callback();
        });
    });
    this.Given(/^I should see Save button in summary card section$/, function ( callback) {
        dashboardSummaryPage.chkSumryCardSaveButton().then(function(yeah){
            console.log('Save button in summary card section: ' + yeah);
            expect(yeah).to.equal(true);
            callback();
        });
    });
    this.Given(/^I click on Cancel button in summary card section$/, function ( callback) {
        dashboardSummaryPage.clickSumryCardCancelButton().then(function(yeah){
            console.log('Clicked on Cancel button in summary card: ' + yeah);
            expect(yeah).to.equal(true);
            callback();
        });
    });
    this.Given(/^I click on Save button in summary card section$/, function ( callback) {
        dashboardSummaryPage.clickSumryCardSaveButton().then(function(yeah){
            console.log('Clicked on Save button in summary card: ' + yeah);
            expect(yeah).to.equal(true);
            callback();
        });
    });
    this.Given(/^I click on add widget button number (\d+) in summary card section$/, function (num, callback) {
        dashboardSummaryPage.clickSumyAddWidgetBtn(Number(num)-1).then(function(yeah){
            console.log('Clicked on add widget button number ' + num + ' : ' + yeah);
            expect(yeah).to.equal(true);
            callback();
        });
    });
    this.Given(/^I should see (\d+) widget thumbnail images displayed in widget library$/, function (num, callback) {
        customcardpage.GetThumbImageWidgetLib().count().then(function(tncount) {
            console.log('ThumbNail Count is: ' + tncount );
            expect(tncount).to.equal(Number(num));
            callback();
        });
    });
    this.Given(/^I should see (\d+) widget description fields displayed in widget library$/, function (num, callback) {
        customcardpage.GetDescriptionWidgetLib().count().then(function(DescriptionCount) {
            console.log('Widget Description Count is: ' + DescriptionCount );
            expect(DescriptionCount).to.equal(Number(num));
            callback();
        });
    });
    this.Given(/^I should see (\d+) widget titles displayed in widget library$/, function (num, callback) {
        customcardpage.GetThumbTitleWidgetLib().count().then(function(titleCount) {
            console.log('Widget Title Count is: ' + titleCount );
            expect(titleCount).to.equal(Number(num));
            callback();
        });
    });
    this.Given(/^Widget (\d+) title should be "([^"]*)"$/, function (index, title, callback) {
        customcardpage.GetThumbTitleWidgetLib().get(Number(index)-1).getText().then(function(titleName){
            console.log('Title as displayed on UI is ' + titleName);
            expect(titleName).to.equal(title);
            callback();
        });
    });
    this.Given(/^I should see (\d+) add widget button displayed in widget library$/, function (numOfAddButton, callback) {
        customcardpage.getAddButtonWidgetLib().count().then(function(count){
            expect(count).to.equal(Number(numOfAddButton));
            callback();
        });
    });

};

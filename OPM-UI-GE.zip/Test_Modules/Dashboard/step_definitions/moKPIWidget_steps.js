/**
 * Created by 212329933 on Oct 19th 2016.
 */
var data = require('../TestData/mo-dashboard-test-data.json').data;

var myStepDefinitionsWrapper = function () {
	this.Then(/^KPI widget is added to Custom card$/, function (callback) {
		console.log('Verifying widget "KPI" is added to the custom card');
		moKWPage.getXaxisLabel().then(function (title) {
			expect(title).to.equal('');
			callback();
		});
	});

	this.Then(/^I should see SETTINGS label$/, function (callback) {
		console.log('Verifying SETTINGS label in Widget Configure page');
		moKWPage.getSettingsLabel().isPresent().then(function (present) {
			expect(present).to.equal(true);
			console.log('SETTINGS label is present');
			callback();
		});
	});

	this.Then(/^I should see KPI Line Chart label$/, function (callback) {
		console.log('Verifying KPI Line Chart label in Widget Configure page');
		moKWPage.getKPILineChartLabel().isPresent().then(function (present) {
			expect(present).to.equal(true);
			console.log('KPI Line Chart label is present');
			callback();
		});
	});

	this.Then(/^I should see KPI Title label$/, function (callback) {
		console.log('Verifying KPI Title label in Widget Configure page');
		moKWPage.getKPITitleLabel().isPresent().then(function (present) {
			expect(present).to.equal(true);
			console.log('KPI Title label is present');
			callback();
		});
	});

	this.Then(/^I should see Options in KPI type dropdown$/, function (expectedOptionsList, callback) {
		var expectctedOptions = expectedOptionsList.hashes();
		browser.sleep(3000);
		moKWPage.getOptionsList().then(function (options) {
			console.log('UI options : '+JSON.stringify(options));
			console.log('');
			expect(options).to.deep.equal(expectctedOptions);
			callback();
		});
	});

	this.Given(/^I select "([^"]*)" from KPI type dropdown in Configure Widget page$/, function (kpi, callback) {

		browser.sleep(5000);
		moKWPage.selectKPI(kpi).then(function () {
			moKWPage.getSelectedKPI().then(function (selectedKPI) {
				expect(kpi).to.equal(selectedKPI);
				callback();
			});
		});
	});

	this.Then(/^I should see header "([^"]*)" in Configure Widget page$/, function (header, callback) {
		browser.sleep(25000);
		moKWPage.getConfigureWidgetHeader().then(function (expectedHeader) {
			expect(header).to.equal(expectedHeader);
			callback();
		});
	});

	this.Then(/^I should see chart in Configure Widget page$/, function (callback) {
		moKWPage.isChartVisible().then(function (present) {
			console.log('chart present : '+present);
			expect(present).to.equal(true);
			callback();
		});
	});

	this.Then(/^I should see header "([^"]*)" in Custom Card in Dashboard page$/, function (header, callback) {
		browser.sleep(5000);
		moKWPage.getWidgetHeaderCustom(header).then(function (expectedHeader) {
			expect(header).to.equal(expectedHeader);
			callback();
		});
	});

	this.Then(/^I should see chart in Custom Card in Dashboard page$/, function (callback) {
		moKWPage.isChartVisible().then(function (present) {
			console.log('chart present : '+present);
			expect(present).to.equal(true);
			callback();
		});
	});
};

module.exports = myStepDefinitionsWrapper;
/**
 * Created by 212340705 on Aug 31st 2017.
 */
module.exports = function() {

    this.Then(/^I should see the Tag Tree Panel$/, function (callback) {
        console.log('Verify I should see the Tag Tree Panel is present');
        TagTreePage.TagTreePage().then(function(present) {
            expect(present).to.equal(true);
            console.log('I should see the Tag Tree Panel is present: '+ present);
            callback();
        });
    });
    this.Then(/^I should see the Tag Tree Tag Browser Panel$/, function (callback) {
        console.log('Verify the Tag Tree Tag Browser Panel is present');
        TagTreePage.checkTagTreeTagBrowserPanel().then(function(present) {
            expect(present).to.equal(true);
            console.log('Tag Tree Tag Browser Panel is present: '+ present);
            callback();
        });
    });
    this.Then(/^I should see the Tag Tree Plotted Tags Panel$/, function (callback) {
        console.log('Verify the Tag Tree Tag Browser Panel is present');
        TagTreePage.checkTagTreePlottedTagsPanel().then(function(present) {
            expect(present).to.equal(true);
            console.log('Tag Tree Plotted Tags Panel is present: '+ present);
            callback();
        });
    });
    this.Then(/^I should see Data label for configuring tags$/, function (callback) {
        console.log('Verify the Data section is present');
        TagTreePage.checkDataLabelConfig().then(function(visible) {
            expect(visible).to.equal(true);
            console.log('Data Label section is present');
            callback();
        });
    });
    this.Then(/^I should see a plus sign to navigate to tag tree panel to configure tags to the widget$/, function (callback) {
        console.log('Verify plus sign to navigate to tag tree panel is present');
        TagTreePage.checkPlusSignTagTree().then(function(visible) {
            expect(visible).to.equal(true);
            console.log('Plus sign to navigate to tag tree panel is present');
            callback();
        });
    });
    this.Then(/^I click on plus sign in widget configuration page to navigate to tag tree panel$/, function (callback) {
        console.log('Click on plus sign to navigate to tag tree panel');
        TagTreePage.checkPlusSignTagTree().then(function(visible) {
            if(visible) {
                console.log("Plus sign to navigate to tag tree panel is present");
                TagTreePage.clickPlusSignTagTree().then(function () {
                    console.log("clicked on Plus sign to navigate to tag tree panel");
                    callback();
                });
            } else {
                console.log("Plus sign not present");
                expect(1).to.equal(0);
                callback();
            }
        });
    });
    this.Then(/^I should see a PlotTag link displayed in top left corner of the tag tree panel$/, function (callback) {
        console.log('Verify there is a PlotTag link at the top corner present');
        TagTreePage.checkPlotTagLink().then(function(visible) {
            expect(visible).to.equal(true);
            console.log('PlotTag link at the top corner is present');
            callback();
        });
    });
    this.Then(/^I should see a Search input field on the top of the tag tree panel$/, function (callback) {
        console.log('Verify there is a Search input field on the top of the tag tree panel');
        TagTreePage.checkSearchInputField().then(function(visible) {
            expect(visible).to.equal(true);
            console.log('Search input field on the top of the tag tree panel is present');
            callback();
        });
    });
    this.Then(/^I should see a Tag Browser title for top section in tag tree panel$/, function (callback) {
        console.log('Verify there is a Tag Browser title for top section in tag tree panel$');
        TagTreePage.checkTagBrowserTitle().then(function(visible) {
            expect(visible).to.equal(true);
            console.log('Tag Browser title for top section is present');
            callback();
        });
    });
    this.Then(/^I should see a plus sign to add secondary assets to the tag tree$/, function (callback) {
        console.log('Verify there is a plus sign to add secondary assets to the tag tree');
        TagTreePage.checkPlusSignAddAssets().then(function(visible) {
            expect(visible).to.equal(true);
            console.log('Plus sign to add secondary assets to the tag tree is present');
            callback();
        });
    });
    this.Then(/^I should see a Plotted Tags title for bottom section in tag tree panel$/, function (callback) {
        console.log('Verify there is a Plotted Tags title for bottom section in tag tree panel');
        TagTreePage.checkPlottedTagsTitle().then(function(visible) {
            expect(visible).to.equal(true);
            console.log('Plotted Tags title for bottom section is present');
            callback();
        });
    });
    this.Then(/^I click on PlotTag link in the tag tree page to save tags$/, function (callback) {
        console.log('Verify there is a PlotTag link present');
        TagTreePage.checkPlotTagLink().then(function(visible) {
            if(visible) {
                console.log('PlotTag link in the tag tree page is present');
                TagTreePage.clickPlotTagLink().then(function () {
                    console.log("clicked on PlotTag link to navigate to widget configuration page");
                    callback();
                });
            } else {
                console.log("PlotTag link not present");
                expect(1).to.equal(0);
                callback();
            }
        });
    });
    this.Then(/^I should see primary asset "([^"]*)" is displayed in tag browser section$/, function (assetName, callback) {
        console.log('Verify primary asset ' + assetName + ' is displayed in tag browser section');
        TagTreePage.checkPrimaryAsset(assetName).then(function(visible) {
            expect(visible).to.equal(true);
            console.log('Primary asset is displayed');
            callback();
        });
    });
    this.Then(/^I should see a chevron icon next to the asset "([^"]*)"$/, function (assetName, callback) {
        console.log('Verify there is a chevron icon next to asset ' + assetName + ' is collapsed');
        TagTreePage.checkAssetChevronIcon(assetName).then(function(visible) {
            expect(visible).to.equal(true);
            console.log('Chevron icon next to the primary set' + assetName + ' is collapsed');
            callback();
        });
    });
    this.Then(/^I should see "([^"]*)" label displayed$/, function (assetName, callback) {
        console.log('Verify ' + assetName + ' label is displayed under the primary asset');
        TagTreePage.checkAssetNameLabel(assetName).then(function(visible) {
            expect(visible).to.equal(true);
            console.log(assetName + ' label is displayed under the primary asset');
            callback();
        });
    });
    this.Then(/^I should not see "([^"]*)" label displayed$/, function (assetName, callback) {
        console.log('Verify ' + assetName + ' label are not displayed under the primary asset');
        TagTreePage.checkAssetNameLabel(assetName).then(function(visible) {
            expect(visible).to.equal(false);
            console.log(assetName + ' label is not displayed under the primary asset');
            callback();
        });
    });
    this.Then(/^I should see collapse all tags chevron next to "([^"]*)" label$/, function (labelName, callback) {
        console.log('Verify all tags chevron next to all tags label are collapsed');
        TagTreePage.checkAllTagsChevron(labelName).then(function(visible) {
            expect(visible).to.equal(true);
            console.log('all tags chevron next to all tags label are collapsed');
            callback();
        });
    });
    this.Then(/^The "([^"]*)" section will collapse and the chevron should point to the right$/, function (assetName, callback) {
        console.log('Click on chevron to collapse the ' + assetName + ' section');
        TagTreePage.checkSectionCollpased(assetName).then(function(visible) {
            expect(visible).to.equal(false);
            console.log('Chevron icon is present and points to the right. ' + assetName + ' is collapsed');
            callback();
        });
    });
    this.Then(/^The primary asset "([^"]*)" will collapse and the chevron should point to the right$/, function (assetName, callback) {
        console.log('Click on chevron to collapse the primary asset' + assetName);
        TagTreePage.checkPrimaryAssetCollpased(assetName).then(function(visible) {
            expect(visible).to.equal(false);
            console.log('Chevron icon is present and points to the right. ' + assetName + ' is collapsed');
            callback();
        });
    });
    this.When(/^I mouse over the primary asset "([^"]*)"$/, function (assetName, callback) {
        console.log('about to mouse over the primary asset ' + assetName);
        browser.actions().mouseMove(TagTreePage.mouseOverPrimaryAsset(assetName)).perform().then(function(){
            console.log('mouse over the primary asset is done');
            callback();
        });
    });
    this.Then(/^I should see a x icon to delete the asset "([^"]*)"$/, function (assetName, callback) {
        console.log('about to mouse over the primary asset ' + assetName + ' to find the x icon');
        browser.actions().mouseMove(TagTreePage.mouseOverPrimaryAsset(assetName)).perform().then(function(){
            TagTreePage.checkXIconMouseOverAsset(assetName).then(function(visible) {
                expect(visible).to.equal(true);
                console.log('x icon is present');
                callback();
            });
        });
    });
    this.When(/^I click on the x icon to delete the asset "([^"]*)"$/, function (assetName, callback) {
        console.log('about to delete the asset ' + assetName);
        browser.actions().mouseMove(TagTreePage.mouseOverPrimaryAsset(assetName)).perform().then(function(){
            TagTreePage.clickXIconMouseOverAsset(assetName).then(function() {
                console.log('clicked on x icon');
                callback();
            });
        });
    });
    this.Then(/^I should see delete confirmation popup with a title "([^"]*)"$/, function (title, callback) {
        console.log('Verify a confirmation popup with title: ' + title);
        TagTreePage.checkPopUpTitleRemoveAsset(title).then(function(visible) {
            expect(visible).to.equal(true);
            console.log('popup showed up');
            callback();
        });
    });
    this.Then(/^I should see the message "([^"]*)" on popup with title "([^"]*)"$/, function (message, title, callback) {
        console.log('Verify a confirmation popup with message: ' + message);
        TagTreePage.checkPopUpMessageRemoveAsset(message, title).then(function(visible) {
            expect(visible).to.equal(true);
            console.log('popup showed up');
            callback();
        });
    });
    this.Then(/^I should see Cancel button in delete asset confirmation popup$/, function (callback) {
        console.log('Verify a Cancel button is present in popup');
        TagTreePage.checkPopUpCancelButtonRemoveAsset().then(function(visible) {
            expect(visible).to.equal(true);
            console.log('Cancel button showed up');
            callback();
        });
    });
    this.Then(/^I should see OK button in delete asset confirmation popup$/, function (callback) {
        console.log('Verify a OK button is present in popup');
        TagTreePage.checkPopUpOKButtonRemoveAsset().then(function(visible) {
            expect(visible).to.equal(true);
            console.log('OK button showed up');
            callback();
        });
    });
    this.When(/^I click on OK button in delete asset confirmation popup$/, function (callback) {
        console.log('Click OK button');
        TagTreePage.clickPopUpOKButtonRemoveAsset().then(function() {
            console.log('clicked on OK button');
            callback();
        });
    });
    this.Then(/^I click on plus sign to add secondary assets to the tag tree$/, function (callback) {
        console.log('Click on plus sign to add secondary assets to the tag tree');
        TagTreePage.checkPlusSignTagTreeMoreAssets().then(function(visible) {
            if(visible) {
                console.log("Plus sign to to add secondary assets to the tag tree is present");
                TagTreePage.clickPlusSignTagTreeMoreAssets().then(function () {
                    console.log("clicked on Plus sign to add secondary assets to the tag tree");
                    callback();
                });
            } else {
                console.log("Plus sign not present");
                expect(1).to.equal(0);
                callback();
            }
        });
    });
    this.When(/^I select the secondary asset "([^"]*)" from context browser$/, function (asset, callback) {
        TagTreePage.clickSecondaryAssetInContextBrowser(asset).then(function () {
            console.log('clicked on context browser: '+ asset);
            callback();
        });
    });
    this.Then(/^I click on the open button at level (\d+) after selecting secondary asset$/, function (num, callback) {
        browser.ignoresynchronization = false;
        TagTreePage.clickOpenButtonContextBrowser(num-1).then(function(){
            console.log('clicked on open button number: ' + num);
            callback();
        });
    });
    this.Then(/^I click on chevron icon next to the asset "([^"]*)"$/, function (assetName, callback) {
        console.log('Click on chevron icon next to the asset ' + assetName);
        TagTreePage.checkAssetChevronIcon(assetName).then(function(visible) {
            if(visible) {
                console.log("Chevron icon next to the asset " + assetName + " is present");
                TagTreePage.clickAssetChevronIcon(assetName).then(function () {
                    console.log("clicked on chevron icon next to the asset " + assetName);
                    callback();
                });
            } else {
                console.log("chevron icon not present");
                expect(1).to.equal(0);
                callback();
            }
        });
    });
    this.Then(/^I should see a chevron icon next to the asset "([^"]*)", below asset "([^"]*)"$/, function (sibblingAsset, parentAsset, callback) {
        console.log('Verify there is a chevron icon next to asset ' + sibblingAsset + ', below asset ' + parentAsset);
        TagTreePage.checkAssetNextBelow(sibblingAsset, parentAsset).then(function(visible) {
            expect(visible).to.equal(true);
            console.log('Chevron icon next to asset ' + sibblingAsset + ', below asset' + parentAsset + ' is present');
            callback();
        });
    });
    this.Then(/^I click on chevron icon next to the asset "([^"]*)", below asset "([^"]*)"$/, function (sibblingAsset, parentAsset, callback) {
        console.log('Click on chevron icon next to the asset ' + sibblingAsset + ', below asset ' + parentAsset);
        TagTreePage.checkAssetNextBelow(sibblingAsset, parentAsset).then(function(visible) {
            if(visible) {
                console.log('Chevron icon next to the asset ' + sibblingAsset + ', below asset' + parentAsset + ' is present');
                TagTreePage.clickAssetNextBelow(sibblingAsset, parentAsset).then(function () {
                    console.log('clicked on chevron icon next to the asset ' + sibblingAsset + ', below asset ' + parentAsset);
                    callback();
                });
            } else {
                console.log("chevron icon not present");
                expect(1).to.equal(0);
                callback();
            }
        });
    });
    this.When(/^I drag and drop (\d+) tags from the tag tree$/, function (numTags, callback) {
        console.log('Drag and drop ' + numTags + ' tags from the tag tree');
        var step = function(i, done){
            if(i < numTags){
                // Find the index where the tag list starts
                TestHelperPO.elementToBeClickable(element.all(by.css('.leaftype-tag.tree-view-leaf.style-scope.px-tree-view-node.x-scope.px-tree-view-leaf-0')).get(i)).then(function () {
                    browser.sleep(2000).then(function () {
                        TestHelperPO.elementToBeClickable(element.all(by.css('.leaftype-tag.tree-view-leaf.style-scope.px-tree-view-node.x-scope.px-tree-view-leaf-0')).get(i)).then(function () {
                            console.log("Element clicked");
                            var ele = element.all(by.css('.leaftype-tag.tree-view-leaf.style-scope.px-tree-view-node.x-scope.px-tree-view-leaf-0')).get(i);
                            var drop = element(by.css('new-edit-widget .content.style-scope.graph-widget-interactive'));
                            console.log("Elements found");
                            TestHelperPO.dragAndDrop(ele, drop).then(function () {
                                console.log("I: " + i + " arg: " + numTags);
                                step(i + 1, done)
                            })
                        })
                    })
                })
            }
            else
                callback();
        }
        step(0, numTags);
    });
    this.Then(/^I should see the tag "([^"]*)" from asset "([^"]*)" listed in plotted tags section$/, function (tagName, assetName, callback) {
        console.log('Verify ' + tagName + ' is listed in plotted tags section');
        TagTreePage.checkPlottedTagSection(tagName, assetName).then(function(visible) {
            expect(visible).to.equal(true);
            console.log(tagName + ' is listed in plotted tags section');
            callback();
        });
    });
    this.Then(/^I should NOT see a plus sign to add secondary assets to the tag tree$/, function (callback) {
        console.log('Verify there is NOT a plus sign to add secondary assets to the tag tree');
        TagTreePage.checkPlusSignAddAssets().then(function(visible) {
            expect(visible).to.equal(false);
            console.log('Plus sign to add secondary assets to the tag tree is NOT present');
            callback();
        });
    });
    this.When(/^I drag and drop top (\d+) tags from All Tags list$/, function (numTags, callback) {
        console.log('Drag and drop ' + numTags + ' tags from the tag tree');
        var step = function(i, done){
            if(i < numTags){
                // Find the index where the tag list starts
                TestHelperPO.elementToBeClickable(element.all(by.css('.leaftype-tag.tree-view-leaf.style-scope.px-tree-view-node.x-scope.px-tree-view-leaf-0')).get(i)).then(function () {
                    browser.sleep(2000).then(function () {
                        TestHelperPO.elementToBeClickable(element.all(by.css('.leaftype-tag.tree-view-leaf.style-scope.px-tree-view-node.x-scope.px-tree-view-leaf-0')).get(i)).then(function () {
                            console.log("Element clicked");
                            var ele = element.all(by.css('.leaftype-tag.tree-view-leaf.style-scope.px-tree-view-node.x-scope.px-tree-view-leaf-0')).get(i);
                            var drop = element(by.css('new-edit-widget #graph-widget-container section.content'));
                            console.log("Elements found");
                            TestHelperPO.dragAndDrop(ele, drop).then(function () {
                                console.log("I: " + i + " arg: " + numTags);
                                step(i + 1, done)
                            })
                        })
                    })
                })
            }
            else
                callback();
        }
        step(0, numTags);
    });
    this.When(/^I drag and drop the tag number (\d+) from All tags list$/, function (tagNumber, callback) {
        console.log('Drag and drop tag number ' + tagNumber + ' from the tag tree');
        TestHelperPO.elementToBeClickable(element.all(by.css('.leaftype-tag.tree-view-leaf.style-scope.px-tree-view-node.x-scope.px-tree-view-leaf-0')).get(tagNumber)).then(function () {
            browser.sleep(2000).then(function () {
                TestHelperPO.elementToBeClickable(element.all(by.css('.leaftype-tag.tree-view-leaf.style-scope.px-tree-view-node.x-scope.px-tree-view-leaf-0')).get(tagNumber)).then(function () {
                    console.log("Element clicked");
                    var ele = element.all(by.css('.leaftype-tag.tree-view-leaf.style-scope.px-tree-view-node.x-scope.px-tree-view-leaf-0')).get(tagNumber);
                    var drop = element(by.css('new-edit-widget #graph-widget-container section.content'));
                    console.log("Elements found");
                    TestHelperPO.dragAndDrop(ele, drop).then(function () {
                        console.log("I: " + tagNumber-1 + " arg: " + tagNumber);
                        callback();
                    })
                })
            })
        })
    });
    this.Then(/^I should see total (\d+) tags in the plotted tags list$/, function (numTags, callback) {
        console.log('Verify there are ' + numTags + ' total in plotted tags list');
        TagTreePage.checkNumTagsPlottedTagsList().then(function(count) {
            expect(Number(count)).to.equal(Number(numTags));
            console.log('Expected number of tags in plotted tags list were ' + numTags + ' and were found ' + count);
            callback();
        });
    });
    this.Then(/^I should be able to remove the tag (\d+) from plotted tags list by clicking on x icon$/, function (tagNumber, callback) {
        console.log('Verify there is a tag ' + tagNumber + ' then delete it');
        browser.actions().mouseMove(TagTreePage.getTagPlottedTagsList(tagNumber)).perform().then(function(){
            TagTreePage.clickXIconTagPlottedTagsList(tagNumber).then(function() {
                console.log('Tag ' + tagNumber + ' was present and deleted');
                callback();
            });
        });
    });

};

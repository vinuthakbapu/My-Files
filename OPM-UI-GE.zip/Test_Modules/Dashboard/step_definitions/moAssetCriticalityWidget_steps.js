/**
 * Created by 212329933 on Oct 19th 2016.
 */
var data = require('../TestData/mo-dashboard-test-data.json').data;
var assetId;

var myStepDefinitionsWrapper = function () {
	if (browser.params.environment)
		assetId = data.env[browser.params.environment].assetId;

	this.Then(/^widget "([^"]*)" is added to Custom card$/, function (widgetTitle, callback) {
		console.log('Verifying widget ' + widgetTitle + ' is added to the custom card');
		moACWPage.getAssetCriticalityWidgetTitle().then(function (title) {
			expect(title).to.equal(widgetTitle);
			callback();
		});
	});

	this.When(/^the "([^"]*)" widget is available on Custom card$/, function (widgetTitle, callback) {
		console.log('Verifying widget ' + widgetTitle + ' is added to the custom card');
		moACWPage.getAssetCriticalityWidgetTitle().then(function (title) {
			expect(title).to.equal(widgetTitle);
			callback();
		});
	});

	this.Then(/^I can see Meridium Overview link for asset$/, function (callback) {
		console.log('Verifying Meridium Overview link for asset');

		moACWPage.getMeridiumOverviewLinkText().then(function (text) {
			console.log('Verifying link text');
			expect(text).to.equal(data.assetCriticality.labels.meridiumOverviewLink + ' ' + assetId);

			moACWPage.getMeridiumOverviewLinkRedirectUrl().then(function (redirectUrl) {
				moService.getAssetOverviewRedirectUrl().then(function (expectedUrl) {
					expect(redirectUrl).to.equal(expectedUrl);

					console.log('Verifying link target type');
					moACWPage.getMeridiumOverviewLinkFormTarget().then(function (targetType) {
						expect(targetType).to.equal('_blank');

						console.log('Verifying presence of submit button');
						moACWPage.getMeridiumOverviewLinkSubmit().then(function (type) {
							expect(type).to.equal('submit');
							callback();
						});
					});
				});
			});
		});
	});

	this.Then(/^I can see Criticality link$/, function (callback) {
		console.log('Verifying Criticality link');

		moACWPage.getCriticalityLinkUrl().then(function (redirectUrl) {
			moService.getAssetCriticalityRedirectUrl().then(function (expectedUrl) {
				expect(redirectUrl).to.equal(expectedUrl);

				console.log('Verifying link target type');
				moACWPage.getCriticalityLinkTarget().then(function (targetType) {
					expect(targetType).to.equal('_blank');

					console.log('Verifying presence of submit button');
					moACWPage.getCriticalityLinkSubmit().then(function (type) {
						expect(type).to.equal('submit');
						callback();
					});
				});
			});
		});
	});

	this.Then(/^I can see "([^"]*)" label$/, function (label, callback) {
		switch (label) {
			case "CRITICALITY":
				moACWPage.getCriticalityLabel().then(function (text) {
					expect(text.split(' ')[0]).to.equal(label);
					callback();
				});
				break;

			case "FINANCIAL":
				moACWPage.getFinancialLabel().then(function (text) {
					expect(text.split(' ')[0]).to.equal(label);
					callback();
				});
				break;

			case "Environment":
				moACWPage.getEnvironmentLabel().then(function (text) {
					expect(text.split('\n')[0]).to.equal(label);
					callback();
				});
				break;

			case "Operations":
				moACWPage.getOperationsLabel().then(function (text) {
					expect(text.split('\n')[0]).to.equal(label);
					callback();
				});
				break;

			case "Safety":
				moACWPage.getSafetyLabel().then(function (text) {
					expect(text.split('\n')[0]).to.equal(label);
					callback();
				});
				break;
		}
	});

	this.Then(/^I can see "([^"]*)" value$/, function (label, callback) {
		switch (label) {
			case "CRITICALITY":
				moACWPage.getCriticalityLinkText().then(function (value) {
					moService.getAttributeValue(label).then(function (expectedValue) {
						expect(value).to.equal(expectedValue);
						callback();
					});
				});
				break;

			case "FINANCIAL":
				moACWPage.getFinancialValue().then(function (value) {
					moService.getFinancial().then(function (expectedValue) {
						expect(value).to.equal('$' + Number.parseInt(expectedValue).toLocaleString('en-US'));
						callback();
					});
				});
				break;

			case "Environment":
				moACWPage.getEnvironmentValue().then(function (value) {
					moService.getAttributeValue(label).then(function (expectedValue) {
						expect(value).to.equal(expectedValue);
						callback();
					});
				});
				break;

			case "Operations":
				moACWPage.getOperationsValue().then(function (value) {
					moService.getAttributeValue(label).then(function (expectedValue) {
						expect(value).to.equal(expectedValue);
						callback();
					});
				});
				break;

			case "Safety":
				moACWPage.getSafetyValue().then(function (value) {
					moService.getAttributeValue(label).then(function (expectedValue) {
						expect(value).to.equal(expectedValue);
						callback();
					});
				});
				break;
		}

	});

	this.Then(/^I can see "([^"]*)" flag$/, function (label, callback) {
		switch (label) {
			case "CRITICALITY":
				moACWPage.getCriticalityFlagStyle().then(function (color) {
					moService.getAttributeColor(label).then(function (expectedColor) {
						expect(color).to.contain(expectedColor.toLowerCase());
						callback();
					});
				});
				break;

			case "Environment":
				moACWPage.getEnvironmentFlagStyle().then(function (color) {
					moService.getAttributeColor(label).then(function (expectedColor) {
						expect(color).to.contain(expectedColor.toLowerCase());
						callback();
					});
				});
				break;

			case "Operations":
				moACWPage.getOperationsFlagStyle().then(function (color) {
					moService.getAttributeColor(label).then(function (expectedColor) {
						expect(color).to.contain(expectedColor.toLowerCase());
						callback();
					});
				});
				break;

			case "Safety":
				moACWPage.getSafetyFlagStyle().then(function (color) {
					moService.getAttributeColor(label).then(function (expectedColor) {
						expect(color).to.contain(expectedColor.toLowerCase());
						callback();
					});
				});
				break;
		}
	});

	// this method will be removed later
	this.When(/^I select the dashboard "([^"]*)"$/, function (view, callback) {
		console.log('verify if view exists already. delete if it is present');
		createviewpage.chkViewSelectorDropdown().then(function (yeah) {
			console.log('deck selecor drop down is visible: ', yeah);
			if (yeah) {
				console.log('Deck selector is present, going to look for the view to delete');
				createviewpage.clickViewSelectorDropdown().then(function () {
					console.log('clicked on deck selector');
					createviewpage.chkView(view).then(function (present) {
						console.log('chkView: ' + present);
						if (present) {
							console.log('found the view: ' + view);
							createviewpage.clickView(view).then(function () {
								callback();
							})
						} else {
							console.log('view not found');
							callback();
						}
					})
				})
			} else {
				console.log('no existing dashboards to delete');
				callback();
			}

		});
	});

};

var getFlagClass = function (value) {
	var cls;

	if (value >= 0 && value <= 9.9) {
		cls = 'riskcategory-flag-green';
	} else if (value >= 10 && value <= 99.9) {
		cls = 'riskcategory-flag-palegold';
	} else if (value >= 100 && value <= 999.9) {
		cls = 'riskcategory-flag-lightsalmon';
	} else if (value >= 1000) {
		cls = 'riskcategory-flag-Salmon';
	}

	return cls;
};

module.exports = myStepDefinitionsWrapper;

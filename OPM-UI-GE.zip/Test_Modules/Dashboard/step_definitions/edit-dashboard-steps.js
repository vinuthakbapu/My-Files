/**
 * Created by 212340705 on 12/7/2015.
 */
var randomVuName = "TestVu_" + TestHelper.getRandomString();
var duplicateVu = "DupVu_" + TestHelper.getRandomString();
var currentpage = 'DashboardAppPages';
var dashboardCount = 0;
module.exports = function() {
    // this.setDefaultTimeout(60000);

    this.Then(/^I should see edit dashboard link in dashboard menu$/, function (callback) {
        console.log('Verify edit dashboard link is present in dashboard menu');
        createviewpage.chkEditDashboardLink().then(function(present){
            console.log('edit dashboard link in dashboard menu present: '+ present);
            expect(present).to.equal(true);
            callback();
        });
    });
    this.Then(/^I click on edit dashboard link in the dashboard menu$/, function (callback) {
        console.log('about to click on edit dashboard link');
        createviewpage.clickCardActionMenuBtn().then(function () {
            console.log('clicked on dashboard kebab menu');
            createviewpage.clickEditDashboardLink().then(function(){
                console.log('clicked on edit dashboard link in dashbaord kebab menu');
                callback();
            })
        });
    });
    this.Then(/^I should see edit dashboard name input field$/, function (callback) {
        console.log('verify edit dashboard name input field is present on card library page');
        createviewpage.chkEditnameInputfield().isPresent()
            .then(function(present){
                expect(present).to.equal(true);
                console.log("dashboard name input field is present " + present);
                callback();
            });
    });

    this.Then(/^I should see "([^"]*)" in the Edit name input field prefilled$/, function (arg1, callback) {
        console.log('Verify ***' + arg1 + '***  is present in the name ');
        createviewpage.chkEditnameInputfield().getAttribute('value')
            .then(function(msg){
                expect(msg).to.contain(arg1);
                console.log(arg1 + ' : is present in the name '+msg)
                callback();
            });
    });

    this.Then(/^I should be able to enter the dashboard name as "([^"]*) "$/, function (arg1, callback) {
        console.log('Changing the name of dashboard in edit board');
        createviewpage.chkEditnameInputfield().clear().then(function(){
            createviewpage.chkEditnameInputfield().sendKeys(arg1).then(function(){
                createviewpage.chkEditnameInputfield().getAttribute('value').then(function(txt){
                    console.log('following text entered into edit dashboard name: '+ txt);
                    callback();
                });
            });
        })
    });

    this.Then(/^I should be able to edit dashboard name by adding "([^"]*) at the end"$/, function (arg1, callback) {
        console.log('Changing the name of dashboard in edit board');
        createviewpage.getEditnameInputfieldByTitle().then(function(existingName) {
            console.log("Name of current dashboard name is: " + existingName);
            createviewpage.chkEditnameInputfield().clear().then(function(){
                createviewpage.chkEditnameInputfield().sendKeys(existingName + arg1).then(function(){
                    createviewpage.chkEditnameInputfield().getAttribute('value').then(function(txt) {
                        console.log('following text entered into edit dashboard name: ' + txt);
                        callback();
                    });
                });
            });
        })
    });
    this.When(/^I should be able to see save button in edit dashboard$/, function (callback) {
        console.log('about to check save button in edit dashboard');
        createviewpage.chkSaveEditDashboardButton().then(function(){
            console.log('checked the save button in edit dashboard');
            callback();
        });
    });

    this.When(/^I click on save button in edit dashboard$/, function (callback) {
        console.log('about to click save button in edit dashboard');
        createviewpage.clickSaveEditDashboardButton().then(function(){
            console.log('clicked the save button in edit dashboard');
            callback();
        });
    });
    this.When(/^I should be able to see Cancel button in edit dashboard$/, function (callback) {
        console.log('about to check cancel button in edit dashboard');
        createviewpage.chkCancelEditDashboardButton().then(function(){
            console.log('checked the cancel button in edit dashboard');
            callback();
        });
    });

    this.When(/^I click on Cancel button in edit dashboard$/, function (callback) {
        console.log('about to click cancel button in edit dashboard');
        createviewpage.clickCancelEditDashboardButton().then(function(){
            console.log('clicked the cancel button in edit dashboard');
            callback();
        });
    });
    this.When(/^I should be able to click on done button$/, function (callback) {
        console.log('about to done cancel button in edit dashboard');
        createviewpage.clickDoneEditDashboardButton().then(function(){
            console.log('clicked the done button in edit dashboard');
            callback();
        });
    });
    this.Then(/^I should not see edit dashboard link in dashboard menu$/, function (callback) {
        console.log('Verify edit dashboard link is not present in dashboard menu');
        createviewpage.chkEditDashboardLink().then(function(present){
            console.log('edit dashboard link in dashboard menu present: '+ present);
            expect(present).to.equal(false);
            callback();
        });
    });
    this.Then(/^I should see disabled edit dashboard link in dashboard menu$/, function (callback) {
        console.log('Verify edit dashboard link is  disabled in dashboard menu');
        createviewpage.chkEditDashboardLinkDisabled().then(function(present){
            console.log('Edit dashboard link in dashboard menu present: '+ present);
            expect(present).to.equal(true);
            callback();
        });
    });



}


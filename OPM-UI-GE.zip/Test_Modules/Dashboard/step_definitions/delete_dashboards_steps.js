var currentpage = 'DashboardAppPages';


module.exports = function() {
    // this.setDefaultTimeout(120000);

    this.When(/^I delete all "([^"]*)" instances if they already exist$/, function (view, callback) {
        console.log('verify if view exists already. delete if it is present');

        browser.sleep(5000).then(function() {
            createviewpage.chkViewSelectorDropdown().then(function(yeah) {
                console.log('Deck selector drop down is visible: ', yeah);
                if (yeah) {
                    console.log('Deck selector is present, going to look for the view to delete');
                    var foundAMatch = true;
                    var step = function (bool) {
                        if (bool === true) {
                            createviewpage.chkViewSelectorDropdown().then(function(yeah) {
                                if (yeah) {
                                    createviewpage.clickViewSelectorDropdown().then(function () {
                                        AdvancedNavPage.chkViewTest(view).then(function (found) {
                                            foundAMatch = found;
                                            console.log("<<<Match found>>> = " + foundAMatch);
                                        }).then(function () {
                                            if (foundAMatch) {
                                                createviewpage.clickView(view);
                                            }
                                        }).then(function () {
                                            if (foundAMatch) {
                                                console.log('going to delete the view');
                                                createviewpage.clickCardActionMenuBtn();
                                            }
                                        }).then(function () {
                                            if (foundAMatch) {
                                                console.log('clickCardActionMenuBtn');
                                                createviewpage.clickDeleteViewLink();
                                            }
                                        }).then(function () {
                                            if (foundAMatch) {
                                                console.log('clickDeleteViewLink');
                                                createviewpage.clickDeleteViewConfirmOKBtn();
                                            }
                                        }).then(function () {
                                            if (foundAMatch) {
                                                console.log('clickDeleteViewConfirmOKBtn');
                                                createviewpage.chkDeleteSpinnerHidden();
                                            }
                                        }).then(function () {
                                            if (foundAMatch) {
                                                console.log('Delete spinner is hidden');
                                                console.log('deleted view: ' + view);
                                            }
                                        }).then(function () {
                                            browser.sleep(1000);
                                            step(foundAMatch);
                                        })
                                    });
                                }else{
                                    console.log('view selector dropdown is not present.');
                                    callback();
                                }
                            });
                        }
                        else {
                            callback();
                        }
                    };
                    step(foundAMatch);
                }else{
                    console.log('view selector dropdown is not present.');
                    callback();
                }
            });
        });
    });
    this.When(/^Delete all views$/, function (callback) {
        browser.sleep(2000).then(function(){
            console.log('about to delete all the views');
            createviewpage.getViewSelectorDropdown().then(function (present) {
                console.log('Deck selector drop-down is present:' + present);
                if(present){
                    createviewpage.getAllDashboardInDeck().then(function(decks){
                        var noOfDecks = decks.length - 1;
                        console.log('Decks count: ' + noOfDecks);

                        var step = function (start, done) {
                            console.log('inside the step')
                            if (start < done) {
                                console.log(start + ' ' + done)
                                createviewpage.deleteDeck(start).then(function(){
                                    step(start + 1, done)
                                });
                            }
                            else {
                                console.log('deleted all decks/views.');
                                callback();
                            }
                        };
                        step(0,noOfDecks)
                    });
                }else {
                    callback();
                }
            });
        });
    });
}

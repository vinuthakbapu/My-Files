/**
 * Created by 212329933 on Oct 19th 2016.
 */
var data = require('../TestData/mo-dashboard-test-data.json').data;
//var envData = data.env[browser.params.environment];
var assetId; // = envData.assetId;
var tenantUUId; // = envData.opts.headers.tenant;
var widgetTestData = data.openWorkOrdersWidget;
var maxRows = 5;
var openWorkOrdersServiceData = new Array();

var myStepDefinitionsWrapper = function () {
	if(browser.params.environment) {
		assetId = data.env[browser.params.environment].assetId;
		tenantUUId = data.env[browser.params.environment].opts.headers.tenant
	}

	this.Then(/^Open Work Orders widget is added to Custom card$/, function (callback) {
		console.log('Verifying widget "Open Work Orders" is added to the custom card');
		moOWOWPage.getOpenWorkOrdersWidgetTitle().then(function (title) {
			expect(title).to.equal(widgetTestData.labels.title);
			callback();
		});
	});

	this.When(/^Open Work Orders widget is available on Custom card$/, function (callback) {
		moOWOWPage.getOpenWorkOrdersWidgetTitle().then(function (title) {
			expect(title).to.equal(widgetTestData.labels.title);
			callback();
		});
	});

	this.When(/^I should see View All link$/, function (callback) {
		moOWOWPage.getViewAllLinkText().then(function (linkText) {
			expect(linkText).to.equal('View All');
			callback();
		});
	});

	this.When(/^I should see View All link with meridium redirect url$/, function (callback) {
		moOWOWPage.getViewAllFormDetails().then(function (form) {
			var details = form.split(':::');
			moService.getAllWorkOrdersRedirectUrl().then(function (expectedUrl) {
				expect(details[0]).to.equal(expectedUrl);
				expect(details[0]).to.contain(assetId);
				expect(details[0]).to.contain(tenantUUId);
				expect(details[1]).to.equal('_blank');
				expect(details[2]).to.equal('submit');

				callback();
			});
		});
	});

	this.Then(/^I should see open work orders table headers$/, function (callback) {
		moOWOWPage.getTableHeaders().then(function (headers) {
			expect(headers).to.deep.equal(widgetTestData.labels.tableHeaders);
			callback();
		});
	});

	this.When(/^I should see maximum "([^"]*)" rows in open work orders table$/, function (expectedCount, callback) {
		moOWOWPage.getRowCount().then(function (count) {
			if (count > expectedCount)
				expect(true).to.equal(false);
			else
				expect(true).to.equal(true);
			callback();
		});
	});

	this.Then(/^I should see open work orders table data$/, function (callback) {
		moOWOWPage.getTableData().then(function (tableData) {
			moService.getOpenWorkOrdersForAsset().then(function (serviceData) {
				openWorkOrdersServiceData = serviceData;

				if (openWorkOrdersServiceData.length > maxRows) {
					openWorkOrdersServiceData = openWorkOrdersServiceData.splice(0, maxRows);
				}

				for (var i = 0; i < openWorkOrdersServiceData.length; i++) {
					var obj = openWorkOrdersServiceData[i];
					expect(tableData[i][0]).to.equal(obj['orderId']);
					expect(tableData[i][1]).to.equal(doNullCheck(obj['caseId']));
					expect(doNullCheck(obj['orderDescription'])).to.contain(getSubString(tableData[i][2]));
					expect(tableData[i][3]).to.equal(doNullCheck(obj['orderSystemStatus']));
					expect(tableData[i][4]).to.equal(getFormattedDate(obj['orderCreationDate']));
					expect(tableData[i][5]).to.equal(getFormattedDate(obj['maintenanceCompletionDate']));
					expect(tableData[i][6]).to.equal(doNullCheck(obj['orderTypeDescription']));
				}
				callback();
			});
		});
	});

	this.Then(/^I should see open work orders links$/, function (callback) {
		moOWOWPage.getAllOpenWorkOrdersLinks().then(function (links) {
			for (var i = 0; i < openWorkOrdersServiceData.length; i++) {
				var obj = openWorkOrdersServiceData[i];
				expect(links[i]).to.equal(obj['orderId']);
			}

			callback();
		});
	});

	this.Then(/^I should see open work orders links with redirect urls$/, function (callback) {
		var entityKeys = new Array();
		for (var i = 0; i < openWorkOrdersServiceData.length; i++) {
			var obj = openWorkOrdersServiceData[i];
			entityKeys.push(obj['entityKey']);
		}

		moOWOWPage.getAllRecommendationsRedirectUrls().then(function (forms) {
			moService.getRecommendationsRedirectUrlsList(entityKeys).then(function (urlsList) {
				for (var i = 0; i < forms.length; i++) {
					var formData = forms[i].split(':::');
					expect(formData[0]).to.equal(urlsList[i]);
					expect(formData[0]).to.contain(tenantUUId);
					expect(formData[1]).to.equal('_blank');
					expect(formData[2]).to.equal('submit');
				}
				callback();
			});
		});
	});

	this.Then(/^I should see open work orders case links$/, function (callback) {
		moOWOWPage.getAllCaseLinks().then(function (links) {
			var cnt = 0;
			for (var i = 0; i < openWorkOrdersServiceData.length; i++) {
				var obj = openWorkOrdersServiceData[i];
				if (doNullCheck(obj['caseId']) !== '') {
					expect(links[cnt++]).to.equal(obj['caseId']);
				}
			}

			callback();
		});
	});
};

var getFormattedDate = function (date) {
	if (date === undefined || date === 'null' || date === null || date.trim() === '')
		return '';

	var dateWithoutTS = date.split("T")[0].split("-");
	return dateWithoutTS[1] + '/' + dateWithoutTS[2] + '/' + dateWithoutTS[0];
}

var getSubString = function (str) {
	if (str.length > 12)
		return str.substr(0, str.length - 1);

	return str;
}

var doNullCheck = function (str) {
	if (str === null || str === 'null' || str.trim() === '')
		return '';

	return str.replace(/ +/g, ' ');
}

module.exports = myStepDefinitionsWrapper;

/**
 * Created by 212677088 on 12/7/2017.
 */

module.exports = function () {
    var delay=5000;

    this.Given(/^I click on plus button$/, function (callback) {
        console.log('***about to click on Multi-Forecast + button***');
        browser.sleep(delay).then(function () {
            multiForecastPO.clickPlusButton().then(function () {
                console.log('clicked the + button');
                callback();
            });
        });
    });

    this.Then(/^Edit the title of Forecast as (.*)$/, function (name, callback) {
        console.log('***About to set Title value ***' + name);
        multiForecastPO.forecastTitleText().clear().then(function () {
            multiForecastPO.forecastTitleText().sendKeys(name).then(function () {
                console.log('Tilt le for current Forecast is set');
                callback();
            });
        });
    });

    this.Then(/^Add Historical tag value as (.*)$/, function (name, callback) {
        console.log('***About to set Historical tag value ***' + name);
        multiForecastPO.historicalTagText().clear().then(function () {
            multiForecastPO.historicalTagText().sendKeys(name).then(function () {
                browser.sleep(delay).then(function () {
                    callback();
                });
            });
        });
    });

    this.Then(/^I select the tag from list$/, function (callback) {
        console.log('***About to set select the value from dropdown ***');
        multiForecastPO.selectTagDropDown().then(function () {
            console.log('Dropdown value selected');
            callback();
        });
    });

    this.Then(/^Add Forecast tag value as (.*)$/, function (name, callback) {
        console.log('***About to set Forecast tag value ***' + name);
        multiForecastPO.forecastTagText().clear().then(function () {
            multiForecastPO.forecastTagText().sendKeys(name).then(function () {
                browser.sleep(delay).then(function () {
                    callback();
                });
            });
        });
    });

    this.Then(/^Set Target value as (.*)$/, function (name, callback) {
        console.log('***About to set Target value ***' + name);
        multiForecastPO.targetText().clear().then(function () {
            multiForecastPO.targetText().sendKeys(name).then(function () {
                console.log('Target value is set');
                callback();
            });
        });
    });

    this.Then(/^Set Threshold value as (.*)$/, function (name, callback) {
        console.log('***About to set Threshold value ***' + name);
        multiForecastPO.thresholdText().clear().then(function () {
            multiForecastPO.thresholdText().sendKeys(name).then(function () {
                browser.sleep(delay).then(function () {
                    callback();
                });
            });
        });
    });

    this.Then(/^I refresh the page$/, function (callback) {
        console.log('about to relaunch the url: -- ' + browser.params.login.baseUrl);
        multiForecastPO.getUrl(browser.params.login.baseUrl).then(function () {
            browser.sleep(delay).then(function () {
                callback();
            });
        });
    });

    this.Then(/^I click on collapse button$/, function (callback) {
        multiForecastPO.expandIcon().then(function(){
            callback();
        });
    });

    this.Given(/^I click on expand button next to (.*) Forecast$/, function (num, callback) {
        console.log('***about to click on expand button next to Forecast***');
        collapseIcon=element.all(by.css('#graph-widget-configure-container:not([hidden]) #widget-configuration>li:last-child>ul:nth-child('+num+') i[class*="fa-caret-right"]')).get(0);
        expandIcon=element.all(by.css('#graph-widget-configure-container:not([hidden]) #widget-configuration>li:last-child>ul:nth-child('+num+') i[class*="fa-caret-down"]')).get(0);
        browser.sleep(delay).then(function () {
            collapseIcon.isPresent().then(function(present) {
                    if (present) {
                        collapseIcon.click();
                        console.log('Clicked Collapse Icon');
                    } else {
                        console.log('Clicked expand Icon');
                    }
                },
                function(err){
                    console.log('Error',err);
                });

            callback();
        });
    });

    this.Given(/^I click on Delete Forecast button at (.*)$/, function (num, callback) {
        console.log('***about to click on Multi-Forecast deleteIcon button***',num);
        deleteIcon=element.all(by.css('#graph-widget-configure-container:not([hidden]) #widget-configuration>li:last-child>ul:nth-child('+num+') a[id*="delete"] i')).get(0);
        browser.sleep(delay).then(function () {
            deleteIcon.isPresent().then(function(present) {
                    if (present) {
                        deleteIcon.click();
                        console.log('Clicked delete Icon');
                    }
                },
                function(err){
                    console.log('Error',err);
                });

            callback();
        });
    });

    this.Given(/^I click on Delete OK Button$/, function (callback) {
        console.log('***about to click on Multi-Forecast deleteOKButton button***');
        browser.sleep(delay).then(function () {
            multiForecastPO.deleteOKButton().then(function () {
                callback();
            });
        });
    });

    this.Given(/^I wait for page to load$/, function (callback) {
        browser.sleep(delay).then(function () {
            callback();
        });
    });

    this.Given(/^I verify the presence of Widget Settings$/, function (callback) {
        multiForecastPO.getWidgetSettings().isPresent().then(function () {
            callback();
        });
    });

    this.Given(/^I verify the presence of Title$/, function (callback) {
        multiForecastPO.getWidgetTitle().isPresent().then(function () {
            callback();
        });
    });

    this.Given(/^I verify the presence of Title Text$/, function (callback) {
        multiForecastPO.getWidgetTitleText().isPresent().then(function () {
            callback();
        });
    });

    this.Given(/^I verify the presence of Date Range$/, function (callback) {
        multiForecastPO.getDateRange().isPresent().then(function () {
            callback();
        });
    });

    this.Given(/^I verify the presence of Previous Text$/, function (callback) {
        multiForecastPO.getPreviousTextBox().isPresent().then(function () {
            callback();
        });
    });

    this.Given(/^I verify the presence of Next Text$/, function (callback) {
        multiForecastPO.getNextTextBox().isPresent().then(function () {
            callback();
        });
    });

    this.Given(/^I verify the presence of Previous dropdown$/, function (callback) {
        multiForecastPO.getPreviousDropdown().isPresent().then(function () {
            callback();
        });
    });

    this.Given(/^I verify the presence of Next dropdown$/, function (callback) {
        multiForecastPO.getNextDropdown().isPresent().then(function () {
            callback();
        });
    });

    this.Given(/^I verify the presence of Plus Icon$/, function (callback) {
        multiForecastPO.clickPlusButton().isPresent().then(function () {
            callback();
        });
    });

    this.Given(/^I verify the presence of Default Text$/, function (callback) {
        multiForecastPO.getDefaultText().isPresent().then(function () {
            callback();
        });
    });

    this.Given(/^I verify the presence of Timeseries Chart$/, function (callback) {
        multiForecastPO.getTsChart().isPresent().then(function () {
            callback();
        });
    });

    this.When(/^I verify the presence of Forecast Title$/, function (callback) {
        multiForecastPO.forecastTitleText().isPresent().then(function () {
            callback();
        });
    });

    this.When(/^I verify the presence of Delete Icon$/, function (callback) {
        multiForecastPO.deleteIcon().then(function () {
            callback();
        });
    });

    this.When(/^I verify the presence of Historical Dropdown$/, function (callback) {
        multiForecastPO.getHistoricalSelect().isPresent().then(function () {
            callback();
        });
    });

    this.When(/^I verify the presence of Historical Text$/, function (callback) {
        multiForecastPO.historicalTagText().isPresent().then(function () {
            callback();
        });
    });

    this.When(/^I verify the presence of Forecast Dropdown$/, function (callback) {
        multiForecastPO.getForecastSelect().isPresent().then(function () {
            callback();
        });
    });

    this.When(/^I verify the presence of Forecast Text$/, function (callback) {
        multiForecastPO.forecastTagText().isPresent().then(function () {
            callback();
        });
    });

    this.When(/^I verify the presence of Target$/, function (callback) {
        multiForecastPO.targetText().isPresent().then(function () {
            callback();
        });
    });

    this.When(/^I verify the presence of Threshold$/, function (callback) {
        multiForecastPO.thresholdText().isPresent().then(function () {
            callback();
        });
    });

    this.Then(/^Add I search for Historical tag value as "([^"]*)"$/, function (arg1, callback) {
        multiForecastPO.historicalTagText().clear().then(function () {
            multiForecastPO.historicalTagText().sendKeys(arg1).then(function () {
                browser.sleep(delay).then(function () {
                    callback();
                });
            });
        });
    });

    this.Then(/^Add I search for Forecast tag value as "([^"]*)"$/, function (arg1, callback) {
        multiForecastPO.forecastTagText().clear().then(function () {
            multiForecastPO.forecastTagText().sendKeys(arg1).then(function () {
                browser.sleep(delay).then(function () {
                    callback();
                });
            });
        });
    });

    this.Then(/^I Set Target value field as "([^"]*)"$/, function (name, callback) {
        console.log('***About to set Target value ***' + name);
        multiForecastPO.targetText().clear().then(function () {
            multiForecastPO.targetText().sendKeys(name).then(function () {
                console.log('Target value is set');
                callback();
            });
        });
    });

    this.Then(/^I Set Threshold value field as "([^"]*)"$/, function (name, callback) {
        console.log('***About to set Threshold value ***' + name);
        multiForecastPO.thresholdText().clear().then(function () {
            multiForecastPO.thresholdText().sendKeys(name).then(function () {
                browser.sleep(delay).then(function () {
                    callback();
                });
            });
        });
    });

    this.Then(/^I select Previous dropdown value as "([^"]*)"$/, function (arg1, callback) {
        multiForecastPO.getPreviousDropdown().element(by.cssContainingText('option', arg1)).click();
        callback();
    });

    this.Then(/^I verify the Next dropdown value as "([^"]*)"$/, function (arg1, callback) {
        multiForecastPO.getNextDropdown().element(by.cssContainingText('option', arg1)).getText().valueOf()
            .then(function (text) {
                console.log('Next Dropdown value is ---', text);
                expect(text).to.contain(arg1);
            })
        callback();
    });

    this.Then(/^I select Next dropdown value as "([^"]*)"$/, function (arg1, callback) {
        multiForecastPO.getNextDropdown().element(by.cssContainingText('option', arg1)).click();
        callback();
    });

    this.Then(/^I verify the Previous dropdown value as "([^"]*)"$/, function (arg1, callback) {
        multiForecastPO.getPreviousDropdown().element(by.cssContainingText('option', arg1)).getText().valueOf()
            .then(function (text) {
                console.log('Next Dropdown value is ---', text);
                expect(text).to.contain(arg1);
            });
        callback();
    });

    this.Then(/^I verify the chart$/, function () {

        var deferred = protractor.promise.defer();

        var xCoOrdinates = '.new-edit-widget #svgCanvas #chartSVG #layer0 .axis:nth-child(2) text';
        var yCoOrdinates = '.new-edit-widget #svgCanvas #chartSVG #layer0 .axis:nth-child(1) text';
        var mouseOn = '.new-edit-widget #svgCanvas #chartSVG [width="582"]';
        var tooltiptext = '#tooltip #message #dateTime #firstDateTime';

        protractor.promise.controlFlow().execute(function () {
            deferred.fulfill(
                element.all(by.css(xCoOrdinates)).map(function (elm) {
                    return elm.getText();
                }).then(function (texts) {
                    console.log("xlength---", texts.length);
                    texts.forEach(function (val) {
                        console.log("values---", val);
                    });
                })
            );

            deferred.fulfill(
                element.all(by.css(yCoOrdinates)).map(function (elm) {
                    return elm.getText();
                }).then(function (texts) {
                    console.log("ylength---", texts.length);
                    texts.forEach(function (val) {
                        console.log('values---', val);
                    });
                })
            );

        });
        return deferred;
    });

    this.When(/^I verify the presence of Straight line of UoM value on chart$/, function (callback) {
        multiForecastPO.straightLine().isPresent().then(function () {
            callback();
        });
    });

    this.When(/^I verify the presence of Straight line of UoM value on chart$/, function (callback) {
        multiForecastPO.dashLine().isPresent().then(function () {
            callback();
        });
    });

    this.Given(/^I verify the presence of Graph Smoothing$/, function (callback) {
        multiForecastPO.graphSmoothingTitle().isPresent().then(function () {
            callback();
        });
    });

    this.Given(/^I verify the presence of Normalization dropdown and its elements$/, function (callback) {
        multiForecastPO.normalizationTitle().isPresent().then(function () {
            multiForecastPO.normalizationDropdown().all(by.tagName('option')).then(function(elements){
                var elemCount = elements.length,
                    counter = 0;

                elements.forEach(function(element) {
                    element.getText().then(function(optionValue) {
                        counter += 1;
                    });
                });
            });
            callback();
        });
    });

    this.Given(/^I verify System of Measure textbox is not editable$/, function (callback) {
        multiForecastPO.systemOfMeasureText().isPresent().then(function () {
            callback();
        });
    });

    this.Given(/^I verify Primary axis is not editable$/, function (callback) {
        multiForecastPO.primarySelectDisabled().isPresent().then(function () {
            callback();
        });
    });

    this.Given(/^I verify Secondary axis is not editable$/, function (callback) {
        multiForecastPO.secondarySelectDisabled().isPresent().then(function () {
            callback();
        });
    });

    this.When(/^I verify presence of Select Axis dropdown and its elements$/, function (callback) {
        browser.sleep(delay);
        multiForecastPO.selectAxisDropdown().all(by.tagName('option')).then(function(elements){
            var elemCount = elements.length,
                counter = 0,
                axisArray = ['Primary', 'Secondary'];

            elements.forEach(function(element) {
                element.getText().then(function(optionValue) {
                    console.log("Dropdown value-->"+optionValue);
                    console.log("Array value-->"+axisArray[counter]);
                    expect(optionValue).to.contain(axisArray[counter]);
                    counter += 1;
                });
            });
            callback();
        });
    });

    this.Then(/^I select (.*) from Select Axis dropdown$/, function (name, callback) {
        multiForecastPO.selectAxisDropdown().element(by.cssContainingText('option', name)).click();
        callback();
    });

    this.Then(/^I change the UoM value to another value (.*) on (.*)$/, function (changeuom, axisval, callback) {
        if(axisval === "Primary"){
            multiForecastPO.primarySelectEnabled().isPresent().then(function () {
                multiForecastPO.primarySelectEnabled().element(by.cssContainingText('option', changeuom)).click();
            });
        }else{
            multiForecastPO.secondarySelectEnabled().isPresent().then(function () {
                multiForecastPO.secondarySelectEnabled().element(by.cssContainingText('option', changeuom)).click();
            });
        }
        callback();
    });

    this.Then(/^I verify (.*) Y\-axis is not editable$/, function (name, callback) {
        if(name === "Primary"){
            multiForecastPO.primarySelectDisabled().isPresent();
        }else{
            multiForecastPO.secondarySelectDisabled().isPresent();
        }
        callback();
    });

    this.Then(/^I verify (.*) Y\-axis is editable and UoM value should be displayed by default$/, function (name, callback) {
        if(name === "Primary"){
            multiForecastPO.primarySelectEnabled().isPresent().then(function () {
                multiForecastPO.primarySelectEnabled().$('option:checked').getText().then(function(text){
                    console.log('Primary dropdown value-->'+ text);
                });
            });
        }else{
            multiForecastPO.secondarySelectEnabled().isPresent().then(function () {
                multiForecastPO.secondarySelectEnabled().$('option:checked').getText().then(function (text) {
                    console.log('Secondary dropdown value-->'+text);
                });
            });
        }
        callback();
    });

    this.Then(/^I verify (.*) on chart along with (.*) dropdown$/, function (chartuom,axisval) {
        var deferred = protractor.promise.defer();
        var arryOfStrings;

        protractor.promise.controlFlow().execute(function () {
            if(axisval === "Primary"){
                deferred.fulfill(
                    multiForecastPO.primaryAxisUoMLegend().isPresent().then(function () {
                        multiForecastPO.primaryAxisUoMLegend().getText().valueOf().then(function (primaryChartText) {
                            console.log('Primary legend-->', primaryChartText);
                            arryOfStrings = primaryChartText.split(':');
                            console.log('arryOfStrings.length-->', arryOfStrings.length);
                            if(arryOfStrings[1].indexOf(chartuom) >=0 ){
                                console.log('Dropdown value matches with legend value!!');
                            }
                        });
                    })
                );
            }else{
                deferred.fulfill(
                    multiForecastPO.secondaryAxisUoMLegend().isPresent().then(function () {
                        multiForecastPO.secondaryAxisUoMLegend().getText().valueOf().then(function (secondaryChartText) {
                            console.log('secondary legend-->', secondaryChartText);
                            arryOfStrings = secondaryChartText.split(':');
                            console.log('arryOfStrings.length-->', arryOfStrings.length);
                            if(arryOfStrings[1].indexOf(chartuom) >=0 ){
                                console.log('Dropdown value matches with legend value!!');
                            }
                        });
                    })
                );
            }
        });

        if(chartuom !== null && chartuom !== ''){
            if(axisval === "Primary"){
                multiForecastPO.primarySelectEnabled().isPresent().then(function () {
                    multiForecastPO.primarySelectEnabled().$('option:checked').getText().then(function(primarySelectText){
                        console.log('Primary dropdown value-->'+ primarySelectText);
                        expect(primarySelectText).to.contain(arryOfStrings[1].trim());
                    });
                });
            }else{
                multiForecastPO.secondarySelectEnabled().isPresent().then(function () {
                    multiForecastPO.secondarySelectEnabled().$('option:checked').getText().then(function(secondarySelectText){
                        console.log('secondary dropdown value-->'+ secondarySelectText);
                        expect(secondarySelectText).to.contain(arryOfStrings[1].trim());
                    });
                });
            }

        }
        return deferred;
    });

    this.Then(/^UoM value to change "([^"]*)" on axis "([^"]*)"$/, function (changeuom, axisval, callback) {
        if(axisval === "Primary"){
            multiForecastPO.primarySelectEnabled().isPresent().then(function () {
                multiForecastPO.primarySelectEnabled().element(by.cssContainingText('option', changeuom)).click();
            });
        }else{
            multiForecastPO.secondarySelectEnabled().isPresent().then(function () {
                multiForecastPO.secondarySelectEnabled().element(by.cssContainingText('option', changeuom)).click();
            });
        }
        callback();
    });

    this.When(/^click on asset tab in micro app$/, function (callback) {
        console.log('***about to click on Asset Menu ***');
        browser.sleep(delay).then(function () {
            multiForecastPO.clickAssetMenu().then(function () {
                callback();
            });
        });
    });

    this.When(/^I click on (.*) from the context browser$/, function ( asset, callback) {
        createviewpage.clickAssetInContextBrowser(asset)
            .then(function () {
                console.log('clicked on context browser: ' + asset);
                callback();
            })
    });

    this.Then(/^I click on dashboard tab from context browser$/, function (callback) {
        console.log('about to click on dashboard tab in left nav');
        createviewpage.clickDashboardTab().then(function() {
            browser.sleep(delay).then(function () {
                callback();
            });
        });
    });

    this.When(/^I click on All Dashboards tab link$/, function (callback) {
        multiForecastPO.allDashboards().then(function () {
            callback();
        });
    });

    this.When(/^I enter the name in (.*) filter$/, function (name, callback) {
        multiForecastPO.nameFilter().clear().then(function () {
            multiForecastPO.nameFilter().sendKeys(name).then(function () {
                callback();
            });
        });
    });

    this.Then(/^I click on the first element from search list$/, function (callback) {
        multiForecastPO.firstSearchResult().then(function () {
            callback();
        });
    });

    this.When(/^I click on Create New button$/, function (callback) {
        browser.sleep(delay).then(function () {
            multiForecastPO.createNewDashboard().then(function () {
                callback();
            });
        });
    });

    this.When(/^I enter the Title in (.*) field$/, function (title, callback) {
        multiForecastPO.generateRandomNumber().then(function (num) {
            multiForecastPO.addTitle().clear().then(function () {
                multiForecastPO.addTitle().sendKeys(title+num).then(function () {
                    callback();
                });
            });
        });
    });

    this.Then(/^I click on Choose Context dropdown$/, function (callback) {
        multiForecastPO.dropdownChooseContext().then(function () {
            callback();
        });
    });

    this.Then(/^I click on Choose Context option$/, function (callback) {
        multiForecastPO.optionChooseContext().then(function () {
            callback();
        });
    });

    this.Then(/^I click on Custom card Add button$/, function (callback) {
        multiForecastPO.customcardAdd().then(function () {
            callback();
        });
    });

    this.Then(/^I click on Dashboard Save button$/, function (callback) {
        multiForecastPO.saveDashboard().then(function () {
            callback();
        });
    });

//-----Asset Menu details-------------------------------------
    this.Given(/^I verify the Asset Instance page$/, function (callback) {
        multiForecastPO.assetInstanceHeader().isPresent().then(function () {
            callback();
        });
    });

    this.Given(/^I click Tags tab$/, function (callback) {
        multiForecastPO.assetInstanceTagTab().then(function () {
            callback();
        });
    });

    this.When(/^I click on add tags icon$/, function (callback) {
        multiForecastPO.addTags().then(function () {
            callback();
        });
    });

    this.When(/^I add the (.*) to source textbox$/, function (title, callback) {
        multiForecastPO.sourceID().clear().then(function () {
            multiForecastPO.sourceID().sendKeys(title).then(function () {
                callback();
            });
        });
    });

    this.When(/^I add the (.*) to description textbox$/, function (title, callback) {
        multiForecastPO.tagDesc().clear().then(function () {
            multiForecastPO.tagDesc().sendKeys(title).then(function () {
                callback();
            });
        });
    });

    this.When(/^I add the (.*) to tag textbox$/, function (title, callback) {
        multiForecastPO.tagName().clear().then(function () {
            multiForecastPO.tagName().sendKeys(title).then(function () {
                callback();
            });
        });
    });

    this.When(/^I select the (.*) from Tag Classification dropdown$/, function (index, callback) {
        multiForecastPO.tagClassSelect().then(function () {
            callback();
        });
    });

    this.When(/^I select the active from Status dropdown$/, function (callback) {
        multiForecastPO.statusSelect().then(function () {
            callback();
        });
    });

    this.Then(/^I click on Create button$/, function (callback) {
        multiForecastPO.createButton().then(function () {
            browser.sleep(delay).then(function () {
                callback();
            });
        });
    });

    this.When(/^I click on the (.*) link$/, function (tagname, callback) {
        var ele = element(by.xpath("//table[contains(@class,'table--rows')]//tr/td//div[not(@class='ng-hide')]//a[text()='"+tagname+"']"));
        ele.click().then(function(){
            callback();
        });
    });

    this.When(/^I click on the UoM Settings$/, function (callback) {
        multiForecastPO.UoMText().then(function () {
            multiForecastPO.UoMSettings().then(function () {
                callback();
            });
        });
    });

    this.When(/^I enter the (.*) value$/, function (uom, callback) {
        multiForecastPO.UoMDefinition().click().then(function(){
            multiForecastPO.UoMDefinition().clear().then(function () {
                multiForecastPO.UoMDefinition().sendKeys(uom).then(function () {
                    callback();
                });
            });
        });
    });

    this.When(/^I click on Save tag button$/, function (callback) {
        multiForecastPO.saveUoMChange().then(function () {
            browser.sleep(delay).then(function () {
                multiForecastPO.backTagButton().then(function () {
                    callback();
                });
            });
        });
    });

    this.When(/^I click on the delete tag Icon$/, function (callback) {
        multiForecastPO.deleteTagIcon().then(function () {
            callback();
        });
    });

    this.When(/^I click on the delete tag button$/, function (callback) {
        multiForecastPO.deleteTagButton().then(function () {
            browser.sleep(delay).then(function () {
                callback();
            });
        });
    });

    this.When(/^I click on Dashboard context$/, function (callback) {
        multiForecastPO.dashboardEditContext().then(function () {
            callback();
        });
    });

    this.When(/^I click on Delete Dashboard$/, function (callback) {
        multiForecastPO.dashboardDelete().then(function () {
            callback();
        });
    });

    this.When(/^I click on Delete Ok button$/, function (callback) {
        multiForecastPO.deleteDashboardOkButton().then(function () {
            browser.sleep(delay).then(function () {
                callback();
            });
        });
    });

};
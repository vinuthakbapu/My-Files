/**
 * Created by 212677088 on 12/28/2017.
 */
var myStepDefinitionsWrapper;
myStepDefinitionsWrapper = function () {
    'use strict';

    this.Given(/^I prepare the test data (.*)$/, function (name, callback) {
        multiForecastRestPO.generateDataForTags(name);
        callback();
    });


    this.Then(/^I inject time series (.*)$/, function (name, callback) {
        multiForecastRestPO.postTimeSeriesData(name);
        callback();
    });

};

module.exports = myStepDefinitionsWrapper;
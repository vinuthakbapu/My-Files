/**
 * Created by 212677088 on 9/17/2018.
 */
module.exports = function () {
    var delay = 12000;
    var util = require("util");
    var data = require('../TestData/OPMAPIEndpoints.json').data.env[browser.params.environment];
    var results;
    var histCount = [];
    var errCount = [];
    var countArray =[];

    this.Given(/^I run timeseries5 fetch query for (.*) with (.*) and (.*) to get (.*)$/, function (params, startTime, endTime, op, callback) {
        var tagNames;
        var URL;
        if(params === "controllerConfiguration"){
            URL = data.fetchQuery.controllerurl;
            tagNames = data[params];
        }else{
            URL = data.fetchQuery.url;
            tagNames = data[params];
        }
        console.log("tagnames-->" + tagNames);
        var startTime = new Date();
        startTime.setDate(startTime.getDate()-1);
        startTime = startTime.toISOString().split('T')[0];
        startTime = startTime + 'T00:00:00Z';
        console.log('startTime-->',startTime);
        var endTime = new Date();
        endTime.setDate(endTime.getDate()-2);
        endTime = endTime.toISOString().split('T')[0];
        endTime = endTime + 'T00:00:00Z';
        console.log('endTime-->',endTime);

        var URL = util.format(URL, op, tagNames, endTime, startTime);
        console.log("URL-->" + URL);
        multiForecastRestPO.getQueryResults(URL).then(function (serviceData) {
            results = serviceData;
            callback();
        });
    });

    this.Given(/^I verify the Average PV Limits header name$/, function (callback) {
        loopDashboardPO.getElement('averagePV').getText().then(function (val) {
            console.log("averagePV Title:" + val);
            TestHelper.assertEqual(val, 'Average PV Limits exceeded');
            callback();
        });
    });
    this.Then(/^I verify the PV Variance header name$/, function (callback) {
        loopDashboardPO.getElement('pvVariance').getText().then(function (val) {
            console.log("pvVariance Title:" + val);
            TestHelper.assertEqual(val, 'PV Variance [%]');
            callback();
        });
    });
    this.Then(/^I verify the PV Variability header name$/, function (callback) {
        loopDashboardPO.getElement('pvVariability').getText().then(function (val) {
            console.log("totalMode Title:" + val);
            TestHelper.assertEqual(val, 'PV Variability');
            callback();
        });
    });
    this.Given(/^I verify Average PV Limits value$/, function (callback) {
        loopDashboardPO.getElement('averagePVval').getText().then(function (val) {
            console.log("averagePVval Value:" + val);
            var expectedVal = 0;
            results.forEach(function (obj) {
                if (obj.tagId === "Loop1.Percentage Limits Exceeded") {
                    console.log("postman value-->" + obj.data[0].v);
                    expectedVal = parseFloat(obj.data[0].v, 10);
                    expectedVal = loopDashboardPO.roundDecimalPoints(expectedVal);
                }
            });
            console.log('expectedVal:' + expectedVal);
            TestHelper.assertEqual(parseFloat(val, 10), expectedVal);
            callback();
        });
    });
    this.Then(/^I verify PV Variance value$/, function (callback) {
        loopDashboardPO.getElement('pvVarianceVal').getText().then(function (val) {
            console.log("pvVarianceVal Value:" + val);
            var expectedVal = 0;
            results.forEach(function (obj) {
                if (obj.tagId === "Loop1.PV Variance") {
                    console.log("postman value-->" + obj.data[0].v);
                    expectedVal = parseFloat(obj.data[0].v, 10);
                    expectedVal = loopDashboardPO.roundDecimalPoints(expectedVal);
                }
            });
            console.log('expectedVal:' + expectedVal);
            TestHelper.assertEqual(parseFloat(val, 10), expectedVal);
            callback();
        });
    });
    this.Then(/^I verify PV Variability value$/, function (callback) {
        loopDashboardPO.getElement('pvVariabilityVal').getText().then(function (val) {
            console.log("pvVariabilityVal Value:" + val);
            var expectedVal = 0;
            results.forEach(function (obj) {
                if (obj.tagId === "Loop1.PV Variability") {
                    console.log("postman value-->" + obj.data[0].v);
                    expectedVal = parseFloat(obj.data[0].v, 10);
                    expectedVal = loopDashboardPO.roundDecimalPoints(expectedVal);
                }
            });
            console.log('expectedVal:' + expectedVal);
            TestHelper.assertEqual(parseFloat(val, 10), expectedVal);
            callback();
        });
    });
};
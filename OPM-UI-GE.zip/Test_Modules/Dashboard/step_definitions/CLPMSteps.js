module.exports = function () {
    var delay = 12000;
    var util = require("util");
    var data = require('../TestData/OPMAPIEndpoints.json').data.env[browser.params.environment];
    var results;
    var histCount = [];
    var errCount = [];
    var countArray =[];
    this.setDefaultTimeout(990000);

    this.Given(/^I run timeseries fetch query for (.*) with (.*) and (.*) to get (.*)$/, function (params, startTime, endTime, op, callback) {
        var tagNames;
        var URL;
        if(params === "controllerConfiguration"){
            URL = data.fetchQuery.controllerurl;
            tagNames = data[params];
        }else{
            URL = data.fetchQuery.url;
            tagNames = data[params];
        }
        console.log("tagnames-->" + tagNames);
        var URL = util.format(URL, op, tagNames, startTime, endTime);
        console.log("URL-->" + URL);
        multiForecastRestPO.getQueryResults(URL).then(function (serviceData) {
            results = serviceData;
            callback();
        });
    });
    //------------------------------------------Card details---------------------------------------------------------
    this.Then(/^I click on the date dropdown$/, function (callback) {
        browser.sleep(delay).then(function () {
            loopDashboardPO.clickElement('dateDropDown').then(function () {
                callback();
            });
        });
    });

    this.Then(/^I select custom time span$/, function (callback) {
        loopDashboardPO.clickElement('customTimeSpan').then(function () {
            browser.sleep(delay).then(function () {
                callback();
            });
        });
    });

    this.Then(/^I enter from date (.*)$/, function (setDate, callback) {
        browser.driver.executeScript("arguments[0].setAttribute('range', arguments[1])",
            loopDashboardPO.getElement('customdatepicker').getWebElement(),
            setDate).then(function(){
                browser.sleep(delay).then(function () {
                    callback();
                });
            });
    });
};
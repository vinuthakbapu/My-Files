
module.exports = function() {
    // this.setDefaultTimeout(60000);

    this.Then(/^I should see Navigation Title in widget config page$/, function (callback) {
        console.log('check to see Navigation Title in widget config page');
        AdvancedNavPage.chkAdvNavTitle().then(function (present) {
            console.log('Navigation Title is present: ' + present);
            TestHelper.assertTrue(present, 'not present');
            callback();
        });
    });
    this.Then(/^I should see a plus sign next to navigation in widget config page$/, function (callback) {
        console.log('check to see plus sign next to navigation in widget config page');
        AdvancedNavPage.chkAdvNavPlusSign().then(function (present) {
            console.log('plus sign next to navigation is present: ' + present);
            TestHelper.assertTrue(present, 'not present');
            callback();
        });
    });
    this.Then(/^I should see (\d+) destinations added to navigation section$/, function (arg1, callback) {
        console.log('check to see if there is ' + arg1 + ' navigation added');
        AdvancedNavPage.chkNavAllCount().count().then(function(count) {
            expect(count).to.be.equal(Number(arg1));
            callback();
        });
    });
    this.Then(/^I click on plus sign next to navigation in widget config page$/, function (callback) {
        AdvancedNavPage.clickAdvNavPlusSign().then(function() {
            console.log('+ sign clicked on');
            callback();
        });
    });
    this.Then(/^I should see a select destination drop down in navigation section$/, function (callback) {
        AdvancedNavPage.chkNavDropDown().then(function(present) {
            TestHelper.assertTrue(present, 'not present');
            callback();
        });
    });
    this.Then(/^I should see a toggle button next to the destination$/, function (callback) {
        AdvancedNavPage.chkToggleButton().then(function(present) {
            TestHelper.assertTrue(present, 'not present');
            callback();
        });
    });
    this.Then(/^Toggle button in navigation with index (\d+) should be switched ON by default$/, function (index, callback) {
        //var blueColorMeansToggleButtonIsOn = "rgba(9, 134, 164, 1)";
        browser.sleep(1000).then(function() {
            AdvancedNavPage.checkToggleButton(index).then(function(isSetToOn) {
                console.log("Button is: " + isSetToOn);
                expect(isSetToOn).to.equal(true);
                callback();
            });
        });
    });
    this.Then(/^I should see (\d+) x icons to delete a destination from Navigation$/, function (arg1, callback) {
        console.log('check to see if there are ' + arg1 + ' x icon(s) used to delete destination(s)');
        AdvancedNavPage.chkAll_x_icon().then(function(count) {
            expect(count).to.be.equal(Number(arg1));
            callback();
        });
    });
    this.Then(/^I click on select destination drop down "([^"]*)" in navigation section$/, function (arg1, callback) {
        console.log('Click on drop down menu for Destination');
        AdvancedNavPage.clickOnDestinationDropDown(arg1-1).then(function() {
            callback();
        });
    });
    this.Then(/^I click on destination drop down (\d+) to select "([^"]*)" in navigation section$/, function (index, arg1, callback) {
        console.log('Click on drop down menu for Destination');
        AdvancedNavPage.clickOnDestinationDropDown(index-1).then(function() {
            AdvancedNavPage.clickOnDestinationDropDownByName(arg1).then(function() {
                AdvancedNavPage.clickOnDestinationDropDown(index-1).then(function() {
                    callback();
                });
            });
        });
    });
    this.Then(/^I should see "([^"]*)" as navigation destination$/, function (arg1, callback) {
        console.log('Check if ' + arg1 + ' is displayed under Destination dropDown button');
        AdvancedNavPage.chkItemNameUnderDestination(arg1).then(function(textValue) {
            expect(textValue).to.be.equal(arg1);
            callback();
        });
    });
    this.Then(/^I will select "([^"]*)" as a destination for navigation for dropDown "([^"]*)"$/,
        function (NameOfAsset, index, callback) {
        browser.sleep(3000).then(function() {
            AdvancedNavPage.clickOnDestinationDropDownByIndexAndName(index, NameOfAsset).then(function() {
                callback();
            });
        });
    });


    this.Then(/^I select "([^"]*)" as a destination for navigation$/, function (NameOfAsset, callback) {
        browser.sleep(2000).then(function() {
            AdvancedNavPage.clickOnDestinationDropDownByNameNoIndex(NameOfAsset).click().then(function() {
                callback();
            });
        });
    });
    this.Then(/^I should see "([^"]*)" link under the navigation$/, function (arg1, callback) {
        browser.sleep(3000).then(function() {
            AdvancedNavPage.getContextLinkUnderNavigation().then(function(textValue) {
                console.log("Link text = " + textValue);
                expect(textValue).to.be.equal(arg1);
                callback()
            });
        });
    });
    this.Then(/^I click on "([^"]*)"$/, function (arg1, callback) {
        AdvancedNavPage.clickOnSetContextLink(arg1).then(function(linkClicked) {
            console.log("Link clicked on = " + linkClicked);
            callback();
        });
    });
    this.Then(/^I click on "([^"]*)" (\d+)$/, function (arg1, index, callback) {
        AdvancedNavPage.clickOnSetContextLinkWithIndex(arg1, index-1).then(function(linkClicked) {
            console.log("Link clicked on = " + linkClicked);
            callback();
        });
    });
    this.Then(/^Done button should be greyed out in widget config page$/, function (callback) {
        AdvancedNavPage.chkDoneButtonThatHasBeenGreyedOut().then(function(isDoneButtonGreyedOut) {
            console.log("Link available = " + isDoneButtonGreyedOut);
            callback();
        });
    });
    this.Then(/^selected asset context name "([^"]*)" should be displayed under Navigation Dashboard$/, function (asset, callback) {
        AdvancedNavPage.checkNewlyCreatedAndLinkedDashboadAssetItem().then(function(returnedValue) {
            expect(asset).to.be.equal(returnedValue);
            callback();
        });
    });

    this.Then(/^selected asset context name "([^"]*)" should be displayed under Navigation Dashboard (\d+)$/,
                                        function (asset, index, callback) {
        AdvancedNavPage.checkNewlyCreatedAndLinkedDashboadAssetItemArray(index-1).then(function(returnedValue) {
            expect(asset).to.be.equal(returnedValue);
            callback();
        });
    });
    this.Then(/^I should see x icon to delete the context next to the context name$/, function (callback) {
        AdvancedNavPage.checkThe_X_iconNextToAsset().then(function(xIcon) {
            console.log("x icon next to Asset is = " + xIcon);
            callback();
        });
    });
    this.Then(/^I should see dashboard selector drop down in edit widget page under Navigation Dashboard$/, function (callback) {
        AdvancedNavPage.checkDashboardSelectorDropDown().then(function(dashboardSelectorIsShown) {
            console.log("dashBoard selected is shown = " + dashboardSelectorIsShown);
            callback();
        });
    });
    this.Then(/^I select the dashboard "([^"]*)" from the drop down under Navigation Dashboard$/, function (asset, callback) {
        AdvancedNavPage.selectDashboardSelectorDropDown().then(function() {
            console.log('Clicked on the deck selector dropDown');
            browser.sleep(4000).then(function() {
                AdvancedNavPage.clickSelectedOption2(asset).then(function() {
                    callback();
                })
            })
        });
    });
    this.Then(/^I should see the arrow icon for navigating to default destination$/, function (callback) {
        AdvancedNavPage.checkArrowIcon().then(function() {
            callback();
        });
    });
    this.Then(/^I should not see navigation kebab menu in widget$/, function (callback) {
        AdvancedNavPage.checkNavigationKebabMenuInWidget().then(function(BooleanValue) {
            expect(BooleanValue).to.be.equal(false);
            callback();
        });
    });
    this.Then(/^I click on arrow icon for navigating to default destination$/, function (callback) {
        browser.sleep(2000).then(function() {
            AdvancedNavPage.clickArrowIcon().then(function() {
                callback();
            });
        });
    });
    this.Then(/^I should not see edit card option in edit card menu in new Chromeless browser$/, function (callback) {
        AdvancedNavPage.checkEditCardOptionMenu().then(function(isDisplayed) {
            expect(isDisplayed).to.be.equal(false);
            callback();
        });
    });
    this.Then(/^I should see navigation kebab menu in widget$/, function (callback) {
        AdvancedNavPage.checkKebabMenuInWidget().then(function() {
            callback();
        });
    });
    this.Then(/^I click on navigation kebab menu in widget$/, function (callback) {
        AdvancedNavPage.clickKebabMenuInWidget().then(function() {
            callback();
        });
    });
    this.Then(/^I should see navigation kebab menu in current widget$/, function (callback) {
        AdvancedNavPage.checkKebabMenuInCurrentWidget().then(function() {
            callback();
        });
    });
    this.Then(/^I click on navigation kebab menu in current widget$/, function (callback) {
        AdvancedNavPage.clickKebabMenuInCurrentWidget().then(function() {
            callback();
        });
    });
    this.Then(/^I should see "([^"]*)" options in Navigation Kebab menu in widget$/, function (arg1, callback) {
        AdvancedNavPage.checkCountOfNavKebabMenuInWidget().count().then(function(count) {
            expect(count).to.be.equal(Number(arg1));
            callback();
        });
    });
    this.Then(/^I should see "([^"]*)" in Navigation kebab menu$/, function (arg1, callback) {
        AdvancedNavPage.checkItemInNavigationKebabDropDownMenu(arg1).then(function() {
            callback();
        });
    });
    this.Then(/^I select "([^"]*)" from Navigation kebab menu$/, function (arg1, callback) {
        AdvancedNavPage.selectItemInNavigationKebabDropDownMenu(arg1).then(function() {
            callback();
        });
    });
    this.Then(/^I should see "([^"]*)" Micro app$/, function (arg1, callback) {
        browser.sleep(5000).then(function() {
            AdvancedNavPage.checkMicroAppNameToBePresent(arg1).then(function(NameOfApp) {
                console.log("Title of page: " + NameOfApp);
                expect(arg1).to.be.equal(NameOfApp);
                callback();
            });
        });
    });
    this.Then(/^I should see "([^"]*)" Micro app "([^"]*)"$/, function (arg1, arg2, callback) {
        browser.sleep(5000).then(function() {
            AdvancedNavPage.checkAlertMicroAppNameToBePresent(arg1).then(function(NameOfApp) {
                console.log("Title of page: " + NameOfApp);
                expect(arg1).to.be.equal(NameOfApp);
                callback();
            });
        });
    });
    this.Then(/^I should not see dashboard kebab menu$/, function (callback) {
        AdvancedNavPage.checkDashboardKebabMenuIfExists(isDisplayed).then(function() {
            expect(isDisplayed).to.be.equal(false);
            callback();
        });
    });
    this.Then(/^I should see asterisks next to all required fields$/, function (callback) {
        AdvancedNavPage.getCountOfAssetsUnderNavigation().then(function(assetSize) {
            for (var indexObj = 0; indexObj < assetSize; indexObj = indexObj + 1) {
                (function() {
                    var index = indexObj;
                    AdvancedNavPage.checkAsteriskForAllNavigationAsset(index).then(function () {
                        console.log('Check asterisk for asset at index: ' + index);
                    });
                }());
            }
        });
        callback();
    });

    this.Then(/^I should see asterisks (\d+) for required field$/, function (arg1, callback) {
        AdvancedNavPage.checkAsteriskForAllNavigationAsset(arg1 - 1).then(function() {
            console.log('Check asterisk for asset at index:' + (arg1 - 1));
            callback();
        });
    });

    this.Then(/^I should not see asterrisk next to setcontext field (\d+)$/, function (arg1, callback) {
        AdvancedNavPage.checkThe_X_iconNextToAssetNotPresent(arg1-1).then(function (isVisible) {
            console.log('Availability of asterrisk is: ' + isVisible);
            expect(isVisible).to.be.equal(false);
            callback();
        });
    });

    this.Then(/^I should not see asterrisk next to dashboard selection dropdown (\d+)$/, function (index, callback) {
        AdvancedNavPage.checkThe_X_iconNextToDashboardDropDownNotPresent(index - 1).then(function (present) {
            console.log('Check asterisk next to dashboard selection dropdown');
            expect(present).to.be.equal(false);
            callback();
        });
    });

    this.Then(/^I should toggle off navigation option (\d+) in widget config page$/, function (arg1, callback) {
        browser.sleep(1000).then(function() {
            AdvancedNavPage.toggleOffNavigationOption(arg1).then(function() {
                callback();
            });
        });
    });
    this.Then(/^I should toggle on navigation option (\d+) in widget config page$/, function (arg1, callback) {
        browser.sleep(1000).then(function() {
            AdvancedNavPage.toggleOffNavigationOption(arg1).then(function() {
                callback();
            });
        });
    });
    this.Then(/^I click on "([^"]*)" th x icon in navigation section$/, function (arg1, callback) {
        AdvancedNavPage.clickOnXButtonToDeleteAsset(arg1).then(function() {
            callback();
        });
    });

    this.Then(/^I should see the dashboard name "([^"]*)" opened in chromeless browser$/, function (arg1, callback) {
        browser.sleep(3000).then(function() {
            AdvancedNavPage.checkDashboardMicroAppNameToBePresent(arg1).then(function(NameOfApp) {
                console.log("Name of app displayed: " + NameOfApp);
                expect(arg1).to.be.contains(NameOfApp);
                callback();
            });
        });
    });

    this.Then(/^I can see the dashboard name "([^"]*)" opened in chromeless browser$/, function (arg1, callback) {
        browser.sleep(3000).then(function() {
            AdvancedNavPage.checkDashboardMicroAppNameInListToBePresent().then(function(NameOfApp) {
                console.log("Name of app displayed: " + NameOfApp);
                // var isViewNameMatching = NameOfApp.indexOf(arg1) !== -1;
                // console.log('isViewNameMatching: ',NameOfApp.indexOf(arg1));
                // expect(isViewNameMatching).to.equal(true);
                // // expect(NameOfApp).to.be.equal(arg1);
                expect(NameOfApp).to.be.contains(arg1);
                callback();
            });
        });
    });

    this.Then(/^I should see a toggle button selected$/, function (callback) {
        console.log('check to see toggle is ON');
        AdvancedNavPage.ChkAdvNavToggle(0).then(function (present) {
            console.log('check to see toggle1 is ON: ' + present);
            // TestHelper.assertTrue(present, 'not present');
            AdvancedNavPage.ChkAdvNavToggle(1).then(function (present) {
                console.log('check to see toggle2 is ON: ' + present);
                AdvancedNavPage.ChkAdvNavToggle(2).then(function (present) {
                    console.log('check to see toggle3 is ON: ' + present);
                    AdvancedNavPage.ChkAdvNavToggle(3).then(function (present) {
                        console.log('check to see toggle4 is ON: ' + present);
                        AdvancedNavPage.ChkAdvNavToggle(4).then(function (present) {
                            console.log('check to see toggle5 is ON: ' + present);
                            AdvancedNavPage.ChkAdvNavToggle(5).then(function (present) {
                                console.log('check to see toggle6 is ON: ' + present);
                                callback();
                            });
                        });
                    });
                });
            });
        });
    });


    this.Then(/^I click on toggle button (\d+) in navigation section$/, function (num, callback) {
        console.log('check to see toggle#' + num + ' is ON');
        AdvancedNavPage.ClickAdvNavToggle(Number(num-1)).then(function () {
            console.log('clicked toggle #: ' + num);
            AdvancedNavPage.ChkAdvNavToggle(Number(num-1)).then(function (present) {
                console.log('check toggle# ' + num + ' is selected: ' + present);
                callback();
            });
        });
    });
    this.Then(/^I click on plus sign in advanced navigation section$/, function (callback) {
        AdvancedNavPage.clickAdvNavPlusSign().then(function () {
            browser.sleep(2000).then(function(){
                callback();
            })
        });
    });

    this.When(/^I click on dashboard drop down list$/, function (callback) {
        createviewpage.clickViewSelectorDropdown().then(function () {
            callback();
        });
    });


    this.Then(/^I should see "([^"]*)" Micro app chart container$/, function (arg1, callback) {
        browser.sleep(10000).then(function() {
            AdvancedNavPage.checkMicroAppContainerToBePresent(arg1).then(function(isPresent) {
                console.log("MicroAppIsPresent: " + isPresent);
                callback();
            });
        });
    });

};

var currentpage = 'DashboardAppPages';
var dash_cnt = 0;
var name = "";

module.exports = function() {
    // this.setDefaultTimeout(60000);

    this.Given(/^I should see set as favorite dashboard link in dashboard menu$/, function (callback) {
        console.log("about to see to set as favorite dashboard");
        createviewpage.clickCardActionMenuBtn().then(function () {
            console.log("clicked on card action menu button");
            dem.findElement(currentpage, 'dropdown').getAttribute('hidden').then(function(visible){
                if(visible) {
                    console.log("card action menu popup is open");
                    favoritesPage.chkSetFavoriteDashboardLink().then(function () {
                        console.log("clicked on set as default dashboard link");
                        callback();
                    });
                }
            })
        });
    });

    this.Given(/^I should click on set as favorite dashboard link in dashboard menu$/, function (callback) {
        console.log("click set a favorite dashboard link");
        createviewpage.clickCardActionMenuBtn().then(function () {
            console.log("clicked on card action menu button");
            dem.findElement(currentpage, 'dropdown').getAttribute('hidden').then(function(visible){
                if(visible) {
                    console.log("card action menu popup is open");
                    favoritesPage.clickSetFavoriteDashboardLink().then(function () {
                        console.log("clicked on set as favorite dashboard link");
                        callback();
                    });
                }
            })
        });
    });

    this.When(/^I should see Favorites option is listed in left nav under Dashboard Micro App$/, function (callback) {
        favoritesPage.chkDashboardFavorites().then(function (present) {
            expect(present).to.equal(true);
            callback();
        });
    });
    this.When(/^I click on favorites option in the left nav$/, function (callback) {
        favoritesPage.clickDashboardFavorites().then(function (present) {
            expect(present).to.equal(true);
            callback();
        });
    });
    this.When(/^Favorites page should open up$/, function (callback) {
        favoritesPage.chkFavoritesPage().then(function (present) {
            expect(present).to.equal(true);
            callback();
        });
    });
    this.When(/^I should not see "([^"]*)" in favorites page$/, function (dash, callback) {
        favoritesPage.chkDashNotExistInFavPage(dash).then(function (present) {
            console.log(dash + ' is listed on the favorites page: ' + present);
            expect(present).to.equal(true);
            callback();
        });
    });
    this.When(/^I should see "([^"]*)" in favorites page$/, function (dash, callback) {
        favoritesPage.chkDashExistInFavPage(dash).then(function (present) {
            console.log(dash + ' is listed on the favorites page: ' + present);
            expect(present).to.equal(true);
            callback();
        });
    });
    this.When(/^Set the value of favorite dashboard counter$/, function (callback) {
        favoritesPage.cntFavoriteDashboard().then(function (cnt) {
            dash_cnt = cnt;
            console.log('dash_cnt' + dash_cnt);
            callback();
        });
    });

    this.When(/^Check the count of favorite dashboard after adding$/, function (callback) {
        favoritesPage.cntFavoriteDashboard().then(function (cnt) {
            console.log('dash_cnt and name' + cnt);
            expect(cnt).to.equal(dash_cnt+1);
            callback();
        });
    });

    this.When(/^Check the name "([^"]*)" of last dashboard added$/, function (dashname, callback) {
        favoritesPage.cntFavoriteDashboard().then(function (cnt) {
            console.log('number of dashbaords on favorite page: ' + cnt);
            favoritesPage.getLastFavoriteDashboardName(cnt - 1).then(function (name) {
                console.log('favorite dashboard number:  ' + (cnt - 1) + ' name is : ' + name);
                expect(name).to.equal(dashname);
                callback();
            });
        });
    });
    this.When(/^Check the last favorite dashboard displays the context name "([^"]*)"$/, function (dashname, callback) {
        favoritesPage.cntFavoriteDashboard().then(function (cnt) {
            console.log('number of dashbaords on favorite page: ' + cnt);
            favoritesPage.getLastFavoriteDashboardAsset(cnt - 1).then(function (name) {
                console.log('favorite dashboard number:  ' + (cnt - 1) + ' name is : ' + name);
                expect(name).to.equal(dashname);
                callback();
            });
        });
    });
    this.When(/^Check the blue star is displayed$/, function (callback) {
        favoritesPage.cntFavoriteDashboard().then(function (cnt) {
            console.log('number of dashbaords on favorite page: ' + cnt);
            favoritesPage.chkFavoriteDashboardStarDisplay(cnt - 1).then(function (present) {
                expect(present).to.equal(true);
                callback();
            })
        })
    });
    this.When(/^Check the count of favorite dashboard thumbnails$/, function (callback) {
        favoritesPage.cntFavoriteDashboard().then(function (dashcnt) {
            console.log('dash_cnt and name' + dashcnt);
            favoritesPage.cntFavoriteDashboardThumbnail().then(function (cnt) {
                expect(cnt).to.equal(dashcnt);
                callback();
            })
        })
    });
    this.When(/^Check total number of favorite stars$/, function (callback) {
        favoritesPage.cntFavoriteDashboard().then(function (dashcnt) {
            console.log('dash_cnt and name' + dashcnt);
            favoritesPage.cntFavoriteDashboardStars().then(function (cnt) {
                expect(cnt).to.equal(dashcnt);
                callback();
            })
        })
    });
    this.When(/^Check the name "([^"]*)" in the favorite dashboard page$/, function (dashName, callback) {
        favoritesPage.chkfavDashboard(dashName).then(function (present) {
            console.log("Card is present  = " + present);
            expect(present).to.equal(true);
            callback();
        });
    });

    this.When(/^Check the name "([^"]*)" not present in the favorite dashboard page$/, function (dashName, callback) {
        favoritesPage.chkfavDashboardPresent(dashName).then(function (present) {
            console.log("Card is present  = " + present);
            expect(present).to.equal(false);
            callback();
        });
    });

    this.Given(/^I should see a check mark displayed next to set as favorite dashboard option in dashboard menu$/, function (callback) {
        console.log("check mark displayed for favorite: ");
        createviewpage.clickCardActionMenuBtn().then(function () {
            console.log("clicked on card action menu button");
            dem.findElement(currentpage, 'dropdown').getAttribute('hidden').then(function(visible){
                if(visible) {
                    console.log("card action menu popup is open");
                    favoritesPage.chkSetFavoriteDashboardCheck().then(function (present) {
                        console.log('before check mark = ' + present)
                        expect(present).to.equal(true);
                        console.log("check mark is displayed next to set as default dashboard option :" + present);
                        callback();
                    });
                }
            })
        });
    });

    /*
    this.Given(/^I should not see check mark displayed next to set as favorite dashboard option in dashboard menu$/, function (callback) {
        createviewpage.clickCardActionMenuBtn().then(function () {
            console.log("clicked on card action menu button");
            dem.findElement(currentpage, 'dropdown').getAttribute('hidden').then(function(visible){
                if(visible) {
                    console.log("card action menu popup is open : " + visible);
                    element.all(by.css('#viewMenuList #makeFavorite i.fa-check')).then(function(items) {
                        if(items.length > 0) {
                            console.log("check mark is displayed next to set as favorite dashboard option :" + items.length);
                            callback();
                        }else{
                            console.log("check mark is not displayed next to set as favorite dashboard option :" + items.length);
                            callback();
                        }
                    });

                }
            })
        });
    });
    */
    this.Given(/^I should not see a check mark displayed next to set as favorite dashboard option in dashboard menu$/, function (callback) {
        console.log("check mark displayed for favorite: ");
        createviewpage.clickCardActionMenuBtn().then(function () {
            console.log("clicked on card action menu button");
            dem.findElement(currentpage, 'dropdown').getAttribute('hidden').then(function(visible){
                if (visible) {
                    console.log("card action menu popup is open");
                    favoritesPage.chkSetFavoriteDashboardCheckNotPresent().then(function (present) {
                        console.log("check mark is displayed next to set as default dashboard option :" + present);
                        expect(present).to.equal(false);
                        callback();
                    });
                }
            })
        });
    });

    this.Given(/^click on the star next to the dashboard name "([^"]*)"$/, function (dashname, callback) {
        favoritesPage.clickFavoriteDashboardStar(dashname).then(function (present) {
            expect(present).to.equal(true);
            console.log("Clicked on star next to :" + dashname);
            callback();
        });
    });
    this.Then(/^Refresh browser$/,function (callback){
        browser.refresh().then(function(){
            callback();
        });
    });
    this.When(/^Check the count of favorite dashboard after removing$/, function (callback) {
        favoritesPage.cntFavoriteDashboard().then(function (cnt) {
            console.log('dash_cnt and name' + cnt);
            expect(cnt).to.equal(dash_cnt-1);
            callback();
        });
    });
    this.When(/^click on the thumbnail of dashboard "([^"]*)"$/, function (dashboardName, callback) {
        favoritesPage.clickFavoriteDashboardthumbnail(dashboardName).then(function () {
            callback();
        });
    });
    this.Then(/^I should see (\d+) dashboards in favorites page$/,function(num, callback){
        console.log('fav dashboard count should be: '+num)
        favoritesPage.cntFavoriteDashboardStars().then(function (cnt) {
            console.log('Actual fav dashboard count: '+cnt);
            expect(cnt).to.equal(Number(num));
            callback();
        });
    });

    this.Given(/^Unfavorite all dashboards$/, function (callback) {
        console.log('about to unfavorite all dashboards');
        favoritesPage.cntFavoriteDashboardStars().then(function (cnt) {
            console.log('cntFavoriteDashboardStars: ' + cnt);
            var step = function (i, done) {
                if (i < done) {
                    favoritesPage.ClickFavoriteDashboardStarDisplay(i).then(function () {
                        browser.sleep(500);
                        console.log('deleted dash# : ' + i);
                        step(i+1, done)
                    });
                }
                else {
                    console.log('all dashboards are deleted');
                    callback();
                }
            };
            step(0,cnt);
        });
    });

    this.Given(/^Unfavorite "([^"]*)" if it exists$/, function (dashname, callback) {
        favoritesPage.chkfavDashboardExists(dashname).then(function (present) {
            if(present) {
                console.log('Fav Dash '+ dashname + ' : ' + present);
                favoritesPage.clickFavoriteDashboardStar(dashname).then(function (present) {
                        expect(present).to.equal(true);
                        console.log("Clicked on star next to :" + dashname);
                        callback();
                    }
                );
            }else {
                console.log('view not found');
                callback();
            }
        });
    });
    this.Given(/^It should give a dashboard does not exist message$/,function(callback) {
        console.log('Trying to navigate to a dashboard which does not exist ');
        favoritesPage.chkFavoriteDashboardExists().then(function (present) {
            expect(present).to.equal(true);
            console.log('After checking for dashboard');
            callback();

        });
    });
    this.Given(/^I should see the asset "([^"]*)"$/,function(asset1,callback){
        favoritesPage.getAssetContext().then(function(currentAsset){
            console.log('Context is: ', currentAsset);
            expect(asset1).to.equal(currentAsset);
            callback();
        });
    });
}

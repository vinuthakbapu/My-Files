
module.exports = function() {
    // this.setDefaultTimeout(60000);

    this.Then(/^satellite view should be enabled by default$/, function (callback) {
        editGeoSpatialWidgetPage.checkSatelliteViewIsSelectedByDefault().then(function (isSelected) {
            expect(true).to.equal(isSelected)
            callback();
        });
    });

    this.Then(/^I add the asset layer$/, function (callback) {
        // Write code here that turns the phrase above into concrete actions
        editGeoSpatialWidgetPage.clickAddAssetLayerIcon().then(function(){
            console.log('Clicked on the add new asset layer icon ');
            callback();
        });
    });


    this.Then(/^I enter "([^"]*)" asset layer sequence$/, function (sequence, callback) {
        editGeoSpatialWidgetPage.getAssetLayerSequenceInputField().clear().sendKeys(sequence).then(function () {
            console.log('entered the asset layer sequence # ' + sequence);
            callback();
        });
    });

    this.Then(/^I enter "([^"]*)" asset layer title$/, function (title, callback) {
        editGeoSpatialWidgetPage.getAssetLayerTitleInputField().sendKeys(title).then(function () {
            console.log('entered the asset layer sequence # ' + title);
            callback();
        });
    });

    this.Then(/^I deselect all the Assets$/, function (callback) {
        editGeoSpatialWidgetPage.deselectAllAsset().then(function(){
            callback();
        });
    });

    this.Then(/^I select "([^"]*)" asset$/, function (assetName, callback) {
        editGeoSpatialWidgetPage.SelectAsset(assetName).then(function(){
            console.log('entered the asset name # ' + assetName);
            callback();

        });
    });

    this.Then(/^I save the asset layer$/, function (callback) {
        editGeoSpatialWidgetPage.saveAssetLayer().then(function(){
            browser.sleep(5000).then(function(){
                callback();
            })
        });
    });

    this.Then(/^Asset layer should be saved$/, function (callback) {
        editGeoSpatialWidgetPage.getSavedAssetLayer().isDisplayed().then(function (isDisplayed) {
            expect(true).to.equal(isDisplayed)
            callback();
        });
    });

    this.Then(/^Asset layer should be deleted/, function (callback) {
        browser.manage().timeouts().implicitlyWait(5000);
        editGeoSpatialWidgetPage.getSavedAssetLayer().isPresent().then(function (isPresent) {
            expect(false).to.equal(isPresent)
            browser.manage().timeouts().implicitlyWait(50000);
            callback();
        }).catch(function(e){
            console.log(e)
        });
    });

    this.Then(/^Add new asset layer section should be removed/, function (callback) {
        editGeoSpatialWidgetPage.getAddNewAssetLayerSection().isDisplayed().then(function (isDisplayed) {
            expect(false).to.equal(isDisplayed)
            callback();
        });
    });

    this.Then(/^I cancel the asset Layer$/, function (callback) {

        editGeoSpatialWidgetPage.cancelAssetLayer().then(function(){
            browser.sleep(5000).then(function(){
                callback();
            })
        });
    });

    this.Then(/^I delete the "([^"]*)" asset Layer$/, function (assetLayerNo,callback) {

        editGeoSpatialWidgetPage.deleteAssetLayer(assetLayerNo).then(function(){
            callback();
        });
    });


    this.Then(/^Asset layer sequence "([^"]*)" should be saved in "([^"]*)" asset layer$/, function (expectedLayerSequence,assetLayerNo,callback) {

        editGeoSpatialWidgetPage.getSavedAssetLayerSequenceValue(assetLayerNo).then(function(layerSequence){
            layerSequence.getAttribute('value').then(function(actualLayerSequence){
                expect(actualLayerSequence).to.equals(expectedLayerSequence);
                callback();
            })


        });
    });

    this.Then(/^Asset layer title "([^"]*)" should be saved in "([^"]*)" asset layer$/, function (expectedLayerTitle,assetLayerNo,callback) {

        editGeoSpatialWidgetPage.getSavedAssetLayerTitleValue(assetLayerNo).then(function(layerTitle){
            layerTitle.getAttribute('value').then(function(actualLayerTitle){
                expect(actualLayerTitle).to.equals(expectedLayerTitle);
                callback();
            })

        });
    });

    this.Then(/^Below assets should be saved in "([^"]*)" asset Layer$/, function(assetLayerNo,table,callback) {

        editGeoSpatialWidgetPage.getSavedAssetNames(assetLayerNo).then(function(assetName){

            console.log(assetName+"####assname#####");

            for(var i=0;i<table.raw().length;i++){

                (function(num){

                assetName[i].then(function(actual){

                    expect(actual).to.equals(table.raw()[num][0]);
                    console.log("verified the saved assets #"+ table.raw()[num][0]);

                })
                })(i);


            }

            callback();

        });
    });


    this.Then(/^visibility toggle button should be on$/, function (callback) {
        editGeoSpatialWidgetPage.checkAssetLayerVisibilityIsSelectedByDefault().then(function (isSelected) {
            expect(true).to.equal(isSelected)
            callback();
        });
    });

    this.Then(/^validation message should be displayed$/, function (callback) {
        editGeoSpatialWidgetPage.getAssetLayerSequenceValidationMessage().isDisplayed().then(function (isDisplayed) {
                expect(true).to.equal(isDisplayed);
                    editGeoSpatialWidgetPage.getAssetLayerSequenceValidationMessage().getText().then(function(validationMessage){
                    expect("*Order Number already exists or invalid").to.equals(validationMessage);
                    callback();



            });
        });
    });

    this.Then(/^On searching "([^"]*)" again no search results found message should be displayed$/, function (assetName,callback) {
        editGeoSpatialWidgetPage.getNoSearchResultFoundMessage(assetName).then(function(message){
            message.isDisplayed().then(function (isDisplayed) {
                expect(true).to.equal(isDisplayed);
                message.getText().then(function(validationMessage){
                    expect("No Search Results Found").to.equals(validationMessage);
                    callback();
                });


            });
        });
    });


    this.Then(/^asset should be plotted on the map$/, function (callback) {
        //editGeoSpatialWidgetPage.protractorImageComparison(assetName).then(function(percentage){
        //
        //    TestHelper.assertEqual(0, percentage, callback)
        //    callback();
        //        });
        //
        //
        //    });

        browser.protractorImageComparison.checkElement(element(by.css('#widget-placeholder #map')), 'satellite',{ignoreAntialiasing: true}).then(function (percentDifferent) {

            //The function returns a promise with the percentage that shows difference
            console.log("The difference: " + percentDifferent)

            //Asserting if the percentage is 0 meaning that there are no differences between the two images
            TestHelper.assertEqual(0, percentDifferent, callback)
            callback();
        });
    });


    this.Then(/^I add the custom layer$/, function (callback) {
        // Write code here that turns the phrase above into concrete actions
        editGeoSpatialWidgetPage.clickAddCustomLayerIcon().then(function(){
            console.log('Clicked on the add new custom layer icon ');
            callback();
        });
    });


    this.When(/^I select "([^"]*)" custom layer type/, function (customLayerType, callback) {
        editGeoSpatialWidgetPage.selectCustomLayerType(customLayerType).then(function(){
            console.log('Clicked on the add new custom layer icon ');
            callback();
        });


    });

    this.When(/^I enter "([^"]*)" custom layer sequence$/, function (sequence, callback) {
        editGeoSpatialWidgetPage.getCustomLayerSequenceInputField().clear().sendKeys(sequence).then(function () {
            console.log('entered the asset layer sequence # ' + sequence);
            callback();
        });
    });

    this.When(/^I enter "([^"]*)" custom layer title$/, function (dataSource, callback) {
        editGeoSpatialWidgetPage.getCustomLayerTitleInputField().sendKeys(dataSource).then(function () {
            console.log('entered the asset layer sequence # ' + dataSource);
            callback();
        });
    });

    this.When(/^I enter "([^"]*)" custom layer data source$/, function (title, callback) {
        editGeoSpatialWidgetPage.getCustomLayerDataSourceInputField().sendKeys(title).then(function () {
            console.log('entered the asset layer sequence # ' + title);
            callback();
        });
    });

    this.Then(/^I save the custom layer$/, function (callback) {
        editGeoSpatialWidgetPage.saveCustomLayer().then(function(){
            browser.sleep(5000).then(function(){
                callback();
            })
        });
    });

    this.Then(/^Custom layer should be saved$/, function (callback) {
        editGeoSpatialWidgetPage.getSavedCustomLayer().isDisplayed().then(function (isDisplayed) {
            expect(true).to.equal(isDisplayed)
            callback();
        });
    });

    this.Then(/^Custom layer sequence "([^"]*)" should be saved in "([^"]*)" custom layer$/, function (expectedLayerSequence,customLayerNo,callback) {

        editGeoSpatialWidgetPage.getSavedCustomLayerSequenceValue(customLayerNo).then(function(layerSequence){
            layerSequence.getAttribute('value').then(function(actualLayerSequence){
                expect(actualLayerSequence).to.equals(expectedLayerSequence);

                callback();
            })


        });
    });


    this.Then(/^Custom layer title "([^"]*)" should be saved in "([^"]*)" custom layer$/, function (expectedLayerTitle,customLayerNo,callback) {

        editGeoSpatialWidgetPage.getSavedCustomLayerTitleValue(customLayerNo).then(function(layerTitle){
            layerTitle.getAttribute('value').then(function(actualLayerTitle){
                expect(actualLayerTitle).to.equals(expectedLayerTitle);
                callback();
            })

        });
    });


    this.Then(/^Custom layer data source "([^"]*)" should be saved in "([^"]*)" custom layer$/, function (expectedLayerDataSource,customLayerNo,callback) {

        editGeoSpatialWidgetPage.getSavedCustomLayerDataSourceValue(customLayerNo).then(function(customLayerDataSource){
            customLayerDataSource.getAttribute('value').then(function(actualCustomLayerDataSource){
                expect(actualCustomLayerDataSource).to.equals(expectedLayerDataSource);
                callback();
            })

        });
    });


    this.Then(/^visibility of custom layer toggle button should be on$/, function (callback) {
        editGeoSpatialWidgetPage.checkCustomLayerVisibilityIsSelectedByDefault().then(function (isSelected) {
            expect(true).to.equal(isSelected)
            callback();
        });
    });

    this.Then(/^Custom layer validation message should be displayed$/, function (callback) {
        editGeoSpatialWidgetPage.getCustomLayerSequenceValidationMessage().isDisplayed().then(function (isDisplayed) {
            expect(true).to.equal(isDisplayed);
            editGeoSpatialWidgetPage.getCustomLayerSequenceValidationMessage().getText().then(function(validationMessage){
                expect("*Order Number already exists or invalid").to.equals(validationMessage);

                callback();



            });
        });
    });

    this.Then(/^I cancel the custom Layer$/, function (callback) {

        editGeoSpatialWidgetPage.cancelCustomLayer().then(function(){
            browser.sleep(5000).then(function(){
                callback();
            })
        });
    });

    this.Then(/^Add new custom layer section should be removed/, function (callback) {
        editGeoSpatialWidgetPage.getAddNewCustomLayerSection().isDisplayed().then(function (isDisplayed) {
            expect(false).to.equal(isDisplayed)
            callback();
        });
    });

    this.Then(/^I delete the "([^"]*)" custom Layer$/, function (customerLayerNo,callback) {

        editGeoSpatialWidgetPage.deleteCustomLayer(customerLayerNo).then(function(){
            callback();
        });
    });

    this.Then(/^Custom layer should be deleted/, function (callback) {
        browser.manage().timeouts().implicitlyWait(5000);
        editGeoSpatialWidgetPage.getSavedCustomLayer().isPresent().then(function (isPresent) {
            expect(false).to.equal(isPresent)
            browser.manage().timeouts().implicitlyWait(50000);
            callback();
        }).catch(function(e){
            console.log(e)
        });
    });

}



/**
 * Created by 212677088 on 10/10/2018.
 */
module.exports = function () {
    var delay = 15000;
    var util = require("util");
    var data = require('../TestData/OPMAPIEndpoints.json').data.env[browser.params.environment];
    var results;
    
    this.Given(/^I run fleet fetch query for (.*) to get (.*)$/, function (params, op, callback) {
        var tagNames;
        var URL;
        var startTime = (new Date());
        startTime.setDate(startTime.getDate() - 1);
        startTime = startTime.toISOString().split('T')[0];
        startTime = startTime + 'T00:00:00Z';
        console.log('startTime-->', startTime);
        var endTime = (new Date());
        endTime.setDate(endTime.getDate() - 7);
        endTime = endTime.toISOString().split('T')[0];
        endTime = endTime + 'T00:00:00Z';
        console.log('endTime-->', endTime);
        URL = data.fetchQuery.url;
        tagNames = data[params];
        console.log("tagnames-->" + tagNames);
        var URL = util.format(URL, op, tagNames, endTime, startTime);
        console.log("URL-->" + URL);
        multiForecastRestPO.getQueryResults(URL).then(function (serviceData) {
            results = serviceData;
            callback();
        });
    });
    this.When(/^I click on (.*) from the dashboard context$/, function (asset, callback) {
        var ele = element(by.xpath("//span[text()='" + asset + "']/ancestor::div[@class='dx-item dx-treeview-item']/following::div[1]"));
        browser.sleep(delay).then(function () {
            ele.click().then(function () {
                callback();
            });
        });
    });
    this.When(/^I click on (.*) header$/, function (asset, callback) {
        var header = element(by.xpath("//span[text()='" + asset + "']"));
        header.click().then(function () {
            callback();
        });
    });
    this.Then(/^I click on Select Asset Context$/, function (callback) {
        browser.sleep(delay).then(function () {
            fleetDashboardPO.clickElement('selectContext').then(function () {
                callback();
            });
        });
    });
    this.Then(/^I click on Open button$/, function (callback) {
        browser.sleep(delay).then(function () {
            fleetDashboardPO.clickElement('openAsset').then(function () {
                callback();
            });
        });
    });
    this.Given(/^I verify Average Control Loop Performance histogram header name$/, function (callback) {
        fleetDashboardPO.getElement('fleetChartHeader').getText().then(function (val) {
            console.log("Average Control Loop Title:" + val);
            TestHelper.assertEqual(val, 'Average Control Loop Performance');
            callback();
        });
    });
    this.Given(/^I verify Average Control Loop Performance histogram chart$/, function (callback) {
        fleetDashboardPO.getElement('fleetChartSection').isPresent().then(function () {
            callback();
        });
    });
    this.Then(/^I verify Control Loop Performance header name$/, function (callback) {
        fleetDashboardPO.getElement('fleetTableHeader').getText().then(function (val) {
            console.log("Control Loop Title:" + val);
            TestHelper.assertEqual(val, 'Control Loop Performance');
            callback();
        });
    });
    this.Then(/^I verify Control Loop Performance table$/, function (callback) {
        fleetDashboardPO.getElement('fleetTableSection').isPresent().then(function () {
            callback();
        });
    });
    this.Then(/^I verify the AVG Limits Exceeded$/, function (callback) {
        fleetDashboardPO.getElement('mining1AvgLimit').getText().then(function (val) {
            val = val.trim();
            var expectedVal = 0;
            results.forEach(function (obj) {
                if (obj.tagId === "Mining1.Percentage Limits Exceeded") {
                    console.log("postman value-->" + obj.data[0].v);
                    expectedVal = parseFloat(obj.data[0].v, 10);
                    expectedVal = fleetDashboardPO.roundDecimalPoints(expectedVal);
                }
            });
            TestHelper.assertEqual(parseFloat(val, 10), expectedVal);
            TestHelper.assertEqual(parseFloat(val, 10), expectedVal);
            callback();
        });
    });
    this.Then(/^I verify the AVG Performance Index$/, function (callback) {
        fleetDashboardPO.getElement('mining1AvgPerformance').getText().then(function (val) {
            val = val.trim();
            console.log("mining1AvgPerformance Value:" + val);
            var expectedVal = 0;
            results.forEach(function (obj) {
                if (obj.tagId === "Mining1.Overall Performance") {
                    console.log("postman value-->" + obj.data[0].v);
                    expectedVal = parseFloat(obj.data[0].v, 10);
                    expectedVal = fleetDashboardPO.roundDecimalPoints(expectedVal);
                }
            });
            console.log('expectedVal:' + expectedVal);
            TestHelper.assertEqual(parseFloat(val, 10), expectedVal);
            callback();
        });
    });
    this.Then(/^I verify the MV Movement$/, function (callback) {
        fleetDashboardPO.getElement('mining1MVMovement').getText().then(function (val) {
            val = val.trim();
            console.log("mining1MVMovement Value:" + val);
            var expectedVal = 0;
            results.forEach(function (obj) {
                if (obj.tagId === "Mining1.Movement Index") {
                    console.log("postman value-->" + obj.data[0].v);
                    expectedVal = parseFloat(obj.data[0].v, 10);
                    expectedVal = fleetDashboardPO.roundDecimalPoints(expectedVal);
                }
            });
            console.log('expectedVal:' + expectedVal);
            TestHelper.assertEqual(parseFloat(val, 10), expectedVal);
            callback();
        });
    });
    this.Then(/^I verify the MV Saturation$/, function (callback) {
        fleetDashboardPO.getElement('mining1MVSaturation').getText().then(function (val) {
            val = val.trim();
            console.log("mining1MVSaturation Value:" + val);
            var expectedVal = 0;
            results.forEach(function (obj) {
                if (obj.tagId === "Mining1.Percentage MV Saturation") {
                    console.log("postman value-->" + obj.data[0].v);
                    expectedVal = parseFloat(obj.data[0].v, 10);
                    expectedVal = fleetDashboardPO.roundDecimalPoints(expectedVal);
                }
            });
            console.log('expectedVal:' + expectedVal);
            TestHelper.assertEqual(parseFloat(val, 10), expectedVal);
            callback();
        });
    });
    this.Then(/^I verify the AVG Manual$/, function (callback) {
        fleetDashboardPO.getElement('mining1AvgManual').getText().then(function (val) {
            val = val.trim();
            console.log("mining1AvgManual Value:" + val);
            var expectedVal = 0;
            results.forEach(function (obj) {
                if (obj.tagId === "Mining1.Percentage Manual") {
                    console.log("postman value-->" + obj.data[0].v);
                    expectedVal = parseFloat(obj.data[0].v, 10);
                    expectedVal = fleetDashboardPO.roundDecimalPoints(expectedVal);
                }
            });
            console.log('expectedVal:' + expectedVal);
            TestHelper.assertEqual(parseFloat(val, 10), expectedVal);
            callback();
        });
    });
    this.Then(/^I verify the AVG Auto$/, function (callback) {
        fleetDashboardPO.getElement('mining1AvgAuto').getText().then(function (val) {
            val = val.trim();
            console.log("mining1AvgAuto Value:" + val);
            var expectedVal = 0;
            results.forEach(function (obj) {
                if (obj.tagId === "Mining1.Percentage Auto") {
                    console.log("postman value-->" + obj.data[0].v);
                    expectedVal = parseFloat(obj.data[0].v, 10);
                    expectedVal = fleetDashboardPO.roundDecimalPoints(expectedVal);
                }
            });
            console.log('expectedVal:' + expectedVal);
            TestHelper.assertEqual(parseFloat(val, 10), expectedVal);
            callback();
        });
    });
    this.Then(/^I verify the AVG Cascade$/, function (callback) {
        fleetDashboardPO.getElement('mining1AvgCascade').getText().then(function (val) {
            val = val.trim();
            console.log("mining1AvgCascade Value:" + val);
            var expectedVal = 0;
            results.forEach(function (obj) {
                if (obj.tagId === "Mining1.Percentage Cascade") {
                    console.log("postman value-->" + obj.data[0].v);
                    expectedVal = parseFloat(obj.data[0].v, 10);
                    expectedVal = fleetDashboardPO.roundDecimalPoints(expectedVal);
                }
            });
            console.log('expectedVal:' + expectedVal);
            TestHelper.assertEqual(parseFloat(val, 10), expectedVal);
            callback();
        });
    });
    this.Then(/^I verify the AVG Shutdown$/, function (callback) {
        fleetDashboardPO.getElement('mining1AvgShutdown').getText().then(function (val) {
            val = val.trim();
            console.log("mining1AvgShutdown Value:" + val);
            var expectedVal = 0;
            results.forEach(function (obj) {
                if (obj.tagId === "Mining1.Percentage Shutdown") {
                    console.log("postman value-->" + obj.data[0].v);
                    expectedVal = parseFloat(obj.data[0].v, 10);
                    expectedVal = fleetDashboardPO.roundDecimalPoints(expectedVal);
                }
            });
            console.log('expectedVal:' + expectedVal);
            TestHelper.assertEqual(parseFloat(val, 10), expectedVal);
            callback();
        });
    });
    this.Then(/^I verify the Good Quality Data$/, function (callback) {
        fleetDashboardPO.getElement('mining1GoodQuality').getText().then(function (val) {
            val = val.trim();
            console.log("mining1GoodQuality Value:" + val);
            var expectedVal = 0;
            results.forEach(function (obj) {
                if (obj.tagId === "Mining1.Percentage Good Quality") {
                    console.log("postman value-->" + obj.data[0].v);
                    expectedVal = parseFloat(obj.data[0].v, 10);
                    expectedVal = fleetDashboardPO.roundDecimalPoints(expectedVal);
                }
            });
            console.log('expectedVal:' + expectedVal);
            TestHelper.assertEqual(parseFloat(val, 10), expectedVal);
            callback();
        });
    });
    this.Then(/^I verify the AVG PV Variability$/, function (callback) {
        fleetDashboardPO.getElement('mining1PVVariability').getText().then(function (val) {
            val = val.trim();
            console.log("mining1PVVariability Value:" + val);
            var expectedVal = 0;
            results.forEach(function (obj) {
                if (obj.tagId === "Mining1.PV Variability") {
                    console.log("postman value-->" + obj.data[0].v);
                    expectedVal = parseFloat(obj.data[0].v, 10);
                    expectedVal = fleetDashboardPO.roundDecimalPoints(expectedVal);
                }
            });
            console.log('expectedVal:' + expectedVal);
            TestHelper.assertEqual(parseFloat(val, 10), expectedVal);
            callback();
        });
    });
    this.Then(/^I verify the Total Configuration Changes$/, function (callback) {
        fleetDashboardPO.getElement('mining1TotalConfiguration').getText().then(function (val) {
            val = val.trim();
            console.log("mining1TotalConfiguration Value:" + val);
            var expectedVal = 0;
            results.forEach(function (obj) {
                if (obj.tagId === "Mining1.Total PIDF Changes") {
                    console.log("postman value-->" + obj.data[0].v);
                    expectedVal = parseFloat(obj.data[0].v, 10);
                    expectedVal = fleetDashboardPO.roundDecimalPoints(expectedVal);
                }
            });
            console.log('expectedVal:' + expectedVal);
            TestHelper.assertEqual(parseFloat(val, 10), expectedVal);
            callback();
        });
    });
    this.Then(/^I verify the AVG Absolute Error$/, function (callback) {
        fleetDashboardPO.getElement('mining1AvgError').getText().then(function (val) {
            val = val.trim();
            console.log("mining1AvgError Value:" + val);
            var expectedVal = 0;
            results.forEach(function (obj) {
                if (obj.tagId === "Mining1.PV Error Absolute Average") {
                    console.log("postman value-->" + obj.data[0].v);
                    expectedVal = parseFloat(obj.data[0].v, 10);
                    expectedVal = fleetDashboardPO.roundDecimalPoints(expectedVal);
                }
            });
            console.log('expectedVal:' + expectedVal);
            TestHelper.assertEqual(parseFloat(val, 10), expectedVal);
            callback();
        });
    });
    this.Given(/^I click on the (.*) from fleet table$/, function (asset, callback) {
        var linkname = element(by.xpath("//*[contains(@class,'aha-Loop-td')]//span[contains(text(),'" + asset + "')]"));
        browser.sleep(delay).then(function () {
            linkname.click().then(function () {
                browser.sleep(delay).then(function () {
                    callback();
                });
            });
        });
    });
    this.Given(/^I switch the window to loop dashboard$/, function (callback) {
        var winHandles = browser.getAllWindowHandles();
        browser.sleep(delay).then(function () {
            browser.ignoreSynchronization = true;
            winHandles.then(function (handles) {
                var parentWindow = handles[0];
                var popUpWindow = handles[1];
                browser.switchTo().window(popUpWindow);
                callback();
            });
        });
    });
};

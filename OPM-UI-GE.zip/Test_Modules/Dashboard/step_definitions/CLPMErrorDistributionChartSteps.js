/**
 * Created by 212677088 on 9/17/2018.
 */
module.exports = function () {

    var delay = 12000;
    var util = require("util");
    var data = require('../TestData/OPMAPIEndpoints.json').data.env[browser.params.environment];
    var results;
    var histCount = [];
    var errCount = [];
    var countArray =[];
    this.setDefaultTimeout(990000);

    this.Given(/^I run timeseries2 fetch query for (.*) with (.*) and (.*) to get (.*)$/, function (params, startTime, endTime, op, callback) {
        var tagNames;
        var URL;
        if(params === "controllerConfiguration"){
            URL = data.fetchQuery.controllerurl;
            tagNames = data[params];
        }else{
            URL = data.fetchQuery.url;
            tagNames = data[params];
        }
        console.log("tagnames-->" + tagNames);
        var URL = util.format(URL, op, tagNames, startTime, endTime);
        console.log("URL-->" + URL);
        multiForecastRestPO.getQueryResults(URL).then(function (serviceData) {
            results = serviceData;
            callback();
        });
    });

    this.Given(/^I verify the Error Distribution header name$/, function (callback) {
        loopDashboardPO.scrollIntoView(loopDashboardPO.getElement('errorHeader')).then(function () {
            loopDashboardPO.getElement('errorHeader').getText().then(function (val) {
                console.log("error Distribution Header Title:" + val);
                TestHelper.assertEqual(val, 'Error Distribution');
                callback();
            });
        });
    });
    this.Given(/^I initialize timeseries and error array$/, function (callback) {
        countArray = Array.apply(null, Array(100)).map(Number.prototype.valueOf, 0);
        errCount = Array.apply(null, Array(100)).map(Number.prototype.valueOf, 0);
        callback();
    });
    this.Given(/^I get the count of all error bins$/, function (callback) {
        element.all(by.css("#opm-histogram-container .error-chart-container svg .bar rect")).then(function (items) {
            for (var i = 0; i < items.length; i++) {
                (function (index) {
                    loopDashboardPO.scrollIntoView(items[index]).then(function () {
                    });
                    browser.actions().mouseMove(items[index]).perform();
                    element(by.css("#opm-histogram-container .errorToolTip div:nth-child(1)")).getText().valueOf().then(function (text) {
                        console.log('Error  value is ---', text);
                    });
                    element(by.css("#opm-histogram-container .errorToolTip div:nth-child(2)")).getText().valueOf().then(function (text) {
                        console.log('Duration value is ---', text);
                        errCount[index] = text;
                    });
                })(i);
            }
            callback();
        });
    });
    this.Then(/^I verify error count with timeseries count$/, function (callback) {
        TestHelper.assertEqual(errCount, countArray);
        callback();
    });
};
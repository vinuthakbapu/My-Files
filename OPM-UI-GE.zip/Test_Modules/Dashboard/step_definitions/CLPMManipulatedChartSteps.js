/**
 * Created by 212677088 on 9/14/2018.
 */
module.exports = function () {
    var delay = 12000;
    var util = require("util");
    var data = require('../TestData/OPMAPIEndpoints.json').data.env[browser.params.environment];
    var results;
    var histCount = [];
    var errCount = [];
    var countArray =[];
    this.setDefaultTimeout(990000);

    this.Given(/^I run timeseries1 fetch query for (.*) with (.*) and (.*) to get (.*)$/, function (params, startTime, endTime, op, callback) {
        var tagNames;
        var URL;
        if(params === "controllerConfiguration"){
            URL = data.fetchQuery.controllerurl;
            tagNames = data[params];
        }else{
            URL = data.fetchQuery.url;
            tagNames = data[params];
        }
        console.log("tagnames-->" + tagNames);
        var URL = util.format(URL, op, tagNames, startTime, endTime);
        console.log("URL-->" + URL);
        multiForecastRestPO.getQueryResults(URL).then(function (serviceData) {
            results = serviceData;
            callback();
        });
    });

    this.Given(/^I get the count of all histogram bins$/, function (callback) {
        element.all(by.css("#opm-histogram-container .chart-container svg .bar rect")).then(function (items) {
            for (var i = 0; i < items.length; i++) {
                (function (index) {
                    loopDashboardPO.scrollIntoView(items[index]);
                    browser.actions().mouseMove(items[index]).perform();
                    element(by.css("#opm-histogram-container .toolTip div:nth-child(1)")).getText().valueOf().then(function (text) {
                        console.log('MV value is ---', text);
                    });
                    element(by.css("#opm-histogram-container .toolTip div:nth-child(2)")).getText().valueOf().then(function (text) {
                        console.log('Count value is ---', text);
                        histCount[index] = text;
                    });
                })(i);
            }
            callback();
        });
    });
    this.Given(/^I initialize timeseries and histogram array$/, function (callback) {
        countArray = Array.apply(null, Array(100)).map(Number.prototype.valueOf, 0);
        histCount = Array.apply(null, Array(100)).map(Number.prototype.valueOf, 0);
        callback();
    });
    this.Given(/^I get the count from timerseries$/, function (callback) {
        console.log('results length-->', results.length);
        results.forEach(function (objs) {
            objs.data.forEach(function (obj) {
                var condition = obj.v;
                condition = parseInt(condition, 10);
                countArray[condition] = countArray[condition] + 1;
            });
        });
        console.log('Histogram UI values-->', histCount);
        console.log('Timeseries values-->', countArray);
        callback();
    });
    this.Given(/^I verify the Error Distribution histrogram$/, function (callback) {
        loopDashboardPO.getElement('errorHeader').isPresent().then(function () {
            callback();
        });
    });
    this.Then(/^I verify histogram count with timeseries count$/, function (callback) {
        TestHelper.assertEqual(histCount, countArray);
        callback();
    });
    this.Given(/^I verify the Manipulated Variable Distribution header name$/, function (callback) {
        var manipulate = element(by.css("h3[class*='clpm-cv-distribution']"));
        loopDashboardPO.scrollIntoView(manipulate).then(function () {
            loopDashboardPO.getElement('manipulatedHeader').getText().then(function (val) {
                console.log("manipulatedHeader Title:" + val);
                TestHelper.assertEqual(val, 'Manipulated Variable Distribution(%)');
                callback();
            });
        });
    });
    this.Then(/^I verify the legend values from 0\-5$/, function (callback) {
        loopDashboardPO.getElement('manipulatedLegend0-5').getText().then(function (val) {
            console.log("manipulatedLegend0-5 Title:" + val);
            TestHelper.assertEqual(val, '0-5');
            callback();
        });
    });
    this.Then(/^I verify the legend values from 6\-30$/, function (callback) {
        loopDashboardPO.getElement('manipulatedLegend6-30').getText().then(function (val) {
            console.log("manipulatedLegend6-30 Title:" + val);
            TestHelper.assertEqual(val, '6-30');
            callback();
        });
    });
    this.Then(/^I verify the legend values from 31\-70$/, function (callback) {
        loopDashboardPO.getElement('manipulatedLegend31-70').getText().then(function (val) {
            console.log("manipulatedLegend3 Title:" + val);
            TestHelper.assertEqual(val, '31-70');
            callback();
        });
    });
    this.Then(/^I verify the legend values from 71\-95$/, function (callback) {
        loopDashboardPO.getElement('manipulatedLegend71-95').getText().then(function (val) {
            console.log("manipulatedLegend71-95 Title:" + val);
            TestHelper.assertEqual(val, '71-95');
            callback();
        });
    });
    this.Then(/^I verify the legend values from 96\-100$/, function (callback) {
        loopDashboardPO.getElement('manipulatedLegend96-100').getText().then(function (val) {
            console.log("manipulatedLegend96-100 Title:" + val);
            TestHelper.assertEqual(val, '96-100');
            callback();
        });
    });
};
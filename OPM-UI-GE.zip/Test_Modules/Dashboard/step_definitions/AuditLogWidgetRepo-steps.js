/**
 * Created by 212340705 on Aug 28th 2017.
 */
module.exports = function() {

    this.Given(/^I see the audit log micro app in left nav$/, function (callback) {

        console.log('Verify the audit log micro app is displayed in left nav');
        createviewpage.CheckAuditLogsMicroApp().then(function(present) {
            if(present){
                expect(present).to.equal(true);
                console.log('audit log micro app is displayed in left nav: '+ present);
                callback();
            }else{
                console.log('audit log micro app is displayed in left nav. check the user permissions:' + present);
                expect(present).to.equal(true);
                callback();
            }
        });
    });

    this.When(/^I click on audit log micro app in left nav$/, function (callback) {
        console.log('about to click on audit log micro app in left nav');
        createviewpage.ClickAuditLogsMicroApp().then(function() {
            browser.sleep(3000).then(function(){
                console.log('clicked on audit log micro app in left nav');
                callback();
            });
        });
    });

    this.Then(/^I should see audit log management page open$/, function (callback) {

        console.log('Verify the audit log management page open');
        createviewpage.CheckAuditLogsPage().then(function(present) {
            if(present){
                expect(present).to.equal(true);
                console.log('audit log management page is open: '+ present);
                callback();
            }else{
                console.log('audit log management page is open::' + present);
                expect(present).to.equal(true);
                callback();
            }
        });
    });

    this.Then(/^I should see the choose audit log drop down$/, function (callback) {
        console.log('Verify the choose audit log drop down is present');
        createviewpage.CheckAuditLogSelectionMenu().then(function(present) {
            if(present){
                expect(present).to.equal(true);
                console.log('choose audit log drop down is present: '+ present);
                callback();
            }else{
                console.log('choose audit log drop down is present::' + present);
                expect(present).to.equal(true);
                callback();
            }
        });
    });
    this.When(/^I click on choose audit log drop down$/, function (callback) {
        createviewpage.ClickAuditLogSelectionMenu().then(function() {
            browser.sleep(3000).then(function(){
                console.log('clicked on choose audit log drop down');
                callback();
            });
        });
    });

    this.Then(/^I should see the "([^"]*)" option in the drop down$/, function (arg1, callback) {
        console.log('Verify the ' + arg1 + ' is listed in the selection drop down menu');
        createviewpage.CheckAuditLogApp(arg1).then(function(present) {
            if(present){
                expect(present).to.equal(true);
                console.log( arg1 + ' is listed in the selection drop down menu: '+ present);
                callback();
            }else{
                console.log( arg1 + ' is listed in the selection drop down menu: '+ present);
                expect(present).to.equal(true);
                callback();
            }
        });
    });

    this.Given(/^I select "([^"]*)" option from the chose audit log drop down menu$/, function (arg1, callback) {
        createviewpage.selectAuditLogApp(arg1).then(function() {
            browser.sleep(3000).then(function(){
                console.log('clicked on audit log drop down option '+ arg1);
                callback();
            });
        });
    });

    this.Then(/^I should see the calendar object to select the date$/, function (callback) {
        console.log('Verify the calendar object to select the date is present');
        createviewpage.CheckAuditLogCalendarObj().then(function(present) {
            if(present){
                expect(present).to.equal(true);
                console.log('calendar object to select the date is present: '+ present);
                callback();
            }else{
                console.log('calendar object to select the date is present:' + present);
                expect(present).to.equal(true);
                callback();
            }
        });
    });


    this.When(/^I select the date "([^"]*)"$/, function (date, callback) {
        console.log('About to select the date ' + date);
        createviewpage.selectAuditLogDate(date).then(function() {
            browser.sleep(3000).then(function(){
                callback();
            });
        });
    });


    this.When(/^I select the current date$/, function (callback) {
        // var setDay = (new Date().getUTCDate());
        // var setMonth= (new Date().getUTCMonth()) + 1;
        // var setYear = (new Date().getUTCFullYear());

        var setDay = (new Date().getDate());
        var setMonth= (new Date().getMonth()) + 1;
        var setYear = (new Date().getFullYear());

        var date = "";
        setMonth < 10 ? date += "0" : date += "";
        date += setMonth + "/"
        setDay < 10 ? date +=  "0" : date += "";
        date += setDay + "/" + setYear;

        console.log('About to select the date ' + date );
        createviewpage.selectAuditLogDate(date).then(function() {
            browser.sleep(3000).then(function(){
                callback();
            });
        });
    });

    this.Then(/^I click on Apply button to submit date change$/, function (callback) {
        createviewpage.clickAuditLogSelectDateApplyBtn().then(function() {
            browser.sleep(3000).then(function(){
                console.log('Date changed applied');
                callback();
            });
        });
    });

    this.Then(/^I should see the grid with current logs$/, function (callback) {
        console.log('Verify the grid with current logs is present');
        createviewpage.CheckAuditLogGrid().then(function(present) {
            if(present){
                expect(present).to.equal(true);
                console.log('calendar object to select the date is present: '+ present);
                callback();
            }else{
                console.log('calendar object to select the date is present:' + present);
                expect(present).to.equal(true);
                callback();
            }
        });
    });

    this.Then(/^I should see "([^"]*)" in "([^"]*)" column, ad-hoc$/, function (fieldName, columnName, callback) {
        console.log('Verify fieldName ' + fieldName + ' is present in ' + columnName);
        var sizeGrid = 6;
        var column = getProperColumn(columnName);

        createviewpage.CheckAuditLogColumn(column).then(function(columnFieldName) {
            expect(columnFieldName).to.equal(columnName);
            console.log('Valid Column name ' + columnName);

            //we are checking third row so we need to add sizeGrid to column value
            createviewpage.CheckAuditLogColumnData(column+(sizeGrid*2)).then(function(fieldNameData) {
                expect(fieldNameData).to.equal(fieldName);
                console.log('fieldName ' + fieldName + ' is present in column ' + columnName);
                callback();
            });
        });
    });


    this.Then(/^I should see "([^"]*)" in "([^"]*)" column$/, function (fieldName, columnName, callback) {
        console.log('Verify fieldName ' + fieldName + ' is present in ' + columnName);
        var column = getProperColumn(columnName);

        createviewpage.CheckAuditLogColumn(column).then(function(columnFieldName) {
            expect(columnFieldName).to.equal(columnName);
            console.log('Valid Column name ' + columnName);
            createviewpage.CheckAuditLogColumnData(column).then(function(fieldNameData) {
                expect(fieldNameData).to.equal(fieldName);
                console.log('fieldName ' + fieldName + ' is present in column ' + columnName);
                callback();
            });
        });
    });


    this.Then(/^I search for "([^"]*)" in "([^"]*)" column$/, function (fieldName, columnName, callback) {
        console.log('Verify search field on column Name ' + columnName + ' is present');
          var column = getProperColumn(columnName);

        createviewpage.CheckAuditLogSerchField(column-1).then(function (present) {
            expect(present).to.equal(true);
            console.log('Search field present on Column name ' + columnName);
            createviewpage.getAuditLogSerchField().clear().then(function() {
                createviewpage.EnterAuditLogSerchField(fieldName).then(function () {
                    console.log('search for ' + fieldName + 'on ' + columnName);
                    callback();
                });
            });
        });
    });


    this.Then(/^I should see at least one row of data$/, function (callback) {
        console.log('Verify at least one row of data is present');
        createviewpage.getNumAuditLogRows().then(function(numFields) {
            var sizeGrid = 6;
            if((numFields/sizeGrid)>0) {
                console.log('At least a row is present: ');
                callback();
            }
        });
    });


    function getProperColumn(columnName) {
        switch (columnName) {
            case 'User Name':
                return Number(1);
                break;
            case 'Resource':
                return Number(3);
                break;
            case 'Action':
                return Number(4);
                break;
            case 'Detail':
                return Number(5);
                break;
        }
    }


};

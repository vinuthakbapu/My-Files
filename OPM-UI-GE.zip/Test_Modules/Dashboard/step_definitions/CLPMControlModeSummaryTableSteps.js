/**
 * Created by 212677088 on 9/17/2018.
 */
module.exports = function () {
    var delay = 30000;
    var util = require("util");
    var data = require('../TestData/OPMAPIEndpoints.json').data.env[browser.params.environment];
    var results;
    var histCount = [];
    var errCount = [];
    var countArray =[];

    this.Given(/^I run timeseries3 fetch query for (.*) with (.*) and (.*) to get (.*)$/, function (params, startTime, endTime, op, callback) {
        var tagNames;
        var URL;
        if(params === "controllerConfiguration"){
            URL = data.fetchQuery.controllerurl;
            tagNames = data[params];
        }else{
            URL = data.fetchQuery.url;
            tagNames = data[params];
        }
        console.log("tagnames-->" + tagNames);
        var startTime = new Date();
        startTime.setDate(startTime.getDate()-1);
        startTime = startTime.toISOString().split('T')[0];
        startTime = startTime + 'T00:00:00Z';
        console.log('startTime-->',startTime);
        var endTime = new Date();
        endTime.setDate(endTime.getDate()-2);
        endTime = endTime.toISOString().split('T')[0];
        endTime = endTime + 'T00:00:00Z';
        console.log('endTime-->',endTime);

        var URL = util.format(URL, op, tagNames, endTime, startTime);
        console.log("URL-->" + URL);
        multiForecastRestPO.getQueryResults(URL).then(function (serviceData) {
            results = serviceData;
            callback();
        });
    });

    this.Given(/^I verify the Control Mode Summary header name$/, function (callback) {
        browser.sleep(delay).then(function () {
            loopDashboardPO.getElement('controlModeSummaryTable').getText().then(function (val) {
                Logger.info("controlModeSummaryTable Title:" + val);
                TestHelper.assertEqual(val, 'Control Mode Summary');
                callback();
            });
        });
    });
    this.Then(/^I verify the Mode header name$/, function (callback) {
        loopDashboardPO.getElement('modeColumnHeader').getText().then(function (val) {
            console.log("modeColumnHeader Title:" + val);
            TestHelper.assertEqual(val, 'Mode');
            callback();
        });
    });
    this.Then(/^I verify the Duration header name$/, function (callback) {
        loopDashboardPO.getElement('durationColumnHeader').getText().then(function (val) {
            console.log("durationColumnHeader Title:" + val);
            TestHelper.assertEqual(val, 'Duration(%)');
            callback();
        });
    });
    this.Then(/^I verify the Lower Limit Exceeded header name$/, function (callback) {
        loopDashboardPO.getElement('lowerLimitColumnHeader').getText().then(function (val) {
            console.log("lowerLimitColumnHeader Title:" + val);
            TestHelper.assertEqual(val, 'Lower Limit Exceeded(%)');
            callback();
        });
    });
    this.Then(/^I verify the Upper Limit Exceeded header name$/, function (callback) {
        loopDashboardPO.getElement('upperLimitColumnHeader').getText().then(function (val) {
            console.log("upperLimitColumnHeader Title:" + val);
            TestHelper.assertEqual(val, 'Upper Limit Exceeded(%)');
            callback();
        });
    });
    this.Then(/^I verify the Total Limit Exceeded header name$/, function (callback) {
        loopDashboardPO.getElement('totalLimitColumnHeader').getText().then(function (val) {
            console.log("totalLimitColumnHeader Title:" + val);
            TestHelper.assertEqual(val, 'Total Limits Exceeded(%)');
            callback();
        });
    });
    this.Then(/^I verify the Manual header name$/, function (callback) {
        loopDashboardPO.getElement('manualMode').getText().then(function (val) {
            console.log("manualMode Title:" + val);
            TestHelper.assertEqual(val, 'Manual');
            callback();
        });
    });
    this.Then(/^I verify the Auto header name$/, function (callback) {
        loopDashboardPO.getElement('autoMode').getText().then(function (val) {
            console.log("autoMode Title:" + val);
            TestHelper.assertEqual(val, 'Auto');
            callback();
        });
    });
    this.Then(/^I verify the Cascade header name$/, function (callback) {
        loopDashboardPO.getElement('cascadeMode').getText().then(function (val) {
            console.log("cascadeMode Title:" + val);
            TestHelper.assertEqual(val, 'Cascade');
            callback();
        });
    });
    this.Then(/^I verify the Shutdown header name$/, function (callback) {
        loopDashboardPO.getElement('shutdownMode').getText().then(function (val) {
            console.log("shutdownMode Title:" + val);
            TestHelper.assertEqual(val, 'Shutdown');
            callback();
        });
    });
    this.Then(/^I verify the Total header name$/, function (callback) {
        loopDashboardPO.getElement('totalMode').getText().then(function (val) {
            console.log("totalMode Title:" + val);
            TestHelper.assertEqual(val, 'Total');
            callback();
        });
    });
    this.Given(/^I verify Auto\-Duration value$/, function (callback) {
        loopDashboardPO.getElement('autoDuration').getText().then(function (val) {
            console.log("autoDuration Value:" + val);
            var expectedVal = 0;
            results.forEach(function (obj) {
                if (obj.tagId === "Loop1.Percentage Auto") {
                    console.log("postman value-->" + obj.data[0].v);
                    expectedVal = parseFloat(obj.data[0].v, 10);
                    expectedVal = loopDashboardPO.roundDecimalPoints(expectedVal);
                }
            });
            console.log('expectedVal:' + expectedVal);
            TestHelper.assertEqual(parseFloat(val, 10), expectedVal);
            callback();
        });
    });
    this.Then(/^I verify Cascade\-Duration value$/, function (callback) {
        loopDashboardPO.getElement('cascadeDuration').getText().then(function (val) {
            console.log("cascadeDuration Value:" + val);
            var expectedVal = 0;
            results.forEach(function (obj) {
                if (obj.tagId === "Loop1.Percentage Cascade") {
                    console.log("postman value-->" + obj.data[0].v);
                    expectedVal = parseFloat(obj.data[0].v, 10);
                    expectedVal = loopDashboardPO.roundDecimalPoints(expectedVal);
                }
            });
            console.log('expectedVal:' + expectedVal);
            TestHelper.assertEqual(parseFloat(val, 10), expectedVal);
            callback();
        });
    });
    this.Then(/^I verify Shutdown\-Duration value$/, function (callback) {
        loopDashboardPO.getElement('shutdownDuration').getText().then(function (val) {
            console.log("shutdownDuration Value:" + val);
            var expectedVal = 0;
            results.forEach(function (obj) {
                if (obj.tagId === "Loop1.Percentage Shutdown") {
                    console.log("postman value-->" + obj.data[0].v);
                    expectedVal = parseFloat(obj.data[0].v, 10);
                    expectedVal = loopDashboardPO.roundDecimalPoints(expectedVal);
                }
            });
            console.log('expectedVal:' + expectedVal);
            TestHelper.assertEqual(parseFloat(val, 10), expectedVal);
            callback();
        });
    });
    this.Then(/^I verify Manual\-Duration value$/, function (callback) {
        loopDashboardPO.getElement('manualDuration').getText().then(function (val) {
            console.log("manualDuration Value:" + val);
            var expectedVal = 0;
            results.forEach(function (obj) {
                if (obj.tagId === "Loop1.Percentage Manual") {
                    console.log("postman value-->" + obj.data[0].v);
                    expectedVal = parseFloat(obj.data[0].v, 10);
                    expectedVal = loopDashboardPO.roundDecimalPoints(expectedVal);
                }
            });
            console.log('expectedVal:' + expectedVal);
            TestHelper.assertEqual(parseFloat(val, 10), expectedVal);
            callback();
        });
    });
    this.Then(/^I verify Total\-Duration value$/, function (callback) {
        loopDashboardPO.getElement('totalDuration').getText().then(function (val) {
            console.log("totalDuration Value:" + val);
            var expectedVal = 0;
            results.forEach(function (obj) {
                if (obj.tagId === "Loop1.Percentage Manual" | obj.tagId === "Loop1.Percentage Cascade" | obj.tagId === "Loop1.Percentage Auto") {
                    expectedVal = expectedVal + parseFloat(obj.data[0].v, 10);
                    expectedVal = loopDashboardPO.roundDecimalPoints(expectedVal);
                }
            });
            console.log('expectedVal:' + expectedVal);
            TestHelper.assertEqual(parseFloat(val, 10), expectedVal);
            callback();
        });
    });
    this.Given(/^I verify Auto\-Lower Limit value$/, function (callback) {
        loopDashboardPO.getElement('autoLower').getText().then(function (val) {
            console.log("autoLower Value:" + val);
            var expectedVal = 0;
            results.forEach(function (obj) {
                if (obj.tagId === "Loop1.Percentage Auto LL Exceeded") {
                    console.log("postman value-->" + obj.data[0].v);
                    expectedVal = parseFloat(obj.data[0].v, 10);
                    expectedVal = loopDashboardPO.roundDecimalPoints(expectedVal);
                }
            });
            console.log('expectedVal:' + expectedVal);
            TestHelper.assertEqual(parseFloat(val, 10), expectedVal);
            callback();
        });
    });
    this.Then(/^I verify Cascade\-Lower Limit value$/, function (callback) {
        loopDashboardPO.getElement('cascadeLower').getText().then(function (val) {
            console.log("cascadeLower Value:" + val);
            var expectedVal = 0;
            results.forEach(function (obj) {
                if (obj.tagId === "Loop1.Percentage Cascade LL Exceeded") {
                    console.log("postman value-->" + obj.data[0].v);
                    expectedVal = parseFloat(obj.data[0].v, 10);
                    expectedVal = loopDashboardPO.roundDecimalPoints(expectedVal);
                }
            });
            console.log('expectedVal:' + expectedVal);
            TestHelper.assertEqual(parseFloat(val, 10), expectedVal);
            callback();
        });
    });
    this.Then(/^I verify Shutdown\-Lower Limit value$/, function (callback) {
        loopDashboardPO.getElement('shutdownLower').getText().then(function (val) {
            console.log("shutdownLower Value:" + val);
            var expectedVal = 0;
            results.forEach(function (obj) {
                if (obj.tagId === "Loop1.Percentage Shutdown LL Exceeded") {
                    console.log("postman value-->" + obj.data[0].v);
                    expectedVal = parseFloat(obj.data[0].v, 10);
                    expectedVal = loopDashboardPO.roundDecimalPoints(expectedVal);
                }
            });
            console.log('expectedVal:' + expectedVal);
            TestHelper.assertEqual(parseFloat(val, 10), expectedVal);
            callback();
        });
    });
    this.Then(/^I verify Manual\-Lower Limit value$/, function (callback) {
        loopDashboardPO.getElement('manualLower').getText().then(function (val) {
            console.log("manualLower Value:" + val);
            var expectedVal = 0;
            results.forEach(function (obj) {
                if (obj.tagId === "Loop1.Percentage Manual LL Exceeded") {
                    console.log("postman value-->" + obj.data[0].v);
                    expectedVal = parseFloat(obj.data[0].v, 10);
                    expectedVal = loopDashboardPO.roundDecimalPoints(expectedVal);
                }
            });
            console.log('expectedVal:' + expectedVal);
            TestHelper.assertEqual(parseFloat(val, 10), expectedVal);
            callback();
        });
    });
    this.Then(/^I verify Total\-Lower Limit value$/, function (callback) {
        loopDashboardPO.getElement('totalLower').getText().then(function (val) {
            console.log("totalLower Value:" + val);
            var expectedVal = 0;
            results.forEach(function (obj) {
                if (obj.tagId === "Loop1.Percentage Manual LL Exceeded" | obj.tagId === "Loop1.Percentage Cascade LL Exceeded" | obj.tagId === "Loop1.Percentage Auto LL Exceeded") {
                    expectedVal = expectedVal + parseFloat(obj.data[0].v, 10);
                    expectedVal = loopDashboardPO.roundDecimalPoints(expectedVal);
                }
            });
            console.log('expectedVal:' + expectedVal);
            TestHelper.assertEqual(parseFloat(val, 10), expectedVal);
            callback();
        });
    });
    this.Given(/^I verify Auto\-Upper Limit value$/, function (callback) {
        loopDashboardPO.getElement('autoUpper').getText().then(function (val) {
            console.log("autoUpper Value:" + val);
            var expectedVal = 0;
            results.forEach(function (obj) {
                if (obj.tagId === "Loop1.Percentage Auto UL Exceeded") {
                    console.log("postman value-->" + obj.data[0].v);
                    expectedVal = parseFloat(obj.data[0].v, 10);
                    expectedVal = loopDashboardPO.roundDecimalPoints(expectedVal);
                }
            });
            console.log('expectedVal:' + expectedVal);
            TestHelper.assertEqual(parseFloat(val, 10), expectedVal);
            callback();
        });
    });
    this.Then(/^I verify Cascade\-Upper Limit value$/, function (callback) {
        loopDashboardPO.getElement('cascadeUpper').getText().then(function (val) {
            console.log("cascadeUpper Value:" + val);
            var expectedVal = 0;
            results.forEach(function (obj) {
                if (obj.tagId === "Loop1.Percentage Cascade UL Exceeded") {
                    console.log("postman value-->" + obj.data[0].v);
                    expectedVal = parseFloat(obj.data[0].v, 10);
                    expectedVal = loopDashboardPO.roundDecimalPoints(expectedVal);
                }
            });
            console.log('expectedVal:' + expectedVal);
            TestHelper.assertEqual(parseFloat(val, 10), expectedVal);
            callback();
        });
    });
    this.Then(/^I verify Shutdown\-Upper Limit value$/, function (callback) {
        loopDashboardPO.getElement('shutdownUpper').getText().then(function (val) {
            console.log("shutdownUpper Value:" + val);
            var expectedVal = 0;
            results.forEach(function (obj) {
                if (obj.tagId === "Loop1.Percentage Shutdown UL Exceeded") {
                    console.log("postman value-->" + obj.data[0].v);
                    expectedVal = parseFloat(obj.data[0].v, 10);
                    expectedVal = loopDashboardPO.roundDecimalPoints(expectedVal);
                }
            });
            console.log('expectedVal:' + expectedVal);
            TestHelper.assertEqual(parseFloat(val, 10), expectedVal);
            callback();
        });
    });
    this.Then(/^I verify Manual\-Upper Limit value$/, function (callback) {
        loopDashboardPO.getElement('manualUpper').getText().then(function (val) {
            console.log("manualUpper Value:" + val);
            var expectedVal = 0;
            results.forEach(function (obj) {
                if (obj.tagId === "Loop1.Percentage Manual UL Exceeded") {
                    console.log("postman value-->" + obj.data[0].v);
                    expectedVal = parseFloat(obj.data[0].v, 10);
                    expectedVal = loopDashboardPO.roundDecimalPoints(expectedVal);
                }
            });
            console.log('expectedVal:' + expectedVal);
            TestHelper.assertEqual(parseFloat(val, 10), expectedVal);
            callback();
        });
    });
    this.Then(/^I verify Total\-Upper Limit value$/, function (callback) {
        loopDashboardPO.getElement('totalUpper').getText().then(function (val) {
            console.log("totalUpper Value:" + val);
            var expectedVal = 0;
            results.forEach(function (obj) {
                if (obj.tagId === "Loop1.Percentage Manual UL Exceeded" | obj.tagId === "Loop1.Percentage Cascade UL Exceeded" | obj.tagId === "Loop1.Percentage Auto UL Exceeded") {
                    expectedVal = expectedVal + parseFloat(obj.data[0].v, 10);
                    expectedVal = loopDashboardPO.roundDecimalPoints(expectedVal);
                }
            });
            console.log('expectedVal:' + expectedVal);
            TestHelper.assertEqual(parseFloat(val, 10), expectedVal);
            callback();
        });
    });
    this.Given(/^I verify Auto\-Total Limit value$/, function (callback) {
        loopDashboardPO.getElement('autoTotal').getText().then(function (val) {
            console.log("autoTotal Value:" + val);
            var expectedVal = 0;
            results.forEach(function (obj) {
                if (obj.tagId === "Loop1.Percentage Auto LL Exceeded" | obj.tagId === "Loop1.Percentage Auto UL Exceeded") {
                    expectedVal = expectedVal + parseFloat(obj.data[0].v, 10);
                    expectedVal = loopDashboardPO.roundDecimalPoints(expectedVal);
                }
            });
            console.log('expectedVal:' + expectedVal);
            TestHelper.assertEqual(parseFloat(val, 10), expectedVal);
            callback();
        });
    });
    this.Then(/^I verify Cascade\-Total Limit value$/, function (callback) {
        loopDashboardPO.getElement('cascadeTotal').getText().then(function (val) {
            console.log("cascadeTotal Value:" + val);
            var expectedVal = 0;
            results.forEach(function (obj) {
                if (obj.tagId === "Loop1.Percentage Cascade LL Exceeded" | obj.tagId === "Loop1.Percentage Cascade UL Exceeded") {
                    expectedVal = expectedVal + parseFloat(obj.data[0].v, 10);
                    expectedVal = loopDashboardPO.roundDecimalPoints(expectedVal);
                }
            });
            console.log('expectedVal:' + expectedVal);
            TestHelper.assertEqual(parseFloat(val, 10), expectedVal);
            callback();
        });
    });
    this.Then(/^I verify Shutdown\-Total Limit value$/, function (callback) {
        loopDashboardPO.getElement('shutdownTotal').getText().then(function (val) {
            console.log("shutdownTotal Value:" + val);
            var expectedVal = 0;
            results.forEach(function (obj) {
                if (obj.tagId === "Loop1.Percentage Shutdown LL Exceeded" | obj.tagId === "Loop1.Percentage Shutdown UL Exceeded") {
                    expectedVal = expectedVal + parseFloat(obj.data[0].v, 10);
                    expectedVal = loopDashboardPO.roundDecimalPoints(expectedVal);
                }
            });
            console.log('expectedVal:' + expectedVal);
            TestHelper.assertEqual(parseFloat(val, 10), expectedVal);
            callback();
        });
    });
    this.Then(/^I verify Manual\-Total Limit value$/, function (callback) {
        loopDashboardPO.getElement('manualTotal').getText().then(function (val) {
            console.log("manualTotal Value:" + val);
            var expectedVal = 0;
            results.forEach(function (obj) {
                if (obj.tagId === "Loop1.Percentage Manual LL Exceeded" | obj.tagId === "Loop1.Percentage Manual UL Exceeded") {
                    expectedVal = expectedVal + parseFloat(obj.data[0].v, 10);
                    expectedVal = loopDashboardPO.roundDecimalPoints(expectedVal);
                }
            });
            console.log('expectedVal:' + expectedVal);
            TestHelper.assertEqual(parseFloat(val, 10), expectedVal);
            callback();
        });
    });
};
/**
 * Created by 212329933 on Oct 19th 2016.
 */
var data = require('../TestData/mo-dashboard-test-data.json').data;
var rdata = data.recommendationsWidget;
var maxRows = 5;
var recommendationsServiceData = new Array();

var myStepDefinitionsWrapper = function () {
	this.Then(/^Recommendations widget is added to Custom card$/, function (callback) {
		console.log('Verifying widget "RECOMMENDATIONS" is added to the custom card');
		moRWPage.getRecommendationsWidgetTitle().then(function (title) {
			expect(title).to.equal(rdata.labels.title);
			callback();
		});
	});

	this.When(/^Recommendations widget is available on Custom card$/, function (callback) {
		moRWPage.getRecommendationsWidgetTitle().then(function (title) {
			expect(title).to.equal(rdata.labels.title);
			callback();
		});
	});

	this.Then(/^I should see recommendations table headers$/, function (callback) {
		moRWPage.getTableHeaders().then(function (headers) {
			expect(headers).to.deep.equal(rdata.labels.tableHeaders);
			callback();
		});
	});

	this.When(/^I should see maximum "([^"]*)" rows in recommendations table$/, function (expectedCount, callback) {
		moRWPage.getRowCount().then(function (count) {
			if (count > Number.parseInt(expectedCount))
				expect(true).to.equal(false);
			else
				expect(true).to.equal(true);
			callback();
		});
	});

	this.Then(/^I should see recommendations table data$/, function (callback) {
		moRWPage.getTableData().then(function (tableData) {
			moService.getRecommendationsForAsset().then(function (serviceData) {
				recommendationsServiceData = serviceData;

				if (recommendationsServiceData.length > maxRows) {
					recommendationsServiceData = recommendationsServiceData.splice(0, maxRows);
				}

				for (var i = 0; i < recommendationsServiceData.length; i++) {
					var obj = recommendationsServiceData[i];

					expect(tableData[i][0]).to.equal(obj['recommendationId']);
					expect(tableData[i][1]).to.equal(doNullCheck(obj['caseId']));
					expect(doNullCheck(obj['description'])).to.contain(getSubString(tableData[i][2]));
					expect(tableData[i][3]).to.equal(obj['state']);
					expect(tableData[i][4]).to.equal(getFormattedDate(obj['creationDate']));
					expect(tableData[i][5]).to.equal(getFormattedDate(obj['targetCompletionDate']));
					expect(tableData[i][6]).to.equal(obj['recommendationType']);
				}
				callback();
			});
		});
	});

	this.Then(/^I should see recommendations links$/, function (callback) {
		moRWPage.getAllRecommendationsLinks().then(function (links) {
			for (var i = 0; i < recommendationsServiceData.length; i++) {
				var obj = recommendationsServiceData[i];
				expect(links[i]).to.equal(obj['recommendationId']);
			}

			callback();
		});
	});

	this.Then(/^I should see recommendations links with redirect urls$/, function (callback) {
		var entityKeys = new Array();
		for (var i = 0; i < recommendationsServiceData.length; i++) {
			var obj = recommendationsServiceData[i];
			entityKeys.push(obj['entityKey']);
		}

		moRWPage.getAllRecommendationsRedirectUrls().then(function (forms) {
			moService.getRecommendationsRedirectUrlsList(entityKeys).then(function (urlsList) {
				for(var i=0; i<forms.length; i++) {
					var formData = forms[i].split(':::');
					expect(formData[0]).to.equal(urlsList[i]);
					expect(formData[1]).to.equal('_blank');
					expect(formData[2]).to.equal('submit');
				}
				callback();
			});
		});
	});

	this.Then(/^I should see recommendations case links$/, function (callback) {
		moRWPage.getAllCaseLinks().then(function (links) {
			var cnt = 0;
			for (var i = 0; i < recommendationsServiceData.length; i++) {
				var obj = recommendationsServiceData[i];
				if(doNullCheck(obj['caseId']) !== '') {
					expect(links[cnt++]).to.equal(obj['caseId']);
				}
			}

			callback();
		});
	});
};

var getFormattedDate = function (date) {
	if (date === undefined || date === 'null' || date === null || date.trim() === '')
		return '';

	var dateWithoutTS = date.split("T")[0].split("-");
	return dateWithoutTS[1] + '/' + dateWithoutTS[2] + '/' + dateWithoutTS[0];
}

var getSubString = function (str) {
	if (str.length > 12)
		return str.substr(0, str.length - 1);

	return str;
}

var doNullCheck = function (str) {
	if (str === null || str === 'null' || str.trim() === '')
		return '';

	return str.replace(/ +/g, ' ');
}

module.exports = myStepDefinitionsWrapper;

/**
 * Created by 212340705 on Aug 31st 2017.
 */
module.exports = function() {

    this.Given(/^I should see page with title "([^"]*)"$/, function (title, callback) {
        console.log('Verify the Widget Repo Admin page title');
        WidgetRepoAdminPage.getWidgetRepoAdminPageTitle().then(function(actualtitle) {
            expect(actualtitle).to.contain(title);
            console.log('the Widget Repo Admin page title: Actual:'+ actualtitle + " expected: " +title );
            callback();
        });
    });
    this.Then(/^I should see upload new button$/, function (callback) {
        console.log('Verify the upload new button is present');
        WidgetRepoAdminPage.checkWidgetUploadBtn().then(function(present) {
            expect(present).to.equal(true);
            console.log('choose audit log drop down is present: '+ present);
            callback();
        });
    });
    this.Then(/^Button text should say "([^"]*)"$/, function (btnText, callback) {
        console.log('Verify the upload new button title is '+ btnText);
        WidgetRepoAdminPage.getWidgetUploadBtnTxt().then(function(actualText) {
            expect(btnText).to.contain(actualText);
            console.log('Upload widget button title: Actual:'+ actualText + " expected: " + btnText );
            callback();
        });
    });
    this.Then(/^I should see search input field$/, function (callback) {
        console.log('Verify the upload new button is present');
        WidgetRepoAdminPage.checkWidgetSearchInput().then(function(present) {
            expect(present).to.equal(true);
            console.log('choose audit log drop down is present: '+ present);
            callback();
        });
    });
    this.Then(/^I should see search magnifying glass icon$/, function (callback) {
        console.log('Verify the upload new button is present');
        WidgetRepoAdminPage.checkWidgetSearchlinkIcon().then(function(present) {
            expect(present).to.equal(true);
            console.log('choose audit log drop down is present: '+ present);
            callback();
        });
    });
    this.Then(/^I enter "([^"]*)" in widget search input field$/, function (searchstr, callback) {
        WidgetRepoAdminPage.EnterWidgetSearchInput(searchstr).then(function() {
            console.log('search for widgets : '+ searchstr);
            callback();
        });
    });
    this.Given(/^I should see (\d+) widget thumbnail images displayed in widget library in widget repo admin UI$/, function (WidgetImgCnt, callback) {
        WidgetRepoAdminPage.getWidgetImageCount().then(function(actualImgCnt) {
            console.log('Widget Image Count: Actual -' + actualImgCnt + " expected count: " + WidgetImgCnt);
            expect(Number(actualImgCnt)).to.equal(Number(WidgetImgCnt));
            callback();
        });
    });
    this.Then(/^Edit button for "Sample Test Automation" should be enabled$/, function (callback) {
        WidgetRepoAdminPage.checkWidgetsEditBtnDisabled().then(function(enabled) {
            expect(enabled).to.equal(null);
            console.log("Edit button for Sample Test Automation is enabled");
            callback();
        });
    });

    this.Then(/^I should see more than (\d+) widget images$/, function (WidgetImgCnt, callback) {
        WidgetRepoAdminPage.getWidgetImageCount().then(function(actualImgCnt) {
            console.log('Widget Image Count: Actual -' + actualImgCnt + '  required count: ' + WidgetImgCnt);
            expect(Number(actualImgCnt)).to.be.greaterThan(Number(WidgetImgCnt));
            console.log('Valid number of images');
            callback();
        });
    });
    this.Then(/^I should see more than (\d+) widget titles$/, function (WidgetTitlesCnt, callback) {
        WidgetRepoAdminPage.getWidgetTitleCount().then(function(actualTitlesCnt) {
            console.log('Widget Image Count: Actual -' + actualTitlesCnt + '  required count: ' + WidgetTitlesCnt);
            expect(Number(actualTitlesCnt)).to.be.greaterThan(Number(WidgetTitlesCnt));
            console.log('Valid number of Titles');
            callback();
        });
    });
    this.Then(/^I should see widget Edit Button in each widget$/, function (callback) {
        WidgetRepoAdminPage.getWidgetsCount().then(function(WidgetsCnt) {
            WidgetRepoAdminPage.getWidgetsEditBtnCount().then(function(WidgetsEditBtnCnt) {
                console.log('Number of widgets: ' + WidgetsCnt);
                console.log('Number of Edit Buttons: ' + WidgetsEditBtnCnt);
                expect(Number(WidgetsEditBtnCnt)).to.be.equal(Number(WidgetsCnt));
                callback();
            });
        });
    });
    this.Then(/^I should see widget "([^"]*)" in each widget$/, function (text, callback) {
        WidgetRepoAdminPage.getWidgetsCount().then(function(WidgetsCnt) {
            WidgetRepoAdminPage.getWidgetsFooterCount(text).then(function(textCnt) {
                console.log('Number of widgets: ' + WidgetsCnt);
                console.log('Number of ' + text + ': ' + textCnt);
                expect(Number(textCnt)).to.be.equal(Number(WidgetsCnt));
                callback();
            });
        });
    });
    this.Given(/^I click on upload new button$/, function (callback) {
        console.log('Click on the upload new button');
        WidgetRepoAdminPage.clickWidgetUploadBtn().then(function() {
            console.log('Clicked on Upload new button');
            callback();
        });
    });
    this.Then(/^I should see the upload new popup window should open$/, function (callback) {
        console.log('Verify new popup window should open');
        WidgetRepoAdminPage.checkWidgetPopupWindow().then(function(present) {
            expect(present).to.equal(true);
            console.log('New popup window is open');
            callback();
        });
    });
    this.Then(/^I should see the "([^"]*)" label in popup$/, function (labelTitle, callback) {
        console.log('Verify ' + labelTitle + ' label in popup is present');
        WidgetRepoAdminPage.checkWidgetPopupMetaDataTitle(labelTitle).then(function(present) {
            expect(present).to.equal(true);
            console.log(labelTitle + ' label in popup is present');
            callback();
        });
    });
    this.Then(/^I should see the star next to "([^"]*)" to indicate it is required field$/, function (labelTitle, callback) {
        console.log('Verify star next to ' + labelTitle + ' is present');
        WidgetRepoAdminPage.checkWidgetPopupStarNextMetaDataTitle(labelTitle).then(function(present) {
            expect(present).to.equal(true);
            console.log('star next to ' + labelTitle +  ' in popup is present');
            callback();
        });
    });
    this.Then(/^I should see a message "([^"]*)"$/, function (message, callback) {
        console.log('Verify mesage ' + message + ' is present');
        WidgetRepoAdminPage.checkWidgetPopupFileMessage(message).then(function(present) {
            expect(present).to.equal(true);
            console.log('message ' + message + ' is present');
            callback();
        });
    });
    this.Then(/^I should see input fields showing the sample file name "([^"]*)" on "([^"]*)" selection$/, function (fileName, selection, callback) {
        console.log('Verify input fields showing the sample file name ' + fileName + ' is present');
        WidgetRepoAdminPage.checkWidgetPopupFileName(fileName, selection).then(function(present) {
            expect(present).to.equal(true);
            console.log('input fields showing the sample file name ' + fileName + ' is present');
            callback();
        });
    });
    this.Then(/^I should see Choose File button next to "([^"]*)" file selection$/, function (selection, callback) {
        console.log('Verify Choose File button next to ' + selection +' file selection is present');
        WidgetRepoAdminPage.checkWidgetPopupChooseFileButton(selection).then(function(present) {
            expect(present).to.equal(true);
            console.log('Choose File button next to ' + selection + ' file selection in popup is present');
            callback();
        });
    });
    this.Then(/^I should see Tenants label$/, function (callback) {
        console.log('Verify Tenants label is present');
        WidgetRepoAdminPage.checkWidgetPopupTenantsLabel().then(function(present) {
            expect(present).to.equal(true);
            console.log('Tenants label is present');
            callback();
        });
    });
    this.Then(/^I should see the Tenants message "([^"]*)"$/, function (message, callback) {
        console.log('Verify Tenants message is present');
        WidgetRepoAdminPage.checkWidgetPopupTenantsMessage(message).then(function(present) {
            expect(present).to.equal(true);
            console.log('Tenants message is present');
            callback();
        });
    });
    this.Then(/^I should see the input field to enter Tenants ids$/, function (callback) {
        console.log("Verify input field to enter Tenants ids is present");
        WidgetRepoAdminPage.checkWidgetPopupTenantsInputField().then(function(present) {
            expect(present).to.equal(true);
            console.log("Input field to enter Tenants ids is present");
            callback();
        });
    });
    this.Then(/^I should see the save button in upload new widget popup$/, function (callback) {
        console.log("Verify save button in upload new widget popup is present");
        WidgetRepoAdminPage.checkWidgetPopupTenantsSaveBtn().then(function(present) {
            expect(present).to.equal(true);
            console.log("Save button in upload new widget popup is present");
            callback();
        });
    });
    this.Then(/^I should see the cancel button in upload new widget popup$/, function (callback) {
        console.log("Verify cancel button in upload new widget popup is present");
        WidgetRepoAdminPage.checkWidgetPopupTenantsCancelBtn().then(function(present) {
            expect(present).to.equal(true);
            console.log("Cancel button in upload new widget popup is present");
            callback();
        });
    });
    this.Then(/^Save button in upload new widget popup should be disabled$/, function (callback) {
        console.log("Verify save button in upload new widget popup is disabled");
        WidgetRepoAdminPage.checkWidgetPopupTenantsSaveBtnDisabled().then(function(disabled) {
            expect(disabled).to.equal('true');
            console.log("Save button in upload new widget popup is disabled");
            callback();
        });
    });
    this.Then(/^Save button in upload new widget popup should be enabled$/, function (callback) {
        console.log("Verify save button in upload new widget popup is enabled");
        WidgetRepoAdminPage.checkWidgetPopupTenantsSaveBtnDisabled().then(function(enabled) {
            expect(enabled).to.equal(null);
            console.log("Save button in upload new widget popup is enabled");
            callback();
        });
    });
    this.Then(/^I click on save button in upload new widget popup$/, function (callback) {
        WidgetRepoAdminPage.clickWidgetPopupTenantsSaveBtn().then(function() {
            console.log("Save button in upload new widget popup is clicked");
            callback();
        });
    });
    this.When(/^I select "([^"]*)" file for "([^"]*)" selection$/, function (fileName, selection, callback) {
        console.log('Verify ' + fileName + ' file is selected for ' + selection);
        WidgetRepoAdminPage.selectWidgetPopupSelectionFile(fileName, selection).then(function() {
            console.log(fileName + ' file is selected for ' + selection);
            callback();
        });
    });
    this.When(/^I select "([^"]*)" file for "([^"]*)" selection on ConfigWidget$/, function (fileName, selection, callback) {
        console.log('Verify ' + fileName + ' file is selected for ' + selection);
        WidgetRepoAdminPage.selectWidgetPopupSelectionFileConfigWidget(fileName, selection).then(function() {
            console.log(fileName + ' file is selected for ' + selection);
            callback();
        });
    });
    this.Then(/^I click on edit button for "([^"]*)" widget$/, function (widgetName, callback) {
        console.log('Click on edit button for ' + widgetName);
        WidgetRepoAdminPage.clickWidgetEditBtn(widgetName).then(function() {
            console.log('Clicked on edit button for ' + widgetName);
            callback();
        });
    });
    this.Then(/^I should see the Configure Widget page$/, function (callback) {
        console.log('Verify this is the Configure Widget page');
        WidgetRepoAdminPage.checkConfigureWidgetPage().then(function(present) {
            expect(present).to.equal(true);
            console.log('This is the Configure Widget page');
            callback();
        });
    });
    this.When(/^I select Upload new version of widget check box in configure widget page$/, function (callback) {
        console.log('Select Upload new version of widget check box');
        WidgetRepoAdminPage.selectConfigureWidgetUploadNewWidget().then(function() {
            console.log('Selected Upload new version of widget check box');
            callback();
        });
    });
    this.When(/^I click on save button on Configure Widget page - top right corner$/, function (callback) {
        console.log('Click on Save Button in top right corner of configure widget page');
        WidgetRepoAdminPage.clickConfigureWidgetSaveBtn().then(function() {
            console.log('Clicked on Save Button in top right corner of configure widget page');
            callback();
        });
    });
    this.Then(/^I should see the save button on Configure Widget page$/, function (callback) {
        console.log('Verify save button on Configure Widget page is present');
        WidgetRepoAdminPage.checkConfigureWidgetSaveBtn().then(function(present) {
            expect(present).to.equal(true);
            console.log('Save button on Configure Widget page is present');
            callback();
        });
    });
    this.Then(/^Save button in Configure Widget page is disabled$/, function (callback) {
        console.log('Verify save button in Configure Widget is disabled');
        WidgetRepoAdminPage.checkConfigureWidgetSaveBtnDisabled().then(function(disabled) {
            expect(disabled).to.equal('true');
            console.log('Save button in Configure Widget is disabled');
            callback();
        });
    });
    this.Then(/^I should see back link, to go back to widgets list page, on Configure Widget page$/, function (callback) {
        console.log('Verify back link on Configure Widget page is present');
        WidgetRepoAdminPage.checkConfigureWidgetBackLink().then(function(present) {
            expect(present).to.equal(true);
            console.log('Back link on Configure Widget page is present');
            callback();
        });
    });
    this.Then(/^I should see the widget title "([^"]*)" as the header on Configure Widget page$/, function (title, callback) {
        console.log('Verify widget title ' + title + ' as the header on page Configure Widget is present');
        WidgetRepoAdminPage.checkConfigureWidgetHeader(title).then(function(present) {
            expect(present).to.equal(true);
            console.log('widget title ' + title + ' on Configure Widget page is present');
            callback();
        });
    });
    this.Then(/^I should see the description "([^"]*)" of the widget as sub header on Configure Widget page$/, function (descrptn, callback) {
        console.log('Verify the description ' + descrptn + ' of the widget as sub header on Configure Widget page');
        WidgetRepoAdminPage.checkConfigureWidgetHeader(descrptn).then(function(present) {
            expect(present).to.equal(true);
            console.log('widget description ' + descrptn + ' on Configure Widget page is present');
            callback();
        });
    });
    this.Then(/^I should see the "([^"]*)" date on the top right corner of the Configure Widget page$/, function (lastUpdate, callback) {
        console.log('Verify ' + lastUpdate + ' date on the top right corner of the Configure Widget page is present');
        WidgetRepoAdminPage.checkConfigureWidgetHeader(lastUpdate).then(function(present) {
            expect(present).to.equal(true);
            console.log(lastUpdate + ' date on the top right corner of the Configure Widget page is present');
            callback();
        });
    });
    this.Then(/^I should see the "([^"]*)" number of the widget on Configure Widget page$/, function (version, callback) {
        console.log('Verify ' + version + ' number of the widget on Configure Widget page is present');
        WidgetRepoAdminPage.checkConfigureWidgetHeader(version).then(function(present) {
            expect(present).to.equal(true);
            console.log(version + ' number of the widget on Configure Widget page is present');
            callback();
        });
    });
    this.Then(/^I should see the "([^"]*)" in top right corner of the configure widget page$/, function (version, callback) {
        console.log('Verify version is equal to: ' + version);
        WidgetRepoAdminPage.checkConfigureWidgetHeader(version).then(function(present) {
            expect(present).to.equal(true);
            console.log(version + ' version is correct');
            callback();
        });
    });
    this.Then(/^I should see the "([^"]*)" label in Configure Widget page$/, function (title, callback) {
        console.log('Verify ' + title + ' label in Configure Widget page is present');
        WidgetRepoAdminPage.checkConfigureWidgetFormLabel(title).then(function(present) {
            expect(present).to.equal(true);
            console.log(title + ' label in Configure Widget page is present');
            callback();
        });
    });
    this.Then(/^I should see the star next to "([^"]*)" to indicate it is required field in Configure Widget page$/, function (title, callback) {
        console.log('Verify star next to' + title + ' label in Configure Widget page is present');
        WidgetRepoAdminPage.checkConfigureWidgetFormLabelStar(title).then(function(present) {
            expect(present).to.equal(true);
            console.log('Star next to ' + title + ' label in Configure Widget page is present');
            callback();
        });
    });
    this.Then(/^I should see a message "([^"]*)" in Configure Widget page$/, function (message, callback) {
        console.log('Verify ' + message + ' in Configure Widget page is present');
        WidgetRepoAdminPage.checkConfigureWidgetFormLabel(message).then(function(present) {
            expect(present).to.equal(true);
            console.log(message + ' in Configure Widget page is present');
            callback();
        });
    });
    this.Then(/^I should see Choose File button next to "([^"]*)" file selection in Configure Widget page$/, function (selection, callback) {
        console.log('Verify Choose File button next to ' + selection + ' file selection in Configure Widget page is present');
        WidgetRepoAdminPage.checkConfigureWidgetFormChooseFileBtn(selection).then(function(present) {
            expect(present).to.equal(true);
            console.log('Choose File button next to ' + selection + ' file selection in Configure Widget page is present');
            callback();
        });
    });
    this.Then(/^I should see input fields showing the sample file name "([^"]*)" on "([^"]*)" selection in Configure Widget page$/, function (fileName, selection, callback) {
        console.log('Verify input fields showing the sample file name ' + fileName + ' is present');
        WidgetRepoAdminPage.checkConfigureWidgetFormFileName(fileName, selection).then(function(present) {
            expect(present).to.equal(true);
            console.log('input fields showing the sample file name ' + fileName + ' is present');
            callback();
        });
    });
    this.Then(/^I should see Choose File button below "([^"]*)" file selection in Configure Widget page$/, function (selection, callback) {
        console.log('Verify Choose File button below ' + selection + ' file selection in Configure Widget page is present');
        WidgetRepoAdminPage.checkConfigureWidgetFormChooseFileBtnImg(selection).then(function(present) {
            expect(present).to.equal(true);
            console.log('Choose File button below ' + selection + ' file selection in Configure Widget page is present');
            callback();
        });
    });
    this.Then(/^I should see the saved image in image file selection in Configure Widget page$/, function (callback) {
        console.log('Verify the "No image available" image on "image" file selection in Configure Widget page is present');
        WidgetRepoAdminPage.checkConfigureWidgetFormImg().then(function(present) {
            expect(present).to.equal(true);
            console.log('The "No image available" image on "image" file selection in Configure Widget page is present');
            callback();
        });
    });
    this.Then(/^I should see the Add Tenant Access button on Configure Widget page$/, function (callback) {
        console.log('Verify the Add Tenant Access button on Configure Widget page is present');
        WidgetRepoAdminPage.checkConfigureWidgetAddTenantBtn().then(function(present) {
            expect(present).to.equal(true);
            console.log('Add Tenant Access button on Configure Widget page is present');
            callback();
        });
    });
    this.Then(/^I click on Add Tenant Access button on the Configure Widget page$/, function (callback) {
        console.log('Click on Add Tenant Access button on Configure Widget page');
        WidgetRepoAdminPage.clickConfigureWidgetAddTenantBtn().then(function() {
            console.log('Clicked on Add Tenant Access button on Configure Widget page');
            callback();
        });
    });
    this.Then(/^I should see a popup open for tenants$/, function (callback) {
        console.log('Verify a popup open for tenants is present');
        WidgetRepoAdminPage.checkConfigureWidgetPopupTenants().then(function(present) {
            expect(present).to.equal(true);
            console.log('A popup open for tenants is present');
            callback();
        });
    });
    this.Then(/^I should see a label Tenants$/, function (callback) {
        console.log('Verify a label Tenants is present');
        WidgetRepoAdminPage.checkConfigureWidgetPopupTenantsLabel().then(function(present) {
            expect(present).to.equal(true);
            console.log('A label Tenants is present');
            callback();
        });
    });
    this.Then(/^I should see a message "([^"]*)" on popup window$/, function (message, callback) {
        console.log('Verify message ' + message + ' on popup is present');
        WidgetRepoAdminPage.checkConfigureWidgetPopupTenantsMessage(message).then(function(present) {
            expect(present).to.equal(true);
            console.log('Message ' + message + ' on popup is present');
            callback();
        });
    });
    this.Then(/^I should see an input field to enter the tenant ids$/, function (callback) {
        console.log('Verify an input field to enter the tenant ids is present');
        WidgetRepoAdminPage.checkConfigureWidgetPopupInput().then(function(present) {
            expect(present).to.equal(true);
            console.log('An input field to enter the tenant ids is present');
            callback();
        });
    });
    this.Then(/^I should see save button in tenant popup$/, function (callback) {
        console.log('Verify save button in tenant popup is present');
        WidgetRepoAdminPage.checkConfigureWidgetPopupSaveBtn().then(function(present) {
            expect(present).to.equal(true);
            console.log('Save button in tenant popup is present');
            callback();
        });
    });
    this.Then(/^I should see cancel button in tenant popup$/, function (callback) {
        console.log('Verify cancel button in tenant popup is present');
        WidgetRepoAdminPage.checkConfigureWidgetPopupCancelBtn().then(function(present) {
            expect(present).to.equal(true);
            console.log('Cancel button in tenant popup is present');
            callback();
        });
    });
    this.Given(/^I enter the tenant id "([^"]*)" in tenant popup$/, function (tenantId, callback) {
        console.log('Verify I enter the tenant id ' + tenantId + ' in tenant popup');
        WidgetRepoAdminPage.enterConfigureWidgetPopupTenandId(tenantId).then(function() {
            console.log('tenant id ' + tenantId + ' was entered');
            callback();
        });
    });
    this.Then(/^I click on Save button in tenant popup$/, function (callback) {
        console.log('Click on Save button in tenant popup');
        WidgetRepoAdminPage.clickConfigureWidgetPopupSaveBtn().then(function() {
            console.log('Clicked on Save button in tenant popup');
            callback();
        });
    });
    this.Then(/^I should not see the tenant "([^"]*)" in the list$/, function (tenantId, callback) {
        console.log('Verify tenant ' + tenantId + ' is not present');
        WidgetRepoAdminPage.checkConfigureWidgetPopupNoTenantId(tenantId).then(function(present) {
            expect(present).to.equal(false);
            console.log('tenant ' + tenantId + ' is not present');
            callback();
        });
    });
    this.Given(/^Hard delete all versions of the widget "([^"]*)" from widget library$/, function (widgetID, callback) {
        console.log("inside the step def Hard delete all versions of the widget");

        var buffer = new Buffer('ingestor.496bb641-78b5-4a18-b1b7-fde29788db38.991e5c23-3e9c-4944-b08b-9e83ef0ab598:');
        var base64s = buffer.toString('base64');
        Logger.info(base64s);

        var adminUserOpts = {
            url: browser.params.login.tokenURL,
            headers:{
                'Authorization': 'Basic ' + base64s,
                'Content-Type': 'application/x-www-form-urlencoded',
                'tenant': browser.params.login.tenantID
            },
            body:{
                'grant_type' : 'password',
                'username' : browser.params.login.widgetRepoUser,
                'password' : browser.params.login.widgetRepoPswd
            }
        };
        RestHelper.getAccessToken(adminUserOpts.url, adminUserOpts.headers, adminUserOpts.body,function(err, token){
            // console.log('token: '+token);
            var opts = {
                url: browser.params.login.DeletewidgetServiceURL + widgetID,
                headers: {
                    // 'Content-Type': 'application/json',
                    'tenant':browser.params.login.tenantID,
                    'Authorization':'bearer ' +  token
                }
            };
            RestHelper.executeDeleteRequest(opts.url, opts.headers, function(err, res){
                console.log('response status: ' + res.status);
                console.log("Response Body : " + JSON.stringify(res.body));
                // TestHelper.assertEqual(res.status, 204,callback);
                callback();
            })
        });

    });
};

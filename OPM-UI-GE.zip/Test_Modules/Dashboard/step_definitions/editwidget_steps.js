/**
 * Created by 212340705 on Mar 21st 2016.
 */
var TotalDashboards = 0;
module.exports = function() {
    // this.setDefaultTimeout(60000);

    this.Then(/^I click on edit icon for widget "([^"]*)" in custom card$/, function (num, callback) {
        console.log('about to click on edit widget icon for widget # ' + num );
        //var widget = element.all(by.css('div.layout__block.custom-card')).get(num-1);
        var widget = customcardpage.getwidget(num-1);
        browser.actions().mouseMove(widget).perform().then(function(){
            console.log('mouseover done: ' );
            addcardpage.clickEditWidgetIconCustomEditCard(num-1).then(function(){
                console.log('Clicked on edit widget icon for widget# ' + num);
                callback();
            });
        });
    });

    this.When(/^I click on delete icon for widget "([^"]*)" in Custom card to delete "([^"]*)"$/, function (num, widget, callback) {
        console.log('about to click on delete widget icon for widget # ' + num );



        var widgets = element.all(by.css('div.layout__block.custom-card')).get(num-1);

        browser.actions().mouseMove(widgets).perform().then(function(){

            console.log('mouseover done: ' );
            addcardpage.getDltWidgetIconCustomEditCard((num*2)-1).click()
                .then(function(){

                    console.log('Clicked on delete widget icon for widget# ' + num);
                    expect(element(by.css(widget)).isPresent()).to.eventually.be.eql(false).notify(callback);
                });
        });
    });

    this.Then(/^Error "(.*)" should be shown$/, function (arg1, callback) {
        console.log('Verify the error message');

        //element(by.cssContainingText('#navitemlist a span', arg1)).isPresent()
        editWidgetPage.getErrorMessageText().isPresent().then(function(present){
            expect(present).to.equal(true);
            console.log('Error message : You do not have permission to perform this action. ');
            callback();
        });
    });


    this.Then(/^I click on edit icon for widget "([^"]*)" in 6up card$/, function (num, callback) {
        console.log('about to click on edit widget icon for widget # ' + num );

        var widget;
        switch (Number(num)){
            case 1:
                widget = element(by.css('div.widget-1'));
                break;
            case 2:
                widget = element(by.css('div.widget-2'));
                break;
            case 3:
                widget = element(by.css('div.widget-3'));
                break;
            case 4:
                widget = element(by.css('div.widget-4'));
                break;
            case 5:
                widget = element(by.css('div.widget-5'));
                break;
            case 6:
                widget = element(by.css('div.widget-6'));
                break;
        }

        browser.actions().mouseMove(widget).perform().then(function(){
            console.log('mouseover done: ' );
            addcardpage.getEditWidgetIcon6upEditCard(num-1).click().then(function(){
                console.log('Clicked on edit widget icon for widget# ' + num);
                callback();
            });
        });
    });
    this.When(/^I should see widget configuration page$/, function (callback) {
        console.log('Verify edit widget page opens up');
        editWidgetPage.getEditWidgetHeaderByText().isPresent().then(function(present){
            expect(present).to.equal(true);
            console.log('Edit widget header is present');
            callback();
        });
    });

    this.When(/^I should see widget title field$/, function (callback) {

        console.log('Verify Title field is present');
        editWidgetPage.getEditWidgetTitleNamebyText().isPresent().then(function(present){
            expect(present).to.equal(true);
            console.log('Edit widget title field is present');
            callback();
        });
    });


    this.When(/^I should see widget target field$/, function (callback) {
        console.log('Verify target field is present');
        editWidgetPage.getEditWidgetTargetNamebyText().isPresent().then(function(present){
            expect(present).to.equal(true);
            console.log('Edit widget Target field is present');
            callback();
        });
    });
    this.When(/^I should see widget threshold field$/, function (callback) {

        console.log('Verify threshold field is present');
        editWidgetPage.getEditWidgetThresholdNamebyText().isPresent().then(function(present){
            expect(present).to.equal(true);
            console.log('Edit widget threshold is present');
            callback();
        });
    });

    this.When(/^I should see widget chart field$/, function (callback) {

        console.log('Verify chart field is present');
        editWidgetPage.getEditWidgetChartNamebyText().isPresent().then(function(present){
            expect(present).to.equal(true);
            console.log('Edit widget chart field is present');
            callback();
        });
    });

    this.Then(/^Edit Widget title field as "([^"]*)"$/, function (arg1, callback) {
        console.log('Verify Title field is present');
        editWidgetPage.configureTitleinputfield().clear().then(function() {
            editWidgetPage.configureTitleinputfield().sendKeys(arg1).then(function () {
                console.log('Edit widget title field is present');
                callback();
            });
        });
    });

    this.Then(/^I should see the title field "([^"]*)"$/, function (arg1, callback) {
        console.log('Verify Title field is present');
        browser.sleep(5000).then(function () {
            editWidgetPage.configureTitleinputfield().getAttribute("value").then(function (string) {
                expect(string).contains(arg1);
                console.log(' STRING ', string);
                console.log('Edit widget title field is present');
                callback();
            });
        });
    });

    this.Then(/^Edit Widget Threshold field as "([^"]*)"$/, function (arg1, callback) {
        console.log('Verify Threshold field is present');
        editWidgetPage.configureThresholdinputfield().clear().then(function() {
            editWidgetPage.configureThresholdinputfield().sendKeys(arg1).then(function () {
                console.log('Edit widget Threshold field is present');
                callback();
            });
        });
    });

    this.Then(/^I should see the threshold field "([^"]*)"$/, function (arg1, callback) {
        console.log('Verify Threshold field is present');
        browser.sleep(5000).then(function () {
            editWidgetPage.configureThresholdinputfield().getAttribute("value").then(function (string) {
                expect(string).contains(arg1);
                console.log(' STRING ', string);
                console.log('Edit widget Threshold field is present');
                callback();
            });
        });
    });

    this.Then(/^Edit Widget Target field as "([^"]*)"$/, function (arg1, callback) {
        console.log('Verify Target field is present');
        editWidgetPage.configureTargetinputfield().clear().then(function() {
            editWidgetPage.configureTargetinputfield().sendKeys(arg1).then(function () {
                console.log('Edit widget Target field is present');
                callback();
            });
        });
    });

    this.Then(/^I should see the target field "([^"]*)"$/, function (arg1, callback) {
        console.log('Verify Target field is present');
        browser.sleep(5000).then(function () {
            editWidgetPage.configureTargetinputfield().getAttribute("value").then(function (string) {
                expect(string).contains(arg1);
                console.log(' STRING ', string);
                console.log('Edit Target Threshold field is present');
                callback();
            });
        });
    });


    this.When(/^I should see current widget configuration page$/, function (callback) {
        console.log('Verify edit widget page opens up');
        editWidgetPage.getCurrentWidgetHeaderByText().isPresent().then(function(present){
            expect(present).to.equal(true);
            console.log('Edit widget header is present');
            callback();
        });
    });

    this.When(/^I should see send and receive buttons in actions menu on edit widget page$/, function (callback) {

        console.log('Verify edit widget page opens up');
        editWidgetPage.checkCommSendAndReceiveButtonInInteraciveGraphWidget().then(function(present){
            expect(present).to.equal(true);
            console.log('Edit widget header is present');
            callback();
        });

    });
    this.When(/^I enable the send messages feature in actions menu on edit widget page$/, function (callback) {

        console.log('Verifying send button is present');
        editWidgetPage.clickSendDataBtn().then(function(present){
            expect(present).to.equal(true);
            console.log('send button is present');
            callback();
        });

    });
    this.When(/^I enable the receive messages feature in actions menu on edit widget page$/, function (callback) {

        console.log('Verifying receiving button is present');
        editWidgetPage.clickReceiveDataBtn().then(function(present){
            expect(present).to.equal(true);
            console.log('recieve button is present');
            callback();
        });

    });
    this.When(/^I should see "([^"]*)" as the default refresh property$/, function (refresh, callback) {

        console.log('Verify default refresh property value is ', refresh);
        //editWidgetPage.getWidgetRefreshProperty().getText().then(function(txt){
        editWidgetPage.getWidgetRefreshProperty().then(function(txt){
            expect(txt.trim()).to.equal(refresh);
            console.log('default refresh property: ' + txt + '.  Expected:  ' + refresh);
            callback();
        });
    });
    this.When(/^I should see "([^"]*)" as the default navigation property$/, function (navigation, callback) {

        console.log('Verify default navigation property value is ', navigation);
        //editWidgetPage.getWidgetNavigationProperty().getText().then(function(txt){
        editWidgetPage.getWidgetNavigationProperty().then(function(txt){
            expect(txt.trim()).to.equal(navigation);
            console.log('default navigation property: ' + txt + '.  Expected:  ' + navigation);
            callback();
        });
    });
    this.When(/^Get the dashboard count from deck selector on dashboard page$/, function ( callback) {

        console.log('Get the dashboard count and store into a global variable for later user ');
        createviewpage.getDashboardsCountInDeck().then(function(count){
            TotalDashboards = count;
            console.log('decks in deckselector dropdown: ' + count );
            callback();
        });
    });
    this.When(/^I select "([^"]*)" from navigation options$/, function (navigationOption, callback) {

        console.log('Clicking on the navigation option ' + navigationOption);

        editWidgetPage.clickWidgetNavigationSelect().then(function(){
            console.log('Clicked on the navigation select');
            editWidgetPage.clickSelectedOption(navigationOption).then(function(){
                console.log('Clicked on the navigation option ' + navigationOption);
                callback();
            });
        });
    });

    this.When(/^I select "([^"]*)" from refresh options$/, function (refreshOption, callback) {

        console.log('Clicking on the refresh option ' + refreshOption);

        editWidgetPage.getWidgetRefreshSelect().click().then(function(){
            console.log('Clicked on the refresh select');
            editWidgetPage.clickSelectedOption(refreshOption).then(function(){
                console.log('Clicked on the refresh option ' + refreshOption);
                callback();
            });
        });
    });
    this.When(/^I click on search icon on tag toolbox$/, function (callback) {

        console.log('Clicking on the tag toolbox');
        editWidgetPage.clickTagSearchIcon().then(function(){
            console.log('Clicked on the search tag icon ');
            callback();
        });
    });
    this.When(/^I select "([^"]*)" from search criteria$/, function (tagOption, callback) {
        console.log('Selecting the tag search option ' + tagOption);

        editWidgetPage.clickSearchCriteriaSelector().then(function(){
            browser.sleep(4000);
            console.log('Clicked on the tag toolbox criteria selector dropdown');
            editWidgetPage.clickSelectedOption(tagOption).then(function(){
                console.log('Clicked on the tag toolbox option ' + tagOption);
                callback();
            });
        });
    });
    this.When(/^I should not see "([^"]*)" from search criteria$/, function (tagOption, callback) {
        console.log('Checking tag search option:-- ' + tagOption);

        editWidgetPage.clickSearchCriteriaSelector().then(function(){
            console.log('Clicked on the tag toolbox criteria selector dropdown');
            editWidgetPage.getSelectedOption2(tagOption).then(function(present){
                console.log('Option ' + tagOption + ' is present:' + present);
                expect(present).to.equal(false);
                callback();
            });
        });
    });

    this.Given( /^I enter tag search "([^"]*)" in tag toolbox$/, function (tagInput, callback) {
        console.log('Entering search criteria in to tag search input field ');
        editWidgetPage.getTagToolboxInput().sendKeys(tagInput).then(function(){
            editWidgetPage.getTagToolboxInput().click().then(function() {
                browser.sleep(5000).then(function () {
                    callback();
                });
            });
        });
    });

    this.Then(/^I clear tag search input field\$$/, function (callback) {
        console.log('Clearing Tag search input field');
        editWidgetPage.clearTagSearchInputField().then(function(){
            console.log('Cleared tag search tag field');
            callback();
        });
    });

    this.Given( /^I select a tag from search results and add to the widget$/, function (callback) {
        console.log('Clicking on the first tag search result');
        editWidgetPage.getTagToolboxInput().click().then( function () {
            console.log('clicked on tag search input field');
            editWidgetPage.getFirstTagName().then(function(firstTagInSearchResults){
                var firstTagInSearchResults = firstTagInSearchResults;
                console.log('firstTagInSearchResults: ', firstTagInSearchResults);
                var tagToolboxSearchResult = editWidgetPage.getTagToolboxSearchResult();
                browser.actions().mouseMove(tagToolboxSearchResult).perform().then(function(){
                    console.log('mouseover done: ');
                    var tagToolboxSearchResultIcon = editWidgetPage.getTagToolboxSearchResultIcon();
                    tagToolboxSearchResultIcon.click().then(function(){
                        callback();
                    });
                });
            });
        });
    });

    this.Then(/^tag "([^"]*)" and tag "([^"]*)" should exist in plotted tags list$/, function (arg1, arg2, callback) {
        var tagNames = editWidgetPage.getPlottedTagNames();
        tagNames.then(function(res){
            expect(res).to.include(arg1);
            expect(res).to.include(arg2);
            callback();
        });
    });


    this.Given( /^I select a tag from search results and add to the widget for second tag$/, function (callback) {
        console.log('Clicking on the first tag search result');
        //editWidgetPage.chkNoResultsFound().then(function(yeah){
        //    if(yeah){
        editWidgetPage.getTagToolboxInput().click() .then( function () {
            console.log('clicked on tag search input field');
            editWidgetPage.getFirstTagName().then(function(firstTagInSearchResults){
                console.log(firstTagInSearchResults) ;
                browser.actions().mouseMove(editWidgetPage.getTagToolboxSearchResult()).perform().then(function(){
                    console.log('mouseover done: ');
                    editWidgetPage.getTagToolboxSearchResultIcon().click().then(function(){
                        editWidgetPage.getSecondPlottedTagName() .then(function(txt){
                            expect(txt).to.equal(firstTagInSearchResults);
                            console.log("Tag added to the widget");
                            callback();
                        });
                    });
                });
            });
        })
        //    }else{
        //        console.log('Tag search not found any results, unable to click on first tag');
        //        callback();
        //    }
        //})
    });


    this.Then(/^I remove plotted tag "([^"]*)"$/, function (arg1, callback) {
        console.log(arg1) ;
        browser.actions().mouseMove(editWidgetPage.getFirstPlottedTag()).perform().then(function() {
            console.log('mouseover done: ');
            editWidgetPage.getTagToolboxPlottedTagIcon().click().then(function () {
                console.log("Tag removed from the widget");
                callback();
            });
        });
    });


    this.Given( /^I click on Done button in edit widget page$/, function (callback) {
        console.log('about to click on the done button in edit widget configuration page');

        browser.sleep(3000).then(function(){
            editWidgetPage.clickDoneBtnEditWidget().then( function () {
                console.log('Clicked on the done button in edit widget configuration page.');
                browser.sleep(3000).then(function(){callback()});
            });
        });
    });

    this.Given( /^I click on the save button after configuring the widget$/, function (callback) {
        console.log('about to click on save card button');

        editWidgetPage.clickWidgetSaveCardButton().then( function () {
            browser.sleep(5000).then(function(){
                console.log('Clicked on the save card button.');
            });
            callback();
        })
    });

    this.Given( /^I should not see navigation icon on Graph widget$/, function (callback) {
        console.log('Checking for the navigation icon');

        editWidgetPage.getWidgetNavigationHiddenIcon().isPresent().then(function(hidden){
            expect(hidden).to.equal(true);
            console.log('navigation icon on graph widget is NOT present');
            callback();
        });
    } );

    this.Given( /^I should see navigation icon on Graph widget$/, function (callback) {
        console.log('Checking for the navigation icon');

        editWidgetPage.getWidgetNavigationVisibleIcon().then(function(present){
            expect(present).to.equal(true);
            console.log('navigation icon on graph widget is present and enabled');
            callback();
        });
    } );

    this.Given( /^the navigation button is disabled$/, function (callback) {
        console.log('Checking for the navigation icon');

        editWidgetPage.getWidgetNavigationDisabledIcon().isPresent().then(function(disabled){
            expect(disabled).to.equal(true);
            console.log('navigation icon on graph widget is disabled');
            callback();
        });
    } );

    this.Given( /^the Ondemand refresh icon is disabled$/, function (callback) {
        console.log('Checking for the navigation icon');

        editWidgetPage.getWidgetRefreshDisabledIcon().isPresent().then(function(disabled){
            expect(disabled).to.equal(true);
            console.log('refresh icon on  widget is disabled');
            callback();
        });
    } );

    this.Given( /^the navigation button is enabled$/, function (callback) {
        console.log('Checking for the enabled navigation icon');

    editWidgetPage.getWidgetNavigationEnabledIcon().isPresent().then(function(enabled){
        expect(enabled).to.equal(true);
        console.log('navigation icon on graph widget is enabled');
        callback();
    });
} );

    this.Then(/^I should see Ondemand refresh icon Widget$/, function (callback) {
        console.log('Checking for the navigation icon'); 
        
        editWidgetPage.getWidgetRefreshVisibleIcon().isPresent() .then(function(present){ 
            expect(present).to.equal(true); 
            console.log('refresh icon on  widget is present and enabled'); 
            callback(); 
        }); 
    } );
    this.Then(/^I should not see Ondemand refresh button on non-static widgets/, function (callback) {
        console.log('I should not see Ondemand refresh button on non-static widgets');
        editWidgetPage.getOnDemandRefreshBtn().isPresent() .then(function(present){
            expect(present).to.equal(false);
            console.log('On-Demand refresh button on widget is present: ' + present);
            callback();
        });
    });

    this.Then(/^the Ondemand refresh icon is enabled$/, function (callback) {
        console.log('Checking for the enabled navigation icon'); 
        
        editWidgetPage.getWidgetRefreshEnabledIcon().isPresent() .then(function(enabled){ 
            expect(enabled).to.equal(true); 
            console.log('refresh icon on  widget is enabled'); 
            callback(); 
        }); 
    } );


    this.Then( /^I click on Navigation icon on the Graph widget$/, function (callback) {
        console.log('Clicking on the navigation icon on graph widget');
        browser.sleep(5000);
        try{
            console.log("find element - "  + editWidgetPage.getWidgetNavigationEnabledIcon());
            editWidgetPage.getWidgetNavigationEnabledIcon().click().then(function(){
                console.log("Clicked on the navigation icon") ;
                callback();
            }) ;
        }catch(e){
            console.log("Retrying after a lag to handle refresh disabling the widget.") ;

            editWidgetPage.getWidgetNavigationEnabledIcon().click().then(function(){
                console.log("Clicked on the navigation icon") ;
                callback();
            }) ;
        }

    } );

    this.Given( /^I should navigate to "([^"]*)" from Graph widget$/, function (url, callback) {
        console.log('Clicking on the navigation icon on graph widget');

        browser.getAllWindowHandles().then(function (handles) {
            var newWindowHandle = handles[1];
            console.log('New tab opened ', newWindowHandle);
            browser.driver.switchTo().window(newWindowHandle).then(function () {

                browser.getCurrentUrl().then(function(newurl) {
                    console.log('URL for the new tab is ', newurl);
                    //var isUrlMatching = newurl.indexOf(url, newurl.length - url.length) !== -1;
                    var isUrlMatching = newurl.indexOf(url) !== -1;
                    expect(isUrlMatching).to.equal(true);

                    callback();
                });
            });
        });
    });

    this.When(/^I should see edit widget as page header$/, function (callback) {

        console.log('Verify edit widget page header');

        editWidgetPage.getEditWidgetPageHeader().getText()
            .then(function(txt){
                expect(txt.trim()).to.equal('EDIT WIDGET');
                console.log('edit widget page header: ' + txt + '.  Expected:  EDIT WIDGET' );
                callback();
            });
    });

    this.Then( /^I click on "([^"]*)" alerts on static alerts widget$/, function (priority, callback) {
        console.log('Clicking on the priority link ' + priority + ' on alerts widget.');

        try{
            editWidgetPage.getWidgetAlertsByPriority(Number(priority)-1).click().then(function(){
                console.log("Clicked on the priority link for " + priority) ;
                callback();
            }) ;
        }catch(e){
            console.log("Retrying after a lag to handle refresh disabling the widget.") ;

            editWidgetPage.getWidgetAlertsByPriority(Number(priority)-1).click().then(function(){
                console.log("Clicked on the priority link for " + priority) ;
                callback();
            }) ;
        }

    } );

    this.Then( /^I should navigate to microapp in chromeless tab "([^"]*)"$/, function (url, callback) {
        console.log('Opening a new microapp in a new browser tab');
        browser.sleep(5000).then(function(){
            browser.getAllWindowHandles().then(function (handles) {
                console.log('handles: ' + handles);
                var newWindowHandle = handles[1];
                console.log('New tab opened ', newWindowHandle);
                browser.sleep(10000).then(function(){
                    browser.driver.switchTo().window(newWindowHandle).then(function () {
                        browser.getCurrentUrl().then(function(newurl) {
                            console.log('URL for the new tab is ', newurl);
                            console.log('URL for the new tab is ', url);
                            //var isUrlMatching = newurl.indexOf(url, newurl.length - url.length) !== -1;
                            var isUrlMatching = newurl.indexOf(url) !== -1;
                            console.log('isURLMatching: ',newurl.indexOf(url));
                            expect(isUrlMatching).to.equal(true);
                            callback();
                        });
                    });
                });

            });
        })


    });

    this.Then( /^I should navigate to cases microapp in chromeless tab "([^"]*)" for "([^"]*)" cases$/, function (url, severity, callback) {

        editWidgetPage.getWidgetCasesBySeverity(severity).isPresent().then(function(present){
            if(present){
                console.log('Opening new browser tab for cases.');

                browser.getAllWindowHandles().then(function (handles) {
                    var newWindowHandle = handles[1];
                    console.log('New tab opened ', newWindowHandle);
                    browser.driver.switchTo().window(newWindowHandle).then(function () {

                        browser.getCurrentUrl().then(function(newurl) {
                            console.log('URL for the new tab is ', newurl);
                            //var isUrlMatching = newurl.indexOf(url, newurl.length - url.length) !== -1;
                            var isUrlMatching = newurl.indexOf(url) !== -1;
                            expect(isUrlMatching).to.equal(true);

                            callback();
                        });
                    });
                });
            }else{
                callback();
            }
        }) ;

    });


    this.Then( /^I close the new browser tab$/, function (callback) {
        console.log('Closing the new browser tab');
        browser.getAllWindowHandles().then(function (handles) {
                if(handles.length > 1){
                    newWindowHandle = handles[1];
                    browser.switchTo().window(newWindowHandle).then(function () {
                        browser.driver.close().then(function () {
                            console.log('closed the new browser tab');
                            browser.switchTo().window(handles[0]);
                            callback();
                        });
                    });
                }else{
                    callback();
                }
         });
    });

    this.Then( /^I switch to the main browser tab$/, function (callback) {
        console.log('Switching to the main browser tab');
        browser.getAllWindowHandles().then(function (handles) {
            browser.switchTo().window(handles[0]);

            callback();
        });
    });

    this.Then( /^the Priority "([^"]*)" alerts are displayed$/, function (priority, callback) {
        console.log('Checking for priority ' + priority + ' alerts.');

        browser.getAllWindowHandles().then(function (handles) {
            browser.driver.switchTo().window(handles[0]);
            editWidgetPage.getWidgetAlertsNumber(Number(priority)-1)
                .then(function(num){
                    if(num > 0){
                        browser.driver.switchTo().window(handles[1]);
                        editWidgetPage.getAlertsInListByPriority(priority)
                            .then(function(badge){
                                expect(badge).to.equal(priority);
                                console.log("Checked for the badges present on alerts for priority " + priority) ;

                                callback();
                            }) ;
                    }else{
                        console.log("There are no alerts with priority " + priority + ". Hence not checking for the badges") ;
                        callback();
                    }
                }) ;
        });
    } );

    this.Then( /^the alerts with priority "([^"]*)" are in "([^"]*)" state$/, function (priority, status, callback) {
        console.log('Checking for alert status ');

        browser.getAllWindowHandles().then(function (handles) {
            browser.driver.switchTo().window(handles[0]);
            editWidgetPage.getWidgetAlertsNumber(Number(priority)-1)
                .then(function(num){
                    if(num > 0){
                        browser.driver.switchTo().window(handles[1]);
                        editWidgetPage.getAlertsInListByStatus()
                            .then(function(txt){
                                expect(txt).to.equal(status);
                                console.log("Checked for the status of alert") ;

                                callback();
                            }) ;
                    }else{
                        console.log("There are no alerts with priority " + priority  + ". Hence not checking for the status") ;
                        callback();
                    }
                }) ;
        });
    } );

    this.Given( /^"([^"]*)" cases are present on static cases widget$/, function (severity, callback) {
        console.log('Clicking on the open case bar ' + severity + ' on cases widget.');

        editWidgetPage.getWidgetCasesBySeverity(severity).isPresent().then(function(present){
            callback();
        }) ;
    } );

    this.Then( /^I click on "([^"]*)" cases on static cases widget$/, function (severity, callback) {
        console.log('Clicking on the open case bar ' + severity + ' on cases widget.');


        browser.driver.isElementPresent(by.css('rect[severity*="' + severity + '"]:not([height="0"])')).then(function (isPresent) {
            if(isPresent){
                try{
                    editWidgetPage.getWidgetCasesBySeverity(severity).click().then(function(){
                        console.log("Clicked on the cases severity bar for " + severity) ;

                        callback();
                    }) ;
                }catch(e){
                    console.log("Clicking on widget element failed. Retrying.");

                    editWidgetPage.getWidgetCasesBySeverity(severity).click().then(function(){
                        console.log("Clicked on the cases severity bar for " + severity) ;

                        callback();
                    }) ;
                }

            }else{
                console.log("No open cases with severity " + severity) ;
                callback();
            }
        });
    } );

    this.Then( /^the Severity "([^"]*)" cases are displayed$/, function (severity, callback) {


        browser.getAllWindowHandles().then(function (handles) {
            if(handles.length > 1){
                browser.driver.switchTo().window(handles[1]);
                console.log('Checking the cases list for severity ' + severity);
                editWidgetPage.getCasesInListBySeverity().then(function(txt){
                    expect(txt).to.equal(severity);
                    console.log("Checked the cases list for severity " + severity);

                    callback();
                }) ;
            }else{
                console.log("No open cases with severity " + severity) ;
                callback();
            }
        });
    } );


    this.Then( /^the cases are in "([^"]*)" state$/, function (state, callback) {

        browser.getAllWindowHandles().then(function (handles) {
            if(handles.length > 1){
                browser.driver.switchTo().window(handles[1]);
                console.log('Checking the cases list for state ' + state);
                editWidgetPage.getCasesInListByStatus().then(function(txt){
                    expect(txt).to.equal(state);
                    console.log("Checked the cases list for status " + state);

                    callback();
                }) ;
            }else{
                console.log("No open cases with this severity.") ;
                callback();
            }
        });


    } );

    this.Then( /^I should not see Actions section in edit widget page$/, function (callback) {

        console.log('Checking actions section available in the generic graph widget ');
        editWidgetPage.checkActionsSectionInGenericGraphWidget().then(function(txt){
            expect(txt).to.equal(false);
            console.log("Checked actions section not available in the generic graph widget ");
            callback();
        }) ;

    } );

    this.Then( /^I should not see navigation option in edit widget page$/, function (callback) {

        console.log('Checking navigation option button available in the generic graph widget ');
        editWidgetPage.checkNavigationButtonInGenericGraphWidget().then(function(txt){
            expect(txt).to.equal(false);
            console.log("Checked navigation option not available in the generic graph widget ");
            callback();
        }) ;

    } );

    this.Then( /^I should not see Send N Receive data options on edit widget page$/, function (callback) {

        console.log('Checking communication option button available in the generic graph widget ');
        editWidgetPage.checkCommSendAndReceiveButtonInGenericGraphWidget().then(function(txt){
            expect(txt).to.equal(false);
            console.log("Checked communication option not available in the generic graph widget ");
            callback();
        }) ;

    });

    this.Then( /^I should see Actions section in edit widget page$/, function (callback) {

        console.log('Checking actions section available in the interactive graph widget ');
        editWidgetPage.checkActionsSectionInGenericGraphWidget().then(function(txt){
            expect(txt).to.equal(true);
            console.log("Checked actions section available in the interactive graph widget ");
            callback();
        }) ;

    });

    this.Then( /^I should see Navigation option in edit widget page disabled$/, function (callback) {

        console.log('Checking navigation option button disbaled in the interactive graph widget ');
        editWidgetPage.checkNavigationButtonDisabledInInteractiveGraphWidget().then(function(txt){
            expect(txt).to.equal(false);
            console.log("Checked navigation option disabled in the interactive graph widget ");
            callback();
        }) ;

    });

    this.Then( /^I should not be able to select Goes To option in edit widget page$/, function (callback) {

        console.log('Checking Goes to option button disabled in the interactive graph widget ');
        editWidgetPage.checkGoToButtonDisabledInInteractiveGraphWidget().then(function(txt){
            expect(txt).to.equal(false);
            console.log("Checked Goes to option disabled in the interactive graph widget ");
            callback();
        }) ;

    });

    this.Then( /^I click anywhere on the widget "([^"]*)" to send message$/, function (callback) {
        console.log('Checking for received sent in the interactive graph widget. Need manual testing')
    });

    this.Then( /^I check the widget "([^"]*)" is receiving the message$/, function (callback) {
        console.log('Checking for received message in the interactive graph widget. Need manual testing');
    });

    this.Then( /^I check the widget "([^"]*)" is not receiving any messages$/, function (num, callback) {
        console.log('Checking for received not message in the interactive graph widget. Need manual testing');
    });

    this.Then( /^I enable Navigation on edit widget page$/, function (callback) {

        console.log('Enabling Navigation in the interactive graph widget');
        editWidgetPage.enableNavigationInInteractiveGraphWidget().then(function(txt){
            expect(txt).to.equal(true);
            browser.sleep(5000).then(function(){

            });
            console.log("Enabled Navigation in the interactive graph widget");
            callback();
        }) ;

    } );

    this.Then( /^I should see 2 options in navigation menu$/, function (callback) {

        console.log('Checking 2 Options available in the goto menu in the interactive graph widget');
        editWidgetPage.checkOptionsInGoToInInteractiveGraphWidget().then(function(txt){
            expect(txt).to.have.length.above(2);
            console.log("Checked 2 Options available in the goto menu in the interactive graph widget");
            callback();
        }) ;

    } );

    this.Then( /^I should see Dashboard option$/, function (callback) {

        console.log('Checking Dashboard Option available in the goto menu in the interactive graph widget');
        editWidgetPage.checkOptionsInGoToInInteractiveGraphWidget().then(function(txt){
            expect(txt).to.have.length.above(2);
            console.log("Checked Dashboard Option available in the goto menu in the interactive graph widget");
            callback();
        }) ;

    } );

    this.Then( /^I should see Analysis View options$/, function (callback) {

        console.log('Checking Analysis Option available in the goto menu in the interactive graph widget');
        editWidgetPage.checkOptionsInGoToInInteractiveGraphWidget().then(function(txt){
            expect(txt).to.have.length.above(2);
            console.log("Checked Analysis Option available in the goto menu in the interactive graph widget");
            callback();
        }) ;

    } );

    this.Then( /^I check Analysis View is selected in Goes To field$/, function (callback) {

        console.log('Analysis Option is selecting in the goto menu in the interactive graph widget');
        editWidgetPage.enableNavigationInInteractiveGraphWidget().then(function(txt){
            expect(txt).to.equal(true);
            console.log("Analysis Option selected in the goto menu in the interactive graph widget");
            callback();
        }) ;

    } );

    this.Then( /^I should see navigation icon enabled on generic graph interactive widget$/, function (callback) {

        console.log('Navigation Icon is enabling in the interactive graph widget');
        editWidgetPage.getWidgetNavigationEnabledIcon().isPresent().then(function(enabled){
            expect(enabled).to.equal(true);
            console.log("Navigation Icon enabled in the interactive graph widget");
            callback();
        }) ;
    });

    this.Then( /^I should see refresh data option in dashboard menu$/, function (callback) {
        console.log('I should see Pause data option in dashboard menu');
        editWidgetPage.getRefreshDataLink().then(function(txt){
            console.log('getRefreshDataLink ' + txt);
            expect(txt).to.equal(true);
            callback();
        }) ;
    });
    this.Then( /^I should see pause data option in dashboard menu$/, function (callback) {
        console.log('I should see Pause data option in dashboard menu');
        editWidgetPage.getPauseDataLink().then(function(txt){
            console.log('getPauseDataLink ' + txt);
            expect(txt).to.equal(true);
            callback();
        }) ;
    });
    this.Then( /^I click on pause data option in dashboard menu$/, function (callback) {
        console.log('I click Pause data option in dashboard menu');
        editWidgetPage.clickPauseDataLink().then(function(){
            // expect(txt).to.equal(true);
            callback();
        }) ;
    });
    this.Then( /^I check pause data option becomes unpause data in dashboard menu$/, function (callback) {
        console.log('I check pause data option becomes unpause data in dashboard menu');
        editWidgetPage.getUnpauseDataLink().then(function(txt){
            console.log("unpause data expected: " + txt);
            expect(true).to.equal(txt);
            callback();
        }) ;
    });
    this.Then( /^I click on unpause data option in dashboard menu$/, function (callback) {
        console.log('I check pause data option becomes unpause data in dashboard menu');
        editWidgetPage.clickUnpauseDataLink().then(function(){
            // expect(true).to.equal(txt);
            callback();
        }) ;
    });
    this.Then( /^I should see pause data banner displayed on the dashboard$/, function (callback) {
        console.log('I should see pause data banner displayed on the dashboard');
        editWidgetPage.getPauseDataRefreshBar().then(function(txt){
            console.log("getPauseDataRefreshBar expected: " + txt);
            expect(true).to.equal(txt);
            callback();
        }) ;
    });
    this.Then( /^I should not see pause data banner displayed on the dashboard$/, function (callback) {
        console.log('I should not see pause data banner displayed on the dashboard');
        editWidgetPage.getPauseDataRefreshBarHide().then(function(txt){
            console.log("getPauseDataRefreshBar expected: " + txt);
            expect(false).to.equal(txt);
            callback();
        }) ;
    });
    this.Then( /^I should check data paused message on the banner$/, function (callback) {
        console.log('I should see Data Paused message on the banner');
        editWidgetPage.chkPauseDataMsg().then(function(txt){
            console.log("Pause data expected: " + txt);
            expect(true).to.equal(txt);
            callback();
        }) ;
    });
    this.Then( /^I should see data paused a few seconds ago message on the banner$/, function (callback) {
        console.log('I should see Data Paused message on the banner');
        editWidgetPage.getPauseDataMsg().then(function(txt){
            console.log("Pause data expected: " + txt );
            // expect(true).to.equal(txt);
            callback();
        }) ;
    });
    this.Then( /^I should see resume button on the banner$/, function (callback) {
        console.log('I should see Resume button on the banner');
        editWidgetPage.getPausedDataResumeBtn().then(function(txt){
            console.log("getPausedDataResumeBtn expected: " + txt);
            expect(true).to.equal(txt);
            callback();
        }) ;
    });
    this.Then( /^I should click resume button on the banner$/, function (callback) {
        console.log('I should see Resume button on the banner');
        editWidgetPage.clickPausedDataResumeBtn().then(function(){
            console.log("getPausedDataResumeBtn expected: ");
            callback();
        }) ;
    });

    this.Then( /^I select Dashboard option for navigation on edit widget page$/, function (callback) {
        console.log('I select Dashboard Option in the goto options');
        editWidgetPage.dashboardOptionSelected().then(function(){
            browser.sleep(4000);
            console.log('Clicked on the goto selector dropdown');
            editWidgetPage.clickSelectedOption("Dashboards").then(function(){
                console.log('Clicked on the dashboard option ');
                callback();
            });
        });
    });

    this.Then( /^I should not be allowed to save the widget configuration without selecting the asset and dashboard$/, function (callback) {
        console.log('I should not be allowed to save the widget without selecting the asset or dashboard');
        editWidgetPage.clickableDisabledDoneBtnEditWidget().then( function (txt) {
            console.log('unable to click on the done button in edit widget configuration page.');
            expect(true).to.equal(txt);
            callback();
        });
    });

    this.Then( /^I should see total "([^"]*)" "([^"]*)" added to the card$/, function (num, widget, callback) {

        console.log('Checking for number of ' + widget + 'count');
        browser.sleep(4000);
        editWidgetPage.getSpecificWidgetCount(widget).then(function(count){
            expect(count).to.equal(num*1);
            callback();
        }) ;

    });

    this.Then( /^I enable the send and receive messages feature in actions menu on edit widget page$/, function (callback) {

        console.log('Checking for enabled send and receive button');
        editWidgetPage.checkCommSendAndReceiveButtonInInteraciveGraphWidget().then(function(present){
            expect(true).to.equal(present);
            callback();
        });
    });

    this.Then( /^I select the context "([^"]*)" from the advanced context browser$/, function (asset, callback) {
        console.log('I select the ' + asset +' from the advanced context browser');
        //browser.sleep(5000);
        editWidgetPage.checkAssetInAdvContextBrowser(asset).then(function(txt){
            console.log(asset + " is listed in context browser: "+txt);
            editWidgetPage.clickAssetInAdvContextBrowser(asset).then( function (txt) {
                console.log('clicked on the asset in advanced context browser.' + txt);
                expect(true).to.equal(txt);
                callback();
            })
        })

    });

    this.Then( /^I click on Set Context$/, function (callback) {
        console.log('I click in set context');
        editWidgetPage.clickOnSetContext().then(function(txt){
            callback();
        })

    });
    this.When(/^I click on the open button at level "([^"]*)" on the advanced context browser$/, function (arg1, callback) {
        browser.ignoresynchronization = false;

        editWidgetPage.clickOpenButton(arg1-1).then(function(){
            console.log('clicked on open button number: '+ arg1);
            callback();
        });


    });

    this.When(/^selected asset context name "([^"]*)" should be displayed$/, function (asset, callback) {
        editWidgetPage.checkAssetInContextLink(asset).then(function(txt){
            console.log('checked asset in context link '+ txt);
            expect(asset).to.equal(txt);
            callback();
        });
    });

    this.When(/^I should see x icon to delete the context$/, function (callback) {
        editWidgetPage.checkCrossIconNextToContext().then(function(txt){
            console.log('checked cross icon next to context link '+ txt);
            expect(true).to.equal(txt);
            callback();
        });
    });

    this.When(/^I should see dashboard selector drop down in edit widget page$/, function (callback) {
        editWidgetPage.checkDeckSelectorInAdvCB().then(function(txt){
            console.log('checked cross icon next to context link '+ txt);
            expect(true).to.equal(txt);
            callback();
        });
    });

    this.When(/^I should see the same number of dashboards listed as in main veiw selector dropdown$/, function (callback) {
        editWidgetPage.AllDecksInDeckSelectorEditwidget().then(function(cnt){
            console.log('number of Dashboards listed in edit widget deck selector: '+ cnt + " Expected count: " + TotalDashboards);
            expect(TotalDashboards).to.equal(cnt);
            callback();
        });
    });

    this.When(/^I select the dashboard "([^"]*)" from the drop down$/, function (dashboardname, callback) {
        editWidgetPage.selectDeckInDSInAdvCB().then(function(){
            browser.sleep(4000);
            console.log('Clicked on the deck selector dropdown in adv cb');
            editWidgetPage.clickSelectedOption(dashboardname).then(function(){
                console.log('Clicked on the deck option in adv cb');
                callback();
            });
        });
    });

    this.When(/^I should see the asset context name "([^"]*)"$/, function (asset,callback) {
        editWidgetPage.checkAssetNameinCLB(asset).then(function(txt){
            console.log('checking asset name in chromeless browser '+ txt);
            expect(true).to.equal(txt);
            callback();
        });

    });

    this.When(/^I should see the dashboard name "([^"]*)" opened$/, function (deckName,callback) {
        editWidgetPage.checkDeckNameinCLB(deckName).then(function(txt){
            console.log('checking deck name in chromeless browser '+ txt);
            expect(true).to.equal(txt);
            callback();
        });
    });

    this.When(/^I should not see dashboard kabob menu$/, function (callback) {
        editWidgetPage.checkAppHubKabobMenu().then(function(txt){
            console.log('checking apphub kabob menu in chromeless browser '+ txt);
            expect(false).to.equal(txt);
            callback();
        });
    });

    this.When(/^I should not see edit card option in edit card menu$/, function (callback) {
        editWidgetPage.checkEditCardOptionInCLB().then(function(txt){
            console.log('checking edit card option in chromeless browser '+ txt);
            expect(false).to.equal(txt);
            callback();
        });
    });

    this.When(/^I click on x icon next to asset context to clear the selection$/, function (callback) {
        editWidgetPage.clickXIconNextToAssetName().then(function(txt){
            console.log('clicking on x icon next to asset name in widget actions: '+ txt);
            expect(true).to.equal(txt);
            callback();
        });
    });

    this.When(/^I should not see dashboard selector drop down$/, function (callback) {
        editWidgetPage.hiddenDeckSelectorInAdvCB().then(function(txt){
            console.log('should not see deck selector in widget actions'+ txt);
            expect(true).to.equal(txt);
            callback();
        });
    });

    this.When(/^I should see asset context changes to setContext link$/, function (callback) {
        editWidgetPage.checkAssetInContextLink().then(function(txt){
            console.log('asset name changes to set context in widget actions'+ txt);
            expect("Set Context").to.equal(txt);
            callback();
        });
    });

    this.Then( /^I switch off the navigation in edit widget page$/, function (callback) {
        console.log('Disabling Navigation in the interactive graph widget');
        editWidgetPage.enableNavigationInInteractiveGraphWidget().then(function(txt){
            expect(txt).to.equal(true);
            browser.sleep(5000).then(function(){
            });
            console.log("Disabled Navigation in the interactive graph widget");
            callback();
        });
    });


    this.Then(/^I should see a label displayed in HMI widget configuration page for title$/, function (callback) {
        console.log('Verify a lable element is displayed for title');
        editWidgetPage.getLabelforTitleWidgetConfig().then(function(value){
              expect(value).to.equal(true);
            callback();
        });
    });

    this.Then(/^I should see an input field Title in HMI Widget configuration page$/, function (callback) {
        console.log('Verify there is an Input Field Title');
        editWidgetPage.checkTitleInpuFieldInWidgetConfig().then(function(present){
            console.log('Title is present');
            expect(present).to.equal(true);
            callback();
        });
    });

    this.Then(/^By default title field should display "([^"]*)"$/, function (widgetTitle, callback) {
        console.log('Verify title field should display ' + widgetTitle);
        editWidgetPage.getTitleInputValueWidgetConfig().then(function(value){
            console.log('Actual: ' + value + ' Expected: ' + widgetTitle);
            expect(value).to.equal(widgetTitle);
            callback();
        });
    });

    this.When(/^I edit the title to "([^"]*)"$/, function (NewWidgetTtl, callback) {
        console.log('Edit the title to ' + NewWidgetTtl);
        editWidgetPage.setWidgetTitleWidgetConfig(NewWidgetTtl).then(function(){
            console.log('Title edited');
            browser.sleep(1000).then(function(){callback();});
        });
    });

    this.When(/^The disconnected status icon should be displayed$/, function (callback) {
        console.log('Disconnected status icon should be displayed');
        editWidgetPage.getDisconnectedIcon().then(function(present){
            console.log('Disconnected status icon is displayed ');
            expect(present).to.equal(true);
            callback();
        });
    });

    this.When(/^The HMI Widget Canvas is hidden in the widget tile$/, function (callback) {
        console.log('HMI Widget Canvas should be hidden');
        customcardpage.getHMICanvas().then(function(present){
            expect(present).to.equal(false);
            callback();
        });

    });

};

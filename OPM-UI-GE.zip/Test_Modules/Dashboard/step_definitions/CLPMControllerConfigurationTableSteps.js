/**
 * Created by 212677088 on 9/17/2018.
 */
module.exports = function () {

    this.setDefaultTimeout(50000);
    var delay = 12000;
    var util = require("util");
    var data = require('../TestData/OPMAPIEndpoints.json').data.env[browser.params.environment];
    var results;
    var histCount = [];
    var errCount = [];
    var countArray = [];

    this.Given(/^I run timeseries7 fetch query for (.*) with (.*) and (.*) to get (.*)$/, function (params, startTime, endTime, op, callback) {
        var tagNames;
        var URL;
        if (params === "controllerConfiguration") {
            URL = data.fetchQuery.controllerurl;
            tagNames = data[params];
        } else {
            URL = data.fetchQuery.url;
            tagNames = data[params];
        }
        console.log("tagnames-->" + tagNames);
        var startTime = new Date();
        startTime.setDate(startTime.getDate()-1);
        startTime = startTime.toISOString().split('T')[0];
        startTime = startTime + 'T00:00:00Z';
        console.log('startTime-->',startTime);
        var endTime = new Date();
        endTime.setDate(endTime.getDate()-2);
        endTime = endTime.toISOString().split('T')[0];
        endTime = endTime + 'T00:00:00Z';
        console.log('endTime-->',endTime);

        var URL = util.format(URL, op, tagNames, endTime, startTime);
        console.log("URL-->" + URL);
        multiForecastRestPO.getQueryResults(URL).then(function (serviceData) {
            results = serviceData;
            callback();
        });
    });
    this.Given(/^I verify the Report Start header name$/, function (callback) {
        loopDashboardPO.getElement('reportStart').getText().then(function (val) {
            console.log("reportStart Title:" + val);
            TestHelper.assertEqual(val, 'Report Start:');
            callback();
        });
    });
    this.Then(/^I verify the Report End header name$/, function (callback) {
        loopDashboardPO.getElement('reportEnd').getText().then(function (val) {
            console.log("reportEnd Title:" + val);
            TestHelper.assertEqual(val, 'Report End:');
            callback();
        });
    });
    this.Given(/^I verify Report start\-P value$/, function (callback) {
        loopDashboardPO.getElement('reportStartP').getText().then(function (val) {
            console.log("reportStartP Value:" + val);
            var expectedVal;
            results.forEach(function (obj) {
                if (obj.tagId === "Loop1.P") {
                    if (0 != Object.keys(obj.data).length) {
                        console.log("postman value-->" + obj.data[0].v);
                        expectedVal = parseFloat(obj.data[0].v, 10);
                        expectedVal = loopDashboardPO.roundDecimalPoints(expectedVal);
                        console.log('expectedVal:' + expectedVal);
                        TestHelper.assertEqual(parseFloat(val, 10), expectedVal);
                    } else {
                        expectedVal = '';
                        console.log('expectedVal:' + expectedVal);
                        TestHelper.assertEqual('', expectedVal);
                    }
                }
            });
            callback();
        });
    });
    this.Then(/^I verify Report start\-I value$/, function (callback) {
        loopDashboardPO.getElement('reportStartI').getText().then(function (val) {
            console.log("reportStartI Value:" + val);
            var expectedVal;
            results.forEach(function (obj) {
                if (obj.tagId === "Loop1.I") {
                    if (0 != Object.keys(obj.data).length) {
                        console.log("postman value-->" + obj.data[0].v);
                        expectedVal = parseFloat(obj.data[0].v, 10);
                        expectedVal = loopDashboardPO.roundDecimalPoints(expectedVal);
                        console.log('expectedVal:' + expectedVal);
                        TestHelper.assertEqual(parseFloat(val, 10), expectedVal);
                    } else {
                        expectedVal = '';
                        console.log('expectedVal:' + expectedVal);
                        TestHelper.assertEqual('', expectedVal);
                    }
                }
            });
            callback();
        });
    });
    this.Then(/^I verify  Report start\-D value$/, function (callback) {
        loopDashboardPO.getElement('reportStartD').getText().then(function (val) {
            console.log("reportStartD Value:" + val);
            var expectedVal;
            results.forEach(function (obj) {
                if (obj.tagId === "Loop1.D") {
                    if (0 != Object.keys(obj.data).length) {
                        console.log("postman value-->" + obj.data[0].v);
                        expectedVal = parseFloat(obj.data[0].v, 10);
                        expectedVal = loopDashboardPO.roundDecimalPoints(expectedVal);
                        console.log('expectedVal:' + expectedVal);
                        TestHelper.assertEqual(parseFloat(val, 10), expectedVal);
                    } else {
                        expectedVal = '';
                        console.log('expectedVal:' + expectedVal);
                        TestHelper.assertEqual('', expectedVal);
                    }
                }
            });
            callback();
        });
    });
    this.Then(/^I verify Report start\-F value$/, function (callback) {
        loopDashboardPO.getElement('reportStartF').getText().then(function (val) {
            console.log("reportStartF Value:" + val);
            var expectedVal;
            results.forEach(function (obj) {
                if (obj.tagId === "Loop1.F") {
                    if (0 != Object.keys(obj.data).length) {
                        console.log("postman value-->" + obj.data[0].v);
                        expectedVal = parseFloat(obj.data[0].v, 10);
                        expectedVal = loopDashboardPO.roundDecimalPoints(expectedVal);
                        console.log('expectedVal:' + expectedVal);
                        TestHelper.assertEqual(parseFloat(val, 10), expectedVal);
                    } else {
                        expectedVal = '';
                        console.log('expectedVal:' + expectedVal);
                        TestHelper.assertEqual('', expectedVal);
                    }
                }
            });
            callback();
        });
    });
    this.Given(/^I verify Report end\-P value$/, function (callback) {
        loopDashboardPO.getElement('reportEndP').getText().then(function (val) {
            console.log("reportEndP Value:" + val);
            var expectedVal;
            results.forEach(function (obj) {
                if (obj.tagId === "Loop1.P") {
                    console.log("postman value-->" + obj.data[0].v);
                    expectedVal = parseFloat(obj.data[0].v, 10);
                    expectedVal = loopDashboardPO.roundDecimalPoints(expectedVal);
                }
            });
            console.log('expectedVal:' + expectedVal);
            TestHelper.assertEqual(parseFloat(val, 10), expectedVal);
            callback();
        });
    });
    this.Then(/^I verify Report end\-I value$/, function (callback) {
        loopDashboardPO.getElement('reportEndI').getText().then(function (val) {
            console.log("reportEndI Value:" + val);
            var expectedVal;
            results.forEach(function (obj) {
                if (obj.tagId === "Loop1.I") {
                    console.log("postman value-->" + obj.data[0].v);
                    expectedVal = parseFloat(obj.data[0].v, 10);
                    expectedVal = loopDashboardPO.roundDecimalPoints(expectedVal);
                }
            });
            console.log('expectedVal:' + expectedVal);
            TestHelper.assertEqual(parseFloat(val, 10), expectedVal);
            callback();
        });
    });
    this.Then(/^I verify  Report end\-D value$/, function (callback) {
        loopDashboardPO.getElement('reportEndD').getText().then(function (val) {
            console.log("reportEndD Value:" + val);
            var expectedVal;
            results.forEach(function (obj) {
                if (obj.tagId === "Loop1.D") {
                    console.log("postman value-->" + obj.data[0].v);
                    expectedVal = parseFloat(obj.data[0].v, 10);
                    expectedVal = loopDashboardPO.roundDecimalPoints(expectedVal);
                }
            });
            console.log('expectedVal:' + expectedVal);
            TestHelper.assertEqual(parseFloat(val, 10), expectedVal);
            callback();
        });
    });
    this.Then(/^I verify Report end\-F value$/, function (callback) {
        loopDashboardPO.getElement('reportEndF').getText().then(function (val) {
            console.log("reportEndF Value:" + val);
            var expectedVal;
            results.forEach(function (obj) {
                if (obj.tagId === "Loop1.F") {
                    console.log("postman value-->" + obj.data[0].v);
                    expectedVal = parseFloat(obj.data[0].v, 10);
                    expectedVal = loopDashboardPO.roundDecimalPoints(expectedVal);
                }
            });
            console.log('expectedVal:' + expectedVal);
            TestHelper.assertEqual(parseFloat(val, 10), expectedVal);
            callback();
        });
    });
};
//212340705
exports.config = {
	
	// ---- While testing locally
	sauceUser: null,
	sauceKey: null,
	sauceSeleniumAddress: null,
	directConnect: false,
	firefoxPath: null,

	// ---------------------------------------------------------------------------
	// ----- What tests to run ---------------------------------------------------
	// ---------------------------------------------------------------------------

	// Spec patterns are relative to the location of this config.
	specs: [],

	// Patterns to exclude.
	exclude: [],

	// Organize spec files into suites. To run specific suite, --suite=<name of suite>
	suites: {

		forecastingWidget: ['../Features/Login.feature',
			'../Features/add-new-forecasting-dashboard.feature'
		]
},


// Hooks running in the background
	plugins: [{
		path: '../../../node_modules/proui-utils/Compressed_Utils/GeneralHook.js'
	}],

	capabilities: {
		 browserName: 'chrome',
		  proxy: {
		 	// proxyType: 'manual',
		 	// httpProxy: 'sjc1intproxy10.crd.ge.com:8080',
		 	// sslProxy: 'sjc1intproxy10.crd.ge.com:8080'
        // proxyType: 'manual',
        // httpProxy: 'proxy-src.research.ge.com:8080',
        // sslProxy: 'proxy-src.research.ge.com:8080',
              proxyType: 'manual',
              httpProxy: 'grc-americas-sanra-pitc-wkcz.proxy.corporate.gtm.ge.com:80',
              sslProxy: 'grc-americas-sanra-pitc-wkcz.proxy.corporate.gtm.ge.com:80'
		 },
		count: 1,
		shardTestFiles: false,
		maxInstances: 1,
		'chromeOptions': {
			args: ['--no-sandbox', '--test-type=browser'],
			// Set download path and avoid prompting for download even though
			// this is already the default on Chrome but for completeness
			prefs: {
				'credentials_enable_service': false,
				'profile.password_manager_enabled': false,
				'download': {
					'prompt_for_download': false,
					'directory_upgrade': true,
					'default_directory': 'C:/Jenkins/sharedspace/public/test/e2e-reboot/steps/'
				}
			}
		}
	},


	maxSessions: -1,

	allScriptsTimeout: 250000,

	// How long to wait for a page to load.
	getPageTimeout: 650000,

	// Before launching the application
	beforeLaunch: function () {
	},

	// Application is launched but before it starts executing
	onPrepare: function () {

		// Create reports folder if it does not exist
		var folderName = (new Date()).toString().split(' ').splice(1, 4).join(' ');
		var mkdirp = require('mkdirp');
		var reportsPath = "./Reports/";
		global.xyz = " ";

		mkdirp(reportsPath, function (err) {
			if (err) {
				console.error(err);
			} else {
			}
		});

		browser.manage().deleteAllCookies();
		browser.manage().timeouts().pageLoadTimeout(50000);
		browser.manage().timeouts().implicitlyWait(50000);
		// browser.driver.manage().window().setSize(1280, 1440);
        browser.driver.manage().window().setSize(1380, 1440);

		chai = require('chai');
		expect = chai.expect;
		path = require('path');
		Cucumber = require('cucumber');
		fs = require('fs');

		// Initializing necessary utils from proui-utils module
		TestHelper = require('proui-utils').TestHelper;
		TestHelperPO = require('proui-utils').TestHelperPO;
        RestHelper = require('proui-utils').RestHelper;
		ElementManager = require('proui-utils').ElementManager;
		Logger = require('proui-utils').Logger;
        TestHelper.setWaitTime(200000);
		dem = new ElementManager('../../../Test_Modules/Dashboard/dashboard-element-repo.json');
		dem2 = require("../dashboard-element-repo.json");
		TestHelper.setElementManager(dem);

		// Initializing page object variables
		createviewpage = require('../PageObjects/add-new-dashboard-po.js');
        AdvancedNavPage = require('../PageObjects/AdvancedNavigation-po.js');
		addcardpage = require('../PageObjects/addCard-po.js');
		loginPage = require('../PageObjects/login-po.js');
		editWidgetPage = require('../PageObjects/editWidget-po.js');
		customcardpage = require('../PageObjects/CustomCard-po.js');
		favoritesPage = require('../PageObjects/favorite-po.js');
		dashboardSummaryPage = require('../PageObjects/dashboard-summary-po.js');

	},


// Browser parameters for feature files.
	params: {
		login: {
			//baseUrl: 'https://apmrc.int-app.aws-usw02-pr.predix.io/oorcg',
            //username: 'opmrc',
            //password: 'Pa55w0rd'

            baseUrl: 'https://apmqa.int-app.aws-usw02-pr.predix.io/opmqag',
            username: 'opm-smokeuser',
            password: 'Pa55w0rd'


            // baseUrl: 'http://localhost:3000/',
			// username: 'oodev-func4-user',
			// password: 'test1test'

		}
	},

	resultJsonOutputFile: null,
	// If true, protractor will restart the browser between each test.
	// CAUTION: This will cause your tests to slow down drastically.
	restartBrowserBetweenTests: false,

	// Custom framework in this case cucumber
	framework: 'custom',
	frameworkPath: require.resolve('protractor-cucumber-framework'),
	cucumberOpts: {
		// define your step definitions in this file
		require: [
			'../../../node_modules/proui-utils/Compressed_Utils/Reporter.js',
			'../step_definitions/* '
		]
		//format: 'pretty'
	}
};

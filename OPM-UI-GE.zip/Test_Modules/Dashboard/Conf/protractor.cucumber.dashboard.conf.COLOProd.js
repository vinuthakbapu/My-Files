//212340705
path = require('path');
var basePath =  path.resolve(__dirname, '../../../savedPDFfiles');
exports.config = {
	
	// ---- While testing locally
	sauceUser: null,
	sauceKey: null,
	sauceSeleniumAddress: null,
	directConnect: false,
	firefoxPath: null,

	// ---------------------------------------------------------------------------
	// ----- What tests to run ---------------------------------------------------
	// ---------------------------------------------------------------------------

	// Spec patterns are relative to the location of this config.
	specs: [],

	// Patterns to exclude.
	exclude: [],

	// Organize spec files into suites. To run specific suite, --suite=<name of suite>
	suites: {

		dashboard: ['../Features/Login.feature',
			'../Features/add-new-dashboard.feature'
		],

		dashboardAndCard: ['../Features/Login.feature',
			'../Features/AddDashboardAndCard.feature'
		],
		EditDashboard: ['../Features/Login.feature',
			'../Features/edit-dashboard.feature'
		],
		classdashboard: ['../Features/Login.feature',
			'../Features/add-classification-level-dashboard.feature'
		],
		defaultdashboard: ['../Features/Login.feature',
			'../Features/defaultDashboard.feature'
		],
		card:['../Features/Login.feature',
			'../Features/addcard.feature'
		],
		AddCustomCard:['../Features/Login.feature',
			'../Features/addCustomCard.feature'
		],
		SaveCardToLibrary:['../Features/Login.feature',
			'../Features/SaveCardToLibrary.feature'
		],
		widget:['../Features/Login.feature',
			'../Features/addWidgetToCustomCard.feature'
		],
		widgetRefresh:['../Features/Login.feature',
			'../Features/widgetRefresh.feature'
		],
		TimeControl:['../Features/Login.feature',
			'../Features/CardWidgetInteractivity-TimeControl.feature'
		],
		ACS:['../Features/Login.feature',
			////'../Features/ACSdashcreatePermission.feature',
			'../Features/ACSdashviewPermissionOnly.feature'
		],
		Navigation:['../Features/Login.feature',
			'../Features/NavigationToOtherMicroapp.feature'
		],
		WidgetCommunication: ['../Features/Login.feature',
			'../Features/InterWidgetCommunication.feature'
		],
        FavoriteDashboard: ['../Features/Login.feature',
            '../Features/favoriteDashboard.feature'
        ],
		TagWithRoles: ['../Features/Login.feature',
			'../Features/TagDashboardWithRoles.feature'
		],
		DashSummaryCard: ['../Features/Login.feature',
			'../Features/DashboardSummaryCard.feature'
		],
		AdvancedNavigation:['../Features/Login.feature',
            // '../Features/advanced-navigation.feature',
            '../Features/advanced-navigation-enhancement.feature',
            '../Features/advanced-navigation-BarWidget.feature',
            '../Features/advanced-navigation-SpiderWidget.feature',
            '../Features/advanced-navigation-SmallListWidget.feature',
            '../Features/advanced-navigation-KPI.feature',
            '../Features/advanced-navigation-GenericGraphWidget.feature'
		],
        ExportToPDF:[
            '../Features/Login.feature',
            '../Features/ExportToPDF.feature'
		],
        TimeSpan:[
            '../Features/Login.feature',
            '../Features/TimeSpan-GraphWidgets.feature'
        ],
		DashboardCardWidgetRefresh: [
			'../Features/Login.feature',
			'../Features/add-new-dashboard.feature',
			'../Features/AddDashboardAndCard.feature',
			'../Features/addCustomCard.feature',
			'../Features/addcard.feature',
		],
		AddWidget:[
			'../Features/Login.feature',
			'../Features/addWidgetToCustomCard.feature',
			'../Features/widgetRefresh.feature'
		],
		NavigationAndACS: [
			'../Features/Login.feature',
			'../Features/NavigationToOtherMicroapp.feature',
			'../Features/ACSdashviewPermissionOnly.feature'
		],
		DefaultAndClassDashboard: [
			'../Features/Login.feature',
			'../Features/defaultDashboard.feature',
			'../Features/add-classification-level-dashboard.feature'
		],
		TimeControlWidgetCommEditDashTagRoles: [
			'../Features/Login.feature',
			'../Features/CardWidgetInteractivity-TimeControl.feature',
			'../Features/InterWidgetCommunication.feature',
			'../Features/edit-dashboard.feature',
			'../Features/TagDashboardWithRoles.feature'
		],
		SaveCardToLibraryDashboardSummary: [
			'../Features/Login.feature',
			'../Features/SaveCardToLibrary.feature',
			'../Features/DashboardSummaryCard.feature'
		],
		ReArrangeCardsInDashboard: [
			'../Features/Login.feature',
			'../Features/ReArrangeCardsInDashboard.feature'
		],
		webHMI: [
			'../Features/Login.feature',
			'../Features/WebHMIWidget.feature'
		],
        AuditLogWidgetRepo: [
            '../Features/Login.feature',
            '../Features/AuditLogWidgetRepo.feature'
        ],
		WidgetRepoAdminUI: [
			// '../Features/Login.feature',
			'../Features/WidgetRepoAdminUI.feature'
		],
        TagTreeDragDrop: [
            '../Features/Login.feature',
            '../Features/TagTree_DragAndDrop.feature'
        ],
		DashboardSmoke: [
			'../Features/Login.feature',
			'../Features/DashboardSmoke.feature'
		]
},


// Hooks running in the background
	plugins: [{
		path: '../../../node_modules/proui-utils/Compressed_Utils/GeneralHook.js'
	}],

	capabilities: {
		browserName: 'chrome',
		proxy: {
			proxyType: 'manual',
			httpProxy: 'sjc1intproxy01.crd.ge.com:8080',
			sslProxy: 'sjc1intproxy01.crd.ge.com:8080'
		},
		count: 1,
		shardTestFiles: false,
		maxInstances: 1,

		'chromeOptions': {
            // This is the key. Make sure "--no-sandbox" is not part of your args
            'args': ['--disable-web-security', '--ignore-autocomplete-off-autofill'],
			// args: ['--no-sandbox', '--test-type=browser'],
			// Set download path and avoid prompting for download even though
			// this is already the default on Chrome but for completeness
			prefs: {
				'download': {
					'prompt_for_download': false,
					'directory_upgrade': true,
					'default_directory': basePath
				}
			}
		}
	},

	//Browser options
	//multiCapabilities: [
	//	// {
	//	// browserName: 'internet explorer',
	//	// platform: 'ANY',
	//	// version: '11'
	//	// },
	//
	//	// {
	//	// browserName: 'firefox',
	//	// },
	//
	//	{
	//		browserName: 'chrome',
	//		count: 1,
	//		shardTestFiles: false,
	//		maxInstances: 1,
	//		'chromeOptions': {
	//			args: ['--no-sandbox', '--test-type=browser'],
	//			// Set download path and avoid prompting for download even though
	//			// this is already the default on Chrome but for completeness
	//			prefs: {
	//				'download': {
	//					'prompt_for_download': false,
	//					'directory_upgrade': true,
	//					'default_directory': 'C:/Jenkins/sharedspace/public/test/e2e-reboot/steps/'
	//				}
	//			}
	//		}
	//	}
	//
	//],

	maxSessions: -1,

	allScriptsTimeout: 250000,

	// How long to wait for a page to load.
	getPageTimeout: 650000,

	// Before launching the application
	beforeLaunch: function () {

    },

	// Application is launched but before it starts executing
	onPrepare: function () {

		// Create reports folder if it does not exist
		var folderName = (new Date()).toString().split(' ').splice(1, 4).join(' ');
		var mkdirp = require('mkdirp');
		var reportsPath = "./Reports/";
		global.xyz = " ";

		mkdirp(reportsPath, function (err) {
			if (err) {
				console.error(err);
			} else {
			}
		});

		browser.manage().deleteAllCookies();
		browser.manage().timeouts().pageLoadTimeout(50000);
		browser.manage().timeouts().implicitlyWait(50000);
		browser.driver.manage().window().setSize(1280, 1440);

		chai = require('chai');
		expect = chai.expect;
		path = require('path');
		Cucumber = require('cucumber');
		fs = require('fs');

		// Initializing necessary utils from proui-utils module
		TestHelper = require('proui-utils').TestHelper;
		TestHelperPO = require('proui-utils').TestHelperPO;
		ElementManager = require('proui-utils').ElementManager;
		Logger = require('proui-utils').Logger;
		dem = new ElementManager('../../../Test_Modules/Dashboard/dashboard-element-repo.json');
		TestHelper.setElementManager(dem);
		dem2 = require('../../../Test_Modules/Dashboard/dashboard-element-repo.json');

        TestHelper.setWaitTime(120000);

		// Initializing page object variables
		createviewpage = require('../PageObjects/add-new-dashboard-po.js');
		addcardpage = require('../PageObjects/addCard-po.js');
		loginPage = require('../PageObjects/login-po.js');
		editWidgetPage = require('../PageObjects/editWidget-po.js');
		customcardpage = require('../PageObjects/CustomCard-po.js');
		favoritesPage = require('../PageObjects/favorite-po.js');
		dashboardSummaryPage = require('../PageObjects/dashboard-summary-po.js');
        AdvancedNavPage = require('../PageObjects/AdvancedNavigation-po.js');
		TimeSpanPage = require('../PageObjects/TimeSpanGraphWidgets-po.js');

	},

	// A callback function called once tests are finished
	onComplete: function () {
	},

	// A callback function called once tests are cleaning up
	onCleanUp: function (exitCode) {
	},

	// A callback function after tests are launched
	afterLaunch: function () {
	},

// Browser parameters for feature files.
	params: {
		login: {
            baseUrl: 'https://apm.predix.com/patch221',
            username: 'DDClass',
            password: 'Pa55w0rd'
		}
	},

	resultJsonOutputFile: null,
	// If true, protractor will restart the browser between each test.
	// CAUTION: This will cause your tests to slow down drastically.
	restartBrowserBetweenTests: false,

	// Custom framework in this case cucumber
	framework: 'custom',
	frameworkPath: require.resolve('protractor-cucumber-framework'),
	cucumberOpts: {
		// define your step definitions in this file
        tags: ['@DashValidation'],
		require: [
			'../../../node_modules/proui-utils/Compressed_Utils/Reporter.js',
			'../step_definitions/* '
		]
		//format: 'pretty'
	}
};

/**
 * Created by 212677088 on 12/4/2017.
 */
exports.config = {

    sauceUser: null,
    sauceKey: null,
    sauceSeleniumAddress: null,
    directConnect: true,
    firefoxPath: null,

    specs: [],

    exclude: [],

    suites: {

        multiForecastingWidget: [
            '../Features/AddWidgetToDashboard.feature',
            '../Features/MultiForecastSoMUoMValidation.feature'
        ]
    },

    plugins: [{
        path: '../../../node_modules/proui-utils/Compressed_Utils/GeneralHook.js'
    }],

    capabilities: {
        browserName: 'chrome',
        proxy: {
            proxyType: 'manual',
            httpProxy: 'sjc1intproxy02.crd.ge.com:8080',
            sslProxy: 'sjc1intproxy02.crd.ge.com:8080'
        },
        count: 1,
        shardTestFiles: false,
        maxInstances: 1,
        'chromeOptions': {
            args: ['--no-sandbox','--headless', '--test-type=browser'],
            prefs: {
                'credentials_enable_service': false,
                'profile.password_manager_enabled': false,
                'download': {
                    'prompt_for_download': false,
                    'directory_upgrade': true,
                    'default_directory': 'C:/Jenkins/sharedspace/public/test/e2e-reboot/steps/'
                }
            }
        }
    },

    maxSessions: -1,

    allScriptsTimeout: 9999999999,

    getPageTimeout: 650000,

    beforeLaunch: function () {
    },

    onPrepare: function () {
        var folderName = (new Date()).toString().split(' ').splice(1, 4).join(' ');
        var mkdirp = require('mkdirp');
        var reportsPath = "./Reports/";
        global.xyz = " ";

        mkdirp(reportsPath, function (err) {
            if (err) {
                console.error(err);
            } else {
            }
        });

        browser.manage().deleteAllCookies();
        browser.manage().timeouts().pageLoadTimeout(50000);
        browser.manage().timeouts().implicitlyWait(50000);
        browser.driver.manage().window().setSize(1380, 1440);

        chai = require('chai');
        expect = chai.expect;
        path = require('path');
        Cucumber = require('cucumber');
        fs = require('fs');

        const Series = require('time-series-data-generator');
        TestHelper = require('proui-utils').TestHelper;
        TestHelperPO = require('proui-utils').TestHelperPO;
        RestHelper = require('proui-utils').RestHelper;
        ElementManager = require('proui-utils').ElementManager;
        Logger = require('proui-utils').Logger;
        TestHelper.setWaitTime(9000000);
        dem = new ElementManager('../../../Test_Modules/Dashboard/dashboard-element-repo.json');
        dem2 = require("../dashboard-element-repo.json");
        TestHelper.setElementManager(dem);

        createviewpage = require('../PageObjects/add-new-dashboard-po.js');
        multiForecastPO = require('../PageObjects/MultiForecastPO.js');
        multiForecastRestPO = require('../PageObjects/MultiForecastRestPO.js');
        AdvancedNavPage = require('../PageObjects/AdvancedNavigation-po.js');
        addcardpage = require('../PageObjects/addCard-po.js');
        loginPage = require('../PageObjects/login-po.js');
        editWidgetPage = require('../PageObjects/editWidget-po.js');
        customcardpage = require('../PageObjects/CustomCard-po.js');
        favoritesPage = require('../PageObjects/favorite-po.js');
        dashboardSummaryPage = require('../PageObjects/dashboard-summary-po.js');
        fleetDashboardPO = require('../PageObjects/FleetDashboardPO.js');
    },

    params: {
        login: {
            baseUrl: 'https://apmrc.int-app.aws-usw02-pr.predix.io/oorcg',
            username: 'opmrc',
            password: 'Pa55w0rd'
        },
        environment: 'qa'
    },

    resultJsonOutputFile: null,
    restartBrowserBetweenTests: false,

    framework: 'custom',
    frameworkPath: require.resolve('protractor-cucumber-framework'),
    cucumberOpts: {
        require: [
            '../../../node_modules/proui-utils/Compressed_Utils/Reporter.js',
            '../step_definitions/* '
        ]
    }
};

//212340705
exports.config = {
	
	// ---- While testing locally
	sauceUser: null,
	sauceKey: null,
	sauceSeleniumAddress: null,
	directConnect: false,
	firefoxPath: null,

	// ---------------------------------------------------------------------------
	// ----- What tests to run ---------------------------------------------------
	// ---------------------------------------------------------------------------

	// Spec patterns are relative to the location of this config.
	specs: [],

	// Patterns to exclude.
	exclude: [],

	// Organize spec files into suites. To run specific suite, --suite=<name of suite>
	suites: {

		dashboardSmoke: ['../Features/Login.feature',
			'../Features/DashboardSmoke.feature'
		]
},


// Hooks running in the background
	plugins: [{
		path: '../../../node_modules/proui-utils/Compressed_Utils/GeneralHook.js'
	}],

	capabilities: {
		browserName: 'chrome',
		proxy: {
			proxyType: 'manual',
			httpProxy: 'sjc1intproxy10.crd.ge.com:8080',
			sslProxy: 'sjc1intproxy10.crd.ge.com:8080'
		},
		count: 1,
		shardTestFiles: false,
		maxInstances: 1,
		'chromeOptions': {
			args: ['--no-sandbox', '--test-type=browser'],
			// Set download path and avoid prompting for download even though
			// this is already the default on Chrome but for completeness
			prefs: {
				'download': {
					'prompt_for_download': false,
					'directory_upgrade': true,
					'default_directory': 'C:/Jenkins/sharedspace/public/test/e2e-reboot/steps/'
				}
			}
		}
	},

	//Browser options
	//multiCapabilities: [
	//	// {
	//	// browserName: 'internet explorer',
	//	// platform: 'ANY',
	//	// version: '11'
	//	// },
	//
	//	// {
	//	// browserName: 'firefox',
	//	// },
	//
	//	{
	//		browserName: 'chrome',
	//		count: 1,
	//		shardTestFiles: false,
	//		maxInstances: 1,
	//		'chromeOptions': {
	//			args: ['--no-sandbox', '--test-type=browser'],
	//			// Set download path and avoid prompting for download even though
	//			// this is already the default on Chrome but for completeness
	//			prefs: {
	//				'download': {
	//					'prompt_for_download': false,
	//					'directory_upgrade': true,
	//					'default_directory': 'C:/Jenkins/sharedspace/public/test/e2e-reboot/steps/'
	//				}
	//			}
	//		}
	//	}
	//
	//],

	maxSessions: -1,

	allScriptsTimeout: 250000,

	// How long to wait for a page to load.
	getPageTimeout: 650000,

	// Before launching the application
	beforeLaunch: function () {
	},

	// Application is launched but before it starts executing
	onPrepare: function () {

		// Create reports folder if it does not exist
		var folderName = (new Date()).toString().split(' ').splice(1, 4).join(' ');
		var mkdirp = require('mkdirp');
		var reportsPath = "./Reports/";

		mkdirp(reportsPath, function (err) {
			if (err) {
				console.error(err);
			} else {
			}
		});

		browser.manage().deleteAllCookies();
		browser.manage().timeouts().pageLoadTimeout(50000);
		browser.manage().timeouts().implicitlyWait(50000);
		browser.driver.manage().window().setSize(1280, 1440);

		chai = require('chai');
		expect = chai.expect;
		path = require('path');
		Cucumber = require('cucumber');
		fs = require('fs');

		// Initializing necessary utils from proui-utils module
		TestHelper = require('proui-utils').TestHelper;
		TestHelperPO = require('proui-utils').TestHelperPO;
		ElementManager = require('proui-utils').ElementManager;
		Logger = require('proui-utils').Logger;
		cem = new ElementManager('../../../Common_Modules/common-element-repo.json');
		dem = new ElementManager('../../../Test_Modules/Dashboard/dashboard-element-repo.json');
		dem2 = require("../dashboard-element-repo.json");
		TestHelper.setElementManager(cem);

		// Initializing page object variables
		createviewpage = require('../PageObjects/add-new-dashboard-po.js');
		addcardpage = require('../PageObjects/addCard-po.js');
		loginPage = require('../PageObjects/login-po.js');
		editWidgetPage = require('../PageObjects/editWidget-po.js');
		customcardpage = require('../PageObjects/CustomCard-po.js');
		favoritesPage = require('../PageObjects/favorite-po.js');
		dashboardSummaryPage = require('../PageObjects/dashboard-summary-po.js');

	},

	// A callback function called once tests are finished
	onComplete: function () {
	},

	// A callback function called once tests are cleaning up
	onCleanUp: function (exitCode) {
	},

	// A callback function after tests are launched
	afterLaunch: function () {
	},

// Browser parameters for feature files.
	params: {
		login: {
			//baseUrl: 'https://apm-tubs-rc2.run.asv-pr.ice.predix.io/tenant0624',
			//"username": "tenant0624-smokeuser",
			//"password": "test"
            //baseUrl: 'https://apm-tubs-qa2.run.asv-pr.ice.predix.io/tenant0626',
			//username: 'tenant0626-smokeuser',
			//password: 'test'
			//baseUrl: 'https://apm-tubs-qa2.run.asv-pr.ice.predix.io/tenant0726',
			//username: 'tenant0726-smokeuser',
			//password: 'Pa55w0rd',
			//baseUrl: 'https://apm-tubs-qa2.run.asv-pr.ice.predix.io/tenant0726',
			//username: 'tenant0726-smokeuser',
			//password: 'Pa55w0rd'
			//baseUrl: 'https://apm-tubs-qa2.run.asv-pr.ice.predix.io/tenant0809',
			//username: 'tenant0809-smokeuser',
			//password: 'Pa55w0rd'
			//-- STUF Integration environment --
			// baseUrl: 'https://stuf-rc.run.asv-pr.ice.predix.io/sample2',
			// username: 'sample2-smokeuser',
			// password: 'Pa55w0rd'
			//baseUrl: 'https://stuf-rc.run.asv-pr.ice.predix.io/sample5',
			//username: 'sample5-smokeuser',
			//password: 'Pa55w0rd'
			//cust env for migrtion testing
			//baseUrl: 'https://apm-stufcust.run.asv-pr.ice.predix.io/regression',
			//username: 'ddclass',
			//password: 'Pa55w0rd'
			//Pre-prod for Q3 release validaation
			//baseUrl:'https://preprod-apm.predix.com/patch20150520',
			//username: 'DDClass',
			//password: 'Pa55w0rd'
			baseUrl: 'https://stuf-rc.run.asv-pr.ice.predix.io/sample8',
			//username: 'sample8-smokeuser',
			username: 'ddclass',
			password: 'Pa55w0rd'
			// baseUrl: 'https://stuf-rc.run.asv-pr.ice.predix.io/regression-rc',
			//username: 'regression-rc-smokeuser',
			//password: 'Pa55w0rd'
			// baseUrl: 'https://apm-stufpatch.run.asv-pr.ice.predix.io/patch241',
			//username: 'patch241-smokeuser',
			//password: 'Pa55w0rd'
			//baseUrl:'https://apmprod.run.aws-usw02-pr.ice.predix.io/sample',
			//username: 'DDClass',
			//password: 'Pa55w0rd'

		}
	},

	resultJsonOutputFile: null,
	// If true, protractor will restart the browser between each test.
	// CAUTION: This will cause your tests to slow down drastically.
	restartBrowserBetweenTests: false,

	// Custom framework in this case cucumber
	framework: 'custom',
	frameworkPath: require.resolve('protractor-cucumber-framework'),
	cucumberOpts: {
		// define your step definitions in this file
		require: [
			'../../../node_modules/proui-utils/Compressed_Utils/Reporter.js',
			'../step_definitions/* '
		]
		//format: 'pretty'
	}
};

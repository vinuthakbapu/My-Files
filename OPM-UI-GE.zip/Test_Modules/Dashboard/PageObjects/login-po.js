(function () {
    'use strict';


    var currentPage = 'loginPage';
    var dashpage = 'DashboardAppPages'


    var LoginPage = function () {

        return {

            get: function () {
                return browser.driver.get(browser.params.login.baseUrl);
                browser.waitForAngular();
            },
            getUrl: function (url) {
                return browser.driver.get(url);
                browser.waitForAngular();
            },

            setName: function (username) {
                return dem.findElement(currentPage,'username').sendKeys(username);
            },

            setPassword: function (password) {
                return dem.findElement(currentPage,'password').sendKeys(password);
            },

            clickLogin: function () {
                return dem.findElement(currentPage,'password').sendKeys(protractor.Key.ENTER);
            },

            checkHomePage: function() {
                //browser.waitForAngular();
                //var dashtab = cem.findElement('landingPage','dashboardTab');
                //return dashtab.isPresent();
                return TestHelper.isElementPresent('landingPage','dashboardTab');
            },

            checkLogout: function() {
                //browser.waitForAngular();
                return browser.driver.isElementPresent(by.name('password'));

            },
            loginAs: function(usrname, pswd){
                console.log('inside loginAs function');
                var self = this;

                return this.setName(usrname).then(function () {
                    console.log('entered username');
                    browser.sleep(4000);
                    self.setPassword(pswd).then(function () {
                        console.log('entered password');
                        browser.sleep(4000);
                        self.clickLogin().then(function () {

                        })
                    })
                });
            },
            doLogout:function(){
                var deferred = protractor.promise.defer();
                protractor.promise.controlFlow().execute(function(){
                console.log('inside doLogout functtion');
                TestHelper.elementToBeClickable(dashpage,'LoginAvtar').then(function(){
                    console.log('clicked on login avtar');
                    TestHelper.elementToBeClickable(dashpage, 'LogOutLink').then(function(){
                        console.log('clicked on logout link');
                            TestHelper.isElementVisible(currentPage, 'username').then(function(yahnah){
                                console.log('username input field is present: '+yahnah);
                                deferred.fulfill(yahnah);
                            });
                        })
                    });
                });
                return deferred
            },
            clickWithTimeout: function (element, timeout) {
                return browser.wait(function () {
                    return element.click().then(function () {
                            return true;
                        },
                        function () {
                            browser.sleep(1000);
                            console.log("idle for 1 more second..");
                            return false;
                        });
                }, timeout);
            }
        }
    };

    module.exports = new LoginPage();

}());
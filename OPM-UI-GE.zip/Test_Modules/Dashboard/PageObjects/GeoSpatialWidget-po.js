
(function(){
    'use strict';
    var currentpage = 'geoSpatialWidget';
    var GeoSpatialWidget = function() {
        return {
            checkSatelliteViewIsSelectedByDefault: function(){
                return TestHelper.elementToBeSelected(currentpage, 'satelliteView');
            },
            getAssetLayerSequenceInputField: function(){
                return dem.findElement(currentpage, 'AssetLayerSequence');
            },
            getAssetLayerTitleInputField: function(){
                return dem.findElement(currentpage, 'AssetLayerTitle');
            },
            getAssetLayerSearchInputField: function(){
                return dem.findElement(currentpage, 'AssetLayerSearch');
            },

            clickAddAssetLayerIcon: function(){
                return TestHelper.elementToBeClickable(currentpage, 'addAssetLayer');
            },

            enterAssetNameTobeSelected:function(assetName){
                return this.getAssetLayerSearchInputField().click().clear().sendKeys('T').sendKeys(protractor.Key.BACK_SPACE).sendKeys(assetName)
            },

            deselectAllAsset:function(){
                return this.enterAssetNameTobeSelected(protractor.Key.BACK_SPACE).then(function(){
                    return TestHelper.elementToBeClickable(currentpage,'AssetAll');
                });
            },
            SelectAsset:function(assetName){
                return this.enterAssetNameTobeSelected(assetName).then(function(){
                    return TestHelper.elementToBeClickable(currentpage,'Asset');
                });
            },

            saveAssetLayer: function(){
                return TestHelper.elementToBeClickable(currentpage, 'saveAssetLayer');
            },

            cancelAssetLayer: function(){
                return TestHelper.elementToBeClickable(currentpage, 'cancelAssetLayer');
            },

            getDeleteAssets:function(){
                return dem.findElement(currentpage, 'DeleteAssetLayer');

            },

            deleteAssetLayer: function(assetLayerNo){

                return this.getDeleteAssets().then(function(deletes){deletes[deletes.length-assetLayerNo].click();
                });

            },

            getSavedLayerSequence:function(){
                return dem.findElement(currentpage, 'savedAssetLayerSequences');
            },

            getSavedAssetLayerSequenceValue: function (assetLayerNo) {
                return this.getSavedLayerSequence().then(function(savedAssetLayerSequences){

                    return savedAssetLayerSequences[savedAssetLayerSequences.length-assetLayerNo];

                });

            },

            getSavedLayerTitle:function(){
                return dem.findElement(currentpage, 'SavedAssetLayerTittle');
            },

            getSavedAssetLayerTitleValue: function (assetLayerNo) {
                return this.getSavedLayerTitle().then(function(savedLayerTitles){

                    return savedLayerTitles[savedLayerTitles.length-assetLayerNo];

                });

            },


            getSavedAssets:function(assetLayerNo) {

                return this.getSavedLayerSequence().then(function (savedAssetLayerSequences) {
                    var totalLayers = savedAssetLayerSequences.length;

                    var layerNo = (totalLayers - Number(assetLayerNo) + 2);
                    var cssLocator = "#widget-placeholder #widget-configuration>ul>li:nth-child(4)>.clearfix:nth-of-type(" + layerNo + ") ul.selected-asset-div label"
                    dem2["geoSpatialWidget"]["SavedAssets"].locatorValue = cssLocator;
                    return dem.findElement(currentpage, 'SavedAssets');

                });
            },

            getSavedAssetNames: function (assetLayerNo) {

                return this.getSavedAssets(assetLayerNo).then(function(savedAssets){
                    return savedAssets.map(function(savedAsset,index){return savedAsset.getText()});
                })

            },


            checkAssetLayerVisibilityIsSelectedByDefault: function(){
                return TestHelper.elementToBeSelected(currentpage, 'AssetLayerVisibilityToggle');
            },

            getSavedAssetLayer: function(){
            return dem.findElement(currentpage, 'AssetLayerSectionSaved');
            },

            getAddNewAssetLayerSection: function(){
                return dem.findElement(currentpage, 'AssetLayerSectionNew');
            },

            getAssetLayerSequenceValidationMessage: function(){
                return dem.findElement(currentpage, 'AssetLayerValidationMessage');
            },

            clearSearchInputField:function(){
                return this.getAssetLayerSearchInputField().clear().then(function(){
                    return
                })

            },

            getNoSearchResultFoundMessage: function(assetName){
                return this.enterAssetNameTobeSelected(assetName).then(function(){


                        return dem.findElement(currentpage,'AssetLayerSearchIcon').click().then(function(){
                            return browser.sleep(1000).then(function(){
                                return dem.findElement(currentpage, 'NoSearchResultFound');

                        });
                });
                });
            },

            checkAssetIsPloted: function(imageToCompare){
                return protractorImageComparison.checkElement(element(by.css('.pxh-drawer-header')),imageToCompare).then(function (percentDifferent) {

                    //The function returns a promise with the percentage that shows difference
                    console.log("The difference: " + percentDifferent)

                    //Asserting if the percentage is 0 meaning that there are no differences between the two images
                    TestHelper.assertEqual(0, percentDifferent, callback)
                    callback();
                });
            },

            //--------------------------------------custom Layer-------------------------

            clickAddCustomLayerIcon: function(){
                return TestHelper.elementToBeClickable(currentpage, 'addCustomLayer');
            },

            selectCustomLayerType: function(customLayerType){

                var xpathLocator = "//div[@id='widget-placeholder']//div[@id='widget-configuration']//select[@id='layer-type-selection']/option[@value='"+customLayerType+"']"
                console.log("---->>>>>"+xpathLocator)
                dem2["geoSpatialWidget"]["selectCustomLayerType"].locatorValue = xpathLocator;
                //return dem.findElement(currentpage, 'SavedAssets');

                return TestHelper.elementToBeClickable(currentpage, 'selectCustomLayerType');
            },

            getCustomLayerSequenceInputField: function(){
                return dem.findElement(currentpage, 'customLayerSequence');
            },

            getCustomLayerTitleInputField: function(){
                return dem.findElement(currentpage, 'customLayerTitle');
            },

            getCustomLayerDataSourceInputField: function(){
                return dem.findElement(currentpage, 'customLayerDataSource');
            },

            saveCustomLayer: function(){
                return TestHelper.elementToBeClickable(currentpage, 'saveCustomLayer');
            },

            getSavedCustomLayer: function(){
                return dem.findElement(currentpage, 'customLayerSectionSaved');
            },

            getSavedCustomLayerSequenceValue: function (customLayerNo) {
                return this.getCustomSavedLayerSequence().then(function(savedCustomLayerSequences){

                    return savedCustomLayerSequences[savedCustomLayerSequences.length-customLayerNo];

                });

            },

            getCustomSavedLayerSequence:function(){
                return dem.findElement(currentpage, 'savedCustomLayerSequences');
            },

            getSavedCustomLayerTitleValue: function (customLayerNo) {
                return this.getSavedCustomLayerTitle().then(function(savedCustomLayerTitles){

                    return savedCustomLayerTitles[savedCustomLayerTitles.length-customLayerNo];

                });

            },

            getSavedCustomLayerTitle:function(){
                return dem.findElement(currentpage, 'savedCustomLayerTittle');
            },

            getSavedCustomLayerDataSourceValue: function (customLayerNo) {
                return this.getSavedCustomLayerDataSource().then(function(savedCustomLayerDataSource){

                    return savedCustomLayerDataSource[savedCustomLayerDataSource.length-customLayerNo];

                });

            },
            getSavedCustomLayerDataSource:function(){
                return dem.findElement(currentpage, 'savedCustomLayerDataSource');
            },

            //saveAssetLayer: function(){
            //    return TestHelper.elementToBeClickable(currentpage, 'saveAssetLayer');
            //},

            checkCustomLayerVisibilityIsSelectedByDefault: function(){
                return TestHelper.elementToBeSelected(currentpage, 'customLayerVisibilityToggle');
            },


            getCustomLayerSequenceValidationMessage: function(){
                return dem.findElement(currentpage, 'customLayerValidationMessage');
            },

            cancelCustomLayer: function(){
                return TestHelper.elementToBeClickable(currentpage, 'cancelCustomLayer');
            },

            getAddNewCustomLayerSection: function(){
                return dem.findElement(currentpage, 'customLayerSectionNew');
            },

            deleteCustomLayer: function(customLayerNo){

                return this.getDeleteCustoms().then(function(deletes){deletes[deletes.length-customLayerNo].click();
                });

            },

            getDeleteCustoms:function(){
                return dem.findElement(currentpage, 'deleteCustomLayer');

            },


            //getSavedCustomLayer: function(){
            //    return dem.findElement(currentpage, 'AssetLayerSectionSaved');
            //},

        }
    };
    module.exports = new GeoSpatialWidget();
}())
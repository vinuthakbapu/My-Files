/* created by 212340705 on Jan 6th 2016 */
(function(){
    'use strict';
    var currentpage = 'DashboardAppPages';
    var editWidgetPage = function(){
        return {
            getEditWidgetHeaderByText: function(){
                return element(by.cssContainingText('div','Configure Widget'));
            },
            getEditWidgetTitleNamebyText: function(){
                return element(by.cssContainingText('div ul li label','Title'));
            },
            getEditWidgetTargetNamebyText: function(){
                return element(by.cssContainingText('div ul li label','Target'));
            },
            getEditWidgetThresholdNamebyText: function(){
                return element(by.cssContainingText('div ul li label','Threshold'));
            },
            configureTitleinputfield: function(){
                return element(by.id('title'));
            },
            configureTargetinputfield: function(){
                return element(by.id('target-input'));
            },
            configureThresholdinputfield: function(){
                return element(by.id('threshold-input'));
                // return element(by.cssContainingText('div ul li label','Threshold'));
            },
            getEditWidgetChartNamebyText: function(){
                return element(by.cssContainingText('div ul li label','Chart'));
            },

            getCurrentWidgetHeaderByText: function(){
                return element(by.cssContainingText('div .new-edit-widget','Configure Widget'));
            },

            getErrorMessageText: function(){
                return element(by.xpath("//div[text()='You do not have permission to perform this action.']"));
            },
            getEditWidgetHeader: function(){
                return element(by.id('edit-widget-header'));
            },
            getEditWidgetPageHeader: function(){
                return element(by.id('edit-widget-header h3'));
            },
            getEditWidgetSaveButton: function(){
                return element.all(by.id('edit-widget-header button')).get(1);
            },
            getEditWidgetCancelButton: function(){
                return element.all(by.id('edit-widget-header button')).get(0);
            },
            getWidgetRefreshProperty: function(){
                //return element.all(by.css('#refreshEditContainer > select')).get(0).$('option:checked').getText();
                return TestHelperPO.getText(element.all(by.css('#refreshEditContainer > select')).get(0).$('option:checked'));
            },
            getWidgetNavigationProperty: function(){
                //return element.all(by.css('.configure-graph-widget > select')).get(0).$('option:checked').getText();
                return TestHelperPO.getText(element.all(by.css('.configure-graph-widget > select')).get(0).$('option:checked'));
            },
            getWidgetNavigationPropertyOn: function(){
                //return element.all(by.css('.configure-graph-widget > select')).get(1).$('option:checked').getText();
                return TestHelperPO.getText(element.all(by.css('.configure-graph-widget > select')).get(1).$('option:checked'));
            },
            getDashboardTagToolbox: function () {
                return element.all(by.css('span.searchIcon >i.fa.fa-search.dashboard-tag-toolbox')).get(0);
            },
            getWidgetOnDemandRefreshProperty: function(){
                //return element.all(by.css('#refreshEditContainer > select')).get(0).$('option:checked').getText();
                return TestHelperPO.getText(element.all(by.css('#refreshEditContainer > select')).get(0).$('option:checked'));
            },
            clickTagSearchIcon: function () {
                //return element.all(by.css('span.searchIcon >i.fa.fa-search.dashboard-tag-toolbox')).get(0);
                //dem2[currentpage]['TagSearch'].value.index=num;
                return TestHelper.elementToBeClickable(currentpage, 'TagSearch')
            },
            clearTagSearchInputField: function () {
                return element(by.id('tagSearch')).clear();
            },

            clickSearchCriteriaSelector: function () {
                //return element.all(by.css('select.dashboard-tag-toolbox')).get(0);
                return TestHelper.elementToBeClickable(currentpage, 'SearchTypeSelector')
            },
            clickSelectedOption: function (selectOption) {
                //return element(by.cssContainingText('option', selectOption));
                dem2[currentpage]["SelectedOption"].locatorValue=selectOption;
                return TestHelper.elementToBeClickable(currentpage, 'SelectedOption')
            },
            getSelectedOption: function (selectOption) {
                //return element(by.cssContainingText('option', selectOption));
                dem2[currentpage]["SelectedOption"].locatorValue=selectOption;
                 return TestHelper.isElementPresent(currentpage, 'SelectedOption')
                //return element(by.css('option')).isPresent();
            },
            getSelectedOption2: function (selectOption) {
                //return element(by.cssContainingText('option', selectOption));
                dem2[currentpage]["SelectedOption"].locatorValue=selectOption;
                return TestHelper.isElementVisible(currentpage, 'SelectedOption')
                //return element(by.css('option')).isPresent();
            },
            getTagPlusChild: function (selectOption) {
                //return element(by.cssContainingText('option', selectOption));
                dem2[currentpage]["SelectedOption"].locatorValue=selectOption;
                return TestHelper.getText(currentpage, 'SelectedOption');
                //return element(by.css('option')).isPresent();
            },
            getWidgetFooter: function() {
                return element(by.css('#outputFooter2')).getText();
            },
            chkDataServiceError: function() {
                // return TestHelper.isElementPresent(currentpage, 'DataServiceError');
                return TestHelper.isElementVisible(currentpage, 'DataServiceError');
            },
            chkNoResultsFound: function () {
                return TestHelper.isElementPresent(currentpage, 'NoResultsFound');
                // return TestHelper.isElementVisible(currentpage, 'NoResultsFound');
            },
            getTagToolboxInput: function () {
                //return element.all(by.css('input#tagSearch')).get(0);
                return dem.findElement(currentpage, 'TagSearchInput')
            },
            getTagToolboxSearchResult: function () {
                return element.all(by.css('div.tag-result-header.style-scope.dashboard-tag-search-results')).get(0);
            },
            getTagToolboxSearchResultIcon: function () {
                return element.all(by.css('i.fa.fa-plus.style-scope.dashboard-tag-search-results')).get(0);
            },
            getTagToolboxPlottedTagIcon: function () {
                return element.all(by.css('i.fa.fa-times.style-scope.dashboard-plotted-tag-list')).get(0);
            },
            getFirstPlottedTag: function () {
                return element(by.css('h4.tag-name.tagNameWeight.style-scope.dashboard-plotted-tag-list'));
            },
            getPlottedTagNames: function () {
                return element.all(by.css('h4.tag-name.tagNameWeight.style-scope.dashboard-plotted-tag-list')).map(function (elem) {
                    return elem.getText();
                });
            },


            getConfigureWidgetAddButton: function(){
                return element(by.css('button.new-edit-widget#addCardBtn'));
            },
            clickDoneBtnEditWidget: function(){
                return TestHelper.elementToBeClickable(currentpage, 'DoneBtnEditWidget');
                //return element(by.css('button.new-edit-widget#addCardBtn')).click();
                //return element(by.css('button.new-edit-widget')).click();
            },
            clickWidgetSaveCardButton: function(){
                //return element.all(by.css('div.saveBtn button')).get(1);
                return TestHelper.elementToBeClickable(currentpage, 'SaveCardButton');
            },
            clickWidgetNavigationSelect: function () {
                //return element.all(by.css('select.configure-graph-widget')).get(0);
                return TestHelper.elementToBeClickable(currentpage, 'WidgetNavigationSelect');
            },
            getWidgetRefreshSelect: function () {
                return element.all(by.css('select.refresh-edit-component')).get(0);
            },
            getDashboardNavigationOption: function (navigationOption) {
                return element(by.cssContainingText('option', navigationOption));
            },
            getWidgetNavigationEnabledIcon: function () {
                return element(by.css('#analysisNavigation.enable-button:not([hidden])'));
            },
            getWidgetRefreshEnabledIcon: function () {
                return element(by.css('#refreshDiv.enable-button:not([hidden])'));
            },
            getWidgetNavigationDisabledIcon: function () {
                return element(by.css('#analysisNavigation.disable-button:not([hidden])'));
            },
            getWidgetRefreshDisabledIcon: function () {
                return element(by.css('#refreshDiv.disable-button:not([hidden])'));
            },
            getWidgetNavigationVisibleIcon: function () {
                return element(by.css('#analysisNavigation:not([hidden])')).isPresent();
                //return TestHelper.isElementPresent(currentpage, 'WidgetNavigationIcon');
            },
            getWidgetRefreshVisibleIcon: function () {
                return element(by.css('#refreshDiv:not([hidden])'));
            },
            getOnDemandRefreshBtn: function () {
                return element(by.css('#refreshBtn[hidden]'));
            },
            getWidgetNavigationHiddenIcon: function () {
                return element(by.css('#analysisNavigation[hidden]'));
            },
            getWidgetAlertsByPriority: function (priority) {
                //return element(by.cssContainingText('span.epsilon.alerts-widget', priority));
                return element.all(by.css('div.clickable.alerts-widget')).get(priority);
            },
            getWidgetAlertsNumber: function (priority) {
                return element.all(by.css('span.gamma.alerts-widget')).get(priority).getText();
            },
            getAlertsInListByPriority: function (priority) {
                return element.all(by.css('span.badge', priority)).get(0).getText();
            },
            getAlertsInListByStatus: function () {
                return element.all(by.css('h5.alarms-gray-label.alarms-list-item-right')).get(0).getText();
            },
            getFirstTagName: function () {
                return element.all(by.css('h4.tag-name.tagNameWeight.style-scope.dashboard-tag-search-results')).get(0).getText();
            },
            getFirstPlottedTagName: function () {
                return element.all(by.css('h4.tag-name.tagNameWeight.style-scope.dashboard-plotted-tag-list')).get(0).getText();
            },
            getSecondTagName: function () {
                return element.all(by.css('h4.tag-name.tagNameWeight.style-scope.dashboard-tag-search-results')).get(1).getText();
            },
            getSecondPlottedTagName: function () {
                return element.all(by.css('h4.tag-name.tagNameWeight.style-scope.dashboard-plotted-tag-list')).get(1).getText();
            },
            getWidgetCasesBySeverityPresence: function (severity) {
                return element(by.css('rect[severity*="' + severity + '"]:not([height="0"])')).isPresent();
            },
            getWidgetCasesBySeverity: function (severity) {
                return element(by.css('rect[severity*="' + severity + '"]:not([height="0"])'));
            },
            getCasesInListBySeverity: function () {
                return element.all(by.css('div.badge.severity-badge')).get(0).getText();
            },
            getCasesInListByStatus: function () {
                return element.all(by.css('span.inbox-item-status')).get(0).getText();
            },
            checkActionsSectionInGenericGraphWidget: function(){
                return element(by.css('#widget-actions')).isPresent();
            },
            checkNavigationButtonInGenericGraphWidget: function(){
                return element(by.css('#navigation-send')).isPresent();
            },
            checkCommSendAndReceiveButtonInGenericGraphWidget: function(){
                return TestHelper.isElementPresent(currentpage, 'SendDataButton');
            },
            checkCommSendAndReceiveButtonInInteraciveGraphWidget: function(){
                return TestHelper.isElementPresent(currentpage, 'SendDataButton').then(function(test){
                        return TestHelper.isElementPresent(currentpage, 'ReceiveDataButton')
                    });
            },
            checkNavigationButtonDisabledInInteractiveGraphWidget: function(){
                return TestHelper.isElementPresent(currentpage, 'NavButtonDisabled');
            },
            checkGoToButtonDisabledInInteractiveGraphWidget: function(){
                return TestHelper.isElementPresent(currentpage, 'GoToOptionDisabled');
            },
            enableNavigationInInteractiveGraphWidget: function(){
                return TestHelper.elementToBeClickable(currentpage, 'EnableNavigationOption')
            },
            clickSendDataBtn: function(){
                return TestHelper.elementToBeClickable(currentpage, 'SendDataButton');
            },
            clickReceiveDataBtn: function(){
                return TestHelper.elementToBeClickable(currentpage, 'ReceiveDataButton');
            },
            getRefreshDataLink: function () {
                return TestHelper.isElementPresent(currentpage, "RefreshDataLink");
            },
            chkRefreshDataLink: function () {
                return TestHelper.isElementVisible(currentpage, "RefreshDataLink");
            },
            getPauseDataLink: function () {
                return TestHelper.isElementPresent(currentpage, "PauseDataLink");
            },
            clickPauseDataLink: function () {
                return TestHelper.elementToBeClickable(currentpage, "PauseDataLink");
            },
            getPauseDataRefreshBar: function () {
                return TestHelper.isElementPresent(currentpage, "PauseDataRefreshBar");
            },
            getPauseDataRefreshBarHide: function () {
                // return TestHelper.isElementPresent(currentpage, "PauseDataRefreshBarHide");
                return TestHelper.isElementVisible(currentpage, "PauseDataRefreshBarHide");
            },
            getUnpauseDataLink: function () {
                return TestHelper.isElementPresent(currentpage, "UnpauseDataLink");
            },
            clickUnpauseDataLink: function () {
                return TestHelper.elementToBeClickable(currentpage, "UnpauseDataLink");
            },
            chkPauseDataLink: function () {
                return TestHelper.isElementVisible(currentpage, "PauseDataLink");
            },
            chkPauseDataMsg: function() {
                return TestHelper.isElementVisible(currentpage, "PausedDataMsg")
            },
            getPauseDataMsg: function() {
                return TestHelper.getText(currentpage, "PausedDataMsg")
            },
            getPausedDataResumeBtn: function() {
                return TestHelper.isElementPresent(currentpage, "PausedDataResumeBtn")
            },
            clickPausedDataResumeBtn: function() {
                return TestHelper.elementToBeClickable(currentpage, "PausedDataResumeBtn")
            },
            checkOptionsInGoToInInteractiveGraphWidget: function(){
                return element.all(by.css('#widget-actions select > option'));
            },
            checkDashboardOptionInGoToInInteractiveGraphWidget: function(){
                return element.all(by.css('#widget-actions select > option')).get(1);
            },
            dashboardOptionSelected: function(){
                //return element.all(by.css('select.dashboard-tag-toolbox')).get(0);
                return TestHelper.elementToBeClickable(currentpage, 'GotoTypeSelector')
            },
            clickableDisabledDoneBtnEditWidget: function(){
                return element(by.css('button.new-edit-widget:disabled')).isPresent();
            },
            getSpecificWidgetCount: function(widget){
                return element.all(by.css(widget)).count();
            },
            clickAssetInAdvContextBrowser: function(asset){
                dem2[currentpage]["contextItem"].locatorValue=asset;
                return TestHelper.elementToBeClickable(currentpage, "contextItem");
            },
            checkAssetInAdvContextBrowser: function(asset){
                dem2[currentpage]["contextItem"].locatorValue=asset;
                return TestHelper.isElementPresent(currentpage, "contextItem");
            },
            clickOnSetContext: function(){
                return TestHelper.elementToBeClickable(currentpage, "setContext");
            },
            clickOpenButton: function(num){
                dem2[currentpage]["openbuttons2"].value.index=num;
                return TestHelper.elementToBeClickable(currentpage,"openbuttons2");
            },
            checkAssetInContextLink: function(asset){
                return element.all(by.css('#widget-actions a')).get(0).getText();
            },
            checkCrossIconNextToContext: function(){
                return element(by.css('#widget-actions a > .fa-times')).isPresent();
            },
            checkDeckSelectorInAdvCB: function(){
                return TestHelperPO.isElementPresent(element(by.css('#widget-actions #deckSelector')));
            },
            AllDecksInDeckSelectorEditwidget:  function(){
                return dem.findElement(currentpage,'AllDecksInDeckSelectorEditwidget').count();
            },

            selectDeckInDSInAdvCB: function(){
                return TestHelper.elementToBeClickable(currentpage, 'DeckSelectorInAdvCB')
            },
            checkAssetNameinCLB: function(asset){
                return TestHelperPO.isElementPresent(element(by.cssContainingText('#preview-dashboard-wrapper span', asset)));
            },
            checkDeckNameinCLB: function(deckName){
                return TestHelperPO.isElementPresent(element(by.cssContainingText('#preview-dashboard-wrapper span', deckName)));
            },
            checkAppHubKabobMenu: function(){
                return element(by.css('.pxh-drawer-toggle')).isPresent();
            },
            checkEditCardOptionInCLB: function(){
                return TestHelperPO.isElementPresent(element(by.cssContainingText('#cardHeader ul li', "Edit Card")));
            },
            clickXIconNextToAssetName: function(){
                return TestHelperPO.elementToBeClickable(element(by.css('#widget-actions a > .fa-times')));
            },
            hiddenDeckSelectorInAdvCB: function(){
                return element(by.css('#widget-actions #deckSelector[hidden]')).isPresent();
            },
            getLabelforTitleWidgetConfig: function () {
                return TestHelper.isElementVisible(currentpage, 'TitleLabelWidgetConfig')
            },
            checkTitleInpuFieldInWidgetConfig: function () {
                return TestHelper.isElementVisible(currentpage,'TitleInputWidgetConfig')
            },
            getTitleInputValueWidgetConfig: function () {
                // return (element.all(by.css(".text-input.style-scope.apm-hmi-v1-0")).get(0)).getAttribute('value');
                return  dem.findElement(currentpage, 'TitleInputWidgetConfig').getAttribute('value');
            },
            setWidgetTitleWidgetConfig: function (NewWidgetTtl) {
                // return (element.all(by.css(".text-input.style-scope.apm-hmi-v1-0")).get(0)).sendKeys(NewWidgetTtl);
                return TestHelper.sendKeys(currentpage,'TitleInputWidgetConfig', NewWidgetTtl);
            },
            getDisconnectedIcon: function () {
                return TestHelper.isElementVisible(currentpage, 'disconnectedIcon');
            },
        }
    };
    module.exports = new editWidgetPage();
}())
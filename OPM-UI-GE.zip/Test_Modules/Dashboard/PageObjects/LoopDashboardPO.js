(function () {
    'use strict';

    var looppage = 'LoopDashboard';
    var EC = protractor.ExpectedConditions;
    var delay = 7000;

    var loopDashboardPO = function () {
        return {

            getPresentElement: function (element) {
                return browser.wait(EC.presenceOf(element), delay).then(function () {
                    return element;
                });
            },
            roundDecimalPoints: function(tagValue) {
                var formatToDecimal = 'e+2';
                var decimalPlaces = 'e-2';

                return +(Math.round(tagValue + formatToDecimal) + decimalPlaces);
            },
            highlightElement: function (ele) {
                    return browser.driver.executeScript("arguments[0].setAttribute('style', arguments[1]);",this.getElement(ele).getWebElement(), "color: Red; border: 2px solid red;").
                        then(function(resp){
                            browser.sleep(2000);
                            return ele;
                        },function(err){
                            console.log("error is :"+err);
                     });
            },
            getElement: function (ele) {
                return  dem.findElement(looppage, ele);
            },
            clickElement: function (ele) {
                return TestHelper.elementToBeClickable(looppage, ele);
            },
            scrollIntoView: function(ele){
                return browser.executeScript("return arguments[0].scrollIntoView(true);", ele.getWebElement()).then(function() {
                    return browser.sleep(2000).then(function() {
                        return true;
                    });
                });
            }
        }
    };

    module.exports = new loopDashboardPO();
}());
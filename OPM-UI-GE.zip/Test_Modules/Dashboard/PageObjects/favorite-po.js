/* by 502670816  **/
// get function will return the element
// chk function will check to see whether element exists and return empty promise
// click function will click on the element and return empty promise

(function(){
    'use strict';
    var currentpage = 'DashboardAppPages';
    var favoritesPage = null;
    var chart = require('proui-utils').HighChart;
    var section;
    var currentPage = "favoritesPage";

    favoritesPage = function(){
        var self = this;
        return {
            chkSetFavoriteDashboardLink: function () {
                return TestHelper.isElementPresent(currentpage, "SetFavoriteDashboardLink");
            },
            clickSetFavoriteDashboardLink: function () {
                console.log('about to set as a favortie');
                return TestHelper.elementToBeClickable(currentpage, "SetFavoriteDashboardLink");
            },
            chkSetFavoriteDashboardCheck: function(){
                console.log('Checking for favorite dashboard check mark')
                return TestHelper.isElementPresent(currentpage, 'SetFavoriteDashboardCheck');
            },
            chkSetFavoriteDashboardCheckNotPresent: function(){
                console.log('Checking for favorite dashboard check mark')
                return TestHelper.isElementVisible(currentpage, 'SetFavoriteDashboardCheck');
            },

            chkDashboardFavorites : function () {
                console.log('Checking for favorites link')
                return TestHelper.isElementPresent(currentpage, "FavoritesLink");
            },
            clickDashboardFavorites : function () {
                console.log('Clicking on favorites link')
                return TestHelper.elementToBeClickable(currentpage, "FavoritesLink");
            },
            chkFavoritesPage : function () {
                return TestHelper.isElementPresent(currentpage,"FavoritesPage");
            },
            chkDashExistInFavPage : function (dash) {
                return TestHelperPO.isElementPresent(element(by.css('div#'+dash)));
            },
            chkDashNotExistInFavPage : function (dash) {
                return TestHelperPO.isElementNotPresent(element(by.css('div#'+dash)));
            },
            cntFavoriteDashboard : function () {
                return dem.findElement(currentpage, 'FavoriteDashboardItemCount').count();
            },
            getLastFavoriteDashboardName : function (num) {
                dem2[currentpage]['FavoriteDashboardLastItemName'].value.index=num;
                return TestHelper.getText(currentpage,'FavoriteDashboardLastItemName');
            },
            getLastFavoriteDashboardAsset : function (num) {
                dem2[currentpage]['FavoriteDashboardLastItemAsset'].value.index=num;
                return TestHelper.getText(currentpage,'FavoriteDashboardLastItemAsset');
            },
            chkFavoriteDashboardStarDisplay: function(num){
                dem2[currentpage]['FavoriteDashboardStarDisplay'].value.index=num;
                return TestHelper.isElementPresent(currentpage, 'FavoriteDashboardStarDisplay');
            },
            ClickFavoriteDashboardStarDisplay: function(num){
                dem2[currentpage]['FavoriteDashboardStarDisplay'].value.index=num;
                return TestHelper.elementToBeClickable(currentpage, 'FavoriteDashboardStarDisplay');
            },
            cntFavoriteDashboardThumbnail : function () {
                return dem.findElement(currentpage, 'FavoriteDashboardThumbnail').count();
            },
            cntFavoriteDashboardStars : function() {
                return dem.findElement(currentpage, 'FavoriteDashboardStar').count();
            },
            chkfavDashboard: function(dashboardName){
                dem2[currentpage]['FavoriteDashboard'].locatorValue = dashboardName;
                return TestHelper.isElementPresent(currentpage, 'FavoriteDashboard');
            },
            chkfavDashboardPresent: function(dashboardName){
                dem2[currentpage]['FavoriteDashboard'].locatorValue = dashboardName;
                return TestHelper.isElementVisible(currentpage, 'FavoriteDashboard');
            },
            clickFavoriteDashboardStar: function(dashboardName) {
                return TestHelperPO.elementToBeClickable(element(by.css('#'+dashboardName + ' a.star-icon')));
            },
            clickFavoriteDashboardthumbnail: function(dashboardName) {
                return TestHelperPO.elementToBeClickable(element(by.css('#' + dashboardName + '>a.favorite-dashboard')));
            },
            chkfavDashboardExists: function(dashboardName) {
                console.log('checking if the dashboard exists in fav page' + dashboardName);
                return TestHelperPO.isElementPresent(element(by.id(dashboardName)));
            },
            chkFavoriteDashboardExists: function(){
              return TestHelper.isElementPresent(currentpage,'favDashboardExists')
            },
            getAssetContext: function(){
                return TestHelper.getText(currentpage,'assetContext');
            }
        }
    };
    module.exports = new favoritesPage();
}());

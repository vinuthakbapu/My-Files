/* created by 212340705 on Jan 6th 2016 */
(function() {
    'use strict';
    var newDashPg = 'DashboardAppPages';
    var currentpage = 'DashboardAppPages';
    var EC = protractor.ExpectedConditions;

    var addCardPage = function () {
        return {

            chkAddNewCardLink: function () {
                //return element(by.cssContainingText('ul.dropdown-menu li','Add New Card'));
                return TestHelper.isElementPresent(currentpage, "CardActionMenuBtn");
            },
            clickPreviewBtn: function (index) {
                //return element(by.cssContainingText('ul.dropdown-menu li','Add New Card'));
                var idx = index;
                return dem.findElement(currentpage, "customCardPreviewBtn").then(function (ele) {
                    return ele[idx].click();
                })
            },
            getCardLibraryPreviewBtn: function (num) {
                dem2[currentpage]['CardLibraryPreviewBtns'].value.index = num;
                return TestHelper.isElementPresent(currentpage, "CardLibraryPreviewBtns");
            },
            clickCardLibraryPreviewBtn: function (num) {
                dem2[currentpage]['CardLibraryPreviewBtns'].value.index = num;
                return TestHelper.elementToBeClickable(currentpage, "CardLibraryPreviewBtns");
            },
            clickPreviewBackButton: function () {
                /*
                 *  new TestHelper framework fails here.
                 * */
                return element(by.id('back-btn'));
            },
            clickAddNewCardLink: function () {
                //return element(by.css('#addNewCard'));
                //return TestHelper.elementToBeClickable(currentpage, "AddNewCardLink");
                return dem.findElement(currentpage, 'AddNewCardLink').click();
            },
            clickAddCardBtnFromPreview: function () {
                //return element(by.css('#addCardBtn')).click();
                return TestHelper.elementToBeClickable(currentpage, "PreviewAddButton");
                //return dem.findElement(currentpage, 'PreviewAddButton').click();
            },
            getAddNewCardLink: function () {
                //return element(by.css('#addNewCard'));
                return TestHelper.isElementPresent(currentpage, "AddNewCardLink");
                //return dem.findElement(currentpage, 'AddNewCardLink').click();
            },
            chkAddNewCardLink2: function () {
                return TestHelper.isElementVisible(currentpage, "AddNewCardLink");
            },
            chkAddNewCardLinkDisabled: function () {
                return TestHelper.isElementPresent(currentpage, "AddNewCardLinkDisabled");
            },

            chkSetDefaultDashboardLink: function () {
                return element(by.css("#viewMenuList #makeDefault")).isPresent();
                // return TestHelper.isElementVisible(currentpage, "SetDefaultDashboardLink");
            },
            clickSetDefaultDashboardLink: function () {
                return TestHelper.elementToBeClickable(currentpage, "SetDefaultDashboardLink");
            },

            // addCard: function (cardName) {
            //     var self = this;
            //     return protractor.promise.all([
            //         createviewpage.getCardActionMenuBtn().click(),
            //         this.getAddNewCardLink().click(),
            //         this.get6upAddBtn().click(),
            //         browser.sleep(10000)
            //         //this.getSecondPxCard().click(),
            //         //this.getCardTitleInput().sendKeys(cardName)
            //     ], 2000).then(function () {
            //         self.getDoneButton().click();
            //     })
            // },
            chkEditCardTitle: function () {
                return TestHelper.isElementVisible(currentpage, "EditCardMenu");
            },
            getEditCardTitle: function (num) {
                //return element.all(by.id('cardTitle')).get(num);
                return element.all(by.css('div#container div.custom-card >#cardTitle')).get(num);
                //return TestHelper.isElementPresent(currentpage, "cardTitle");
            },
            getCardTitleHeader: function(num){
                return element.all(by.css('div#container h3.custom-card')).get(num);
            },
            getEditCardMenu: function () {
                //return element(by.css('i.editDropDown'));
                return dem.findElement(currentpage, "EditCardMenu");
            },
            clickEditCardMenu: function () {
                //return element(by.css('i.editDropDown'));
                return TestHelper.elementToBeClickable(currentpage, "EditCardMenu");
            },
            clickEditCardMenu_v2: function (cardNumber) {
                dem2[currentpage]["EditCardMenu_v2"].value.index = cardNumber;
                return TestHelper.elementToBeClickable(currentpage, "EditCardMenu_v2");
            },
            checkMoveCardDownOptionEnabled: function(cardNumber) {
                dem2[currentpage]["moveLastCardOption"].value.index = cardNumber;
                return TestHelper.isElementVisible(currentpage,'moveLastCardOption');
            },
            checkMoveCardUpOptionDisabled: function(cardNumber) {
                dem2[currentpage]["moveFirstCardOption"].value.index = cardNumber;
                return TestHelper.getAttribute(currentpage, "moveFirstCardOption","disabled");
            },
            checkMoveCardDownOptionDisabled: function(cardNumber) {
                dem2[currentpage]["moveLastCardOption"].value.index = cardNumber;
                return TestHelper.getAttribute(currentpage,'moveLastCardOption',"disabled");
            },
            checkMoveCardUpOptionEnabled: function(cardNumber) {
                dem2[currentpage]["moveFirstCardOption"].value.index = cardNumber;
                return TestHelper.isElementVisible(currentpage, "moveFirstCardOption");
            },
            moveCardDown: function(cardNumber) {
                dem2[currentpage]["moveLastCardOption"].value.index = cardNumber;
                return TestHelper.elementToBeClickable(currentpage, 'moveLastCardOption');
            },
            moveCardUp: function(cardNumber) {
                dem2[currentpage]["moveFirstCardOption"].value.index = cardNumber;
                return TestHelper.elementToBeClickable(currentpage, 'moveFirstCardOption');
            },
            getCardInFocus: function(cardNumber) {
                dem2[currentpage]["cardInFocus"].value.index = cardNumber;
                return TestHelper.scrollIntoView(currentpage, 'cardInFocus');
            },
            getYLocationOfLocator: function(cardNumber) {
                dem2[currentpage]["cardInFocus"].value.index = cardNumber;
                var headerElement  = dem.findElement(currentpage, 'cardInFocus');
                return headerElement.getLocation();
            },
            getEditCardLink: function () {
                // return element(by.cssContainingText('li.custom-card', 'EditCardLink'));
                return TestHelper.isElementPresent(currentpage, "EditCardLink");
            },
            chkEditCardLink: function (viewname) {
                dem2[currentpage]["EditCardMenu"].locatorValue = viewname;
                return TestHelper.isElementVisible(currentpage, 'EditCardMenu');
            },
            chkEditCardLink2: function (viewname) {
                dem2[currentpage]["EditCardMenu2"].locatorValue = viewname;
                return TestHelper.isElementVisible(currentpage, 'EditCardMenu2');
            },
            clickEditCardLink: function () {
                // return element(by.cssContainingText('li.custom-card', 'EditCardLink'));
                return TestHelper.elementToBeClickable(currentpage, "EditCardLink");
            },
            clickEditCardLink_v2: function (cardLinkNumber) {
                dem2[currentpage]["EditCardLink_v2"].value.index = cardLinkNumber;
                return TestHelper.elementToBeClickable(currentpage, "EditCardLink_v2");
            },
            getDeleteCardLink: function () {
                // return element(by.cssContainingText('li.custom-card', 'Delete Card'));
                return TestHelper.isElementPresent(currentpage, "DeleteCardLink");
            },
            chkTimeControlLink: function () {
                // return element(by.cssContainingText('#cardHeader > div.custom-card > ul > li:nth-of-type(2)')).isPresent();
                return TestHelper.isElementPresent(currentpage, 'TimeControlEditCardMenu');
            },
            clickTimeControlLink: function () {
                return TestHelper.elementToBeClickable(currentpage, 'TimeControlEditCardMenu');
            },
            chkTimeControlCheckmark: function () {
                return TestHelper.isElementPresent(currentpage, 'TimeControlCheckmark');
            },
            chkTimeControl: function () {
                // return TestHelper.isElementPresent(currentpage, 'TimeControl');
                return dem.findElement(currentpage, 'TimeControl');
            },
            chkDatePlaceHolder: function () {
                return TestHelper.isElementPresent(currentpage, 'DatePlaceHolder');
            },
            clickDatePlaceHolder: function () {
                return TestHelper.elementToBeClickable(currentpage, 'DatePlaceHolder');
            },
            chkDateSelectorChevron: function () {
                return TestHelper.isElementPresent(currentpage, 'DateSelectorChevron');
            },
            clickDateSelectorChevron: function () {
                return TestHelper.elementToBeClickable(currentpage, 'DateSelectorChevron');
            },
            chkTimeControlResumeButton: function () {
                return TestHelper.isElementPresent(currentpage, 'ResumeButton');
            },
            clickTimeControlResumeButton: function () {
                return TestHelper.elementToBeClickable(currentpage, 'ResumeButton');
            },
            chkDateSelectorDropdownOpen: function () {
                return dem.findElement(currentpage, 'DateSelectorDropdown').getAttribute('hidden').isPresent();
            },
            chkDateSelectorOptions: function (optionname) {
                dem2[currentpage]["DateSelectorOptions"].locatorValue = optionname;
                return TestHelperPO.isElementPresent(element(by.cssContainingText('ul#dateMenu li div', optionname)));
            },
            getDateSelectorOptions: function (optionname) {
                dem2[currentpage]["DateSelectorOption"].locatorValue = optionname;
                return dem.findElement(currentpage, 'DateSelectorOption');
            },
            chkDateSelectorDateTimeFields: function () {
                return TestHelper.isElementPresent(currentpage, 'DateSelectorDateTimeFields');
            },
            clickDateSelectorDateTimeFields: function () {
                return TestHelper.elementToBeClickable(currentpage, 'DateSelectorDateTimeFields');
            },
            chkDateSelectorDateTimeToFields: function () {
                return TestHelper.isElementPresent(currentpage, 'DateSelectorDateTimeToFields');
            },
            clickDateSelectorDateTimeToFields: function () {
                return TestHelper.elementToBeClickable(currentpage, 'DateSelectorDateTimeToFields');
            },
            getDayBeforeToday: function (day) {
                dem2[currentpage]["DatePickerDay"].locatorValue = day;
                return dem.findElement(currentpage, 'DatePickerDay');
            },
            chkDateSelectorDateTimePicker: function () {
                return dem.findElement(currentpage, 'DateSelectorDateTimePicker').getAttribute('hidden').isPresent();
            },
            chkCustomDateTimePicker: function () {
                return dem.findElement(currentpage, 'CustomDateTimePicker').getAttribute('hidden').isPresent();
            },
            chkDateTimePickerTimestamp: function () {
                return TestHelper.isElementPresent(currentpage, 'DateTimePickerTimestamp');
            },
            getDateTimePickerSelectedToday: function () {
                return dem.findElement(currentpage, 'DateTimePickerSelectedToday')
            },
            getDateTimePickerSelectedDay: function () {
                return dem.findElement(currentpage, 'DateTimePickerSelectedDay')
            },
            chkDateTimePickerCancelBtn: function () {
                return TestHelper.isElementPresent(currentpage, 'DateTimePickerCancelBtn');
            },
            clickDateTimePickerCancelBtn: function () {
                return TestHelper.elementToBeClickable(currentpage, 'DateTimePickerCancelBtn');
            },
            chkDateTimePickerApplyBtn: function () {
                return TestHelper.isElementPresent(currentpage, 'DateTimePickerApplyBtn');
            },
            clickDateTimePickerApplyBtn: function () {
                return TestHelper.elementToBeClickable(currentpage, 'DateTimePickerApplyBtn');
            },
            chkPresets: function () {
                return TestHelper.isElementPresent(currentpage, 'Presets');
            },
            getPresetsOption: function (optionname) {
                dem2[currentpage]["PresetsOption"].locatorValue = optionname;
                return dem.findElement(currentpage, 'PresetsOption');
            },
            clickCustomPickerApplyBtn: function () {
                return TestHelper.elementToBeClickable(currentpage, 'CustomPickerApplyBtn');
            },
            chkWidgetOverlay: function () {
                return TestHelper.isElementPresent(currentpage, 'WidgetOverlay');
            },
            getWidgetOverlayWidgetByID: function (id) {
                return element(by.css('.overlay-widget.custom-card > #' + id)).isPresent();
            },
            getDateTimeSpanByText: function (text) {
                dem2[currentpage]["DateTimeSpanText"].locatorValue = text;
                return dem.findElement(currentpage, 'DateTimeSpanText');
            },
            chkEditCardMenuDropdownOpen: function () {
                // return dem.findElement(currentpage, 'EditCardMenu2').getAttribute('hidden').isPresent();
                return element(by.css('ul.edit-menu:not([hidden])')).isPresent();
            },
            clickDeleteCardLink: function () {
                // return element(by.cssContainingText('li.custom-card', 'Delete Card'));
                return TestHelper.elementToBeClickable(currentpage, "DeleteCardLink");
            },
            getDeleteCardConfirmPopup: function () {
                // return element(by.css('section.modal__content.px-modal >h3#deleteCard-title'));
                return TestHelper.isElementPresent(currentpage, "DeleteCardConfirmPopup");
            },
            getDeleteCardConfirmOkBtn: function () {
                // return element(by.css('view-menu px-modal button#OK')).isPresent();
                return TestHelper.isElementPresent(currentpage, "DeleteCardConfirmOkBtn");
            },
            clickDeleteCardConfirmOKBtn: function () {
//                 return element(by.css('#deleteCard button#OK')).click();
//                return dem.findElement(currentpage, 'DeleteCardConfirmOkBtn').click();
                return TestHelper.elementToBeClickable(currentpage, "DeleteCardConfirmOkBtn");
            },
            getDeleteCardConfirmCancelBtn: function () {
                //return element(by.css('px-dashboard #container px-modal #deleteCard button#Cancel'));
                return TestHelper.isElementPresent(currentpage, "DeleteCardConfirmCancelBtn");
            },
            getDeleteCardConfirmMsg: function () {
//                return element.all(by.css('section.modal__content.px-modal >#deleteMsg')).getText();
//                return TestHelper.isElementPresent(currentpage, "DeleteCardConfirmMsg");
                return element(by.css('div#container #deleteMsg')).getText();
            },
            getAddWidgetButtonCount: function () {
                return element.all(by.css('div#container #add-placeholder-widget-container .add-placeholder-widget')).count();
                // return dem.findElement(currentpage, 'AddWidgetButton');
            },

            getAllCards: function () {
                //return element.all(by.css('div.custom-card-wrapper'));
                //return element.all(by.css('div#container custom-card'));
                return dem.findElement(currentpage, 'cardsInDashboard').count();
            },
            getFirstCard: function () {
                return element(by.css('#cardContainer > div:first-child'))
                    .isDisplayed()
                    .then(function (visible) {
                        return visible;
                    });
            },
            getAllAddBtnsInCardLibrary: function () {
                //return element.all(by.id('add-btn'));
                return TestHelper.isElementPresent(currentpage, "AllAddBtnsInCardLibrary");
            },
            getAllPreviewBtnInCardLibrary: function () {
                //return element.all(by.id('preview-btn'))
                return dem.findElement(currentpage, 'customCardPreviewBtn').count();
            },
            getSpecificPreviewBtnInCardLibrary: function (num) {
                //return element.all(by.id('preview-btn'))
                return dem.findElement(currentpage, 'customCardPreviewBtn').get(num);
            },
            getOverviewCard: function () {
                return element.all(by.id('add-btn')).get(1);
                //return TestHelper.isElementPresent(currentpage, 'customCardPreviewBtn');
            },
            getCustomCard: function () {
                return element.all(by.id('add-btn')).get(0);
                //return TestHelper.isElementPresent(currentpage, 'customCardPreviewBtn');
            },
            getCardLibraryPage: function () {
                return element(by.id('cardContainer'));
//                return TestHelper.isElementPresent(currentpage, 'CardLibraryPage');
            },
            getAllCardTemplates: function () {
                // return element.all(by.css('div.layout__item.add-card-template'));
                return TestHelper.isElementPresent(currentpage, 'AllCardTemplates');
            },
            getAllThumbnails: function () {
                return dem.findElement(currentpage, 'AllCustomcardThumbnail');
            },
            getOverviewCardThumbnail: function () {
                //return TestHelper.isElementPresent(currentpage, 'overviewCardThumbnail');
                return dem.findElement(currentpage, 'overviewCardThumbnail').isPresent();
            },
            getThumbnail: function (img) {
                // return element(by.css('div#Custom Card div.card-thumb-img'));
                var thumbnail = "AllCustomcardThumbnail";
                if (img) {
                    thumbnail = img;
                }
                return TestHelper.isElementPresent(currentpage, thumbnail);
            },
            getOverViewCard: function () {
                // return element(by.css('div#Overview div.card-thumb-img'));
                return TestHelper.isElementPresent(currentpage, 'OverViewCard');
            },
            getPreviewScreen: function () {
                //return element(by.css('section.card-preview'));
                return TestHelper.isElementPresent(currentpage, 'PreviewScreen');
            },
            getPreviewBackButton: function () {
                //return element(by.id('back-btn')).isPresent();
                return TestHelper.isElementPresent(currentpage, 'PreviewBackButton');
            },
            clickPreviewBackButton2: function () {
                //return element(by.id('back-btn')).click();
                return TestHelper.elementToBeClickable(currentpage, 'PreviewBackButton');
            },
            getPreviewImage: function () {
                //return element(by.css('article.card-preview img')).isPresent();
                return TestHelper.isElementPresent(currentpage, 'PreviewImage');
            },
            getPreviewDescription: function () {
                //return element(by.css('article.card-preview p')).isPresent();
                return TestHelper.isElementPresent(currentpage, 'PreviewDescription');
            },
            getPreviewDescriptionText: function () {
                return TestHelper.getText(currentpage, 'PreviewDescription');
            },
            getPreviewAddButton: function () {
                //return element(by.id('addCardBtn')).isPresent();
                //return TestHelperPO.isElementPresent(element(by.id('addCardBtn')));

                return TestHelper.isElementPresent(currentpage, 'PreviewAddButton');
                //return TestHelper.isElementVisible(currentpage, 'PreviewAddButton');
            },
            clickPreviewAddButton: function () {
                //return element(by.id('addCardBtn')).click();
                return TestHelper.elementToBeClickable(currentpage, 'PreviewAddButton');
            },
            getCancelEditCard: function () {
                return TestHelperPO.isElementPresent(element(by.cssContainingText('div#container button.custom-card', 'Cancel')));
            },
            clickCancelEditCard: function () {
                return TestHelperPO.elementToBeClickable(element(by.cssContainingText('div#container button.custom-card', 'Cancel')));
            },
            getCancelBtn: function () {
                return element(by.cssContainingText('div#container button.custom-card', 'Cancel'));
            },
            getSaveBtn: function () {
                return element(by.cssContainingText('div#container button.custom-card', 'Save'));
            },
            getSaveBtn_v2: function (indexNumber) {
                var num = indexNumber * 2 + 1;
                dem2[currentpage]['saveButton_v2'].value.index = num;
                return TestHelper.elementToBeClickable(currentpage, 'saveButton_v2');
            },
            getWidget1: function () {
                return element(by.css('div.widget-1'));
            },
            getDltWidgetIconCount: function () {
                return element.all(by.css('i.fa-times.custom-card')).count();
            },
            getEditWidgetIconCount: function () {
                return element.all(by.css('i.fa-pencil.custom-card')).count();
            },
            clickEditWidgetIconCustomEditCard: function (num) {
                //return element.all(by.css('i.fa-pencil.custom-card')).get(num);

                dem2[currentpage]['EditWidgetIconCustomCard'].value.index = num;
                return TestHelper.elementToBeClickable(currentpage, 'EditWidgetIconCustomCard');
            },

            getEditWidgetIcon: function (num) {
                return element.all(by.css('i.fa-pencil.custom-card')).get(num);
            },
            getDltWidgetIcon: function (num) {
                return element.all(by.css('i.fa-times.custom-card')).get(num);
            },

            getAddWidgetButton: function (num) {
                // return element.all(by.cssContainingText('button','Add Widget')).get(num);
                dem2[currentpage]['AddWidgetButton'].value.index = num;
                return TestHelper.isElementPresent(currentpage, 'AddWidgetButton');
            },
            clickAddWidgetButton: function (num) {
                // return element.all(by.cssContainingText('button','Add Widget')).get(num);
                dem2[currentpage]['AddWidgetButton'].value.index = num;
                return TestHelper.elementToBeClickable(currentpage, 'AddWidgetButton');
            },
            getToastAlertMessage: function (num) {
                //return element.all(by.css('span.px-alert-message')).get(num).getText();
                return TestHelper.isElementPresent(currentpage, 'ToastAlertMessage');
            },
            getToastAlertMessageText: function (num) {
                return element.all(by.css('span.px-alert-message')).get(num).getText();
                //return TestHelper.isElementPresent(currentpage, 'ToastAlertMessage');
            },
            getToastAlertMessageCount: function () {
                //return element.all(by.css('span.px-alert-message')).count();
                //return this.getToastAlertMessage.count();
                return dem.findElement(currentpage, 'ToastAlerts').count();
            },
            getToastAlertCloseIcon: function () {
                // return element.all(by.css('i.fa-times.px-alert-message')).get(0);
                return TestHelper.isElementPresent(currentpage, 'ToastAlertCloseIcon');
            },
            clickToastAlertCloseIcon: function () {
                // return element.all(by.css('i.fa-times.px-alert-message')).get(0);
                return TestHelper.elementToBeClickable(currentpage, 'ToastAlertCloseIcon');
            },
            addSpecificCard: function (type) {
                var self = this;

                return createviewpage.clickCardActionMenuBtn().then(function () {
                    self.clickAddNewCardLink().then(function () {
                        customcardpage.ChkAddCardButtonInCardLibrary(type).then(function (yes) {
                            console.log('inside ChkAddCardButtonInCardLibrary '+yes );
                            if(yes){
                                customcardpage.clickAddCardButtonInCardLibrary(type).then(function (yes) {
                                    console.log('inside clickAddCardButtonInCardLibrary '+yes );

                                    browser.sleep(10000).then(function () {
                                        createviewpage.clickDoneButton().then(function () {
                                            browser.sleep(5000).then(function () {
                                                console.log('addSpecificCard done')
                                            });
                                        });
                                    });
                                });
                            }else{
                                console.log(type + ' is an incorrect card name. please try again with right card name');
                            }
                        });
                    });
                });
            },
            addSpecificCardfromPreview: function (cardName) {
                console.log('inside the addSpecificCard function');
                var self = this;
                return createviewpage.clickCardActionMenuBtn().then(function () {
                    self.clickAddNewCardLink().then(function () {
                        customcardpage.ChkAddCardButtonInCardLibrary(cardName).then(function (yes) {
                            if(yes){
                                customcardpage.clickAddCardPreviewButtonInCardLibrary(cardName).then(function (yes) {
                                    self.clickAddCardBtnFromPreview().then(function(){
                                        browser.sleep(10000).then(function () {
                                            createviewpage.clickDoneButton().then(function () {
                                                browser.sleep(5000).then(function () {
                                                    console.log('addSpecificCardfromPreview done')
                                                });
                                            });
                                        });
                                    });
                                });
                            }else{
                                console.log(type + ' is an incorrect card name. please try again with right card name');
                            }
                        });
                    });
                });
            },
            getCardName: function () {
                return TestHelper.getText(currentpage, 'CardName');
            },
            getCardNameFromArray: function () {
                return TestHelper.getText(currentpage, 'CardNameFromArray');
            },
            getSaveToCardLibraryLinkText: function () {
                return TestHelper.getText(currentpage, 'SaveToCardLibraryLink');
            },
            chkSTCLoptionInEditMenu: function () {
                return TestHelper.isElementPresent(currentpage, 'SaveToCardLibraryLink');
            },
            clickSaveToCardLibrary: function () {
                return TestHelper.elementToBeClickable(currentpage, 'SaveToCardLibraryLink');
            },
    //****** STCLP = SaveToCardLibraryPopup *********
            chkSTCLP: function () {
                return TestHelper.isElementPresent(currentpage, 'SaveToCardLibPopup');
            },
            chkEditCardPopupInCL: function () {
                return TestHelper.isElementPresent(currentpage, 'EditCardPopupInCardLib');
            },
            chkSTCLPlabel:function(labelname){
                dem2[currentpage]['STCLPlabel'].locatorValue = labelname;
                return TestHelper.isElementPresent(currentpage, 'STCLPlabel');
            },
            getSTCLPlabelTxt:function(labelname){
                dem2[currentpage]['STCLPlabel'].locatorValue = labelname;
                return TestHelper.getText(currentpage, 'STCLPlabel');
            },
            getSTCLPspanTxt:function(num){
                dem2[currentpage]['STCLPspan'].value.index = num;
                return TestHelper.getText(currentpage, 'STCLPspan');
            },
            getSTCLPtitleValue:function(){
                return dem.findElement(currentpage, 'STCLPtitleInput').getAttribute('value');
            },
            getSTCLPdescrptionValue:function(){
                return dem.findElement(currentpage, 'STCLPdescInput').getAttribute('value');
            },
            chkSTCLPdescrptionInput:function(){
                return TestHelper.isElementPresent(currentpage, 'STCLPdescInput');
            },
            getSTCLPdescriptionInput:function(){
                return dem.findElement(currentpage, 'STCLPdescInput');
            },
            getSTCLPtitleInput:function(){
                return dem.findElement(currentpage, 'STCLPtitleInput');
            },
            getSTCLPcharLimitTxt:function(){
                return TestHelper.getText(currentpage, 'STCLPspanCharLimit');
            },
            chkSTCLPcancelBtn:function(){
                return TestHelper.isEnabled(currentpage, 'STCLPcancelBtn');
            },
            chkSTCLPsaveBtn:function(){
                return TestHelper.isEnabled(currentpage, 'STCLPsaveBtn');
            },
            isSTCLPcancelBtnDisabled:function(){
                return dem.findElement(currentpage, 'STCLPcancelBtn').getAttribute('disabled');
            },
            isSTCLPsaveBtnDisabled:function(){
                return dem.findElement(currentpage, 'STCLPsaveBtn').getAttribute('disabled');
            },
            clickSTCLPcancelBtn:function(){
                return TestHelper.elementToBeClickable(currentpage, 'STCLPcancelBtn');
            },
            clickSTCLPsaveBtn:function(){
                return TestHelper.elementToBeClickable(currentpage, 'STCLPsaveBtn');
            },
            clickSTCLPFixedRadioBtn:function(){
                dem2[currentpage]['STCLPradioBtn'].value.index = 1;
                return TestHelper.elementToBeClickable(currentpage, 'STCLPradioBtn');
            },
            clickSTCLPTemplateRadioBtn:function(){
                dem2[currentpage]['STCLPradioBtn'].value.index = 0;
                return TestHelper.elementToBeClickable(currentpage, 'STCLPradioBtn');
            },
            GetCardsCountInCardLibrary:function(){
                return dem.findElement(currentpage,'CardsInCardLibrary').count();
            },
            getCardTitleFromCardLib:function(num){
                dem2[currentpage]['CardTitleInCardLibrary'].value.index = num;
                return TestHelper.getText(currentpage, 'CardTitleInCardLibrary');
            },
            clickThumbnailImageCardLibrary: function (num) {
                dem2[currentpage]['CaryLibraryThumbImage'].value.index = num;
                return TestHelper.elementToBeClickable(currentpage, 'CaryLibraryThumbImage');
            },
            getDescriptionFromCardPrview: function () {
                return TestHelper.getText(currentpage, 'PreviewDescription');
            },
            isSTCLPTemplateRadioBtnChecked:function(){
                return dem.findElement(currentpage, 'STCLPTemplateRadioBtn').getAttribute('checked');
            },
            isSTCLPFixedRadioBtnChecked:function(){
                return dem.findElement(currentpage, 'STCLPFixedRadioBtn').getAttribute('checked');
            },
            getSTCLPTemplateRadioBtnLabel:function(){
                dem2[currentpage]['STCLPRadioBtnLabel'].value.index = 1;
                return TestHelper.getText(currentpage, 'STCLPRadioBtnLabel');
            },
            getSTCLPFixedRadioBtnLabel:function(){
                dem2[currentpage]['STCLPRadioBtnLabel'].value.index = 2;
                return TestHelper.getText(currentpage, 'STCLPRadioBtnLabel');
            },
            chkCardLibraryLinkInLeftNav:function(linkname){
                dem2[currentpage]['CardLibraryLinkInLeftNav'].locatorValue = linkname;
                return TestHelper.isElementPresent(currentpage, 'CardLibraryLinkInLeftNav');
            },
            clickCardLibraryLinkInLeftNav:function(linkname){
                dem2[currentpage]['CardLibraryLinkInLeftNav'].locatorValue = linkname;
                return TestHelper.elementToBeClickable(currentpage, 'CardLibraryLinkInLeftNav');
            },
            getCLPageTitle:function(){
                //return element(by.css('#content h3.flex__item')).getText();
                return TestHelper.getText(currentpage, 'CardLibraryPageTitle');
            },
            chkCLKebabMenu:function(num){
                dem2[currentpage]['KebabMenuInCL'].value.index = num;
                return TestHelper.isElementPresent(currentpage, 'KebabMenuInCL');
            },
            clickCLKebabMenu:function(num){
                dem2[currentpage]['KebabMenuInCL'].value.index = num;
                return TestHelper.elementToBeClickable(currentpage, 'KebabMenuInCL');
            },
            chkCLEditCardLink:function(num){
                dem2[currentpage]['editCardLinkInCL'].value.index = num;
                return TestHelper.isElementPresent(currentpage, 'editCardLinkInCL');
            },
            chkCLDeleteCardLink:function(num){
                dem2[currentpage]['deleteCardLinkInCL'].value.index = num;
                return TestHelper.isElementPresent(currentpage, 'deleteCardLinkInCL');
            },
            clickCLEditCardLink:function(num){
                dem2[currentpage]['editCardLinkInCL'].value.index = num;
                return TestHelper.elementToBeClickable(currentpage, 'editCardLinkInCL');
            },
            clickCLDeleteCardLink:function(num){
                dem2[currentpage]['deleteCardLinkInCL'].value.index = num;
                return TestHelper.elementToBeClickable(currentpage, 'deleteCardLinkInCL');
            },
            chkCLEditCardPopup: function () {
                return TestHelper.isElementPresent(currentpage, 'CLEditCardPopup');
            },
//****** CLECP = Card Library Edit Card Popup *********
            chkCLECPlabel:function(labelname){
                dem2[currentpage]['CLECPlabel'].locatorValue = labelname;
                return TestHelper.isElementPresent(currentpage, 'CLECPlabel');
            },
            getCLECPlabelTxt:function(labelname){
                dem2[currentpage]['CLECPlabel'].locatorValue = labelname;
                return TestHelper.getText(currentpage, 'CLECPlabel');
            },
            getCLECPspanTxt:function(num){
                dem2[currentpage]['CLECPspan'].value.index = num;
                return TestHelper.getText(currentpage, 'CLECPspan');
            },
            getCLECPtitleValue:function(){
                return dem.findElement(currentpage, 'CLECPtitleInput').getAttribute('value');
            },
            getCLECPdescrptionValue:function(){
                return dem.findElement(currentpage, 'CLECPdescInput').getAttribute('value');
            },
            chkCLECPdescrptionInput:function(){
                return TestHelper.isElementPresent(currentpage, 'CLECPdescInput');
            },
            getCLECPdescriptionInput:function(){
                return dem.findElement(currentpage, 'CLECPdescInput');
            },
            getCLECPtitleInput:function(){
                return dem.findElement(currentpage, 'CLECPtitleInput');
            },
            getCLECPcharLimitTxt:function(){
                return TestHelper.getText(currentpage, 'CLECPspanCharLimit');
            },
            chkCLECPcancelBtn:function(){
                return TestHelper.isEnabled(currentpage, 'CLECPcancelBtn');
            },
            chkCLECPsaveBtn:function(){
                return TestHelper.isEnabled(currentpage, 'CLECPsaveBtn');
            },
            isCLECPcancelBtnDisabled:function(){
                return dem.findElement(currentpage, 'CLECPcancelBtn').getAttribute('disabled');
            },
            isCLECPsaveBtnDisabled:function(){
                return dem.findElement(currentpage, 'CLECPsaveBtn').getAttribute('disabled');
            },
            clickCLECPcancelBtn:function(){
                return TestHelper.elementToBeClickable(currentpage, 'CLECPcancelBtn');
            },
            clickCLECPsaveBtn:function(){
                return TestHelper.elementToBeClickable(currentpage, 'CLECPsaveBtn');
            },
            clickCLECPFixedRadioBtn:function(){
                dem2[currentpage]['CLECPradioBtn'].value.index = 1;
                return TestHelper.elementToBeClickable(currentpage, 'CLECPradioBtn');
            },
            clickCLECPTemplateRadioBtn:function(){
                dem2[currentpage]['STCLPradioBtn'].value.index = 0;
                return TestHelper.elementToBeClickable(currentpage, 'CLECPradioBtn');
            },
            getCLECPTemplateRadioBtnLabel:function(){
                dem2[currentpage]['CLECPRadioBtnLabel'].value.index = 1;
                return TestHelper.getText(currentpage, 'CLECPRadioBtnLabel');
            },
            getCLECPFixedRadioBtnLabel:function(){
                dem2[currentpage]['CLECPRadioBtnLabel'].value.index = 2;
                return TestHelper.getText(currentpage, 'CLECPRadioBtnLabel');
            },
            isCLECPTemplateRadioBtnChecked:function(){
                return dem.findElement(currentpage, 'CLECPTemplateRadioBtn').getAttribute('checked');
            },
            isCLECPFixedRadioBtnChecked:function(){
                return dem.findElement(currentpage, 'CLECPFixedRadioBtn').getAttribute('checked');
            },
            chkCardPreviewPageTitle:function(cardname){
                dem2[currentpage]['CardPrievewPageTitle'].locatorValue = cardname;
                return TestHelper.isElementPresent(currentpage, 'CardPrievewPageTitle');
            },
            chkExportToPDFlink:function(){
                return TestHelper.isElementPresent(currentpage, 'ExportToPDFLink');
            },
            chkExportToPDFlinkHidden:function(){
                console.log('inside chkExportToPDFlinkHidden');
                // return TestHelper.isElementPresent(currentpage, 'ExportToPDFLinkHidden');
                return TestHelper.isElementVisible(currentpage, 'ExportToPDFLink');
            },
            clickExportToPDFlink:function(){
                return TestHelper.elementToBeClickable(currentpage, 'ExportToPDFLink');
            },
            chkExportDashboardToPDFLinkInKebabMenu:function() {
                return TestHelper.isElementVisible(currentpage, 'ExportDashboardToPDFLink');
            },
            clickExportDashboardToPDFLink:function() {
                return TestHelper.elementToBeClickable(currentpage, 'ExportDashboardToPDFLink');
            }





        };
    };
    module.exports = new addCardPage();
}());


(function(){
    'use strict';
    var currentpage = 'DashboardAppPages';
    var TimeSpanGraphWidget = function() {
        return {
            checkTimeSpanLabel: function() {
                return TestHelper.isElementPresent(currentpage,'timeSpanLabel');
            },
            checkTimeSpanDropDown: function() {
                return TestHelper.isElementPresent(currentpage,'timeSpanDropDown');
            },
            getTimeSpanDropDownDefaultValue: function() {
                return TestHelper.getText(currentpage,'timeSpanDropDownDefaultValue');
            },
            checkElementOfTimeSpanDropDownList: function(arg1) {
                var localIndex = -1;
                if (arg1 === '1 Hour') {
                    localIndex = 0;
                } else if (arg1 === '1 Day') {
                    localIndex = 1;
                } else if (arg1 === '1 Week') {
                    localIndex = 2;
                } else if (arg1 === '1 Month') {
                    localIndex = 3;
                } else if (arg1 === '3 Months') {
                    localIndex = 4;
                } else if (arg1 === '6 Months') {
                    localIndex = 5;
                } else if (arg1 === '1 Year') {
                    localIndex = 6;
                } else {
                    localIndex = 100;
                }
                console.log("index is: " + localIndex);
                dem2[currentpage]["timeSpanDropDownList"].value.index = localIndex;
                return TestHelper.getText(currentpage,'timeSpanDropDownList');
            },
            checkTimeSpanFooterInEditPage: function() {
                return TestHelper.isElementPresent(currentpage,'timeSpanFooterInEditPage');
            },
            getDefaultValueOfTimeSpanFooterInEditPage: function(agr1) {
                return TestHelper.getText(currentpage,'timeSpanFooterInEditPageDefaultValue');
            },
            clickOnTimeSpanDropDownList: function() {
                return TestHelper.elementToBeClickable(currentpage,'clickedOnTimeSpanDropDownList');
            },
            selectItemFromTimeSpanInWCP: function(option1) {
                //WCP = Widget Configuration Page
                return element(by.cssContainingText('new-edit-widget select.date-range-dropdown option', option1));
            },
            checkTimeSpanFooterContainerInWidget: function() {
                return TestHelper.isElementPresent(currentpage,'timeSpanFooterContainerInWidget');
            },
            getDefaultValueInTimeSpanFooterContainerInWidget: function() {
                return TestHelper.getText(currentpage,'timeSpanFooterContainerInWidgetDefaultValue');
            },
            clickTimeSpanFooterInWidgetPage: function(option) {
                dem2[currentpage]["clickedOnTimeSpanFooterInWidgetPage"].locatorValue = option;
                return TestHelper.elementToBeClickable(currentpage,'clickedOnTimeSpanFooterInWidgetPage');
            },
            getDataOperationLabel: function() {
                return TestHelper.getText(currentpage,'dataOperationLabel');
            },
            getDataOperationDropDownValue: function(val) {
                //WCP = Widget Configuration Page
                dem2[currentpage]["dataOperationDropDownValue"].locatorValue = val;
                return TestHelper.isElementPresent(currentpage,'dataOperationDropDownValue');
            },
            getDefaultValueFromOperationDropDown: function() {
                dem2[currentpage]["dataOperationDropDownDefaultValue"].value.index = 3;
                return TestHelper.getText(currentpage,'dataOperationDropDownDefaultValue');
            },
            clickOnDataOperationDropDownList: function() {
                return TestHelper.elementToBeClickable(currentpage,'clickedOnDataOperationDropDown');
            },
            selectItemFromDataOperationInWCP: function(arg1) {
                //WCP = Widget Configuration Page
                var locValue = dem2[currentpage]["dataOperationDropDown"].value.locatorValue;
                return element(by.cssContainingText(locValue, arg1));
            },
            getTimeSeriesForXAxis: function(arg1) {
                dem2[currentpage]["xAxisTimeSpanSeries"].value.index = arg1;
                return TestHelper.getText(currentpage, 'xAxisTimeSpanSeries');
            },
            getTimeSeriesForXAxisInteractive: function(arg1) {
                dem2[currentpage]["xAxisTimeSpanSeriesInteractive"].value.index = arg1;
                return TestHelper.getText(currentpage, 'xAxisTimeSpanSeriesInteractive');
            }


        }
    };
    module.exports = new TimeSpanGraphWidget();
}())
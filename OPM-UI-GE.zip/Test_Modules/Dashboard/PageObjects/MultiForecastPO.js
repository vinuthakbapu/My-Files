/**
 * Created by 212677088 on 12/7/2017.
 */
(function () {
    'use strict';
    var currentpage = 'MultiForecast';
    var assetpage = 'AssetTagInfo';
    var dashboardpage = 'DashboardChanges';
    var EC_TIMEOUT = 9000;
    var EC=protractor.ExpectedConditions;

    var multiForecastPO = function () {
        return {
            selectDropdownbyNum: function ( element, optionNum ) {
                if (optionNum){
                    var options = element.all(by.tagName('option'))
                        .then(function(options){
                            options[optionNum].click();
                        });
                }
            },
            waitForElement: function(targetEle){
                browser.wait(EC.visibilityOf(targetEle), EC_TIMEOUT).then(function(){
                    browser.wait(EC.elementToBeClickable(targetEle), EC_TIMEOUT).then(function(){
                        callback();
                    });
                });
            },
            generateRandomNumber: function(){
                var deferred = protractor.promise.defer();
                protractor.promise.controlFlow().execute(function () {
                    deferred.fulfill(Math.floor(1000 + Math.random() * 9000))
                });
                return deferred;
            },

            clickPlusButton: function () {
                return TestHelper.elementToBeClickable(currentpage, 'plusIcon');
            },
            forecastTitleText: function () {
                return dem.findElement(currentpage, 'forecastTitle');
            },
            historicalTagText: function () {
                return dem.findElement(currentpage, 'historicalTagText');
            },
            selectTagDropDown: function () {
                return TestHelper.elementToBeClickable(currentpage, 'selectTag');
            },
            forecastTagText: function () {
                return dem.findElement(currentpage, 'forecastTagText');
            },
            targetText: function () {
                return dem.findElement(currentpage, 'targetText');
            },
            thresholdText: function () {
                return dem.findElement(currentpage, 'thresholdText');
            },
            expandIcon: function () {
                return TestHelper.elementToBeClickable(currentpage, 'expandIcon');
            },
            collapseIcon: function () {
                return TestHelper.elementToBeClickable(currentpage, 'collapseIcon');
            },
            deleteIcon: function () {
                return TestHelper.elementToBeClickable(currentpage, 'deleteIcon');
            },
            deleteOKButton: function () {
                return TestHelper.elementToBeClickable(currentpage, 'deleteOKButton');
            },
            getUrl: function (url) {
                return browser.driver.get(url);
                browser.waitForAngular();
            },
            getMultiForecastChart: function () {
                return TestHelper.elementToBeClickable(currentpage, 'multiForecastChart');
            },
            getPreviousDropdown: function () {
                return dem.findElement(currentpage, 'previousDropdown');
            },
            getNextDropdown: function () {
                return dem.findElement(currentpage, 'nextDropdown');
            },
            getWidgetSettings: function () {
                return dem.findElement(currentpage, 'widgetSettings');
            },
            getWidgetTitle: function () {
                return dem.findElement(currentpage, 'widgetTitle');
            },
            getWidgetTitleText: function () {
                return dem.findElement(currentpage, 'widgetTitleText');
            },
            getDateRange: function () {
                return dem.findElement(currentpage, 'dateRange');
            },
            getPreviousTextBox: function () {
                return dem.findElement(currentpage, 'previousTextBox');
            },
            getNextTextBox: function () {
                return dem.findElement(currentpage, 'nextTextBox');
            },
            getDefaultText: function () {
                return dem.findElement(currentpage, 'defaultText');
            },
            getTsChart: function () {
                return dem.findElement(currentpage, 'tsChart');
            },
            getHistoricalSelect: function () {
                return dem.findElement(currentpage, 'historicalSelect');
            },
            getForecastSelect: function () {
                return dem.findElement(currentpage, 'forecastSelect');
            },
            straightLine: function () {
                return dem.findElement(currentpage, 'straightLine');
            },
            dashLine: function () {
                return dem.findElement(currentpage, 'dashLine');
            },
            graphSmoothingTitle: function () {
                return dem.findElement(currentpage, 'graphSmoothingTitle');
            },
            normalizationTitle: function () {
                return dem.findElement(currentpage, 'normalizationTitle');
            },
            normalizationDropdown: function () {
                return dem.findElement(currentpage, 'normalizationDropdown');
            },
            systemOfMeasureText: function () {
                return dem.findElement(currentpage, 'systemOfMeasureText');
            },
            primarySelectDisabled: function () {
                return dem.findElement(currentpage, 'primarySelectDisabled');
            },
            secondarySelectDisabled: function () {
                return dem.findElement(currentpage, 'secondarySelectDisabled');
            },
            primarySelectEnabled: function () {
                return dem.findElement(currentpage, 'primarySelectEnabled');
            },
            secondarySelectEnabled: function () {
                return dem.findElement(currentpage, 'secondarySelectEnabled');
            },
            selectAxisDropdown: function () {
                return dem.findElement(currentpage, 'selectAxisDropdown');
            },
            primaryAxisUoMLegend: function () {
                return dem.findElement(currentpage, 'primaryAxisUoMLegend');
            },
            secondaryAxisUoMLegend: function () {
                return dem.findElement(currentpage, 'secondaryAxisUoMLegend');
            },

            //------------------------Dashboard changes-------------------------------------------------

            allDashboards: function () {
                return TestHelper.elementToBeClickable(dashboardpage, 'allDashboards');
            },
            nameFilter: function () {
                return dem.findElement(dashboardpage, 'nameFilter');
            },
            firstSearchResult: function () {
                return TestHelper.elementToBeClickable(dashboardpage, 'firstSearchResult');
            },
            createNewDashboard: function () {
                return TestHelper.elementToBeClickable(dashboardpage, 'createNewDashboard');
            },
            addTitle: function () {
                return dem.findElement(dashboardpage, 'addTitle');
            },
            dropdownChooseContext: function () {
                return TestHelper.elementToBeClickable(dashboardpage, 'dropdownChooseContext');
            },
            optionChooseContext: function () {
                return TestHelper.elementToBeClickable(dashboardpage, 'optionChooseContext');
            },
            customcardAdd: function () {
                return TestHelper.elementToBeClickable(dashboardpage, 'customcardAdd');
            },
            saveDashboard: function () {
                return TestHelper.elementToBeClickable(dashboardpage, 'saveDashboard');
            },
            dashboardEditContext: function () {
                return TestHelper.elementToBeClickable(dashboardpage, 'dashboardEditContext');
            },
            dashboardDelete: function () {
                return TestHelper.elementToBeClickable(dashboardpage, 'dashboardDelete');
            },
            deleteDashboardOkButton: function () {
                return TestHelper.elementToBeClickable(dashboardpage, 'deleteDashboardOkButton');
            },

        // ----------------------------Asset Details-------------------------------------------------------
            clickAssetMenu: function () {
                return TestHelper.elementToBeClickable(assetpage, 'assetTab');
            },
            assetInstanceHeader: function () {
                return dem.findElement(assetpage, 'assetInstanceHeader');
            },
            assetInstanceTagTab: function () {
                return TestHelper.elementToBeClickable(assetpage, 'assetInstanceTagTab');
            },
            addTags: function () {
                return TestHelper.elementToBeClickable(assetpage, 'addTags');
            },
            tagName: function () {
                return dem.findElement(assetpage, 'tagName');
            },
            sourceID: function () {
                return dem.findElement(assetpage, 'sourceID');
            },
            tagClassSelect: function () {
                return TestHelper.elementToBeClickable(assetpage, 'tagClassSelect');
            },
            tagDesc: function () {
                return dem.findElement(assetpage, 'tagDesc');
            },
            statusSelect: function () {
                return TestHelper.elementToBeClickable(assetpage, 'statusSelect');
            },
            createButton: function () {
                return TestHelper.elementToBeClickable(assetpage, 'createButton');
            },
            UoMText: function () {
                return TestHelper.elementToBeClickable(assetpage, 'UoMText');
            },
            UoMSettings: function () {
                return TestHelper.elementToBeClickable(assetpage, 'UoMSettings');
            },
            UoMDefinition: function () {
                return dem.findElement(assetpage, 'UoMDefinition');
            },
            saveUoMChange: function () {
                return TestHelper.elementToBeClickable(assetpage, 'saveUoMChange');
            },
            deleteTagIcon: function () {
                return TestHelper.elementToBeClickable(assetpage, 'deleteTagIcon');
            },
            deleteTagButton: function () {
                return TestHelper.elementToBeClickable(assetpage, 'deleteTagButton');
            },
            backTagButton: function () {
                return TestHelper.elementToBeClickable(assetpage, 'backTagButton');
            }
        }
    };
    module.exports = new multiForecastPO();
}());
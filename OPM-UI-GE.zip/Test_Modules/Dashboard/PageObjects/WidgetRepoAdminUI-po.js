
(function(){
    'use strict';
    var currentpage = 'DashboardAppPages';
    var WidgetRepoAdminPage = function() {
        return {
            getWidgetRepoAdminPageTitle: function() {
                return TestHelper.getText(currentpage,'WidgetRepoAdminPgTtl');
            },
            checkWidgetSearchInput: function() {
                return TestHelper.isElementVisible(currentpage,'WidgetSearchInput');
            },
            EnterWidgetSearchInput: function(searchval) {
                return TestHelper.sendKeys(currentpage, 'WidgetSearchInput', searchval);
            },
            checkWidgetSearchlinkIcon: function() {
                return TestHelper.isElementVisible(currentpage, 'WidgetSearchLinkIcon');
            },
            ClickkWidgetSearchlinkIcon: function() {
                return TestHelper.isElementVisible(currentpage, 'WidgetSearchLinkIcon');
            },
            checkWidgetUploadBtn: function() {
                return TestHelper.isElementVisible(currentpage, 'WidgetUploadNewBtn');
            },
            ClickWidgetUploadBtn: function() {
                return TestHelper.elementToBeClickable(currentpage, 'WidgetUploadNewBtn');
            },
            getWidgetUploadBtnTxt: function() {
                return TestHelper.getText(currentpage, 'WidgetUploadNewBtn');
            },
            getWidgetImageCount: function() {
                return dem.findElement(currentpage, 'WidgetImagesInWidgetRepoAdminUI').count();
            },
            getWidgetTitleCount: function() {
                return dem.findElement(currentpage, 'WidgetTitleInWidgetRepoAdminUI').count();
            },
            getWidgetsCount: function() {
                return dem.findElement(currentpage, 'WidgetsCount').count();
            },
            getWidgetsEditBtnCount: function() {
                return dem.findElement(currentpage, 'WidgetsEditBtnCount').count();
            },
            checkWidgetsEditBtnDisabled: function() {
                return dem.findElement(currentpage, 'WidgetsEditBtn').getAttribute('disabled');
            },
            getWidgetsFooterCount: function(text) {
                var myElements = element.all(by.xpath(" //div[@id='adminWidgetLibraryContainer']/descendant::div/descendant::span/descendant::div[@class='widget-footer style-scope show-widgets']/descendant::span[contains(text(),'" + text + "')] "));
                //return dem.findElement(myElement).count();
                return myElements.count();
            },
            clickWidgetUploadBtn: function() {
                return TestHelper.elementToBeClickable(currentpage, 'WidgetUploadNewBtn');
            },
            checkWidgetPopupWindow: function() {
                return TestHelper.isElementPresent(currentpage, 'WidgetPopupWindow');
            },
            checkWidgetPopupMetaDataTitle: function(labelTitle) {
                var myElement = element(by.xpath(" //form[@id='uploadWidgetsForm']/descendant::label[contains(text(),'" + labelTitle + "')] "));
                return TestHelper.isElementVisible(myElement);
            },
            checkWidgetPopupStarNextMetaDataTitle: function(labelTitle) {
                var myElement = element(by.xpath(" //form[@id='uploadWidgetsForm']/descendant::label[contains(text(),'" + labelTitle + "')]/descendant::span[contains(text(),'*')] "));
                return TestHelper.isElementVisible(myElement);
            },
            checkWidgetPopupFileMessage: function(message) {
                // var myElement = element(by.xpath(" //form[@id='uploadWidgetsForm']/descendant::label/following-sibling::label[contains(text(),'" + message + "')] "));
                // return TestHelper.isElementVisible(myElement);
                dem2[currentpage]["WidgetPopupFileMessage"].locatorValue = message;
                return TestHelper.isElementVisible(currentpage, 'WidgetPopupFileMessage');
            },
            checkWidgetPopupFileName: function(fileName, selection) {
                var myElement = element(by.xpath(" //form[@id='uploadWidgetsForm']/descendant::div/descendant::input[@id='" + selection + "FilePath'][@placeholder='" + fileName + "'] "));
                return TestHelper.isElementVisible(myElement);
            },
            checkWidgetPopupChooseFileButton: function(selection) {
                var myElement = element(by.xpath(" //form[@id='uploadWidgetsForm']/descendant::input[@id='" + selection + "FilePath']/following-sibling::label[contains(text(),'Choose File..')] "));
                return TestHelper.isElementVisible(myElement);
            },
            checkWidgetPopupTenantsLabel: function() {
                return TestHelper.isElementVisible(currentpage, 'WidgetPopupTenantsLabel');
            },
            checkWidgetPopupTenantsMessage: function(message) {
                dem2[currentpage]["WidgetPopupTenantsMessage"].locatorValue = message;
                return TestHelper.isElementVisible(currentpage, 'WidgetPopupTenantsMessage');
            },
            checkWidgetPopupTenantsInputField: function() {
                return TestHelper.isElementVisible(currentpage, 'WidgetPopupTenantsInputField');
            },
            checkWidgetPopupTenantsSaveBtn: function() {
                return TestHelper.isElementVisible(currentpage, 'WidgetPopupTenantsSaveBtn');
            },
            clickWidgetPopupTenantsSaveBtn: function() {
                return TestHelper.elementToBeClickable(currentpage, 'WidgetPopupTenantsSaveBtn');
            },
            checkWidgetPopupTenantsCancelBtn: function() {
                return TestHelper.isElementVisible(currentpage, 'WidgetPopupTenantsCancelBtn');
            },
            checkWidgetPopupTenantsSaveBtnDisabled: function() {
                return dem.findElement(currentpage, 'WidgetPopupTenantsSaveBtn').getAttribute('disabled');
            },
            selectWidgetPopupSelectionFile: function(fileName, selection) {
                var inputField = element(by.xpath(" //form[@id='uploadWidgetsForm']/descendant::div/descendant::input[@id='" + selection + "File'] "));

                var path = require('path');
                var filePath = '../WidgetFiles/' + fileName;
                var absolutePath = path.resolve(__dirname, filePath);

                fs.stat(absolutePath, function (err, stat) {
                    if (err == null) {
                        console.log("File exists");
                        inputField.sendKeys(absolutePath);
                    } else if (err.code == "ENOENT") {
                        console.error("File does not exist!");
                    } else {
                        console.log("Some other error: ", err.code);
                    }
                });

                console.log("File Uploaded");
                return TestHelper.isElementVisible(inputField);
            },
            selectWidgetPopupSelectionFileConfigWidget: function(fileName, selection) {
                var inputField = element(by.xpath(" //form[@id='editWidgetAdminForm']/descendant::label/descendant::input[@id='" + selection + "File'] "));

                var path = require('path');
                var filePath = '../WidgetFiles/' + fileName;
                var absolutePath = path.resolve(__dirname, filePath);

                fs.stat(absolutePath, function (err, stat) {
                    if (err == null) {
                        console.log("File exists");
                        inputField.sendKeys(absolutePath);
                    } else if (err.code == "ENOENT") {
                        console.error("File does not exist!");
                    } else {
                        console.log("Some other error: ", err.code);
                    }
                });

                console.log("File Uploaded");
                return TestHelper.isElementVisible(inputField);
            },
            clickWidgetEditBtn: function(widgetName) {
                var myElement = element(by.xpath(" //div[@id='adminWidgetLibraryContainer']/descendant::span[@class='float--left style-scope show-widgets'][contains(text(),'" + widgetName + "')]/following-sibling::div/descendant::button "));
                return TestHelper.elementToBeClickable(myElement);
            },
            checkConfigureWidgetPage: function() {
                return TestHelper.isElementPresent(currentpage, 'WidgetConfigurePage');
            },
            selectConfigureWidgetUploadNewWidget: function() {
                return TestHelper.isElementVisible(currentpage, 'ConfigureWidgetUploadNewWidget').then(function(present) {
                    if(present) {
                        TestHelper.elementToBeClickable(currentpage, 'ConfigureWidgetUploadNewWidget');
                    } else {
                        console.log("Checkbox is not present");
                        expect(1).to.equal(0);
                        callback();
                    }
                });
            },
            clickConfigureWidgetSaveBtn: function() {
                return TestHelper.elementToBeClickable(currentpage, 'ConfigureWidgetSaveBtn');
            },
            checkConfigureWidgetSaveBtn: function() {
                return TestHelper.isElementVisible(currentpage, 'ConfigureWidgetSaveBtn');
            },
            checkConfigureWidgetSaveBtnDisabled: function() {
                return dem.findElement(currentpage, 'ConfigureWidgetSaveBtn').getAttribute('disabled');
            },
            checkConfigureWidgetBackLink: function() {
                return TestHelper.isElementVisible(currentpage, 'ConfigureWidgetBackLink');
            },
            checkConfigureWidgetHeader: function(text) {
                dem2[currentpage]["ConfigureWidgetTitle"].locatorValue = text;
                return TestHelper.isElementVisible(currentpage, 'ConfigureWidgetTitle');
            },
            widgetConfigGetDescriptionTxt: function(text) {
                dem2[currentpage]["ConfigureWidgetTitle"].locatorValue = text;
                return TestHelper.isElementVisible(currentpage, 'ConfigureWidgetTitle');
            },
            checkConfigureWidgetFormLabel: function(text) {
                dem2[currentpage]["ConfigureWidgetFormLabel"].locatorValue = text;
                return TestHelper.isElementVisible(currentpage, 'ConfigureWidgetFormLabel');
            },
            checkConfigureWidgetFormLabelStar: function(labelTitle) {
                var myElement = element(by.xpath(" //form[@id='editWidgetAdminForm']/descendant::label[contains(text(),'" + labelTitle + "')]/descendant::span[contains(text(),'*')] "));
                return TestHelper.isElementVisible(myElement);
            },
            checkConfigureWidgetFormChooseFileBtn: function(selection) {
                var myElement = element(by.xpath(" //form[@id='editWidgetAdminForm']/descendant::input[@id='" + selection + "FilePath']/following-sibling::label[contains(text(),'Choose File..')] "));
                return TestHelper.isElementVisible(myElement);
            },
            checkConfigureWidgetFormFileName: function(fileName, selection) {
                var myElement = element(by.xpath(" //form[@id='editWidgetAdminForm']/descendant::div/descendant::input[@id='" + selection + "FilePath'][@placeholder='" + fileName + "'] "));
                return TestHelper.isElementVisible(myElement);
            },
            checkConfigureWidgetFormChooseFileBtnImg: function() {
                dem2[currentpage]["ConfigureWidgetFormLabel"].locatorValue = 'Choose File..';
                return TestHelper.isElementVisible(currentpage, 'ConfigureWidgetFormLabel');
            },
            checkConfigureWidgetFormImg: function() {
                return TestHelper.isElementVisible(currentpage, 'ConfigureWidgetFormImg');
            },
            checkConfigureWidgetAddTenantBtn: function() {
                return TestHelper.isElementVisible(currentpage, 'ConfigureWidgetAddTenantBtn');
            },
            clickConfigureWidgetAddTenantBtn: function() {
                return TestHelper.elementToBeClickable(currentpage, 'ConfigureWidgetAddTenantBtn');
            },
            checkConfigureWidgetPopupTenants: function() {
                return TestHelper.isElementPresent(currentpage, 'ConfigureWidgetPopupTenants');
            },
            checkConfigureWidgetPopupTenantsLabel: function() {
                return TestHelper.isElementVisible(currentpage, 'ConfigureWidgetPopupTenantsLabel');
            },
            checkConfigureWidgetPopupTenantsMessage: function(text) {
                dem2[currentpage]["ConfigureWidgetPopupTenantsMessage"].locatorValue = text;
                return TestHelper.isElementVisible(currentpage, 'ConfigureWidgetPopupTenantsMessage');
            },
            checkConfigureWidgetPopupInput: function() {
                return TestHelper.isElementVisible(currentpage, 'ConfigureWidgetPopupInput');
            },
            checkConfigureWidgetPopupSaveBtn: function() {
                return TestHelper.isElementVisible(currentpage, 'ConfigureWidgetPopupSaveBtn');
            },
            checkConfigureWidgetPopupCancelBtn: function() {
                return TestHelper.isElementVisible(currentpage, 'ConfigureWidgetPopupCancelBtn');
            },
            enterConfigureWidgetPopupTenandId: function(tenantId) {
                return TestHelper.sendKeys(currentpage, 'ConfigureWidgetPopupInput', tenantId);
            },
            clickConfigureWidgetPopupSaveBtn: function() {
                return TestHelper.elementToBeClickable(currentpage, 'ConfigureWidgetPopupSaveBtn');
            },
            checkConfigureWidgetPopupNoTenantId: function(text) {
                dem2[currentpage]["ConfigureWidgetPopupNoTenantId"].locatorValue = text;
                return TestHelper.isElementVisible(currentpage, 'ConfigureWidgetPopupNoTenantId');
            }






        }
    };
    module.exports = new WidgetRepoAdminPage();
}());
/* by 212340705  **/
// get function will return the element
// chk function will check to see whether element exists and return empty promise
// click function will click on the element and return empty promise

(function(){
    'use strict';
    var currentpage = 'DashboardAppPages';
    var createVuPage = null;
    var chart = require('proui-utils').HighChart;
    var section;
    var currentPage = "dashboardPage";

    createVuPage = function(){
        var self = this;
        return {
            clickCancelConfigureWidgetButton: function(){
                return TestHelper.elementToBeClickable(currentpage, 'CancelWidgetConfigurationButton');
            },
            getStreamingWidgetTitleElementFromConfigMenu: function(){
                return element(by.id('title'));
            },
            getStreamingWidgetTitle: function(){
                return element(by.css('#graph-widget-container > header > h3'));
            },
            chkStatusIcon: function(){
                return element(by.id('widget-status-indicator'));
            },
            chkTagClearIcon: function(){
                return element(by.css('#timeseries-tag-toolbox > div > div > div.tag-list-controls-container.style-scope.dashboard-tag-toolbox > div > span.x-icon.style-scope.dashboard-tag-toolbox > i'))
            },
            hoverStatusIcon: function(){
                return (element(by.id('widget-status-indicator')));
            },
            getThresholdValueElement: function(thresholdValue){
                return element(by.css('#widget-configuration > ul > li:nth-child(1) > ul > li.input-line.chart-container.clear-fix.style-scope.configure-streaming-widget > div > input'));
            },   
            getGraphElement: function(){
                return element(by.css('#layer1 > g path'));
            },
            getPxChartElement: function(){
                return element(by.id('apmChart'));
            },
            getEditWidgetSaveButton: function(){
                return element.all(by.id('edit-widget-header button')).get(1);
            },
            getViewSelectorDropdown: function(){
                return TestHelper.isElementVisible(currentpage, 'ViewSelectorDropdown');
            },
            getViewSelectorDropdown_chromeless: function(){
                return TestHelper.isElementVisible(currentpage, 'ViewSelectorDropdown_chromeless');
            },
            getAllDashboardInDeck: function(){
                return dem.findElement(currentpage, 'DashboardsInDeck');
            },
            getFirstDashboardInDeck: function(){
                // return dem.findElement(currentpage, 'FirstDashboardInDeck').getText();
                return TestHelper.getText(currentpage, "FirstDashboardInDeck");
            },
            getDashboardsCountInDeck: function(){
                return dem.findElement(currentpage, 'DashboardsInDeck').count();
            },
            getSelectedDashboardName: function() {
                // return dem.findElement(currentpage, 'selectedDashboard').getText();
                return TestHelper.getText(currentpage, "selectedDashboard");
            },
            getSelectedDashboardName_chromeless: function(){
                return TestHelper.getText(currentpage, "selectedDashboard_chromeless");
            },
            chkViewSelectorDropdown: function(){
                console.log('Check view selector dropdown is present using TestHelper isElementPresent');
                return browser.sleep(3000).then(function(){
                    return TestHelper.isElementVisible(currentpage, 'ViewSelectorDropdown');
                    // return dem.findElement(currentpage, 'ViewSelectorDropdown').isPresent();
                    // return TestHelper.isElementPresent(currentpage, 'ViewSelectorDropdown');
                });
            },
            ChkViewSelectorDropdownNotHidden: function(){
                return element(by.css('div.dropdown-text.deck-selector:not([hidden])')).isPresent();
                //return TestHelper.isElementPresent(currentpage, 'ViewSelectorDropdownNotHidden');
                //return dem.findElement(currentpage, 'ViewSelectorDropdown').isPresent();
            },
            chkViewSelectorDropdown_chromeless: function(){
                console.log('Check view selector dropdown is present using TestHelper isElementVisible');
                 return TestHelper.isElementVisible(currentpage, 'ViewSelectorDropdown_chromeless');
            },
            chkSetDefaultDashboardCheck: function(){
                return TestHelper.isElementPresent(currentpage, 'SetDefaultDashboardCheck');
            },

            chkSetDefaultDashboardNotCheck: function(){
                // return TestHelper.isElementNotPresent(currentpage,'SetDefaultDashboardCheck');
                return dem.findElement(currentpage, 'SetDefaultDashboardCheck').isDisplayed();
            },
            clickViewSelectorDropdown: function(){
                console.log("about to click deck Selector dropdown ");
                return TestHelper.elementToBeClickable(currentpage, 'ViewSelectorDropdown');
            },
            clickViewSelectorDropdown_chromeless: function(){
                return dem.findElement(currentpage, 'ViewSelectorDropdown_chromeless').click();
            },
            getAddDashboardLink: function(){
                //return TestHelper.isElementPresent(currentpage, 'AddDashboardLink').then(function(){
                    return dem.findElement(currentpage, 'ViewSelectorDropdown').isPresent();
                //});
            },
            getAddDashboardLink_chromeless: function(){
                return dem.findElement(currentpage, 'ViewSelectorDropdown_chromeless').isPresent();
            },
            clickAddDashboardLink: function(){
                console.log('inside clickAddDashboardLink function in add new dashboard po js');
                return TestHelper.elementToBeClickable(currentpage, 'AddDashboardLink');
                // return dem.findElement(currentpage, 'AddDashboardLink').click();
            },
            clickAddDashboardLink_chromeless: function(){
                return TestHelper.elementToBeClickable(currentpage, 'AddDashboardLink_chromeless');
            },
            getViewnameInputfield: function(){
                //return TestHelper.isElementPresent(currentpage, 'ViewnameInputfield');
                return dem.findElement(currentpage, 'ViewnameInputfield');
            },
            chkViewnameInputfield: function(){
                return TestHelper.isElementPresent(currentpage, 'ViewnameInputfield');
            },
            getSaveViewButton: function(){
                return TestHelper.isElementPresent(currentpage, 'SaveViewButton');
            },
            chkSaveViewButton: function(){
                return TestHelper.isElementPresent(currentpage, 'SaveViewButton');
            },
            clickSaveViewButton: function(){
                return TestHelper.elementToBeClickable(currentpage, 'SaveViewButton');
            },
            getDoneButton: function(){
                return dem.findElement(currentpage, 'DoneButton');
            },
            chkDoneButton: function(){
                return TestHelper.isElementPresent(currentpage, 'DoneButton');
            },
            clickDoneButton: function(){
                return TestHelper.elementToBeClickable(currentpage, 'DoneButton');
            },
            getCancelViewButton: function(){
                return dem.findElement(currentpage, 'CancelViewButton');
            },
            chkCancelViewButton: function(){
                return TestHelper.isElementPresent(currentpage, 'CancelViewButton');
            },
            clickCancelViewButton: function(){
                return TestHelper.elementToBeClickable(currentpage, 'CancelViewButton');
            },
            getCardActionMenuBtn: function(){
                return dem.findElement(currentpage, 'CardActionMenuBtn');
            },
            chkCardActionMenuBtn: function(){
              //  return dem.findElement(currentpage, 'CardActionMenuBtn').click();
                return TestHelper.isElementPresent(currentpage, 'CardActionMenuBtn');
            },
            clickCardActionMenuBtn: function(){
                return TestHelper.elementToBeClickable(currentpage, 'CardActionMenuBtn');
            },
            getDashboardTab: function(){
                return TestHelper.isElementPresent("landingPage", 'dashboardTab');
            },
            clickDashboardTab: function(){
                return TestHelper.elementToBeClickable("landingPage", 'dashboardTab');
            },
            getContextColumnBrowser: function(){
                return TestHelper.isElementPresent("dashboardPage", 'columnBrowser');
            },
            clickOpenButton: function(num){
                dem2["dashboardPage"]["openbuttons2"].value.index=num;
                return TestHelper.elementToBeClickable("dashboardPage","openbuttons2");
            },
            chkView: function(viewname){
                console.log('inside chkView');
                dem2[currentpage]["View"].locatorValue=viewname;
                // return TestHelper.isElementPresent(currentpage, 'View');
                return TestHelper.isElementVisible(currentpage, 'View').then(function(bool){
                console.log("visible boolean: "+ bool);
                //return element(by.cssContainingText('ul#dropdown li div',viewname)).isPresent();
                // return TestHelperPO.isElementPresent(element(by.cssContainingText('ul#dropdown li div',viewname)));
                    return TestHelper.isElementVisible(currentpage, 'View')
                })

            },
            getView: function(viewname){
                dem2[currentpage]["View"].locatorValue=viewname;
                //return TestHelper.isElementPresent(currentpage, 'View');
                return dem.findElement(currentpage, 'View');
            },
            checkView: function(viewname){
                dem2[currentpage]["View"].locatorValue=viewname;
                return TestHelper.isElementPresent(currentpage, 'View');
            },
            clickView: function(viewname){
                dem2[currentpage]["View"].locatorValue = viewname;
                return TestHelper.elementToBeClickable(currentpage, 'View');
            },
            clickView_chromeless: function(viewname){
                dem2[currentpage]["View_chromeless"].locatorValue = viewname;
                return TestHelper.elementToBeClickable(currentpage, 'View_chromeless');
            },
            clickAssetInContextBrowser: function(asset){
                dem2["dashboardPage"]["contextItem"].locatorValue=asset;
                return TestHelper.elementToBeClickable("dashboardPage", "contextItem");
            },
            clickAssetBrowser: function(){
                return TestHelper.elementToBeClickable("dashboardPage", "contextbrowser");
            },
            chkEmptyDashboardContainer: function(){
                //return element(by.css('#empty-dashboard-container'));
                return TestHelper.isElementPresent(currentpage, 'EmptyDashboardContainer');
            },
            chkDeleteSpinner: function(){
                return TestHelper.isElementPresent(currentpage, 'DeleteSpinner');
            },
            chkDeleteSpinnerHidden: function(){
                return TestHelper.isElementPresent(currentpage, 'DeleteSpinnerHidden');
            },
            getEmptyDashboardContainer: function(){
                return TestHelper.isElementPresent(currentpage, 'EmptyDashboardContainer');
               //return dem.findElement(currentpage, 'EmptyDashboardContainer').isPresent();
            },
            getEmptyDashboardButton: function(){
                // return TestHelper.isElementPresent(currentpage, 'EmptyDashboardButton');
                return TestHelper.isElementVisible(currentpage, 'EmptyDashboardButton');
            },
            clickEmptyDashboardButton: function(){
                //return element(by.css('#empty-dashboard-container > button'));
                return TestHelper.elementToBeClickable(currentpage, 'EmptyDashboardButton');
            },
            chkLoginAvtar: function(){
                return TestHelper.isElementPresent(currentpage, 'LoginAvtar');
            },
            clickLoginAvtar: function(){
                return TestHelper.elementToBeClickable(currentpage, 'LoginAvtar');
            },
            chkLoginAvtarPopupVisible: function(){
                return TestHelper.isElementPresent(currentpage, 'LoginAvtarPopup');
            },
            chkSignOutLink: function(){
                return TestHelper.isElementPresent(currentpage, 'SignOutLink');
            },
            clickSignOutLink: function(){
                return TestHelper.elementToBeClickable(currentpage, 'SignOutLink');
            },
            createView: function(VuName){
                var self = this;
                return protractor.promise.all([
                        this.getViewSelectorDropdown().click(),
                        this.getAddDashboardLink().click(),
                        this.getViewnameInputfield().clear(),
                        this.getViewnameInputfield().sendKeys(VuName)]
                    ,25000).then(function () {
                        self.getSaveViewButton().click();
                        browser.sleep(5000);
                        self.getDoneButton().click();
                    });
            },
            createView_V2: function(VuName) {
                var self = this;
                console.log('createView_V2: about to create a view: ', VuName);
                return this.chkViewSelectorDropdown().then(function (present) {
                    if (present) {
                        console.log('deckselector present');
                        self.clickViewSelectorDropdown().then(function () {
                            dem.findElement(currentpage, 'dropdown').getAttribute('hidden').then(function(present2){
                                if(present2){
                                    console.log('deck selector dropdown is hidden so click on the dropdown once again');
                                    self.clickViewSelectorDropdown().then(function () {
                                        TestHelper.scrollIntoView(currentpage,'AddDashboardLink').then(function() {
                                            self.clickAddDashboardLink().then(function () {
                                                self.getViewnameInputfield().sendKeys(VuName);
                                                self.clickSaveViewButton().then(function () {
                                                    self.clickDoneButton().then(function () {});
                                                });
                                            });
                                        });
                                    });
                                }else {
                                    console.log('deckselector is open and visible');
                                    TestHelper.scrollIntoView(currentpage, 'AddDashboardLink').then(function () {
                                        self.clickAddDashboardLink().then(function () {
                                            self.getViewnameInputfield().sendKeys(VuName);
                                            self.clickSaveViewButton().then(function () {
                                                self.clickDoneButton().then(function () {
                                                })
                                            })
                                        });
                                    });
                                }

                            });

                        })
                    } else {
                        console.log('empty dashboard container');
                        self.clickEmptyDashboardButton().then(function () {
                            self.getViewnameInputfield().sendKeys(VuName);
                            self.clickSaveViewButton().then(function () {
                                self.clickDoneButton().then(function () {
                                })
                            })
                        });
                    }
                });
            },
            createDashboardWithSummaryOn: function(VuName) {
                var self = this;
                console.log('Into createDashboardWithSummaryOn: ', VuName);
                return this.getViewSelectorDropdown().then(function (present) {
                    if (present) {
                        console.log('deckselector present');
                        self.clickViewSelectorDropdown().then(function () {
                            dem.findElement(currentpage, 'dropdown').getAttribute('hidden').then(function(present2){
                                if(present2){
                                    console.log('deck selector dropdown is hidden so click on the dropdown once again');
                                    self.clickViewSelectorDropdown().then(function () {
                                        TestHelper.scrollIntoView(currentpage,'AddDashboardLink').then(function() {
                                            self.clickAddDashboardLink().then(function () {
                                                self.getViewnameInputfield().sendKeys(VuName);
                                                dashboardSummaryPage.clickDashboardSummaryToggle();
                                                self.clickSaveViewButton().then(function () {
                                                    self.clickDoneButton().then(function () {});
                                                });
                                            });
                                        });
                                    });
                                }else {
                                    TestHelper.scrollIntoView(currentpage, 'AddDashboardLink').then(function () {
                                        self.clickAddDashboardLink().then(function () {
                                            self.getViewnameInputfield().sendKeys(VuName);
                                            dashboardSummaryPage.clickDashboardSummaryToggle();
                                            self.clickSaveViewButton().then(function () {
                                                self.clickDoneButton().then(function () {});
                                            });
                                        });
                                    });
                                }
                            });
                        })
                    } else {
                        console.log('from empty dashboard container');
                        self.clickEmptyDashboardButton().then(function () {
                            self.getViewnameInputfield().sendKeys(VuName);
                            dashboardSummaryPage.clickDashboardSummaryToggle();
                            self.clickSaveViewButton().then(function () {
                                self.clickDoneButton().then(function () {});
                            });
                        });
                    }
                });
            },
            chkDeleteDashboardLink: function(){
                return element(by.css('#viewMenuList #deleteView')).isPresent();
                // return TestHelper.isElementVisible(currentpage, "DeleteDashboardLink");
            },
            chkDeleteDashboardLinkDisabled: function(){
                return TestHelper.isElementPresent(currentpage, "DeleteDashboardLinkDisabled");
            },
            getDeleteViewLink: function(){
                dem2[currentpage]["DeleteViewLink"].locatorValue='Delete Dashboard';
                return dem.findElement(currentpage, "DeleteViewLink");
            },
            clickDeleteViewLink: function(){
                dem2[currentpage]["DeleteViewLink"].locatorValue='Delete Dashboard';
                return TestHelper.elementToBeClickable(currentpage, "DeleteViewLink");
            },
            getDeleteViewConfirmPopup: function(){
                //return element(by.css('section.modal__content.px-modal'));
                return element(by.css('view-menu px-modal section'));
            },
            getDeleteViewConfirmMessage: function(){
                //return element(by.css('section.modal__content.px-modal >p')).getText();
                return element(by.css('view-menu px-modal p')).getText();
            },
            getDeleteViewConfirmOKBtn: function(){
                //return element(by.id('OK'));
                return element(by.css('view-menu px-modal button#btnModalPositive'));
            },
            clickDeleteViewConfirmOKBtn: function(){
                //return element(by.id('OK'));
                //return element(by.css('view-menu px-modal button#OK')).click();
                return TestHelper.elementToBeClickable(currentpage, "DeleteViewConfirmOKBtn");

            },
            chkDeleteViewConfirmPopup: function(){
                //return element(by.id('OK'));
                //return element(by.css('view-menu px-modal button#OK'));
                return TestHelper.isElementPresent(currentpage, "DeleteViewConfirmPopup");
            },
            clickDeleteViewConfirmCancelBtn: function(){
                //return element(by.id('Cancel'));
                //return element(by.css('view-menu px-modal button#Cancel'));
                return TestHelper.elementToBeClickable(currentpage, "DeleteViewConfirmCancelBtn")
            },
            getDeleteViewConfirmCancelBtn: function(){
                //return element(by.id('Cancel'));
                //return element(by.css('view-menu px-modal button#Cancel'));
                return TestHelper.isElementPresent(currentpage, "DeleteViewConfirmCancelBtn")
            },
            deleteView: function(VuName){
                var self = this;
                return protractor.promise.all([
                    this.getViewSelectorDropdown().click(),
                    this.getView(VuName).click(),
                    this.getCardActionMenuBtn().click(),
                    this.getDeleteViewLink().click(),
                    this.getDeleteViewConfirmOKBtn().click()],25000).then(function(){
                    console.log('deleted view: ' + VuName);
                });
            },
            createDashboardAnd6upCard: function(VuName){
                var self = this;
                return protractor.promise.all([
                        this.getViewSelectorDropdown().click(),
                        this.getAddDashboardLink().click(),
                        this.getViewnameInputfield().clear(),
                        this.getViewnameInputfield().sendKeys(VuName),
                        addcardpage.get6upAddBtn().click()]
                    ,25000).then(function () {
                        self.getSaveViewButton().click();
                        browser.sleep(5000);
                        self.getDoneButton().click();
                    });
            },
            createDashboardAndCard: function(VuName, Type){
                var self = this;
                return this.getViewSelectorDropdown().then(function (present) {
                    if (present) {
                        console.log('deckselector present');
                        self.clickViewSelectorDropdown().then(function () {
                            dem.findElement(currentpage, 'dropdown').getAttribute('hidden').then(function(present2){
                                if(present2){
                                    console.log('deck selector dropdown is hidden so click on the dropdown once again');
                                    self.clickViewSelectorDropdown().then(function () {
                                        TestHelper.scrollIntoView(currentpage,'AddDashboardLink').then(function() {
                                            self.clickAddDashboardLink().then(function () {
                                                browser.sleep(2000).then(function() {
                                                    self.createDashboard(VuName, Type);
                                                })
                                            });
                                        });
                                    });
                                }else {
                                    TestHelper.scrollIntoView(currentpage, 'AddDashboardLink').then(function () {
                                        self.clickAddDashboardLink().then(function () {
                                            self.createDashboard(VuName, Type);
                                        });
                                    });
                                }
                            });
                        })
                    } else {
                        console.log('empty dashboard container');
                        self.clickEmptyDashboardButton().then(function () {
                            self.createDashboard(VuName, Type);
                        });
                    }
                });
            },
            checkClassSelectionChevron: function(){
                return element(by.css('i.fa.fa-chevron-down.add-deck')).isPresent();
                // return dem.findElement(currentpage, 'SelectClassificationChevron').isPresent();
                // return TestHelper.isElementPresent(currentpage, "SelectClassificationChevron");
            },
            clickClassSelectionChevron: function(){
                return TestHelper.elementToBeClickable(currentpage, "SelectClassificationChevron");
            },
            getClassificationDropdown: function(){
                return TestHelper.isElementPresent(currentpage,"ClassificationDropdown");
            },
            getNameFromClassmenu: function(type){
                if(type.indexOf('instance') !== -1 ){
                    return TestHelper.getText(currentpage, "ClassificationInstance");
                }else{
                    return TestHelper.getText(currentpage, "ClassificationClass");
                }
            },
            selectClassificationName: function(){
                //return TestHelper.elementToBeClickable(currentpage, "ClassificationClass");
                return dem.findElement(currentpage, 'ClassificationClass').click();
            },
            getSelectedClassificationValue: function(){
                return TestHelper.getText(currentpage, "SelectedClassificationValue");
            },
            performSaveviewAndDone: function () {
                addcardpage.getToastAlertCloseIcon().then(function(present){
                    console.log('alert message is present');
                    if(present){
                        addcardpage.clickToastAlertCloseIcon().then(function(){
                            console.log('clicked on close alert icon');
                        });
                    }else{
                        console.log('alert message is not present');
                    }
                });
            },
            createDashboard: function(VuName, type){
                var self = this;
                return self.getViewnameInputfield().sendKeys(VuName).then(function(){
                    browser.sleep(2000).then(function(){
                        customcardpage.clickAddCardButtonInCardLibrary(type).then(function () {
                            self.clickSaveViewButton().then(function () {
                                console.log('clicked on save view button');
                                self.clickDoneButton().then(function () {
                                    console.log('clicked on Done button');
                                })
                            });
                        });
                    });
                });
            },
            createClassDashboard: function(VuName){
                var self = this;
                console.log('In function createClassDashboard');
                return self.getViewnameInputfield().sendKeys(VuName).then(function(){
                    self.clickClassSelectionChevron().then(function () {
                        console.log('About to select class');
                        self.selectClassificationName().then(function () {
                            customcardpage.clickCustomcardAddBtn().then(function () {
                                self.clickSaveViewButton().then(function () {
                                    self.clickDoneButton().then(function () {
                                    })
                                })
                            });
                        });
                    });
                });
            },
            createClassDashboardWithCard: function(VuName){
                var self = this;
                return this.getViewSelectorDropdown().then(function (present) {
                    if (present) {
                        console.log('deckselector present');
                        self.clickViewSelectorDropdown().then(function () {
                            dem.findElement(currentpage, 'dropdown').getAttribute('hidden').then(function(present2){
                                if(present2){
                                    console.log('deck selector dropdown is hidden so click on the dropdown once again');
                                    self.clickViewSelectorDropdown().then(function () {
                                        TestHelper.scrollIntoView(currentpage,'AddDashboardLink').then(function() {
                                            self.clickAddDashboardLink().then(function () {
                                                self.createClassDashboard(VuName);
                                            });
                                        });
                                    });
                                }else {
                                    console.log('deck selector dropdown is visible');
                                    TestHelper.scrollIntoView(currentpage, 'AddDashboardLink').then(function () {
                                        self.clickAddDashboardLink().then(function () {
                                            self.createClassDashboard(VuName);
                                        });
                                    });
                                }
                            });

                        })
                    } else {
                        console.log('empty dashboard container');
                        self.clickEmptyDashboardButton().then(function () {
                            self.createClassDashboard(VuName);
                        });
                    }
                });
            },
            selectViewFromDeckSelector: function(arg1){
                var self = this;
                return createviewpage.getViewSelectorDropdown().then(function (present) {
                    if (present) {
                        dem.findElement(currentpage, 'dropdown').getAttribute('hidden').then(function(visible){
                            if(visible){
                                console.log('deck selector dropdown is hidden so click on the dropdown');
                                createviewpage.clickViewSelectorDropdown().then(function () {
                                    self.selectView(arg1);
                                });
                            }else {
                                console.log('deck selector dropdown is already visible');
                                self.selectView(arg1);
                            }
                        });
                    }
                });
            },
            selectView: function (arg1) {
               return createviewpage.clickView(arg1).then(function () {
                    console.log('clicked on view name: ' + arg1);
                    console.log('Verify the selected view name is :' + arg1);
                    createviewpage.getSelectedDashboardName().then(function (txt) {
                        expect(txt).to.equal(arg1);
                        console.log('expected view name: ' + arg1 + ' Actual view name: ' + txt);

                    });
                });
            },
            deleteDeck: function(i) {
                return createviewpage.clickCardActionMenuBtn().then(function () {
                    console.log('clicked on CardActionMenu button');
                    console.log('About delete view number : ' + i);
                    browser.sleep(5000).then(function(){
                        createviewpage.clickDeleteViewLink().then(function () {
                            console.log('clicked on delete view link');
                            browser.sleep(2000).then(function(){
                                createviewpage.getDeleteViewConfirmOKBtn().click().then(function () {
                                    console.log('confirmed and deleted view number: ' + i);
                                });
                            })
                        });
                    })

                });
            },

            setChart: function () {
                console.log("Before")
                section = cem.findElement(currentPage, 'graphWidgetContainer');
                console.log("After getting section")
                chart.setChartElements(section);
            },


            getChartFile: function(a, b, c, d, e,f){
                this.setChart();
                browser.sleep(5000);
                return chart.getApmChartData(a, b, c, d, e,f)
            },
            chkEditnameInputfield: function(){
               // return TestHelper.isElementPresent(currentpage, 'EditnameInputfield'); //T/F
                return dem.findElement(currentpage, 'EditnameInputfield');
            },
            getEditnameInputfieldByTitle: function () {
                return dem.findElement(currentpage, 'EditnameInputfieldByIndex').getAttribute('title');
            },
            getEditnameInputfield: function () {
//                return element.all(by.css('section.modal__content.px-modal >#deleteMsg')).getText();
                return TestHelper.isElementPresent(currentpage, "EditnameInputfield").getAttribute('value');
            //    return dem.findElement(currentpage, 'EditnameInputfield').getText();
            },
            chkEditDashboardLink: function(){
                return element(by.css('#viewMenuList #editDashboard')).isPresent();
                //return TestHelper.isElementVisible(currentpage, "EditDashboardLink");
            },

            clickEditDashboardLink: function(){
                // dem2[currentpage]["EditDashboardLink"].locatorValue='Edit Dashboard';
                // return TestHelper.elementToBeClickable(currentpage, "EditDashboardLink");
                return TestHelper.elementToBeClickable(currentpage, "EditDashboardLink");
            },
            chkEditDashboardLinkDisabled: function(){
                return TestHelper.isElementPresent(currentpage, "EditDashboardLinkDisabled");
            },

            chkSaveEditDashboardButton: function(){
            return TestHelper.isElementPresent(currentpage, 'saveEditDashboardButton');
            },

            clickSaveEditDashboardButton: function(){
            return TestHelper.elementToBeClickable(currentpage, 'saveEditDashboardButton');
            },

            chkCancelEditDashboardButton: function(){
                return TestHelper.isElementPresent(currentpage, 'cancelEditDashboardButton');
            },

            clickCancelEditDashboardButton: function(){
                return TestHelper.elementToBeClickable(currentpage, 'cancelEditDashboardButton');
            },
            clickDoneEditDashboardButton: function(){
                return TestHelper.elementToBeClickable(currentpage, 'doneEditDashboardButton');
            },
            chkAvailableForLabel:function(){
                 return TestHelper.isElementPresent(currentpage,'availableForLabel');
            },
            chkDisabledAvailableToField:function(){
                return TestHelper.isElementPresent(currentpage,'DisabledAvailableToField');
            },
            chkAvailableForDefault:function(){
                return TestHelper.isElementPresent(currentpage,'availableForDefaultRole');
            },
            getTextAvailableFor:function(){
                return TestHelper.getText(currentpage,'availableForDefaultRole');
            },
            chkAvailableForChevron:function(){
                return TestHelper.isElementPresent(currentpage,'availableForChevron');
            },
            clickAvailableForChevron:function(){
                return TestHelper.elementToBeClickable(currentpage,'availableForChevron');
            },
            chkAvailableForList:function(){
                return TestHelper.isElementPresent(currentpage,'availableForSelectList');
            },
            chkAvailableForPublic:function(){
                return TestHelper.isElementPresent(currentpage,'availableForPublic');
            },
            chkAvailableForPrivate:function(){
                return TestHelper.isElementPresent(currentpage,'availableForPrivate');
            },
            clickAvailableForPrivate:function(){
                return TestHelper.elementToBeClickable(currentpage,'availableForPrivate');
            },
            clickAvailableForPublic:function(){
                return TestHelper.elementToBeClickable(currentpage,'availableForPublic');
            },
            chkAvailableForUserGroups:function(){
                return TestHelper.isElementPresent(currentpage,'availableForUserGroups');
            },
            clickAvailableForUserGroups:function(){
                return TestHelper.elementToBeClickable(currentpage,'availableForUserGroups');
            },
            chkEditUserGroupsBtn:function(){
                return TestHelper.isElementPresent(currentpage,'EditUserGroupsButton');
            },
            clickEditUserGroupsBtn:function(){
                return TestHelper.elementToBeClickable(currentpage,'EditUserGroupsButton');
            },
            //CURC - Confirm User Roles Change modal popup
            clickApplyBtnInCURC:function(){
                return TestHelper.elementToBeClickable(currentpage,'CURCapplyBtn');
            },
            chkApplyBtnInCURC:function(){
                return TestHelper.isElementPresent(currentpage,'CURCapplyBtn');
            },
            clickCancelBtnInCURC:function(){
                return TestHelper.elementToBeClickable(currentpage,'CURCcancelBtn');
            },
            chkCancelBtnInCURC:function(){
                return TestHelper.isElementPresent(currentpage,'CURCcancelBtn');
            },
            chkCURCpopupModal:function(){
                return TestHelper.isElementPresent(currentpage,'CURCpopup');
            },
            getCURCtitleText:function(){
                return TestHelper.getText(currentpage,'CURCtitle');
            },
            getCURCmessageText:function(){
                return TestHelper.getText(currentpage,'CURCmessage');
            },
            chkUserGroupPopup:function(){
                return TestHelper.isElementPresent(currentpage,'UserGroupsPopup');
            },
            getUserGroupPopupTitleTxt:function(){
                return TestHelper.getText(currentpage,'UserGroupsPopupTtl');
            },
            clickUserGroupApplyBtn:function(){
                return TestHelper.elementToBeClickable(currentpage,'UserGroupsPopupApplyBtn');
            },
            clickUserGroupCancelBtn:function(){
                return TestHelper.elementToBeClickable(currentpage,'UserGroupsPopupCancelBtn');
            },
            chkUserGroupApplyBtn:function(){
                return TestHelper.isElementPresent(currentpage,'UserGroupsPopupApplyBtn');
            },
            chkUserGroupCancelBtn:function(){
                return TestHelper.isElementPresent(currentpage,'UserGroupsPopupCancelBtn');
            },
            getUserGroupsCountFrmPopup:function(){
                return element.all(by.css('#userGroupsModal section div.modal-items')).count();
            },
            getFirstUserGroupNameUGModal:function(){
                return element.all(by.css('#userGroupsModal section div.modal-items >label')).get(0).getText();
            },
            clickUserGroupLabelInUGmodal:function(text){
                return element(by.cssContainingText('#userGroupsModal section div.modal-items >label',text)).click();
            },
            checkUserGroupSelected:function(text){
                return element(by.cssContainingText('#userGroupsModal section div.modal-items input[type=checkbox]:checked +label',text));
            },
            getUserGroupLabelsCount:function(){
                return dem.findElement(currentpage, 'UserGroupLabels').count();
            },
            chkUserGroupEditButton:function(){
                return TestHelper.isElementPresent(currentpage,'EditUserGroupsButton');
            },
            clickUserGroupEditButton:function(){
                return TestHelper.elementToBeClickable(currentpage,'EditUserGroupsButton');
            },
            getCheckedUserGroupsCountInPopup:function(){
                return element.all(by.css('#userGroupsModal section div.modal-items input[type=checkbox]:checked')).count();
            },
            getFirstCheckedUserGroupName:function(num){
                dem2[currentpage]["UserGroupInpuCheckbox"].value.index=num;
                return  TestHelper.getText(currentpage,"CheckedCheckboxesInUserGroup");

            },
            getChkBxStateFromUGModal:function(num){
                return  element.all(by.css('#userGroupsModal section div.modal-items input')).get(num).isSelected();
            },
            getChkBxStateFromUGModal2:function(num){
                dem2[currentpage]["UserGroupInpuCheckbox"].value.index=num;
                return dem.findElement(currentpage,"UserGroupInpuCheckbox").checked;
            },
            getNameFromUGModal:function(num){
                dem2[currentpage]["UserGroupChkBxLabel"].value.index=num;
                return TestHelper.getText(currentpage,"UserGroupChkBxLabel");
            },
            getCheckedUserGroupChkBxLabel:function(num){
                dem2[currentpage]["UserGroupChkBxLabel"].value.index=num;
                return TestHelper.getText(currentpage,"UserGroupChkBxLabel");
            },
            CheckAuditLogsMicroApp: function(){
                return TestHelper.isElementVisible(currentpage, 'AuditLogMicroApp');
            },
            ClickAuditLogsMicroApp: function(){
                return TestHelper.elementToBeClickable(currentpage, 'AuditLogMicroApp');
            },
            CheckAuditLogsPage: function(){
                return TestHelper.isElementVisible(currentpage, 'AuditLogsPageTitle');
            },
            CheckAuditLogSelectionMenu: function(){
                return TestHelper.isElementVisible(currentpage, 'AuditLogSelectionMenu');
            },
            ClickAuditLogSelectionMenu: function(){
                return TestHelper.elementToBeClickable(currentpage, 'AuditLogSelectionMenu');
            },
            CheckAuditLogApp:function(appname){
                dem2[currentpage]["selectAuditLogApp"].locatorValue=appname;
                return TestHelper.isElementVisible(currentpage, "selectAuditLogApp");
            },
            selectAuditLogApp:function(appname){
                dem2[currentpage]["selectAuditLogApp"].locatorValue=appname;
                return TestHelper.elementToBeClickable(currentpage, "selectAuditLogApp");
            },
            CheckAuditLogCalendarObj: function(){
                return TestHelper.isElementVisible(currentpage, 'AuditLogSelectDate');
            },
            CheckAuditLogGrid: function(){
                return TestHelper.isElementVisible(currentpage, 'AuditLogGrid');
            },
            ClickAuditLogCalendarObj: function(){
                return TestHelper.elementToBeClickable(currentpage, 'AuditLogSelectDate');
            },
            clickAuditLogSelectDateApplyBtn:function(){
                return TestHelper.elementToBeClickable(currentpage, 'AuditLogSelectDateApplyBtn');
            },
            selectAuditLogDate:function(date){
                return TestHelper.elementToBeClickable(currentpage, 'AuditLogSelectDateIcon').then(function () {
                    TestHelper.elementToBeClickable(currentpage, 'AuditLogSelectDateField').then(function () {
                        dem2[currentpage]['AuditLogSelectDateField'].value.index = 0;
                          TestHelper.sendKeys(currentpage, 'AuditLogSelectDateField', date.split('/')[0]).then(function () {
                            dem2[currentpage]['AuditLogSelectDateField'].value.index = 1;
                            TestHelper.sendKeys(currentpage, 'AuditLogSelectDateField', date.split('/')[1]).then(function () {
                                dem2[currentpage]['AuditLogSelectDateField'].value.index = 2;
                                TestHelper.sendKeys(currentpage, 'AuditLogSelectDateField', date.split('/')[2]).then(function () {
                                    console.log('Entered desired Date ' + date);
                                });
                            });
                        });
                    });
                });
            },
            CheckAuditLogColumn:function(num) {
                dem2[currentpage]["AuditLogColumn"].value.index = num;
                return TestHelper.getText(currentpage, "AuditLogColumn");
            },
            CheckAuditLogColumnData:function(num) {
                dem2[currentpage]["AuditLogColumnData"].value.index = num;
                return TestHelper.getText(currentpage, "AuditLogColumnData");
            },
            CheckAuditLogSerchField:function(num) {
                dem2[currentpage]["AuditLogSearchField"].value.index = num;
                return TestHelper.isElementVisible(currentpage, 'AuditLogSearchField');
            },
            EnterAuditLogSerchField:function(fieldName) {
                return TestHelper.sendKeys(currentpage, 'AuditLogSearchField', fieldName);
            },
            getAuditLogSerchField:function() {
                return dem.findElement(currentpage, 'AuditLogSearchField');
            },
            getNumAuditLogRows:function() {
                return dem.findElement(currentpage, 'NumAuditLogRows').count();
            }


        }
    };
    module.exports = new createVuPage();
}());

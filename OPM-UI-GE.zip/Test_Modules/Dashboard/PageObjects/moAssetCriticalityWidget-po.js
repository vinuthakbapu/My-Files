/* created by 212329933 on Oct 10th 2016 */
(function () {
	'use strict';

	//var EC = protractor.ExpectedConditions;
	var data = require('../TestData/mo-dashboard-test-data.json').data[browser.params.environment];

	var maintenanceOptimizationPage = function () {
		return {
			findElement: function (element) {
				return dem.findElement('moAssetCriticalityWidget', element);
			},

			getAssetCriticalityWidgetTitle: function () {
				return this.findElement('assetCriticalityWidgetTitle').getText();
			},

			getMeridiumOverviewLinkText: function() {
				return this.findElement('meridiumOverviewLink').element(by.css('a')).getText();
			},

			getMeridiumOverviewLinkRedirectUrl: function() {
				return this.findElement('meridiumOverviewLink').element(by.css('form')).getAttribute('action');
			},

			getMeridiumOverviewLinkFormTarget: function() {
				return this.findElement('meridiumOverviewLink').element(by.css('form')).getAttribute('target');
			},

			getMeridiumOverviewLinkSubmit: function () {
				return this.findElement('meridiumOverviewLink').element(by.css('form input:nth-child(2)')).getAttribute('type');
			},

			getCriticalityLabel: function () {
				return this.findElement('criticalityLabel').getText();
			},

			getCriticalityContainer: function () {
				return this.findElement('criticalityContainer');
			},

			getCriticalityLinkText: function () {
				return this.getCriticalityContainer().element(by.css('a')).getText();
			},

			getCriticalityLinkForm: function () {
				return this.findElement('criticalityContainer').element(by.css('form'));
			},

			getCriticalityLinkUrl: function () {
				return this.getCriticalityLinkForm().getAttribute('action');
			},

			getCriticalityLinkTarget: function () {
				return this.getCriticalityLinkForm().getAttribute('target');
			},

			getCriticalityLinkSubmit: function () {
				return this.getCriticalityLinkForm().element(by.css('input:nth-child(2)')).getAttribute('type');
			},

			getCriticalityFlagStyle: function () {
				return this.findElement('criticalityFlag').getAttribute('style');
			},

			getFinancialLabel: function () {
				return this.findElement('financialLabel').getText();
			},

			getFinancialValue: function () {
				return this.findElement('financialValue').getText();
			},

			getSafetyLabel: function () {
				return this.findElement('safetyLabel').getText();
			},

			getSafetyFlagStyle: function () {
				return this.findElement('safetyLabel').element(by.css('div span:nth-child(1)')).getAttribute('style');
			},

			getSafetyValue: function () {
				return this.findElement('safetyLabel').element(by.css('div span:nth-child(2)')).getText();
			},

			getEnvironmentLabel: function () {
				return this.findElement('environmentLabel').getText();
			},

			getEnvironmentFlagStyle: function () {
				return this.findElement('environmentLabel').element(by.css('div span:nth-child(1)')).getAttribute('style');
			},

			getEnvironmentValue: function () {
				return this.findElement('environmentLabel').element(by.css('div span:nth-child(2)')).getText();
			},

			getOperationsLabel: function () {
				return this.findElement('operationsLabel').getText();
			},

			getOperationsFlagStyle: function () {
				return this.findElement('operationsLabel').element(by.css('div span:nth-child(1)')).getAttribute('style');
			},

			getOperationsValue: function () {
				return this.findElement('operationsLabel').element(by.css('div span:nth-child(2)')).getText();
			}
		}
	};

	module.exports = new maintenanceOptimizationPage();
}());

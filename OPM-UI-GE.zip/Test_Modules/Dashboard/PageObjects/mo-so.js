/* created by 212329933 on Oct 10th 2016 */
(function () {
	'use strict';

	var data = require('../TestData/mo-dashboard-test-data.json').data.env[browser.params.environment];
	var serviceData = {};

	var moService = function () {
		return {
			getAccessToken: function () {
				var deferred = protractor.promise.defer();

				if (data.opts.headers.Authorization === '' || data.opts.headers.Authorization === null) {
					//console.log('Fetching access token from: ' + data.adminUserOpts.url);
					RestHelper.getAccessToken(data.adminUserOpts.url, data.adminUserOpts.headers, data.adminUserOpts.body, function (err, token) {
						if (token !== null && token !== '') {
							//console.log('Access Token: ' + token);
							deferred.fulfill(token);
							data.opts.headers.Authorization = 'bearer ' + token;
						}
						else
							deferred.reject('Failed to fetch access token from: ' + url);
					});
				} else {
					deferred.fulfill(data.opts.headers.Authorization);
				}

				return deferred.promise;
			},

			getServiceData: function (url, key) {
				var deferred = protractor.promise.defer();

				if (serviceData[key] === undefined || serviceData[key] === null) {
					this.getAccessToken().then(function () {
						//console.log('\nFetching data from: ' + url);
						RestHelper.executeGetRequest(url, data.opts.headers, function (err, res) {
							//console.log('Response Body: ' + JSON.stringify(res.body));

							if (res !== null && res !== '') {
								if (key === 'gateWayConfig') {
									var configData = {};
									configData.baseConfig = JSON.parse(res.body.baseConfig);
									configData.recommendationConfig = JSON.parse(res.body.recommendationConfig);
									configData.allWorkorderConfig = JSON.parse(res.body.allWorkorderConfig);
									configData.assetOverviewConfig = JSON.parse(res.body.assetOverview);
									configData.assetCriticalityConfig = JSON.parse(res.body.assetCriticality);

									serviceData[key] = configData;
									res.body = configData;
								}

								serviceData[key] = res.body;
								deferred.fulfill(res.body);
							}

							else
								deferred.reject('Failed to fetch data from: ' + url);
						});
					});
				} else {
					deferred.fulfill(serviceData[key]);
				}

				return deferred.promise;
			},

			getAssetAttributes: function () {
				var url = data.opts.apmAssetService + '/assets?components=ATTRIBUTES&sourceKey=' + data.assetId;
				var key = 'assetAttributes';
				return this.getServiceData(url, key);
			},

			getGatewayConfig: function () {
				var url = data.opts.apmMOConfigService + '/mo/config/gateway/case?assetId=' + data.assetId;
				var key = 'gateWayConfig';
				return this.getServiceData(url, key);
			},

			getOpenWorkOrdersForAsset: function () {
				var url = data.opts.apmMOWorkOrderService + '/mo/workorder/asset/' + data.assetId + '/open';
				var key = 'openWorkOrders';
				return this.getServiceData(url, key);
			},

			getClosedWorkOrdersForAsset: function () {
				var url = data.opts.apmMOWorkOrderService + '/mo/workorder/asset/' + data.assetId + '/closed';
				var key = 'closedWorkOrders';
				return this.getServiceData(url, key);
			},

			getRecommendationsForAsset: function () {
				var url = data.opts.apmMOWorkOrderService + '/mo/recommendation/asset/' + data.assetId;
				var key = 'recommendations';
				return this.getServiceData(url, key);
			},

			getFinancial: function () {
				var deferred = protractor.promise.defer();

				this.getAssetAttributes().then(function (data) {
					var financialData = data[0].attributes.maintenanceCriticalityCategory.value[2];
					deferred.fulfill(financialData.split('value=')[1]);
				});

				return deferred.promise;
			},

			getAttributeValue: function (name) {
				var deferred = protractor.promise.defer();

				this.getAssetAttributes().then(function (data) {
					var attributes = data[0].attributes.maintenanceCriticalityCategory.value; //.value[index];
					for (var i=0; i<attributes.length; i++) {
						if (attributes[i].indexOf(name.toUpperCase()) > -1) {
							deferred.fulfill(attributes[i].split('value=')[1].split(',')[0]);
							break;
						}
					}
				});

				return deferred.promise;
			},

			getAttributeColor: function (name) {
				var deferred = protractor.promise.defer();

				this.getAssetAttributes().then(function (data) {
					var attributes = data[0].attributes.maintenanceCriticalityCategory.value; //.value[index];
					for (var i=0; i<attributes.length; i++) {
						if (attributes[i].indexOf(name.toUpperCase()) > -1) {
							deferred.fulfill(attributes[i].split('color=')[1]);
							break;
						}
					}
				});

				return deferred.promise;
			},

			getAssetOverviewRedirectUrl: function () {
				var deferred = protractor.promise.defer();
				var self = this;
				this.getGatewayConfig().then(function (data) {
					deferred.fulfill(self.getRedirectUrl(data.assetOverviewConfig, 'tenant'));
				});

				return deferred.promise;
			},

			getAssetCriticalityRedirectUrl: function () {
				var deferred = protractor.promise.defer();
				var self = this;
				this.getGatewayConfig().then(function (data) {
					deferred.fulfill(self.getRedirectUrl(data.assetCriticalityConfig, 'tenant'));
				});

				return deferred.promise;
			},

			getAllWorkOrdersRedirectUrl: function () {
				var deferred = protractor.promise.defer();
				var self = this;
				this.getGatewayConfig().then(function (data) {
					deferred.fulfill(self.getRedirectUrl(data.allWorkorderConfig, 'tenant'));
				});

				return deferred.promise;
			},

			getRecommendationsRedirectUrlsList: function (entityKeys) {
				var deferred = protractor.promise.defer();
				var self = this;
				this.getGatewayConfig().then(function (data) {
					var urlsList = new Array();
					for (var i = 0; i < entityKeys.length; i++) {
						urlsList.push(self.getRedirectUrl(data.baseConfig, 'tenant', entityKeys[i]))
					}

					deferred.fulfill(urlsList);
				});

				return deferred.promise;
			},

			getRedirectUrl: function (data, priority, entityKey) {
				var config = data;
				var params = config.queryParams;
				var redirectUrl = config.url + '?';

				var tenant = '';
				var endRoute = '';

				for (var paramId in params) {
					if (params[paramId].name === 'endUIRoute') {
						endRoute = endRoute + params[paramId].name + '=' + encodeURIComponent(params[paramId].value);
						if (entityKey && entityKey !== '') {
							endRoute += entityKey;
						}
					} else {
						tenant = params[paramId].name + '=' + params[paramId].value;
					}
				}

				if (priority === 'tenant')
					redirectUrl += tenant + '&' + endRoute;
				else
					redirectUrl += endRoute + '&' + tenant;

				return redirectUrl;
			}
		}
	};

	module.exports = new moService();
}());
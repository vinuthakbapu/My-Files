/* created by 212329933 on Oct 10th 2016 */
(function () {
	'use strict';

	var data = require('../TestData/mo-dashboard-test-data.json').data[browser.params.environment];
	var chart = require('proui-utils').HighChart;
	var chartContainer;
	var currentPage = 'moKPIWidget';

	var moKPIWidgetPage = function () {
		return {
			findElement: function (element) {
				return dem.findElement('moKPIWidget', element);
			},

			getXaxisLabel: function () {
				return this.findElement('xaxisLabel').getText();
			},

			getSettingsLabel: function(){
				return element(by.cssContainingText('span','SETTINGS'));
			},

			getKPILineChartLabel: function(){
				return element(by.cssContainingText('span','KPI Line Chart'));
			},

			getKPITitleLabel: function(){
				return element(by.cssContainingText('span','KPI Title'));
			},

			clickDropdown: function () {
				return element.all(by.css('#typeSelect')).get(0).click();
			},

			getOptionsList: function () {
				var deferred = protractor.promise.defer();
				this.clickDropdown().then(function () {
					browser.sleep(3000);
					element.all(by.css('#typeSelect')).get(0).all(by.tagName('option')).then(function (opts) {
						var options = new Array();
						opts.forEach(function (opt, index) {
							var tmpObj = new Object();

							opt.getText().then(function (text) {
								if (text.trim().length > 0) {
									tmpObj.Options = text;
									options.push(tmpObj);
								}
							});
						});

						return options;
					}).then(function (options) {
						deferred.fulfill(options);
					});
				});

				return deferred.promise;
			},

			selectKPI: function (kpi) {
				return element.all(by.css('#typeSelect')).get(0).all(by.xpath('option[.="' + kpi + '"]')).click();
			},

			getSelectedKPI: function() {
				return element.all(by.css('#typeSelect')).get(0).element(by.css('option:checked')).getText();
			},

			getConfigureWidgetHeader: function() {
				return TestHelper.getText(currentPage, 'configureWidgetHeader');
			},

			getWidgetHeaderCustom: function (headerText) {
				return element(by.xpath('//div[.="'+ headerText +'"]')).getText();
			},

			getWidgetHeader: function() {
				return TestHelper.getText(currentPage, 'widgetHeader');
			},





			/*clickUlMenu: function () {
				return TestHelper.elementToBeClickable(currentPage, 'menuUl');
			},

			clickEditMenu: function () {
				return TestHelper.elementToBeClickable(currentPage, 'editMenu');
			},*/


			setChart: function () {
				console.log("Before")
				chartContainer = dem.findElement(currentPage, 'chart');
				console.log("After getting section")
				chart.setChartElements(chartContainer);
			},

			isChartVisible: function () {
				this.setChart();
				return chart.isChartDisplayed();
			}
		}
	};

	module.exports = new moKPIWidgetPage();
}());

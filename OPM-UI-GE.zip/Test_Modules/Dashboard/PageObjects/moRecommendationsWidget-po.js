/* created by 212329933 on Oct 10th 2016 */
(function () {
	'use strict';

	var data = require('../TestData/mo-dashboard-test-data.json').data[browser.params.environment];

	var maintenanceOptimizationPage = function () {
		return {
			findElement: function (element) {
				return dem.findElement('moRecommendationsWidget', element);
			},

			getRecommendationsWidgetTitle: function () {
				return this.findElement('title').getText();
			},

			getRowCount: function () {
				return element.all(by.css('#scrollBodyTableContainer div.rows')).count();
			},

			getTableHeaders: function () {
				var deferred = protractor.promise.defer();
				element.all(by.css('#scrollBodyTableContainer span.th')).then(function (ths) {
					var headers = new Array();
					ths.forEach(function (th, index) {
						th.element(by.css('span')).getText().then(function (header) {
							if (header.trim().length > 0) {
								header = header.replace(/(\r\n|\n|\r)/gm,"");
								headers.push(header.trim());
							}
						});
					});

					return headers;
				}).then(function (headers) {
					deferred.fulfill(headers);
				});

				return deferred.promise;
			},

			getTableData: function () {
				var deferred = protractor.promise.defer();
				element.all(by.css('#scrollBodyTableContainer div.rows')).then(function (rows) {
					var rowsArray = new Array();
					rows.forEach(function (row, index) {
						row.all(by.css('px-data-table-cell')).then(function (cols) {
							var colsArray = new Array();
							cols.forEach(function (col, index) {
								col.getText().then(function (text) {
									colsArray.push(text);
								});
							});
							return colsArray;
						}).then(function (colsArray) {
							rowsArray.push(colsArray);
						});
					});

					return rowsArray;
				}).then(function (data) {
					deferred.fulfill(data);
				})

				return deferred.promise;
			},

			getAllRecommendationsLinks: function() {
				return this.getAllLinks('#redirectmessagelink');
			},

			getAllCaseLinks: function() {
				return this.getAllLinks('#interRedirectmessagelink');
			},

			getAllLinks: function (path) {
				var deferred = protractor.promise.defer();
				element.all(by.css(path)).then(function (links) {
					var linksArray = new Array();
					links.forEach(function (link, index) {
						link.getText().then(function (linkText) {
							linksArray.push(linkText);
						});
					});

					return linksArray;
				}).then(function (linksArray) {
					deferred.fulfill(linksArray);
				});

				return deferred.promise;
			},

			getAllRecommendationsRedirectUrls: function() {
				var deferred = protractor.promise.defer();
				element.all(by.xpath("//*[contains(@id, 'redirectForm')]")).then(function (forms) {
					var formsArray = new Array();
					forms.forEach(function (form, index) {
						form.getAttribute('action').then(function (action) {
							form.getAttribute('target').then(function (target) {
								form.element(by.css('input:nth-child(2)')).getAttribute('type').then(function (type) {
									formsArray.push(action + ':::' + target + ':::' + type);
								});
							});
						});
					});

					return formsArray;
				}).then(function (formsArray) {
					deferred.fulfill(formsArray);
				});

				return deferred.promise;
			}
		}
	};

	module.exports = new maintenanceOptimizationPage();
}());


(function(){
    'use strict';
    var currentpage = 'DashboardAppPages';
    var TagTreePage = function() {
        return {

            TagTreePage: function() {
                return TestHelper.isElementVisible(currentpage,'TagTreePanel');
            },
            checkTagTreeTagBrowserPanel: function() {
                return TestHelper.isElementVisible(currentpage,'TagTreeTagBrowserPanel');
            },
            checkTagTreePlottedTagsPanel: function() {
                return TestHelper.isElementVisible(currentpage,'TagTreePlottedTagsPanel');
            },
            checkDataLabelConfig: function() {
                return TestHelper.isElementVisible(currentpage,'DataLabelConfig');
            },
            checkPlusSignTagTree: function() {
                return TestHelper.isElementVisible(currentpage,'PlusSignTagTree');
            },
            clickPlusSignTagTree: function() {
                return TestHelper.elementToBeClickable(currentpage,'PlusSignTagTree');
            },
            checkPlotTagLink: function() {
                return TestHelper.isElementVisible(currentpage,'PlotTagLink');
            },
            checkSearchInputField: function() {
                return TestHelper.isElementVisible(currentpage,'SearchInputField');
            },
            checkTagBrowserTitle: function() {
                return TestHelper.isElementVisible(currentpage, 'TagBrowserTitle');
            },
            checkPlusSignAddAssets: function() {
                return TestHelper.isElementVisible(currentpage,'PlusSignAddAssets');
            },
            checkPlottedTagsTitle: function() {
                return TestHelper.isElementVisible(currentpage, 'PlottedTagsTitle');
            },
            clickPlotTagLink: function() {
                return TestHelper.elementToBeClickable(currentpage,'PlotTagLink');
            },
            checkPrimaryAsset: function(assetName) {
                dem2[currentpage]["PrimaryAssetTitle"].locatorValue = assetName;
                return TestHelper.isElementPresent(currentpage, 'PrimaryAssetTitle');
                //isElementPresent is used instead of isElementVisible due CSS returns an array, so elements are Present but visible one at a time
            },
            checkAssetChevronIcon: function(assetName) {
                var myElement = element(by.xpath("//*[@id='text'][contains(text(),'" + assetName + "')]/preceding-sibling::div[@id='toggle']/iron-icon" ));
                return TestHelper.isElementVisible(myElement);
            },
            clickAssetChevronIcon: function(assetName) {
                var myElement = element(by.xpath("//*[@id='text'][contains(text(),'" + assetName + "')]/preceding-sibling::div[@id='toggle']/iron-icon" ));
                return TestHelper.elementToBeClickable(myElement);
            },
            checkAssetNextBelow: function(sibblingAsset, parentAsset) {
                var myElement = element(by.xpath("//*[@id='text'][contains(text(),'" + parentAsset + "')]/ancestor::*[@id='label']/following-sibling::*[@id='container']/descendant::*[@id='text'][contains(text(),'" + sibblingAsset + "')]/preceding-sibling::div[@id='toggle']/iron-icon" ));
                return TestHelper.isElementVisible(myElement);
            },
            clickAssetNextBelow: function(sibblingAsset, parentAsset) {
                var myElement = element(by.xpath("//*[@id='text'][contains(text(),'" + parentAsset + "')]/ancestor::*[@id='label']/following-sibling::*[@id='container']/descendant::*[@id='text'][contains(text(),'" + sibblingAsset + "')]/preceding-sibling::div[@id='toggle']/iron-icon" ));
                return TestHelper.elementToBeClickable(myElement);
            },
            checkAssetNameLabel: function(assetName) {
                var myElement = element(by.xpath("//*[@id='text'][contains(text(),'" + assetName + "')]"));
                return TestHelper.isElementVisible(myElement);
            },
            checkAllTagsChevron: function(labelName) {
                var myElement = element(by.xpath("//*[@id='text'][contains(text(),'" + labelName + "')]/preceding-sibling::div[@id='toggle']"));
                return TestHelper.isElementVisible(myElement);
            },
            checkSectionCollpased: function() {
                return TestHelper.isElementVisible(currentpage,'SectionCollpased');
            },
            checkPrimaryAssetCollpased: function() {
                return TestHelper.isElementVisible(currentpage,'PrimarySectionCollpased');
            },
            checkPlusSignTagTreeMoreAssets: function() {
                return TestHelper.isElementVisible(currentpage,'PlusSignTagTreeMoreAssets');
            },
            clickPlusSignTagTreeMoreAssets: function() {
                return TestHelper.elementToBeClickable(currentpage,'PlusSignTagTreeMoreAssets');
            },
            clickSecondaryAssetInContextBrowser: function(asset){
                dem2[currentpage]["secondaryContextItem"].locatorValue = asset;
                return TestHelper.elementToBeClickable(currentpage, "secondaryContextItem");
            },
            clickOpenButtonContextBrowser: function(num){
                dem2[currentpage]["openbuttonsContextBrowser"].value.index = num;
                return TestHelper.elementToBeClickable(currentpage,"openbuttonsContextBrowser");
            },
            mouseOverPrimaryAsset: function(assetName) {
                return element(by.xpath("//*[@id='text'][contains(text(),'" + assetName + "')]"));
            },
            checkXIconMouseOverAsset: function(assetName) {
                var myElement = element(by.xpath("//*[@id='text'][contains(text(),'" + assetName + "')]/ancestor::div[@id='label']/descendant::div[@class='tree-view-remove-icon style-scope px-tree-view-branch']/iron-icon"));
                return TestHelper.isElementVisible(myElement);
            },
            clickXIconMouseOverAsset: function(assetName) {
                var myElement = element(by.xpath("//*[@id='text'][contains(text(),'" + assetName + "')]/ancestor::div[@id='label']/descendant::div[@class='tree-view-remove-icon style-scope px-tree-view-branch']/iron-icon"));
                return TestHelper.elementToBeClickable(myElement);
            },
            checkPopUpTitleRemoveAsset: function(title) {
                dem2[currentpage]["PopUpTitleRemoveAsset"].locatorValue = title;
                return TestHelper.isElementPresent(currentpage,'PopUpTitleRemoveAsset');
            },
            checkPopUpMessageRemoveAsset: function(message, title) {
                var myElement = element(by.xpath("//*[@id='delete-asset-modal-title'][contains(text(),'" + title + "')]/following-sibling::p[contains(text(),'" + message + "')]"));
                return TestHelper.isElementPresent(myElement);
            },
            checkPopUpCancelButtonRemoveAsset: function() {
                return TestHelper.isElementPresent(currentpage,'PopUpCancelButtonRemoveAsset');
            },
            checkPopUpOKButtonRemoveAsset: function() {
                return TestHelper.isElementPresent(currentpage,'PopUpOKButtonRemoveAsset');
            },
            clickPopUpOKButtonRemoveAsset: function() {
                return TestHelper.elementToBeClickable(currentpage,'PopUpOKButtonRemoveAsset');
            },
            checkPlottedTagSection: function(tagName, assetName) {
                var myElement = element(by.xpath("//span[@class='label style-scope px-tree-view-leaf'][contains(text(),'" + assetName + "')]/following-sibling::span[@class='sub-label style-scope px-tree-view-leaf'][contains(text(),'" + tagName + "')]"));
                return TestHelper.isElementVisible(myElement);
            },
            checkNumTagsPlottedTagsList: function() {
                return dem.findElement(currentpage, "NumTagsPlottedTagsList").count();
            },
            getTagPlottedTagsList: function(tagNumber) {
                dem2[currentpage]["tagPlottedTagList"].value.index = Number(tagNumber)-1;
                return dem.findElement(currentpage, "tagPlottedTagList");
            },
            clickXIconTagPlottedTagsList: function(tagNumber) {
                dem2[currentpage]["xIconTagPlottedTagList"].value.index = Number(tagNumber)-1;
                var myElement = dem.findElement(currentpage, "xIconTagPlottedTagList");
                return TestHelper.elementToBeClickable(myElement);
            }






        }
    };
    module.exports = new TagTreePage();
}())
/* created by 212677088 on Feb 23rd 2018 */
(function () {
    'use strict';
    const Series = require('time-series-data-generator');
    var fs = require('fs');
    var path=require('path');
    var util = require( "util" );



    var data = require('../TestData/OPMAPIEndpoints.json').data.env[browser.params.environment];
    var jsonData = '';
    var auth;
    var serviceData = [];

    var multiForecastRestPO = function () {
        return {
            //------------------------------Data Generator-----------------------------------------

            generateDataForTags: function(name){
                var tagArray = ['Tag_001'];
                var outputJson = {};
                outputJson.tags = [];

                var today = (new Date());
                today.setDate(today.getDate()+30);
                today = today.toISOString().split('T')[0];
                today = today + 'T00:00:00Z';
                console.log('Today-->',today);
                var previousday = (new Date());
                previousday.setDate(previousday.getDate()-30);
                previousday = previousday.toISOString().split('T')[0];
                previousday = previousday + 'T00:00:00Z';
                console.log('previousday-->',previousday);

                tagArray.forEach(function(entry, index) {
                    var inputTagId = entry;

                    const from = previousday;
                    const until = today;
                    const interval = 24*3600;
                    const keyName = 'value';
                    const series = new Series({from, until, interval, keyName});
                    var inputArray=series.sin();


                    var data = [];

                    inputArray.forEach(function(entry, index) {
                        var dataItem = {
                            "ts": "",
                            "v": "",
                            "q": "3"
                        };
                        dataItem.ts = entry.timestamp;
                        dataItem.v = entry.value;
                        data[index] = dataItem;

                    });

                    var jsonItemArray = {};
                    var jsonItem = {
                        "tagId": inputTagId,
                        "data": data
                    };

                    jsonItem.data = data;
                    jsonItemArray = jsonItem;
                    outputJson.tags.push(jsonItemArray);
                });
                console.log(JSON.stringify(outputJson));
                fs.readFile(path.resolve(__dirname, '../TestData/'+name+'.json'), function(err, file){
                    if(err){
                        console.log('Read error MultiForecast Test Data-->', err);
                    }
                    fs.writeFile(path.resolve(__dirname, '../TestData/'+name+'.json'), JSON.stringify(outputJson),function(err){
                        console.log('Error in MultiForecast Test Data',err);
                    });
                });
            },
            //---------------------------------------------End of Data Generator----------------------------------------------------------------

            getAccessToken: function () {
                var deferred = protractor.promise.defer();

                if (data.opts.headers.Authorization === '' || data.opts.headers.Authorization === null) {
                    RestHelper.getAccessToken(data.adminUserOpts.url, data.adminUserOpts.headers, data.adminUserOpts.body, function (err, token) {
                        if (token !== null && token !== '') {

                            console.log('token-->',token);
                            data.opts.headers.Authorization = 'Bearer ' + token;
                            deferred.fulfill(token);
                        }
                        else
                            deferred.reject('Failed to fetch access token from: ' + url);
                    });
                } else {
                    deferred.fulfill(data.opts.headers.Authorization);
                }

                return  deferred.promise;
            },

            getQueryResults: function(url) {
                var deferred = protractor.promise.defer();
                this.getAccessToken().then(function () {

                    RestHelper.executeGetRequest( url, data.opts.headers, function (err, res) {

                        if (res !== null && res !== '') {
                            console.log('res.body : ' +JSON.parse(JSON.stringify(res.body.tagList)) );
                            serviceData=JSON.parse(JSON.stringify(res.body.tagList));
                            deferred.fulfill(serviceData);

                        }

                        if(err){
                            console.log("Error occured while fetching data-->"+err);
                        }

                    });
                });
                return deferred.promise;
            },



            getJSONData: function (name) {
                var deferred = protractor.promise.defer();
                var rStream = fs.createReadStream(path.resolve(__dirname, '../TestData/'+name+'.json'));
                var data = '';
                rStream.setEncoding('utf8');
                rStream.on('data', function(chunk) {
                    data+=chunk;
                });
                rStream.on('end', function() {
                    console.log('Read user data');
                    console.log(data);
                });
                jsonData=data;
                deferred.fulfill(jsonData);
                return deferred.promise;
            },

            postTimeSeriesData: function (name) {
                var deferred = protractor.promise.defer();

                this.getAccessToken().then(function () {
                    RestHelper.executePostRequest(data.opts.url, data.opts.headers, jsonData , function(err, res){
                        if (res !== null && res !== '') {
                            console.log("Created user : " + JSON.stringify(res.status));
                        }else{
                            deferred.reject('Failed to fetch data from: ' + data.opts.url);
                        }
                    });
                });
                return deferred.promise;
            },

            updateJSONData: function (name) {
                var jsonArray;
                var i;
                var today = (new Date()).toISOString().split('T')[0];
                today = today + 'T13:58:48.610Z';
                console.log(today);

                fs.readFile(path.resolve(__dirname, '../TestData/'+name+'.json'), function(err, file){
                    if(err){
                        console.log('Read error-->', err);
                    }
                    jsonArray = JSON.parse(file);
                    for(i=0;i<8;i++){
                        jsonArray.tags[i].data.push({
                            "ts": today,
                            "v": 1390,
                            "q": "3"
                        });
                    }

                    console.log('Updated Json-->',JSON.stringify(jsonArray));
                    fs.writeFile(path.resolve(__dirname, '../TestData/'+name+'.json'), JSON.stringify(jsonArray),function(err){
                        console.log('Error');
                    });
                });
            }

        }
    };

    module.exports = new multiForecastRestPO();
}());
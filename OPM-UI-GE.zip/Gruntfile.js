module.exports = function(grunt) {
    'use strict';


    grunt.initConfig({
        pkg: grunt.file.readJSON('package.json'),

        jshint: {
            files: ['Gruntfile.js', 'step_definitions/*.js'],
            options: {
                // options here to override JSHint defaults
                globals: {
                    jQuery: true,
                    console: true,
                    module: true,
                    document: true
                }
            }

        },
        execute: {
            target: {
                src:['./node_modules/proui-utils/updateChromeDriver.js']
            }
        },

        shell: {
            options: {
                stdout:true
            },
             disableSSL:
             {
                 command:'npm config set strict-ssl false'
             },
            npm_install: {
                command: 'npm install --only=dev --proxy=http://sjc1intproxy02.crd.ge.com:8080'
            },
            npm_update: {
                command: 'npm update --only=dev --proxy=http://sjc1intproxy02.crd.ge.com:8080'
            },
            protractor_install: {
                command: 'node ./node_modules/protractor/bin/webdriver-manager update --proxy=http://sjc1intproxy02.crd.ge.com:8080 --ignore_ssl'
            }
            // ie_install: {
            //     command: 'node ./node_modules/protractor/bin/webdriver-manager update --ie --proxy=http://proxy-src.research.ge.com:8080'
            // }


        },
        protractor: {
        //default: {
        //    options: {
        //        keepAlive: true,
        //        configFile: 'Common_Modules/Conf/protractor.cucumber.common.conf.js',
        //        args: {suite: 'dashboard'}
        //    },
        //},
        default: {
            options: {
                keepAlive: false,
                configFile: 'Test_modules/Dashboard/Conf/protractor.cucumber.dashboard.conf.js',
                args: {suite: 'dashboard',
                    username: ''}
            }
        },
        test: {
            options: {
                keepAlive: false,
                configFile: grunt.option('conf'),
                args: {cucumberOpts:grunt.option('spec'), suite: grunt.option('suite'),params:{
                        login:{
                            baseUrl:grunt.option('baseUrl'),
                            username:grunt.option('username'),
                            password:grunt.option('password')
                        }
                    }
                }
            }
        },

        browser:{
            options: {
                keepAlive: false,
                configFile: grunt.option('conf'),
                args: {cucumberOpts:grunt.option('spec'),suite: grunt.option('suite'), browser: grunt.option('browser'),
                    baseUrl:grunt.option('baseUrl'),
                    username:grunt.option('username'),
                    password:grunt.option('password')}
            }
        },

        noSuite: {
                options: {
                    keepAlive: false,
                    configFile: grunt.option('conf')
                }
            },
            singlerun: {},
            auto: {
                keepAlive: false,
                options: {
                    args: {
                        seleniumPort: 4444
                    }
                }
            }
        }


    });

    var target = grunt.option('target') || 'def';

    grunt.loadNpmTasks('grunt-execute');

    grunt.loadNpmTasks('grunt-contrib-jshint');

    grunt.loadNpmTasks('grunt-shell-spawn');

    grunt.loadNpmTasks('grunt-protractor-runner');

    //grunt.loadNpmTasks('perfjankie');

    //grunt.registerTask('default', ['jshint', 'shell','protractor:default']);
    grunt.registerTask('default', ['jshint', 'execute:target','shell','protractor:default']);
    grunt.registerTask('default',  function(arg) {
        try {
            grunt.task.run('jshint');
            grunt.task.run('execute:target');
            grunt.task.run('shell');
            //grunt.task.run('protractor:default');
            // doSomethingThatThrowsAnExceptionOnError(arg);
            // Success!
            //grunt.verbose.ok();
        } catch(e) {
            // Something went wrong.
            grunt.verbose.or.write(msg).error().error(e.message);
            grunt.fail.warn('Something went wrong.');
        }
    });

    grunt.registerTask('test',  function(arg) {
        try {
            grunt.task.run('jshint');
            grunt.task.run('execute:target');
            grunt.task.run('shell:disableSSL');
            grunt.task.run('shell:protractor_install');
            grunt.task.run('protractor:test');
            // doSomethingThatThrowsAnExceptionOnError(arg);
            // Success!
            //grunt.verbose.ok();
        } catch(e) {
            // Something went wrong.
            grunt.verbose.or.write(msg).error().error(e.message);
            grunt.fail.warn('Something went wrong.');
        }
    });
    //grunt.registerTask('test', ['jshint','shell','protractor:test']);

    //grunt.registerTask('noSuite', ['jshint','shell','protractor:noSuite']);
    grunt.registerTask('noSuite', ['jshint', 'execute:target','shell','protractor:noSuite']);


    grunt.registerTask('browser', ['jshint','shell','protractor:browser']);

    //var protractorperf = require('protractor-perf');
    // grunt.registerTask('performance', function() {
    //     var donerun = this.async();
    //     // Optional config Object that overwrites properties of conf.js.
    //     // Useful to set property values from grunt.option()
    //     var argv = {
    //         selenium: 'http://localhost:54321/wd/hub',
    //         seleniumPort: 54321,
    //         suite: grunt.option('suite')
    //
    //     };
    //     protractorperf.run(grunt.option('conf'), donerun, argv); // config file
    // });
    grunt.registerTask('run', ['protractorperf']);
};
# Dashboard regression suite

For running this test suite on windows slave with Jenkins, Refer [here](https://github.build.ge.com/APM/apm-dashboard-ui-tests/wiki/Automation-on-Jenkins-windows-slave)

To Take the latest changes from APM to our develop branch, Create a PR from [this link](https://github.build.ge.com/OperationsOptimization/oo-dashboard-ui-tests/compare/develop...APM:master)


## Installation Instructions
           
1)     Should have Github account

2)     Send your SSO to chigullapally@ge.com to provide an access to the repo

3) 	Open new terminal and clone repo from GitHub to the local system
```
git clone https://github.build.ge.com/APM-Dashboard/apm-dashboard-ui-tests.git
```

4)     Open IDE (WebStorm) and select File-> Open and navigate to cloned Project

5) Run the commands below to install all the required dependencies:
npm install -g grunt --proxy=http://proxy-src.research.ge.com:8080
npm install --only=dev --proxy=http://proxy-src.research.ge.com:8080
6) Run the commands below

npm install
grunt
    
7) Format to execute the tests from command line
grunt test --conf=workspacedirectory\protractor.cucumber.dashboard.conf.js --suite=dashboard (suite name)

8) Add/edit configuration in web storm
Node interpreter: /Users/212340705/.nvm/versions/node/v5.10.1/bin/node
working directory:
javascript file: node_modules/protractor/bin/protractor
application parameter: xxxx/protractor.cucumber.dashboard.conf.js --suite=<suitename>

## Executing E2E Tests
Command to Execute Operations Optimization Configurable Dashboard UI E2E Tests : 

npm test

## For LOCAl developmemt
  
Go to Test Modules > Protractor.cucumber.dashboard.conf.js

Comment out the following lines of code

```
proxy: {
	proxyType: 'manual',
	httpProxy: 'sjc1intproxy10.crd.ge.com:8080',
	sslProxy: 'sjc1intproxy10.crd.ge.com:8080'
},

```

## OO widget test cases

oo widget test cases can referred in the following location 

```
oo-dashboard-ui-tests/Test_Modules/Dashboard/Features/add-new-streaming-dashboard.feature 
```

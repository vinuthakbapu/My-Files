#!/bin/bash -ex
printf "\nNODE_PATH: %s\n" "$NODE_PATH"
printf "\nWORKSPACE: \n" "$WORKSPACE"
printf "\nnode version: `node -v`"

printf "*** ENV Variables ***"
printenv
printf "*********************"

printf "*** PROXY Variables BEFORE ***"
env | grep -i proxy
printf "*********************"
printf "*********************"

export http_proxy=http://sjc1intproxy10.crd.ge.com:8080
export https_proxy=http://sjc1intproxy10.crd.ge.com:8080
export all_proxy=http://sjc1intproxy10.crd.ge.com:8080
export no_proxy="devcloud.sw.ge.com,openge.ge.com,github.sw.ge.com,localhost,127.0.0.1,api.grc-apps.svc.ice.ge.com,login.grc-apps.svc.ice.ge.com,loggregator.grc-apps.svc.ice.ge.com,uaa.grc-apps.svc.ice.ge.com,console.grc-apps.svc.ice.ge.com,192.168.50.4,xip.io"

printf "*** PROXY Variables AFTER ***"
env | grep -i proxy
printf "*********************"
printf "*********************"



#Snpm install -g grunt --proxy=http://sjc1intproxy10.crd.ge.com:8080
#npm config set strict-ssl false
#npm install --only=dev --proxy=http://sjc1intproxy10.crd.ge.com:8080

cd $WORKSPACE/node_modules/protractor/bin
# node webdriver-manager update --proxy=http://sjc1intproxy10.crd.ge.com:8080
#node webdriver-manager update --chrome --versions.chrome=2.29 --proxy=http://sjc1intproxy10.crd.ge.com:8080

#grunt test --conf=$WORKSPACE/Test_Modules/Dashboard/Conf/protractor.cucumber.streaming.conf.js --suite=streamingWidget
grunt test --conf=$WORKSPACE/Common_Modules/Conf/sparkAnalyticFlowForRC.conf.js --suite=CafSparkPythonAnalyticFlow


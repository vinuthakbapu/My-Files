#!/bin/bash -ex
printf "\nNODE_PATH: %s\n" "$NODE_PATH"
printf "\nWORKSPACE: \n" "$WORKSPACE"
printf "\nnode version: `node -v`"

printf "*** ENV Variables ***"
printenv
printf "*********************"

npm install --only=dev --proxy=http://sjc1intproxy10.crd.ge.com:8080

cd $WORKSPACE/node_modules/protractor/bin
node webdriver-manager update --proxy=http://sjc1intproxy10.crd.ge.com:8080

grunt test --conf=$WORKSPACE/Common_Modules/Conf/sparkJavaAnalyticFlow.conf.js --suite=CafSparkJavaAnalyticFlow


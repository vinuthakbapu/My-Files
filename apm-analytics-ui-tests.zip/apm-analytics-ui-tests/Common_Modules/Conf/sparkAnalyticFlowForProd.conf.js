exports.config = {

    // ---- While testing locally
    sauceUser: null,
    sauceKey: null,
    sauceSeleniumAddress: null,

    directConnect: false,
    firefoxPath: null,

    // ---------------------------------------------------------------------------
    // ----- What tests to run ---------------------------------------------------
    // ---------------------------------------------------------------------------

    // Spec patterns are relative to the location of this config.
    specs: [],

    // Patterns to exclude.
    exclude: [],

    // Organize spec files into suites. To run specific suite, --suite=<name of suite>
    suites: {
        // login: ['../Features/apmLogin.feature'],
        CafAnalyticCRUD: ['../Features/CafAnalyticCRUD.feature'],
        CafDeployment: ['../Features/CafDeployment.feature'],
        CafAnalyticTemplate: ['../Features/CafAnalyticTemplate.feature'],
        CafAssetFilters: ['../Features/CafAssetFilters.feature'],

        AnalyticsJourney: ['../Features/AnalyticsJourney.feature'],
        AnalyticsRegression: ['../Features/AnalyticRegression.feature'],
        AnalyticCRUD: ['../Features/AnalyticCRUD.feature'],
        AnalyticTemplate: ['../Features/AnalyticTemplate.feature'],
        AnalyticDeployment: ['../Features/AnalyticAssetSelection.feature'],
        AssetSelection: ['../Features/AnalyticAssetSelection.feature'],
        AnalyticIOmapping: ['../Features/AnalyticIOMapping.feature'],
        AnalyticSchedule: ['../Features/AnalyticSchedule.feature'],
        AnalyticReview: ['../Features/AnalyticReview.feature'],
        AssetFilters: ['../Features/assetFilters.feature'],

        OrchestrationCRUD: ['../Features/CAFOrchestrationCRUD.feature'],
        OrchestrationCRUDSteps: ['../Features/OrchestrationCRUDSteps.feature'],
        OrchestrationIOMap: ['../Features/OrchestrationIOMapping.feature'],
        OrchestrationDeployment: ['../Features/OrchestrationDeployment.feature'],

        CafAnalyticCRUD: ['../Features/CafAnalyticCRUD.feature'],
        CafDeployment: ['../Features/CafDeployment.feature'],
        CafAnalyticTemplate: ['../Features/CafAnalyticTemplate.feature'],
        CafAssetFilters: ['../Features/CafAssetFilters.feature'],
        CafAnalyticIOMapping: ['../Features/CafAnalyticIOMapping.feature'],
        CafAnalyticAssetSelection: ['../Features/CafAnalyticAssetSelection.feature'],
        CafAnalyticSchedule: ['../Features/CafAnalyticSchedule.feature'],

        CafSparkJavaAnalyticFlow: ['../Features/CafSparkJavaAnalyticFlow.feature'],
        CafSparkPythonAnalyticFlow: ['../Features/CafSparkPythonAnalyticFlow.feature'],
        CafSparkJavaStreamingAnalyticFlow: ['../Features/CafSparkJavaStreamingAnalyticFlow.feature'],
        CafSparkAlertsBatchAnalyticFlow: ['../Features/CafSparkAlertsBatchAnalyticFlow.feature'],
        CafSparkAlertsStreamingAnalyticFlow: ['../Features/CafSparkAlertsStreamingAnalyticFlow.feature'],
        CafSparkForecastingAnalyticFlow: ['../Features/CafSparkForecastingAnalyticFlow.feature'],
        CafSparkDeleteAnalytic: ['../Features/CafSparkDeleteAnalytic.feature']



    },

    // Hooks running in the background
    plugins: [{
        path: '../../node_modules/proui-utils/Compressed_Utils/GeneralHook.js',
    }],

    capabilities: {

        browserName: 'chrome',
        proxy: {
            // proxyType: 'manual',
            // httpProxy: 'sjc1intproxy01.crd.ge.com:8080',
            // sslProxy: 'sjc1intproxy01.crd.ge.com:8080',
            // proxyType: 'manual',
            // httpProxy: 'proxy-src.research.ge.com:8080',
            // sslProxy: 'proxy-src.research.ge.com:8080',
            proxyType: 'manual',
            httpProxy: 'grc-americas-sanra-pitc-wkcz.proxy.corporate.gtm.ge.com:80',
            sslProxy: 'grc-americas-sanra-pitc-wkcz.proxy.corporate.gtm.ge.com:80',

},
        count: 1,
        shardTestFiles: false,
        maxInstances: 1,
        'chromeOptions': {
            args: ['--no-sandbox', '--test-type=browser'],
            // Set download path and avoid prompting for download even though
            // this is already the default on Chrome but for completeness
            prefs: {
                'download': {
                    'prompt_for_download': false,
                    'directory_upgrade': true,
                    'default_directory': 'C:/Jenkins/sharedspace/public/test/e2e-reboot/steps/'
                }
            }
        }
    },


    //Browser options
    //multiCapabilities: [
    //	// {
    //	// browserName: 'internet explorer',
    //	// platform: 'ANY',
    //	// version: '11'
    //	// },
    //
    //	// {
    //	// browserName: 'firefox',
    //	// },
    //
    //	{
    //		browserName: 'chrome',
    //		count: 1,
    //		shardTestFiles: false,
    //		maxInstances: 1,
    //		'chromeOptions': {
    //			args: ['--no-sandbox', '--test-type=browser'],
    //			// Set download path and avoid prompting for download even though
    //			// this is already the default on Chrome but for completeness
    //			prefs: {
    //				'download': {
    //					'prompt_for_download': false,
    //					'directory_upgrade': true,
    //					'default_directory': 'C:/Jenkins/sharedspace/public/test/e2e-reboot/steps/'
    //				}
    //			}
    //		}
    //	}
    //
    //],

    params: {
        //env: 'dev'
    },

    maxSessions: -1,

    allScriptsTimeout: 250000,

    // How long to wait for a page to load.
    getPageTimeout: 650000,

    // Before launching the application
    beforeLaunch: function () {
    },

    // Application is launched but before it starts executing
    onPrepare: function () {
        browser.ignoreSynchronization = true;
        // Create reports folder if it does not exist
        var folderName = (new Date()).toString().split(' ').splice(1, 4).join(' ');
        var mkdirp = require('mkdirp');
        var reportsPath = "./Reports/";

        mkdirp(reportsPath, function (err) {
            if (err) {
                console.error(err);
            }
        });

        browser.manage().deleteAllCookies();
        browser.manage().timeouts().pageLoadTimeout(50000);
        browser.manage().timeouts().implicitlyWait(50000);
        browser.driver.manage().window().setSize(1280, 1440);
        //browser.driver.manage().window().maximize();
        //browser.driver.manage().window().setSize(1280, 1440);

        chai = require('chai');
        expect = chai.expect;
        path = require('path');
        Cucumber = require('cucumber');
        fs = require('fs');

        chaiAsPromised = require('chai-as-promised');
        chai.use(chaiAsPromised);

        // Initializing page object variables
        loginPage = require('../PageObjects/apm-login-po.js');
        createOrchestrationPage = require('../PageObjects/cafOrchCreate-po.js');
        viewOrchestrationPage = require('../PageObjects/viewOrch-po.js');
        orchIOMapPage = require('../PageObjects/orchIOMap-po.js');
        orchStepsPage = require('../PageObjects/cafOrchSteps-po.js');
        orchDeployPage = require('../PageObjects/orchDeploy-po.js');




        //caf section
        cafCreateAnalyticPage = require('../PageObjects/cafCreateAnalytic-po.js');
        cafDeploymentPage = require('../PageObjects/cafDeployment-po.js');
        cafAnalyticTemplatePage = require('../PageObjects/cafAnalyticTemplate-po.js');
        cafanalyticTemplatePage = require('../PageObjects/cafAnalyticTemplate-po.js');
        cafAssetFilters = require('../PageObjects/cafAssetFilters-po.js');
        cafAssetSelectionPage = require('../PageObjects/cafAssetSelection-po.js');
        cafSchedulePage = require('../PageObjects/cafSchedule-po');
        cafIOMappingPage = require('../PageObjects/cafIOMapping-po');
        cafAnalyticsJourneyPage = require('../PageObjects/cafAnalyticsJourney-po');
        cafReviewPage = require('../PageObjects/cafReview-po');

        // Initializing necessary utils from proui-utils module
        TestHelper = require('proui-utils').TestHelper;
        TestHelperPO = require('proui-utils').TestHelperPO;
        ElementManager = require('proui-utils').ElementManager;
        Logger = require('proui-utils').Logger;
        cem = new ElementManager('../../../Common_Modules/common-element-repo.json');
        cemPath = require('./../common-element-repo.json');
        TestHelper.setElementManager(cem);
        RestHelper = require('proui-utils').RestHelper;
        commonTestData = require('../TestData/common-test-data.json').data;
        restUtil = require('./rest-util.js');

        TestHelper.setWaitTime(60000);

        navPage= require('../PageObjects/nav-po.js');
        analysisPage = require('../PageObjects/analysis-dash-po.js');
        analysisTS = require('../PageObjects/analysis-TS-po.js');
        analysisPA = require('../PageObjects/analysis-PA-po.js');
        //aem = new ElementManager('../../Test_Modules/Analysis/analysis-element-repo.json');
        aemPath = require('../../Test_Modules/Analysis/analysis-element-repo.json');


        //defining global variables
        var analyticName = "";

        //libaries
        async = require('async');
    },

    // A callback function called once tests are finished
    onComplete: function () {
    },
    // A callback function called once tests are cleaning up
    onCleanUp: function (exitCode) {
    },
    // A callback function after tests are launched
    afterLaunch: function () {
    },

    // Browser parameters for feature files.
    params: {
        login: {

             baseUrl: 'https://apmprod.apm.aws-usw02-pr.predix.io/uaa',
             mgrusername: 'opm-automationuser',
             mgrpassword: 'Pa55w0rd',

        },
    },

    resultJsonOutputFile: null,

    // If true, protractor will restart the browser between each test.
    // CAUTION: This will cause your tests to slow down drastically.
    restartBrowserBetweenTests: false,

    // Custom framework in this case cucumber
    framework: 'custom',
    frameworkPath: require.resolve('protractor-cucumber-framework'),
    cucumberOpts: {
        // tags:['@beena','~@donotrunplease'],
        // define your step definitions in this file
        require: [
            '../step_definitions/*',
            '../../node_modules/proui-utils/Compressed_Utils/Reporter.js',
            // '../step_definitions/login-spec.js',
            // '../step_definitions/createAnalytic-spec.js',
            // '../step_definitions/assetFilter-spec.js',
        ],

        //format: 'pretty'
    },
};
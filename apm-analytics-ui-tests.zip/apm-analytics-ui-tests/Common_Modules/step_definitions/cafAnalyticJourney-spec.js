module.exports = function () {

    var alertTemplateName;
    var deploymentName;
    var analyticName;
    let appHubPath = browser.params.appHubpath;

    this.When(/^user selects the asset filter$/, function (callback) {
        browser.sleep(2000).then(function () { // give some sleep time for the asset filters to appear
            cafAnalyticsJourneyPage.assetFilter().click().then(function () {
                browser.sleep(1000).then(function () {
                    cafAnalyticsJourneyPage.assetFilterValue().click().then(function () {
                        callback();
                    });
                });
            });
        });
    });

    this.When(/^user clicks the search button$/, function (callback) {
        cafAnalyticsJourneyPage.assetSearch().click().then(function () {
            callback();
        });
    });

    this.Then(/^the assets should be displayed$/, function (callback) {
        cafAnalyticsJourneyPage.assetsDisplayed();
        callback();
    });

    this.When(/^cafUser enters the deployment name in journey test$/, function (callback) {
        deploymentName = 'deploy' + TestHelperPO.getRandomString();
        console.log("random deployment Name is " + deploymentName);
        cafDeploymentPage.deploymentName().sendKeys(deploymentName).then(function () {
            browser.sleep(2000);
            callback();
        });
    });

    this.When(/^user clicks the search button$/, function (callback) {
        cafAnalyticsJourneyPage.assetSearch().click().then(function () {
            callback();
        });
    });

    this.When(/^user clicks the next button$/, function (callback) {
        browser.sleep(5000).then(function () {
            cafAnalyticsJourneyPage.assetGoNext().click().then(function () {
                callback();
            });
        });
    });

    this.Then(/^caf IO Mapping page should be displayed$/, function (callback) {
        browser.actions().mouseMove(cafSchedulePage.titleHeader()).perform().then(function () {
            cafSchedulePage.titleHeader().getText().then(function (text) {
                expect(text).to.equal('DATAFLOW');
                callback();
            });
        });
    });

    this.When(/^caf user search for tag "av_tag_10"$/, function (callback) {
        cafAnalyticsJourneyPage.assetTagSearchInput().sendKeys("av_tag_10").then(function () {
            callback();
        });
    });

    this.When(/^caf user select map all asset radio option$/, function (callback) {
        cafAnalyticsJourneyPage.mapPerAllAssetInput().click().then(function () {
            callback();
        });
    });

    this.When(/^caf user maps the first asset tag result$/, function (callback) {
        cafAnalyticsJourneyPage.inputDefRow().click().then(function () {
            cafAnalyticsJourneyPage.firstTagResult().click().then(function () {
                callback();
            });
        });
    });

    this.When(/^caf user maps the "([^"]*)" asset tag result$/, function (tagIndex, callback) {
        tagIndex = parseInt(tagIndex);
        cafAnalyticsJourneyPage.inputDefRow().click().then(function () {
            cafAnalyticsJourneyPage.xTagResult(tagIndex).click().then(function () {
                callback();
            });
        });
    });

    this.When(/^caf user search for the tag "([^"]*)"$/, function (arg1, callback) {
        cafAnalyticsJourneyPage.assetTagSearchInput().clear().sendKeys(arg1).then(function () {
            cafAnalyticsJourneyPage.firstTagResult().click().then(function () {
                callback();
            });
        });
    });

    this.When(/^caf user search for the custom attribute "([^"]*)"$/, function (arg1, callback) {
        cafAnalyticsJourneyPage.customattributeSearchInput().clear().sendKeys(arg1).then(function () {
            cafAnalyticsJourneyPage.firstTagResult().click().then(function () {
                callback();
            });
        });
    });

    this.Then(/^caf user clears the search$/, function (callback) {
        cafAnalyticsJourneyPage.assetTagSearchClear().click().then(function () {
            callback();
        });
    });

    this.When(/^user clicks on the button to add tags$/, function (callback) {
        cafAnalyticsJourneyPage.addTagsToInputDefinition().click().then(function () {
            callback();
        });
    });

    this.Then(/^user selects the option to Add Tags$/, function (callback) {
        cafAnalyticsJourneyPage.selectAddTagsOption().click().then(function () {
            callback();
        });
    });

    this.When(/^caf user selects the first row of input definition$/, function (callback) {
        cafAnalyticsJourneyPage.selectInputDefinitionFirstRow().click().then(function () {
            callback();
        });
    });

    this.When(/^caf user selects the second row of input definition$/, function (callback) {
        cafAnalyticsJourneyPage.selectInputDefinitionSecondRow().click().then(function () {
            callback();
        });
    });

    this.Then(/^caf user clicks the first asset tag result$/, function (callback) {
        browser.sleep(500).then(function () {
            cafAnalyticsJourneyPage.selectFirstTagSearchResult().click().then(function () {
                callback();
            });
        });
    });

    this.Then(/^the caf tag should be displayed in the search results$/, function (callback) {
        browser.sleep(5000).then(function () {
            cafAnalyticsJourneyPage.inputTagName().getText().then(function (string) {
                expect(string).contains('AV_TAG');
                console.log(' STRING ', string);
                callback();
            });
        });
    });

    this.Then(/^the caf tag "([^"]*)" should be displayed in the search results$/, function (arg1, callback) {
        browser.sleep(5000).then(function () {
            cafAnalyticsJourneyPage.inputTagName().getText().then(function (string) {
                expect(string).contains(arg1);
                console.log(' STRING ', string);
                callback();
            });
        });
    });

    this.When(/^caf user enters a new deployment name "([^"]*)"$/, function (arg1, callback) {
        deploymentName = arg1 + randVal;
        cafAssetSelectionPage.getDeplpoymentNameInput().sendKeys(deploymentName).then(function () {
            callback();
        });
    });

    this.When(/^user clicks the tag icon to map to the input definition$/, function (callback) {
        cafAnalyticsJourneyPage.assetRowToDrop().click().then(function () {
            cafAnalyticsJourneyPage.inputTagIconClickToAdd().click().then(function () {
                cafAnalyticsJourneyPage.assetRowToDrop().getText().then(function (string) {
                    console.log('STRING', string);
                    callback();
                });
            });
        });
    });

    this.Then(/^the caf tag should be mapped to the input definition$/, function (callback) {
        browser.sleep(5000).then(function () {
            cafAnalyticsJourneyPage.inputDefinitionMapped().getText().then(function (string) {
                expect(string).contains('AV_TAG_1');
                // expect(string).contains('AV_TAG_1');
                callback();
            });
        });
    });

    this.Then(/^the caf tag "([^"]*)" should be mapped to the input definition$/, function(arg1, callback) {
        cafAnalyticsJourneyPage.inputDefinitionMapped().getText().then(function (string) {
            expect(string).contains(arg1);
            callback();
        });
    });

    this.Then(/^the caf tag "([^"]*)" should be mapped to the "([^"]*)" input definition$/, function(tag,inputNo,callback) {
        cafAnalyticsJourneyPage.inputDefinition(inputNo).getText().then(function (string) {
            if(tag==="")
            {
                expect(string).contains('Required')
            }else{
                expect(string).contains(tag);
            }
            callback();
        });
    });

    this.Then(/^the first caf tag should be mapped to the output definition$/, function (callback) {
        browser.sleep(5000).then(function () {
            cafAnalyticsJourneyPage.firstOutputDefinitionMapped().getText().then(function (string) {
                expect(string).to.equal('AV_TAG_8');
                callback();
            });
        });
    });

    this.Then(/^the second caf tag should be mapped to the output definition$/, function (callback) {
        browser.sleep(5000).then(function () {
            cafAnalyticsJourneyPage.secondOutputDefinitionMapped().getText().then(function (string) {
                expect(string).to.equal('AV_TAG_1');
                callback();
            });
        });
    });

    this.Then(/^the caf tag "([^"]*)" should be mapped to the output definition$/, function (arg1, callback) {
        browser.sleep(5000).then(function () {
            cafAnalyticsJourneyPage.firstOutputDefinitionMapped().getText().then(function (string) {
                expect(string).contains(arg1);
                callback();
            });
        });
    });

    this.When(/^user clicks the next button on IO mapping page$/, function (callback) {
        browser.sleep(5000).then(function () {
            cafAnalyticsJourneyPage.assetIOMappingGoNext().click().then(function () {
                callback();
            });
        });
    });

    this.Then(/^the schedule page should be displayed$/, function (callback) {
        cafAnalyticsJourneyPage.verifySchedulePage().getText().then(function (string) {
            expect(string).contains('SCHEDULE');
            callback();
        });
    });

    this.When(/^caf user clicks the from calendar icon$/, function (callback) {
        cafAnalyticsJourneyPage.scheduleFromCalendarIcon().click().then(function () {
            callback();
        });
    });

    this.When(/^caf user selects the start date$/, function (callback) {
        console.log(cafAnalyticsJourneyPage.todayDateFormat());
        cafAnalyticsJourneyPage.scheduleCalendarStartDayInputBox().clear().sendKeys(cafAnalyticsJourneyPage.OneMonthBackDate()).then(function () {
            callback();
        });
    });

    this.When(/^caf user selects the start date "([^"]*)"$/, function (targetDate, callback) {
        console.log(targetDate); // Should have format 'MM/DD/YYYY'
        cafAnalyticsJourneyPage.scheduleCalendarStartDayInputBox().clear().sendKeys(targetDate).then(function () {
            callback();
        });
    });

    this.When(/^caf user selects the start date one month back$/, function (callback) {
        console.log(cafAnalyticsJourneyPage.OneMonthBackDate());
        cafAnalyticsJourneyPage.scheduleCalendarStartDayInputBox().clear().sendKeys(cafAnalyticsJourneyPage.OneMonthBackDate()).then(function () {
            callback();
        });
    });

    this.When(/^caf user selects the start date one year back$/, function(callback) {
        console.log(cafAnalyticsJourneyPage.OneYearBackDate());
        cafAnalyticsJourneyPage.scheduleCalendarStartDayInputBox().clear().sendKeys(cafAnalyticsJourneyPage.OneMonthBackDate()).then(function () {
            callback();
        });
    });

    this.When(/^caf user selects the end date$/, function(callback) {
        console.log(cafAnalyticsJourneyPage.todayDateFormat());
        cafAnalyticsJourneyPage.scheduleCalendarEndDayInputBox().clear().sendKeys(cafAnalyticsJourneyPage.todayDateFormat()).then(function () {
            callback();
        });
    });

    this.When(/^caf user enters the start time$/, function (callback) {
        cafAnalyticsJourneyPage.scheduleCalendarStartTime().click().then(function () {
            callback();
        });
    });

    this.When(/^caf user enters the end time$/, function (callback) {
        cafAnalyticsJourneyPage.scheduleCalendarEndTime().click().then(function () {
            callback();
        });
    });

    this.When(/^caf user enters the priority$/, function (callback) {
        cafAnalyticsJourneyPage.addPriority().sendKeys(2);
        cafAnalyticsJourneyPage.addPriority().clear();
        cafAnalyticsJourneyPage.addPriority().sendKeys("abc").then(function () {
            cafAnalyticsJourneyPage.schedulePage().click();
            cafAnalyticsJourneyPage.priorityMessage().isDisplayed();
        });
        cafAnalyticsJourneyPage.addPriority().clear();
        cafAnalyticsJourneyPage.addPriority().sendKeys(2);
        callback();
    });

    this.When(/^caf user clicks the apply button$/, function (callback) {
        cafAnalyticsJourneyPage.scheduleCalendarSelectionApply().click().then(function () {
            callback();
        });
    });

    this.When(/^user clicks the next button on the Schedule Page$/, function (callback) {
        cafAnalyticsJourneyPage.schedulePageGoNext().click().then(function () {
            callback();
        });
    });

    this.Then(/^the review page should be displayed$/, function (callback) {
        cafAnalyticsJourneyPage.verifyReviewPage();
        callback();
    });

    this.When(/^caf user closes the analytic deployment$/, function (callback) {
        cafAnalyticsJourneyPage.closesAnalyticDeployment().then(function () {
            callback();
        });
    });

    this.Then(/^user clicks delete button$/, function (callback) {
        cafAnalyticsJourneyPage.deleteAnalyticBtn().then(function () {
            callback();
        });
    });

    this.Then(/^the user confirms delete button$/, function (callback) {
        cafAnalyticsJourneyPage.deleteAnalyticBtnConfirm().then(function () {
            callback();
        });
    });

    this.When(/^caf user clicks the deploy button$/, function (callback) {
        cafAnalyticsJourneyPage.deployAnalyticDeployment().click().then(function () {
            browser.sleep(1000).then(function () {
                callback();
            });
        });
    });

    this.When(/^user clicks the close icon of alert message$/, function (callback) {
        browser.pause()
        cafAnalyticsJourneyPage.alertMessage().click().then(function () {
            console.log("clicked the close icon of alert message")
            callback();
        });
    });

    this.Then(/^the caf deployment should be displayed$/, function (callback) {
        cafDeploymentPage.DeploymentRecord().isDisplayed().then(function (visible) {
            expect(visible).to.equal(true);
            console.log("deployment record is displayed")
            callback();
        });
    });

    this.Then(/^cafUser verify input values in the template page$/, function (callback) {
        let el = cafAnalyticTemplatePage.getInputDefinitionTable();
        cafAnalyticTemplatePage.getInputDefinitionDefaultText(el).then(function (text) {
            assert.notEqual(text.trim(), "Select to add orto upload inputs", "input definition values are not present");
            callback();
        });
    });

    this.Then(/^cafUser verify constant values in the template page$/, function (callback) {
        let el = cafAnalyticTemplatePage.getConstantsTable();
        cafAnalyticTemplatePage.getConstantsDefaultText(el).then(function (text) {
            assert.notEqual(text.trim(), "Select to add orto upload constants", "constant values are not present");
            callback();
        });
    });

    this.Then(/^cafUser verify output values in the template page$/, function (callback) {
        let el = cafAnalyticTemplatePage.getOutputDefinitionTable();
        cafAnalyticTemplatePage.getOutputDefinitionDefaultText(el).then(function (text) {
            assert.notEqual(text.trim(), "Select to add orto upload outputs", "output definition values are not present");
            callback();
        });
    });

    this.Then(/^cafUser verify output event value appears in the template page$/, function (callback) {
        let el = cafAnalyticTemplatePage.getOutputEventsTable();
        cafAnalyticTemplatePage.getOutputEventsDefaultText(el).then(function (text) {
            assert.notEqual(text.trim(), "Select to add output events (e.x. Alarms, Alerts, Anomalies, etc)", "output definition values are not present");
            callback();
        });
    });

    this.Then(/^the caf alert message should be displayed$/, function (callback) {
        browser.sleep(1000).then(function () {
            cafAnalyticsJourneyPage.alertMessage().isDisplayed().then(function (visible) {
                expect(visible).to.equal(true);
                console.log("alert message is displayed")
                callback();
            });
        });
    });

    this.Then(/^Caf user can now see smart signal maintnance app link$/, function (callback) {
        browser.sleep(4000).then(function () {
            cafAnalyticsJourneyPage.getSmartSignalMaintnanceLink().isDisplayed().then(function (visible) {
                expect(visible).to.equal(true);
                callback();
            });
        });
    });

    this.When(/^user clicks on the smartsignal link$/, function (callback) {
        cafAnalyticsJourneyPage.getSmartSignalMaintnanceLink().click().then(function () {
            browser.sleep(4000).then(function () {
                callback();
            });
        });
    });

    this.Then(/^the deployment record will be opened in new tab in smart signal maintenance app$/, function (callback) {
        cafAnalyticsJourneyPage.getSmartSignalMaintnanceLinkUrl().then(function(url){
            console.log('this is the url...', url)
            cafAnalyticsJourneyPage.getSmartSignalMaintnanceLink().click().then(function () {
                browser.getAllWindowHandles().then(function (handles) {
                    newWindowHandle = handles[1];
                    browser.switchTo().window(newWindowHandle).then(function () {
                        browser.getCurrentUrl().then(function (newUrl) {
                            expect(url).to.deep.equal(url);
                            callback();
                        });

                    });
                });
            });
        });
    });

    this.When(/^caf user clicks the alerts link in the left nav bar$/, function (callback) {
        cafAnalyticsJourneyPage.alertLinks().click().then(function () {
            callback();
        });
    });

    this.When(/^caf user clicks the unclaimed link$/, function (callback) {
        cafAnalyticsJourneyPage.unclaimedAlerts().click().then(function () {
            callback();
        });
    });

    this.Then(/^the caf alerts should be displayed$/, function (callback) {
        cafAnalyticsJourneyPage.verifyAlertsPage().click().then(function () {
            callback();
        });
    });

    this.Then(/^latest AutoAnalyticAlert should be displayed$/, function (callback) {
        cafAnalyticsJourneyPage.latestAlertTitle().getText().then(function (name) {
            expect(name).to.equal("AutoAnalyticAlert");
            cafAnalyticsJourneyPage.latestAlertDate().getText().then(function (date) {
                console.log(cafAnalyticsJourneyPage.todayDate());
                expect(date).to.equal(cafAnalyticsJourneyPage.todayDate());
                callback();
            });
        });
    });

    this.Then(/^the status of the deployment is inProgress$/, function (callback) {
        cafAnalyticsJourneyPage.deploymentStatus().getText().then(function (status) {
            expect(status).to.equal('In Progress')
            callback();
        });
    });

    this.Then(/^the deployment link is disabled$/, function (callback) {
        callback();
    });

    this.When(/^I enter the name of the caf output event$/, function (callback) {
        let el = cafAnalyticTemplatePage.getOutputEventsTable();
        cafAnalyticTemplatePage.getOutputEventsElement(el).click().then(function () {
            cafAnalyticTemplatePage.EnterOutputEventsName(el, alertTemplateName).then(function () {
                callback();
            });
        });
    });

    this.Then(/^latest automation alert should be displayed$/, function(callback) {
        cafAnalyticsJourneyPage.latestAlertTitle().getText().then(function(name) {
            expect(name).to.equal(alertTemplateName);
            callback();
        });
    });

    this.When(/^caf user refreshes the page and the status is "([^"]*)"$/, function (arg1, callback) {
        browser.sleep(100000).then(function () {
            browser.refresh().then(function () {
                cafAnalyticsJourneyPage.deploymentStatus().getText().then(function (status) {
                    expect(status).to.equal(arg1);
                    callback();
                });
            });
        });
    });

    this.When(/^I click on the latest automation alert$/, function (callback) {
        cafAnalyticsJourneyPage.latestAlertTitle().click().then(function () {
            browser.sleep(2000).then(function () {
                callback();
            });
        });
    });

    this.When(/^I click on the latest automation alert$/, function (callback) {
        cafAnalyticsJourneyPage.latestAlertTitle().click().then(function() {
            browser.sleep(2000).then(function() {
                callback();
            });
        });
    });

    this.When(/^the user drags the first tag and drops onto definition$/, function (callback) {
        var dragElement = $$(".assetTagList .assetTagBox").get(0);
        var dropElement = $('tr#apm-dp-input-row-0');
        TestHelperPO.elementToBeClickable(dropElement).then(function () {
            browser.sleep(2000).then(function () {
                TestHelperPO.elementToBeClickable(dragElement).then(function () {
                    console.log("Element clicked");
                    TestHelperPO.dragAndDrop(dragElement, dropElement).then(function () {
                        console.log("Top tag has been dropped.");
                        callback();
                    });
                });
            });
        });
    });

    this.Then(/^map "([^"]*)" attribute to the "([^"]*)" definition$/, function (arg1, arg2, callback) {
        let attributeName = element(by.xpath("//div[contains(text(),'"+ arg1 +"')]/../.."));
        let definitionName = $("[title='"+ arg2 +"']");

        TestHelperPO.elementToBeClickable(definitionName).then(function () {
            browser.sleep(2000).then(function () {
                TestHelperPO.elementToBeClickable(attributeName).then(function () {
                    console.log("Element clicked");
                    TestHelperPO.dragAndDrop(attributeName, definitionName).then(function () {
                        console.log("Top tag has been dropped.");
                        callback();
                    });
                });
            });
        });
    });

    this.When(/^the caf deployment delete icon should be displayed$/, function (callback) {
        cafDeploymentPage.cafDeleteDeploymentIcon().isDisplayed().then(function (visible) {
            expect(visible).to.equal(true);
            callback();
        });
    });

    this.When(/^user clicks on the delete icon in the deployments tab$/, function (callback) {
        cafDeploymentPage.cafDeleteDeploymentIcon().click().then(function () {
            callback();
        });
    });

    this.When(/^user clicks the yes button in the delete delete modal$/, function (callback) {
        cafDeploymentPage.deploymentDeleteConfirmInDeploymentsTab().click().then(function () {
            callback();
        });
    });

    this.When(/^the cafUser clicks on the alert templates microapp$/, function (callback) {
        cafAnalyticsJourneyPage.clickAlertTemplatesTab().click().then(function () {
            browser.sleep(2000).then(function () {
                callback();
            });
        });
    });

    this.When(/^user clicks on the plus icon$/, function (callback) {
        cafAnalyticsJourneyPage.clickPlusIconInAlertTemplates().click().then(function () {
            browser.sleep(3000).then(function () {
                callback();
            });
        });
    });

    this.When(/^user enters a new alert template name$/, function (callback) {
        alertTemplateName = 'AnalyticAutomation_' + TestHelperPO.getRandomString();
        cafAnalyticsJourneyPage.AlertTemplateNameField().sendKeys(alertTemplateName).then(function () {
            callback();
        });
    });

    this.When(/^user clicks on the save button in alert templates$/, function (callback) {
        cafAnalyticsJourneyPage.clickSaveButttonInAlertTemplates().click().then(function () {
            browser.sleep(1000).then(function () {
                callback();
            });
        });
    });

    this.Then(/^the alert template creation success message is displayed$/, function (callback) {
        cafAnalyticsJourneyPage.alertTemplateCreationSuccessMessage().isDisplayed().then(function (flag) {
            expect(flag).to.equal(true);
            callback();
        });
    });

    this.When(/^the failure exclamation icon is not displayed$/, function (callback) {
        cafAnalyticsJourneyPage.failureExclamationIcon().then(function (flag) {
            expect(flag).to.equal(false);
            callback();
        });
    });

    this.When(/^the count of alerts generated is correct$/, function (callback) {
        cafAnalyticsJourneyPage.getAnalyticAutomationAlerts(alertTemplateName).count().then(function (count) {
            expect(count).to.equal(4);
            callback();
        });
    });

    this.Then(/^cafUser enter the value in the name field$/, function (callback) {
        analyticName = 'zTest' + TestHelperPO.getRandomString();
        console.log("random analytic Name is " + analyticName);
        cafCreateAnalyticPage.enterName(analyticName).then(function () {
            callback();
        });
    });

    this.Then(/^caf user searches for created template in the search bar$/, function (callback) {
        console.log("Searching for: " + analyticName);
        cafAnalyticsJourneyPage.getTemplateTableSearchBar().sendKeys(analyticName).then(function () {
            callback();
        });
    });

    this.When(/^I enter dynamic output tag name on the search input box on tag tree in analysis$/, function (callback) {
        var dynamicOutputTagName = analyticName + "." + deploymentName + "_DeploymentStep1_1.mean"
        TestHelper.isElementPresent("tagTreePage", "tagTree_SearchInputBox").then(function (boolean) {
            browser.sleep(1000).then(function () {
                console.log('Search input box present: ' + boolean);
                TestHelper.elementToBeClickable("tagTreePage", "tagTree_SearchInputBox").then(function () {
                    element(by.css('#tagsubpanels tag-tree input')).clear().sendKeys(dynamicOutputTagName).then(function () {
                        console.log("Tag name entered to search input field: " + dynamicOutputTagName);
                        browser.sleep(1000).then(function () {
                            callback();
                        });
                    });
                });
            });
        });
    });

    this.When(/^user waits until the analytic gets published$/, function (callback) {
        let analyticUri;
        restUtil.makeRequest("caf" + appHubPath + "/api/caf-mgmt-svc/v1/analyticEntries", 'GET', null, 'application/json').then(function (resp) {
            JSON.parse(resp.body).forEach(function (analytic) {
                if (analytic.name == analyticName) {
                    analyticUri = analytic.uri;
                    console.log("analyticUri is ", analyticUri);
                }
            });
            restUtil.makeRequest("caf" + appHubPath + "/api/caf-mgmt-svc/v1/" + analyticUri, 'GET', null, 'application/json').then(function (resp) {
                analyticEntry = JSON.parse(resp.body)
                publishStatus = analyticEntry.publishStatus;
                console.log("publish status is ", publishStatus);
                if (publishStatus == "Published") {
                    callback();
                } else {
                    var count = 0;
                    while (publishStatus == "Queued" || publishStatus == "InProgress") {
                        console.log("in while loop");
                        count++;
                        browser.sleep(2000).then(function () { //asynchronous
                            console.log("Slept " + count + " time for 2 secs");
                            restUtil.makeRequest("caf" + appHubPath + "/api/caf-mgmt-svc/v1/" + analyticUri, 'GET', null, 'application/json').then(function (resp) {
                                analyticEntry = JSON.parse(resp.body)
                                publishStatus = analyticEntry.publishStatus;
                                console.log("publish status is ", publishStatus);
                            });
                        });
                    }
                    expect(publishStatus).to.equal("Published");
                    callback();
                }
            });
        });
    });
}

/**
 * Created by 212340705 on Jan 8th 2016.
 */

var randomCardName = "TestCard_" + TestHelper.getRandomString();
var cardsInCardLibrary = 0;

module.exports = function() {
    // this.setDefaultTimeout(60000);

    this.When(/^I select a view "([^"]*)"$/, function (arg1, callback) {
        console.log('about to click on view');
        browser.sleep(1000).then(function() {
            createviewpage.getViewSelectorDropdown().then(function (present) {
                if (present) {
                    console.log("View Selector is present: " + present);
                    browser.sleep(3000).then(function() {
                        createviewpage.clickViewSelectorDropdown().then(function () {
                            createviewpage.clickView(arg1).then(function () {
                                console.log('clicked on view name: ' + arg1);
                                console.log('Verify the selected view name is :' + arg1);
                                createviewpage.getSelectedDashboardName().then(function (txt) {
                                    expect(txt).to.contains(arg1);
                                    /*
                                    var isViewNameMatching = txt.indexOf(arg1) !== -1;
                                    console.log('isViewNameMatching: ',txt.indexOf(arg1));
                                    expect(isViewNameMatching).to.equal(true);
                                    */
                                    // expect(txt).to.equal(arg1);
                                    console.log('expected view name: ' + arg1 + ' Actual view name: ' + txt);
                                    callback();
                                });
                            });
                        });
                    });
                }
            });
        });
    });


    this.When(/^I select a view "([^"]*)" in chromeless$/, function (arg1, callback) {
        console.log('about to click on view');
        browser.sleep(1000).then(function() {
            createviewpage.getViewSelectorDropdown_chromeless().then(function (present) {
                if (present) {
                    console.log("View Selector is present: " + present);
                    browser.sleep(3000).then(function() {
                        createviewpage.clickViewSelectorDropdown_chromeless().then(function () {
                            createviewpage.clickView_chromeless(arg1).then(function () {
                                console.log('clicked on view name: ' + arg1);
                                console.log('Verify the selected view name is :' + arg1)
                                createviewpage.getSelectedDashboardName_chromeless().then(function (txt) {
                                    var isViewNameMatching = txt.indexOf(arg1) !== -1;
                                    console.log('isViewNameMatching: ',txt.indexOf(arg1));
                                    expect(isViewNameMatching).to.equal(true);
                                    // expect(txt).to.equal(arg1);
                                    console.log('expected view name: ' + arg1 + ' Actual view name: ' + txt);
                                    callback();
                                });
                            });
                        });
                    });
                }
            });
        });
    });

    this.Then(/^I should see card action menu with add new card button$/, function (callback) {
        console.log('Verify card action menu button exists');
        createviewpage.chkCardActionMenuBtn().then(function (present) {
            console.log('Card Action menu is present');
            callback();
        });
    });

    this.Given(/^I click on card action menu$/, function (callback) {
        console.log('about to click on card action menu button on top right corner of the page');
        createviewpage.clickCardActionMenuBtn().then(function () {
            console.log('Card Action menu is clicked');
            console.log('verify add new card link is visible in the menu drop down');
            addcardpage.getAddNewCardLink().then(function (present) {
                console.log('Add new card link is present');
                callback();
            });
        });
    });
    this.Given(/^I click on dashboard kebab menu$/, function (callback) {
        console.log('about to click on dashboard kebab menu button on top right corner of the page');
        createviewpage.clickCardActionMenuBtn().then(function () {
            // addcardpage.getAddNewCardLink().then(function (present) {
            //     console.log('Add new card link is present');
                callback();
            // });
        });
    });
    this.Given(/^I click on card action menu only$/, function (callback) {
        console.log('about to click on card action menu button on top right corner of the page');
        createviewpage.clickCardActionMenuBtn().then(function () {
            console.log('Card Action menu is clicked');
            callback();
        });
    });

    this.When(/^I click on add new card button in view menu$/, function (callback) {
        console.log('about to click on add new card link from card action menu drop down');
        browser.sleep(1000).then(function() {
            addcardpage.clickAddNewCardLink().then(function () {
                console.log('Clicked on Add New Card link');
                callback();
            });
        });
    });

    this.Given(/^I click on add new card button in view menu with view access$/, function (callback) {
        console.log('about to click on add new card link from card action menu drop down');
        addcardpage.clickAddNewCardLink().then(function () {
            console.log('Clicked on Add New Card link');
            callback();
        });
    });

    this.Then(/^new card should not be added$/, function (callback) {
        console.log('when user clicks on cancel button, verify that new card is not added');
        //addcardpage.getEditCardTitle().isPresent()
        addcardpage.getCardTitleHeader(0).isPresent()
            .then(function (present) {
                expect(present).to.equal(false);
                console.log('No cards present on the dashboard');
                callback();
            });
    });

    this.Given(/^I am on dashboard page$/, function (callback) {
        console.log('Assuming I am on the dashboard page');
        callback();
    });

    this.When(/^I add a new card "([^"]*)"$/, function (arg1, callback) {
        console.log('About to add a new card to selected dashboard');
        var cards = element.all(by.id('cardTitle'));
        var cardCount;
        cards.count()
            .then(function (cnt) {
                cardCount = cnt;
                console.log('card count before adding a new card: ' + cardCount);
                addcardpage.addCard(arg1)
                    .then(function () {
                        console.log('added a new card with title: ' + arg1);
                        cards.count()
                            .then(function (cnt) {
                                expect(cnt).to.equal(cardCount + 1);
                                console.log('card count after adding the new card: ' + cnt)
                                callback();
                            });
                    });
            });
    });
    this.When(/^I add a new "([^"]*)" card$/, function (arg1, callback) {
        var cardCount = 0;
        console.log('card count before adding a new card: ' + cardCount);
        addcardpage.addSpecificCard(arg1).then(function () {
            console.log('successfully added a new ' + arg1 + ' card');
            addcardpage.getAllCards().then(function (cnt) {
                console.log('actual card count after adding the new card: ' + cnt);
                expect(cnt).to.be.at.least(cardCount + 1);
            callback();
            });
        });
    });

    this.When(/^I add a new "([^"]*)" card from preview screen$/, function (arg1, callback) {
        console.log('about to add a new ' + arg1 + ' card from preview screen');
        var cardCount = 0;
        console.log('card count before adding a new card: ' + cardCount);
        addcardpage.addSpecificCardfromPreview(arg1).then(function () {
            console.log('successfully added a new ' + arg1 + ' card from preview screen');
            addcardpage.getAllCards().then(function (cnt) {
                var expCount = cardCount + 1
                console.log('card count after adding the new card: Expected: '+ expCount + ' Actual: '+ cnt);
                expect(cnt).to.at.least(cardCount + 1);
                callback();
            });
        });

    });
    this.Then(/^I should verify the card count$/, function (callback) {
        var cards = element.all(by.id('cardTitle'));
        //var cardCount = cards.count();
        cards.count()
            .then(function (cnt) {
                console.log('card count before adding a new card: ' + cnt);
                expect(cnt).to.equal(1);
                callback();
            });
    });

    this.Then(/^I should see card by verifying the card "([^"]*)" title "([^"]*)"$/, function (num, arg1, callback) {
        console.log('Verify the card title');
        //addcardpage.getEditCardTitle(num - 1).getAttribute('value').then(function (ttl) {
        browser.sleep(2000).then(function () {
            addcardpage.getCardTitleHeader(Number(num)-1).getText().then(function(ttl) {
                console.log('actual value: ' + ttl);
                console.log('expected value: ' + arg1);
                expect(ttl).to.equal(arg1);
                console.log('successfully verified the title for card#  ' + num + '- is - ' + ttl);
                callback();
            });
        });
    });

    this.Then(/^I should not see any Data Service Unavailable error$/, function ( callback) {
        console.log('I should not see the Data Service Unavailable error  ' );
        editWidgetPage.chkDataServiceError().then(function (rslt) {
            console.log('Data Service unavailable error present:  '+ rslt);
            expect(rslt).to.equal(false);
            callback();
        });
    });


    this.Then(/^I should see the "([^"]*)" for the widget$/, function (footer, callback) {
        console.log('I should see the footer  - ' + footer);
        editWidgetPage.getWidgetFooter().then(function (txt) {
            expect(footer.trim()).to.equal(txt.trim());
            callback();
        });
    });
    this.Then(/^I should see the card name in a tool tip$/, function (callback) {
        console.log('Verify card title is displayed in a tool tip');
        callback();
    });
    this.Then(/^I click on edit card menu button$/, function (callback) {
        console.log('about to click on edit card menu button');
        browser.sleep(2000).then(function () {
            addcardpage.clickEditCardMenu().then(function () {
                console.log('clicked on edit card menu');
                callback();
            });
        });

    });
    this.Then(/^I click on edit card menu button for card (\d+)$/, function (cardNumber, callback) {
        console.log('about to click on edit card menu button for cardNumber: ' + cardNumber);
        browser.sleep(2000).then(function () {
            addcardpage.getCardInFocus(cardNumber-1).then(function() {
                addcardpage.clickEditCardMenu_v2(cardNumber-1).then(function () {
                    console.log('clicked on edit card menu');
                    callback();
                });
            });
        });
    });


    this.Then(/^I should see Move Card Down option enabled in edit card menu for card (\d+)$/, function (cardNumber, callback) {
        browser.sleep(2000).then(function () {
            addcardpage.checkMoveCardDownOptionEnabled(cardNumber-1).then(function (present) {
                console.log('I should see Move Card Down option enabled');
                expect(present).to.equal(true);
                callback();
            });
        });
    });
    this.Then(/^I should see Move Card Up option disabled in edit card menu for card (\d+)$/, function (cardNumber, callback) {
        browser.sleep(2000).then(function () {
            addcardpage.checkMoveCardUpOptionDisabled(cardNumber-1).then(function (disabled) {
                console.log('I should see Move Card Up option Disabled');
                expect(disabled).to.equal('true');
                callback();
            });
        });
    });
    this.Then(/^I should see Move Card Up option enabled in edit card menu for card (\d+)$/, function (cardNumber, callback) {
        browser.sleep(2000).then(function () {
            addcardpage.checkMoveCardUpOptionEnabled(cardNumber-1).then(function (present) {
                console.log('I should see Move Card Up option Enabled');
                expect(present).to.equal(true);
                callback();
            });
        });
    });
    this.Then(/^I should see Move Card Down option disabled in edit card menu for card (\d+)$/, function (cardNumber, callback) {
        browser.sleep(2000).then(function () {
            addcardpage.checkMoveCardDownOptionDisabled(cardNumber-1).then(function (disabled) {
                console.log('I should see Move Card Down option Disabled');
                expect(disabled).to.equal('true');
                callback();
            });
        });
    });
    this.Then(/^I should not see Move Card Down option in edit card menu for card (\d+)$/, function(cardNumber, callback) {
        browser.sleep(2000).then(function () {
            addcardpage.checkMoveCardDownOptionEnabled(Number(cardNumber - 1)).then(function (isVisible) {
                console.log('Move-Down card option is being displayed: ' + isVisible);
                expect(isVisible).to.equal(false);
                callback();
            });
        });
    });

        this.Then(/^I should not see Move Card Up option in edit card menu for card (\d+)$/, function(cardNumber, callback) {
            browser.sleep(2000).then(function() {
                addcardpage.checkMoveCardUpOptionEnabled(Number(cardNumber-1)).then(function(isVisible) {
                    console.log('Move-Up card option is being displayed: ' + isVisible );
                    expect(isVisible).to.equal(false);
                    callback();
                });
            });
        });


    this.Then(/^I click on Move Card Down option in edit card menu for card (\d+)$/, function (cardNumber, callback) {
        browser.sleep(2000).then(function () {
            addcardpage.clickEditCardMenu_v2(cardNumber-1).then(function () {
                browser.sleep(2000).then(function () {
                    addcardpage.moveCardDown(cardNumber-1).then(function () {
                        console.log('>>> card ' + cardNumber + ' is moved DOWN');
                        browser.sleep(2000).then(function () {
                            callback();
                        });
                    });
                });
            });
        });
    });
    this.Then(/^I click on Move Card Up option in edit card menu for card (\d+)$/, function (cardNumber, callback) {
        browser.sleep(2000).then(function () {
            addcardpage.clickEditCardMenu_v2(cardNumber-1).then(function () {
                browser.sleep(2000).then(function () {
                    addcardpage.moveCardUp(cardNumber-1).then(function () {
                        console.log('>>> card ' + cardNumber + ' is moved UP');
                        browser.sleep(2000).then(function () {
                            callback();
                        });
                    });
                });
            });
        });
    });
    this.Then(/^I should see Card (\d+) in focus$/, function (cardNumber, callback) {
        browser.sleep(2000).then(function () {
            addcardpage.getYLocationOfLocator(cardNumber-1).then(function(value1) {
                console.log('>>> y-location of element is (before):' + value1.y);
                addcardpage.getCardInFocus(cardNumber-1).then(function() {
                    addcardpage.getYLocationOfLocator(cardNumber-1).then(function(value2) {
                        console.log('>>> y-location of element is (after): ' + value2.y);
                        var isInFocus = (value1.y <= (value2.y + 10)) || (value2.y <= (value1.y + 10));
                        console.log('Check if card is in focus after moved: ' + isInFocus);
                        expect(isInFocus).to.equal(true);
                        callback();
                    });
                });
            });
        });
    });
    this.Then(/^I click on edit card link in edit card menu for card (\d+)$/, function (cardNumber, callback) {
        console.log('about to click on edit card link');
        addcardpage.clickEditCardLink_v2(cardNumber-1).then(function () {
            console.log('clicked on edit card link');
            callback();
        });
    });
    this.Then(/^I should see a delete card link in edit card menu$/, function (callback) {
        console.log('Verify delete card link is present');
        addcardpage.getDeleteCardLink().then(function (present) {
            expect(present).to.equal(true);
            callback();
        });
    });

    this.Then(/^I should not see add new card link in dashboard menu$/, function (callback) {
        console.log('Verify add new card link is not present');
        addcardpage.chkAddNewCardLink2()
            .then(function (present) {
                console.log('Add new card link in Dashboard menu is present: ' + present);
                expect(present).to.equal(false);
                callback();
            });
    });
    this.Then(/^I should see add new card link in dashboard menu$/, function (callback) {
        console.log('Verify add new card link is not present');
        addcardpage.getAddNewCardLink()
            .then(function (present) {
                expect(present).to.equal(true);
                callback();
            });
    });
    this.Then(/^I should see disabled add new card link in dashboard menu$/, function (callback) {
        console.log('Verify add new card link is disabled');
        addcardpage.chkAddNewCardLinkDisabled()
            .then(function (present) {
                expect(present).to.equal(true);
                callback();
            });
    });

    this.Then(/^I should not see default dashboard link in dashboard menu$/, function (callback) {
        addcardpage.chkSetDefaultDashboardLink().then(function (present) {
            console.log('Set default dashboard link is present: ' + present);
            expect(present).to.equal(false);
            callback();
        });
    });

    this.Then(/^I should see disabled Default Dashboard link in dashboard menu$/, function (callback) {
        console.log('Verify add default dashboard link is present');
        addcardpage.chkSetDefaultDashboardLink()
            .then(function (present) {
                expect(present).to.equal(false);
                callback();
            });
    });
    this.Then(/^I should see refresh data link in dashboard menu$/, function (callback) {
        console.log('Verify add refresh dashboard link is present');
        addcardpage.getRefreshDataLink()
            .then(function (present) {
                expect(present).to.equal(true);
                callback();
            });
    });

    this.Then(/^I should not see refresh data link in dashboard menu$/, function (callback) {
        console.log('Verify add refresh dashboard link is present');
        addcardpage.chkRefreshDataLink()
            .then(function (present) {
                expect(present).to.equal(false);
                callback();
            });
    });

    this.Then(/^I should see pause data link in dashboard menu$/, function (callback) {
        console.log('Verify add pause dashboard link is present');
        addcardpage.getPauseDataLink()
            .then(function (present) {
                expect(present).to.equal(true);
                callback();
            });
    });

    this.Then(/^I should not see pause data link in dashboard menu$/, function (callback) {
        console.log('Verify add pause dashboard link is present');
        addcardpage.chkPauseDataLink()
            .then(function (present) {
                expect(present).to.equal(false);
                callback();
            });
    });

    this.Then(/^I should not see "([^"]*)" link in card menu$/, function (name, callback) {
        console.log('Verify ' + name + ' card link is not present');
        addcardpage.chkEditCardLink2(name)
            .then(function (present) {
                expect(present).to.equal(false);
                callback();
            });
    });
    this.Then(/^I should see time control link in card menu$/, function (callback) {
        console.log('Verify Time Control link is present');
        addcardpage.chkTimeControlLink()
            .then(function (present) {
                expect(present).to.equal(true);
                callback();
            });
    });

    this.Given(/^I click on edit card link in edit card menu with view access$/, function (callback) {
        console.log('about to click on edit card link');
        addcardpage.getEditCardLink().click()
            .then(function () {
                console.log('clicked on edit card link');
                callback();
            });
    });
    this.Then(/^I should see an edit card link in edit card menu$/, function (callback) {
        console.log('Verify edit card link is present');
        addcardpage.getEditCardLink().then(function (present) {
            expect(present).to.equal(true);
            callback();
        });
    });
    this.Then(/^I click on delete card link in edit card menu$/, function (callback) {
        console.log('about to click on delete card link');
        addcardpage.clickDeleteCardLink()
            .then(function () {
                callback();
            });
    });
    this.Then(/^I click on edit card link in edit card menu$/, function (callback) {
        console.log('about to click on edit card link');
        addcardpage.clickEditCardLink().then(function () {
            console.log('clicked on edit card link');
            callback();
        });
    });
    this.Then(/^I should see delete card confirmation popup window$/, function (callback) {
        console.log('Verify delete card confirmation popup is displayed');
        addcardpage.getDeleteCardConfirmPopup().then(function (present) {
            expect(present).to.equal(true);
            callback();
        });
    });
    this.Then(/^I should see OK button in delete card confirmation popup$/, function (callback) {
        console.log('Verify OK button is present in delete card confirmation popup ');
        addcardpage.getDeleteCardConfirmOkBtn().then(function (present) {
            console.log('DeleteCardConfirmOkBtn present: ', present);
            expect(present).to.equal(true);
            callback();
        });
    });
    this.Then(/^I click on OK button in delete card confirmation popup$/, function (callback) {
        console.log('Verify click on OK button is present in delete card confirmation popup ');
        addcardpage.getDeleteCardConfirmOkBtn().then(function (present) {
            console.log("delete card confirmation OK Btn present: ", present);
            addcardpage.clickDeleteCardConfirmOKBtn()
                .then(function () {
                    callback();
                });
        });
    });
    this.Then(/^I should see Cancel button in delete card confirmation popup$/, function (callback) {
        console.log('Verify Cancel button is present in delete card confirmation popup ');
        addcardpage.getDeleteCardConfirmCancelBtn()
            .then(function (present) {
                expect(present).to.equal(true);
                callback();
            });
    });
    this.Then(/^I click on cancel button in delete card confirmation popup$/, function (callback) {
        console.log('about to click cancel button in delete card confirmation popup ');
        addcardpage.getDeleteCardConfirmCancelBtn().click()
            .then(function () {
                callback();
            });
    });
    this.Then(/^I should see "([^"]*)" name in card confirmation popup text$/, function (arg1, callback) {
        console.log('Verify ***' + arg1 + '***  is present in delete card confirmation popup text ');
        addcardpage.getDeleteCardConfirmMsg()
            .then(function (msg) {
                expect(msg).to.contain(arg1);
                console.log(arg1 + ' : is present in delete card confirmation popup message ')
                callback();
            });
    });

    this.Then(/^I click on Cancel button on confirmation popup$/, function (callback) {

        addcardpage.getDeleteCardConfirmCancelBtn().isPresent()
            .then(function (present) {
                console.log('cancel button is present');
                console.log('about to click cancel button in delete card confirmation popup ');
                addcardpage.getDeleteCardConfirmCancelBtn().click()
                    .then(function () {
                        console.log('clicked on cancel button');
                        callback();
                    });
            });

    });

    this.Then(/^I click on Ok button on confirmation popup$/, function (callback) {
        console.log('about to click on OK button in delete confirmation popup');
        addcardpage.clickDeleteCardConfirmOKBtn()
            .then(function () {
                console.log("OK button on delete view confirmation popup is clicked");
                callback();
            });
    });
    this.Then(/^I should not see the card "([^"]*)" with "([^"]*)"$/, function (num, title, callback) {
        console.log('Verify the card title - ' + title);
        browser.sleep(2000).then(function(){
        addcardpage.getAllCards().then(function (cardcnt) {
            console.log('cards displayed on the dashboard: ' + cardcnt);
            if (cardcnt > 0) {
                //addcardpage.getEditCardTitle(num - 1).getAttribute('value')
                addcardpage.getCardTitleHeader(0).getText().then(function (ttl) {
                    browser.pause();
                    expect(ttl).to.not.equal(title);
                    console.log('successfully verified the card with title: ' + ttl + '  does not exist');
                    callback();
                });
            } else {
                // expect("no card").to.not.equal(title);
                console.log('no cards exist on this dashboard');
                callback();
            }
        });});
    });
    this.Then(/^preview button should be present for all types of cards$/, function (callback) {
        console.log('Verify preveiw button is displayed above each card type in card library');
        addcardpage.getAllPreviewBtnInCardLibrary()
            .then(function(previewbuttons){
                expect(previewbuttons).to.be.above(2);
                console.log('number of preview buttons visible on card library page: ' + previewbuttons);
                callback();
            });
    });

    this.Then(/^click on preview button for overview card$/, function (callback) {
        console.log('about to click on preview button for 6 up card');

        addcardpage.clickPreviewBtn(1).then(function () {
            console.log('clicked on preview button for Overview Card');
            callback();
        });
    });
    this.Then(/^click on card thumbnail for "([^"]*)" card$/, function (type, callback) {
        console.log('about to click on thumbnail image  for ' + type + ' card');
        customcardpage.clickThumbnailImageInAddCardLibrary(type).then(function () {
            console.log('clicked on thumbnail image for card: ' + type);
            callback();
        });
    });

    this.Then(/^preview page should open up$/, function (callback) {
        console.log('Verify preview page opens up');
        addcardpage.getPreviewScreen().then(function (present) {
            expect(present).to.equal(true);
            console.log('Preview page is present');
            callback();
        });
    });

    this.Then(/^I should see card preview page open with card title "([^"]*)"$/, function (cardname, callback) {
        console.log('Verify card preview page title is: '+ cardname);
        addcardpage.chkCardPreviewPageTitle(cardname).then(function (present) {
            console.log('Preview page title '+ cardname + ' is present: ' + present);
            expect(present).to.equal(true);
            callback();
        });
    });

    this.Then(/^back button should be present on preview page$/, function (callback) {
        console.log('Verify back button is present on preview page');
        addcardpage.getPreviewBackButton().then(function (present) {
            expect(present).to.equal(true);
            console.log('Back button is present on Preview page');
            callback();
        });
    });
    this.Then(/^widget image should be present on preview page$/, function (callback) {
        console.log('Verify preview image is present on preview page');
        addcardpage.getPreviewImage().then(function (present) {
            expect(present).to.equal(true);
            console.log('Preview image is present');
            callback();
        });
    });
    this.Then(/^widget description text should be present on preview page$/, function (callback) {
        console.log('Verify widget description is present on preview page');
        addcardpage.getPreviewDescription().then(function (present) {
            expect(present).to.equal(true);
            console.log('Widget Description is present');
            callback();
        });
    });
    this.Then(/^Check the preview page description text is "([^"]*)"$/, function (description, callback) {
        console.log('Verify widget description matches with ' + description);
        addcardpage.getPreviewDescriptionText().then(function (text) {
            console.log('Widget Description Actual: '+ text + " -Expected: "+ description);
            expect(text).to.equal(description);
            callback();
        });
    });
    this.Then(/^Add button should be present on preview page$/, function (callback) {
        console.log('Verify add button is present on preview page');
        addcardpage.getPreviewAddButton().then(function (present) {
            expect(present).to.equal(true);
            console.log('Preview page is present');
            callback();
        });
    });

    this.Then(/^click on back button on card preview page$/, function (callback) {
        console.log('about to click on back button');
        addcardpage.clickPreviewBackButton2().then(function () {
            callback();
        });

    });
    this.Then(/^I should see the card library page$/, function (callback) {

        console.log('Verify card library page is open');
        addcardpage.getCardLibraryPage().isPresent().then(function (present) {
            expect(present).to.equal(true);
            console.log('card library page is present');
            callback();
        });
    });

    this.Given(/^I should see all cards$/, function (callback) {
        console.log('Verify preveiw button is displayed above each card type in card library');
        addcardpage.getAllCardTemplates().count()
            .then(function (cards) {
                expect(cards).to.equal(5);
                console.log('number of cards displayed in card library page: ' + cards);
                callback();
            });
    });
    this.Then(/^add button should be present for all types of cards$/, function (callback) {
        console.log('Verify add button is displayed above each card type in card library');
        addcardpage.getAllAddBtnsInCardLibrary().count()
            .then(function (addBtns) {
                expect(addBtns).to.equal(5);
                console.log('number of preview buttons visible on card library page: ' + addBtns);
                callback();
            });
    });
    this.Then(/^I should see Done button on card library page$/, function (callback) {
        console.log('Verify card library page has a done button');
        createviewpage.chkDoneButton().then(function (present) {
            expect(present).to.equal(true);
            console.log('done button is present on card library page ');
            callback();
        });
    });
    this.Then(/^I click on Done button on card library page$/, function (callback) {
        console.log('about to click on done button on card library page');
        createviewpage.clickDoneButton().then(function () {
            console.log('clicked on done button on card library page');
            callback();
        });
    });
    this.Then(/^I should not find any cards in dashboard$/, function (callback) {
        console.log('verify no cards exist in dashboard');
        addcardpage.getFirstCard().then(function (visible) {
            expect(visible).to.equal(false);
            callback();
        });
    });
    this.Then(/^I should see thumbnails for overview card$/, function (callback) {
        console.log('Check overview card thumb nail image exists in add card library');
        addcardpage.getOverviewCardThumbnail().then(function (present) {
            console.log('overview thumbnail image present: ' + present);
            expect(present).to.equal(true);
            callback();
        });
    });
    this.Then(/^I should see 2 or more cards in card library$/, function (callback) {
        addcardpage.GetCardsCountInCardLibrary().then(function(cards){
            console.log('Cards in card library: ' + cards);
            expect(cards).to.above(1);
            callback();
        });

    });

    this.Then(/^I should see thumbnails for (\d+) card$/, function (arg1, callback) {
        // var index = arg1 - 1;
        // var self = this;
        var count = 0;
        //browser.pause();
        addcardpage.getAllThumbnails().then(function (elems) {
            //debugger;
            count = elems.length;
            expect(count).to.equal(2);
            callback();
        });

    });
    //this.Then(/^I click on add card button for "([^"]*)" card$/, function (type, callback) {
    //    console.log('about to click on add button for ' + type + ' card');
    //    var cardType;
    //    switch (type){
    //        case "Custom Card":
    //            customcardpage.clickCustomcardAddBtn().then(function(){callback();});
    //            break;
    //        case "OverView":
    //            customcardpage.clickOverviewcardAddBtn().then(function(){callback();});
    //            break;
    //        default:
    //            customcardpage.clickCustomcardAddBtn().then(function(){callback();});
    //    }
    //});

    this.Then(/^I click on add card button for "([^"]*)" card$/, function (type, callback) {
        console.log('about to click on add button for ' + type + ' card');
        customcardpage.clickAddCardButtonInCardLibrary(type).then(function () {
            callback();
        });
    });

    this.Then(/^I should see the toast alert message$/, function (callback) {
        console.log('verify toast alert message shows up');
        browser.sleep(3000);//wait for the toast message to show up
        addcardpage.getToastAlertMessage().then(function (yes) {
            if (yes) {
                addcardpage.getToastAlertMessageCount().then(function (cnt) {
                    expect(cnt).to.be.above(0);
                    console.log('alert messages count is: ' + cnt);
                    callback();
                });
            } else {
                console.log('ERROR: toast message is not displayed');
                callback();
            }
        })
    });
    this.Then(/^click on close alert message toast icon$/, function (callback) {
        console.log('about to click on close alert icon');
        addcardpage.getToastAlertCloseIcon().then(function (present) {
            console.log('alert message is present');
            if (present) {
                addcardpage.clickToastAlertCloseIcon().then(function () {
                    console.log('clicked on close alert icon');
                    callback();
                });
            } else {
                console.log('alert message is not present');
                callback();
            }
        });
    });
    this.Then(/^I should see alert message "([^"]*)"$/, function (message, callback) {
        console.log('Verify toast alert message');
        addcardpage.getToastAlertMessageCount().then(function (alertMsgCnt) {
            console.log('Toast alert messages count: ' + alertMsgCnt);
            addcardpage.getToastAlertMessageText(alertMsgCnt - 1).then(function (msg) {
                expect(msg.trim()).to.equal(message.trim());
                console.log('actual message: ' + msg + ' expected message: ' + message);
                browser.sleep(5000);
                callback();
            });
        })
    });

    this.Then(/^I click on add preview button for "([^"]*)" card$/, function (type, callback) {
        console.log('about to click on preview button for ' + type + ' card');
        customcardpage.clickAddCardPreviewButtonInCardLibrary(type).then(function () {
            callback();
        });
    });

    this.Then(/^I click on add button on preview page$/, function (callback) {
        console.log('about to click on add button on card Preview page');
        //browser.sleep(15000).then(function(){
        addcardpage.getPreviewAddButton().then(function (yes) {
            console.log('add button present: ', yes);
            if (yes) {
                addcardpage.clickPreviewAddButton().then(function () {
                    console.log('clicked on add button on preview page');
                    callback();
                });
            }
            //})
        });


    });
    this.Then(/^I should see a Cancel button on edit card$/, function (callback) {
        console.log('Verify cancel button is displayed after clicking edit card link from the edit card menu');
        addcardpage.getCancelBtn().isPresent()
            .then(function (present) {
                expect(present).to.equal(true);
                console.log('Cancel button is present on edit card page');
                callback();
            });
    });
    this.Then(/^I click on cancel button on edit card$/, function (callback) {
        console.log('about to click on cancel button on edit card page');
        addcardpage.clickCancelEditCard()
            .then(function () {
                console.log('Clicked on Cancel button on edit card page');
                callback();
            });
    });

    this.Then(/^I should see a Save button on edit card$/, function (callback) {
        console.log('Verify save button is displayed after clicking edit card link from the edit card menu');
        addcardpage.getSaveBtn().isPresent()
            .then(function (present) {
                expect(present).to.equal(true);
                console.log('Save button is present on edit card page');
                callback();
            });
    });
    this.Then(/^I click on save button on edit card$/, function (callback) {
        console.log('about to click on save button on edit card page');
        addcardpage.getSaveBtn().click()
            .then(function () {
                console.log('Clicked on save button on edit card page');
                callback();
            });
    });
    this.Then(/^I click on save button on edit card for card (\d+)$/, function (cardID, callback) {
        console.log('about to click on save button on edit card page');
        addcardpage.getSaveBtn_v2(cardID).then(function () {
                console.log('Clicked on save button on edit card page: ' + cardID);
                callback();
            });
    });

    this.Then(/^I should see edit widget pencil icon for only "([^"]*)" widgets$/, function (num, callback) {
        console.log('Verify edit card displays only ' + num + ' edit widget pencil icons');
        addcardpage.getEditWidgetIconCount()
            .then(function (cnt) {
                expect(cnt).to.equal(Number(num));
                console.log('Edit widget pencil icons displayed: ' + cnt + '. expected: ' + num);
                callback();
            });
    });
    this.Then(/^I should see delete widget icon for all "([^"]*)" widgets$/, function (num, callback) {
        console.log('Verify edit card displays ' + num + ' delete widget icons');
        addcardpage.getDltWidgetIconCount()
            .then(function (cnt) {
                expect(cnt).to.equal(Number(num));
                console.log('Delete widget icons displayed: ' + cnt + '. expected: ' + num);
                callback();
            });
    });
    this.Then(/^I click on delete icon for widget "([^"]*)" in 6up card$/, function (num, callback) {
        console.log('about to click on delete widget icon for widget # ' + num);

        var widget;
        switch (Number(num)) {
            case 1:
                //widget = element(by.css('div.widget-1'));
                widget = element.all(by.css('div#d1')).get(0);
                break;
            case 2:
                //widget = element(by.css('div.widget-2'));
                widget = element.all(by.css('div#d2')).get(0);
                break;
            case 3:
                //widget = element(by.css('div.widget-3'));
                widget = element.all(by.css('div#d3')).get(0);
                break;
            case 4:
                //widget = element(by.css('div.widget-4'));
                widget = element.all(by.css('div#d1')).get(1);
                break;
            case 5:
                //widget = element(by.css('div.widget-5'));
                widget = element.all(by.css('div#d2')).get(1);
                break;
            case 6:
                //widget = element(by.css('div.widget-6'));
                widget = element.all(by.css('div#d3')).get(1);
                break;
        }

        browser.actions().mouseMove(widget).perform().then(function () {
            console.log('mouseover done: ');
            // clicking on first delete icon found on the sixup card because the count goes down when one of the widget is deleted
            addcardpage.getDltWidgetIcon6upEditCard(0).click()
                .then(function () {
                    console.log('Clicked on delete widget icon for widget# ' + num);
                    callback();
                });
        });
    });

    this.Then(/^I should see "([^"]*)" add widget button on the card$/, function (num, callback) {
        console.log('Verify edit card displays only ' + num + ' add widget button');
        addcardpage.getAddWidgetButtonCount().then(function (cnt) {
            expect(cnt).to.equal(Number(num));
            console.log('Add widget buttons displayed: ' + cnt + '. expected: ' + num);
            callback();
        });
    });
    this.Then(/^I change the card "([^"]*)" title to "([^"]*)"$/, function (num, title, callback) {
        console.log('about to enter a following text in edit card tile input field: ' + title);
        addcardpage.getEditCardTitle(num - 1).clear().then(function () {
            addcardpage.getEditCardTitle(num - 1).sendKeys(title).then(function () {
                console.log('following text entered into card title field: ' + title);
                callback();
            });
        });
    });
    this.Then(/^I check the name of the card to "([^"]*)"$/, function (cardname, callback) {
        addcardpage.getCardNameFromArray().then(function (card) {
            console.log('Card name Actual: ' + card + ' Expected: ' + cardname);
            expect(card).to.equal(cardname);
            callback();
        });
    });

    this.Then(/^I click on save to card library option in edit card menu$/, function (callback) {
        console.log('about to click on save to Card Library link in edit card menu');
        addcardpage.clickSaveToCardLibrary().then(function () {
            console.log('Clicked on save to card library');
            browser.sleep(2000).then(function(){
                callback();
            });
        });
    });

    this.Then(/^I should see save to card library option in edit card menu$/, function (callback) {
        //console.log('Verify save to card library link is present in edit card menu');
        addcardpage.chkSTCLoptionInEditMenu().then(function(yes){
            console.log('save card to library link in edit card menu is present: '+ yes);
            expect(yes).to.equal(true);
            callback();
        });
    });
    this.Then(/^I should see Export to PDF option in edit card menu$/, function (callback) {
        //console.log('Verify Export to PDF option link is present in edit card menu');
        addcardpage.chkExportToPDFlink().then(function(yes){
            console.log('Export to PDF option link in edit card menu is present: '+ yes);
            expect(yes).to.equal(true);
            callback();
        });
    });
    this.Then(/^I should see Export Dashboard as PDF option in dashboard kebab menu$/, function (callback) {
        addcardpage.chkExportDashboardToPDFLinkInKebabMenu().then(function(yes) {
            console.log('Export to PDF option link in Kebab menu is present: '+ yes);
            expect(yes).to.equal(true);
            callback();
        });
    });
    this.Then(/^I click on Export Dashboard as PDF option in dashboard kebab menu$/, function (callback) {
        console.log('about to click on Export to PDF option in Kebab menu');
        addcardpage.clickExportDashboardToPDFLink().then(function() {
            console.log('Clicked on Export Dashboard to PDF option');
            callback();
        });
    });
    this.Then(/^I should not see the Export Dashboard to PDF option in kebab menu when there are no cards in the dashboard$/, function (callback) {
        addcardpage.chkExportDashboardToPDFLinkInKebabMenu().then(function(yes) {
            console.log('Export to PDF option link in Kebab menu is present: '+ yes);
            expect(yes).to.equal(false);
            callback();
        });
    });






    this.Then(/^I should not see Export to PDF option in edit card menu$/, function (callback) {
        console.log('Verify Export to PDF option link is not present in edit card menu');

        addcardpage.chkExportToPDFlinkHidden().then(function(yes){
            console.log('Export to PDF option link in edit card menu is hidden: '+ yes);
            expect(yes).to.equal(false);
            callback();
        });
    });
    this.Then(/^I click on Export to PDF option in edit card menu$/, function (callback) {
        console.log('about to click on Export to PDF option in edit card menu');
        addcardpage.clickExportToPDFlink().then(function () {
            console.log('Clicked on Export to PDF option');
            browser.sleep(2000).then(function(){
                callback();
            });
        });
    });
    this.Then(/^I should see the file "([^"]*)" saved$/, function (filename, callback) {
        console.log('check the filename exist: ' + filename);
        default_directory = path.resolve(__dirname, '../../../savedPDFfiles');

        var fileTolook = '../../../savedPDFfiles/' + filename + '.pdf';
        var  filepath = path.resolve(__dirname, fileTolook);
        console.log('looking for : '+filepath);
        if (fs.existsSync(filepath)) {
            console.log('File saved!');
            callback();
        }
        else{
            console.log("file not found");
            expect(" ").to.equal("");
            callback();
        }
    });
    this.Then(/^Delete the file "([^"]*)" if exists$/, function (filename, callback) {
        console.log('delete the file if exist: ' + filename);
        default_directory = path.resolve(__dirname, '../../../savedPDFfiles');
        var fileTolook = '../../../savedPDFfiles/' + filename + '.pdf';
        var  filepath = path.resolve(__dirname, fileTolook);
        console.log('looking for file : '+filepath);

        if (fs.existsSync(filepath)) {
            browser.sleep(2000).then(function(){
                fs.unlink(filepath,function(err){
                    if(err) return console.log(err);
                    browser.sleep(1000);
                    console.log('file deleted successfully');
                    callback();
                });
            })
        }
        else{
            console.log("file not found");
            callback();
        }

    });

    this.Then(/^I should see 3 dots next to the menu option to indicate it needs next action$/, function (callback) {
        //console.log('Verify save card to library link text has 3 dots');
        addcardpage.getSaveToCardLibraryLinkText().then(function(link){
            var dots = link.substr(-3);
            console.log('save card to library link in edit card menu has 3 dots: '+ dots);
            expect(dots).to.equal('...');
            callback();
        });
    });

    this.Then(/^I should see edit card popup in card library$/, function (callback) {
        addcardpage.chkEditCardPopupInCL().then(function(present){
            console.log('Edit card popup is open: '+ present);
            expect(present).to.equal(true);
            callback();
        });
    });

    this.Then(/^I should see save to card library popup window$/, function (callback) {
        addcardpage.chkSTCLP().then(function(present){
            console.log('save to card library popup is open: '+ present);
            expect(present).to.equal(true);
            callback();
        });
    });
    this.Then(/^I should see a label for "([^"]*)" in save to card popup$/, function (labelname, callback) {
        addcardpage.chkSTCLPlabel(labelname).then(function(present){
            console.log('Label for: '+ labelname + ' is present in save to card library popup: '+ present);
            expect(present).to.equal(true);
            callback();
        });
    });

    this.Then(/^I should see a label for "([^"]*)" in edit card popup$/, function (labelname, callback) {
        addcardpage.chkCLECPlabel(labelname).then(function(present){
            console.log('Label for: '+ labelname + ' is present in save to card library popup: '+ present);
            expect(present).to.equal(true);
            callback();
        });
    });

    this.Then(/^I should see star next to title label indicating it is a mandatory field$/, function (callback) {
        addcardpage.getSTCLPspanTxt(0).then(function(txt){
            console.log('displayed next to Title Label: '+ txt);
            expect(txt).to.equal("*");
            callback();
        });
    });
    this.Then(/^I should see star next to description label indicating it is a mandatory field$/, function (callback) {
        addcardpage.getSTCLPspanTxt(1).then(function(txt){
            console.log('displayed next to Description label:  '+ txt);
            expect(txt).to.equal("*");
            callback();
        });
    });
    this.Then(/^I should see Title input field prepopulated with card inherited title "([^"]*)"$/, function (cardname, callback) {
        //console.log('Verify title input has value: '+ cardname);
        addcardpage.getSTCLPtitleValue().then(function(ttl){
            console.log('Title input Actual value: '+ ttl + ' Expected value: ' + cardname);
            expect(ttl).to.equal(cardname);
            callback();
        });
    });
    this.Then(/^I should see description input field in save to card popup$/, function (callback) {
        addcardpage.chkSTCLPdescrptionInput().then(function(yes){
            console.log('description input field is present in STCLP: ' + yes);
            expect(yes).to.equal(true);
            callback();
        });
    });
    this.Then(/^STCLP description input field should be empty$/, function (callback) {
        addcardpage.getSTCLPdescrptionValue().then(function(value){
            console.log('STCLP Description input field contains: ' + value);
            expect(value).to.equal("");
            callback();
        });
    });
    this.Then(/^STCLP description input field should contain "([^"]*)"$/, function (desc, callback) {
        addcardpage.getSTCLPdescrptionValue().then(function(value){
            console.log('STCLP Description input field contains: ' + value);
            expect(value).to.equal(desc);
            callback();
        });
    });
    this.Then(/^I should see a label displayed with text "([^"]*)"$/, function (spanTxt, callback) {
        addcardpage.getSTCLPcharLimitTxt().then(function(value){
            console.log('Actual: ' + value + ' Expected: ' + spanTxt);
            expect(value).to.equal(spanTxt);
            callback();
        });
    });
    this.Then(/^I enter "([^"]*)" in the description input field$/, function (Desc, callback) {
        addcardpage.getSTCLPdescriptionInput().clear().then(function(){
            addcardpage.getSTCLPdescriptionInput().sendKeys(Desc).then(function(){
                browser.sleep(5000).then(function(){
                    console.log(Desc + ' has been entered into STCLP description field');
                    callback();
                });
            });
        });
    });
    this.Then(/^I enter "([^"]*)" in the description input field of edit card popup$/, function (Desc, callback) {
        addcardpage.getCLECPdescriptionInput().clear().then(function(){
            addcardpage.getCLECPdescriptionInput().sendKeys(Desc).then(function(){
                browser.sleep(8000).then(function(){
                    console.log(Desc + ' has been entered into CLECP description field');
                    callback();
                });
            });
        });
    });

    this.Then(/^I enter "([^"]*)" in the STCLP title input field$/, function (title, callback) {
        browser.sleep(7000).then(function(){
            addcardpage.getSTCLPtitleInput().isPresent().then(function(yes){
                if(yes){
                    addcardpage.getSTCLPtitleInput().clear().then(function(){
                        addcardpage.getSTCLPtitleInput().sendKeys(title).then(function(){
                            browser.sleep(1000).then(function(){
                                console.log(title + ' has been entered into STCLP Title field');
                                callback();
                            });
                        });
                    });
                }else{
                    console.log('element did not load');
                }
            })
        })

    });

    this.Then(/^I clear the description input field$/, function ( callback) {
        addcardpage.getSTCLPdescriptionInput().clear().then(function(){
            addcardpage.getSTCLPdescriptionInput().sendKeys(protractor.Key.DELETE).then(function(){
            browser.sleep(2000).then(function(){
                addcardpage.getSTCLPdescrptionValue().then(function(desc){
                    console.log(' cleared the description field:*' + desc + "*");
                    callback();
                });
            });
            });
        });
    });
    this.Then(/^"([^"]*)" button in save to card library popup should be disabled "([^"]*)"$/, function (button, enable,  callback) {
        if (button === "cancel") {
            addcardpage.isSTCLPcancelBtnDisabled().then(function(yeahNah){
                if (enable === "true"){
                    console.log('Cancel button should be disabled: ' + yeahNah);
                    expect(yeahNah).to.equal('true');
                    callback();
                }else if (enable === "false"){
                    console.log('Cancel button should NOT be disabled: ' + yeahNah);
                    expect(yeahNah).to.equal(null);
                    callback();
                }
            })
        }else if (button === "save"){
            addcardpage.isSTCLPsaveBtnDisabled().then(function(yeahNah){
                if (enable === "true"){
                    console.log('Save button should be disabled: ' + yeahNah);
                    expect(yeahNah).to.equal('true');
                    callback();
                }else if (enable === "false"){
                    console.log('Save button should NOT be disabled: ' + yeahNah);
                    expect(yeahNah).to.equal(null);
                    callback();
                }
            })
        }
    });

    this.Then(/^"([^"]*)" button in edit card popup should be disabled "([^"]*)"$/, function (button, enable,  callback) {
        if (button === "cancel") {
            addcardpage.isCLECPcancelBtnDisabled().then(function(yeahNah){
                if (enable === "true"){
                    console.log('Cancel button should be disabled: ' + yeahNah);
                    expect(yeahNah).to.equal('true');
                    callback();
                }else if (enable === "false"){
                    console.log('Cancel button should NOT be disabled: ' + yeahNah);
                    expect(yeahNah).to.equal(null);
                    callback();
                }
            })
        }else if (button === "save"){
            addcardpage.isCLECPsaveBtnDisabled().then(function(yeahNah){
                if (enable === "true"){
                    console.log('Save button should be disabled: ' + yeahNah);
                    expect(yeahNah).to.equal('true');
                    callback();
                }else if (enable === "false"){
                    console.log('Save button should NOT be disabled: ' + yeahNah);
                    expect(yeahNah).to.equal(null);
                    callback();
                }
            })
        }
    });

    this.Then(/^I click on "([^"]*)" button in save to card library popup$/, function (button,  callback) {
        if (button === "cancel") {
            addcardpage.clickSTCLPcancelBtn().then(function(){
                console.log('clicked on STCLP cancel button');
                callback();
            })
        }else if (button === "save"){
            addcardpage.clickSTCLPsaveBtn().then(function(){
                console.log('clicked on STCLP Save button');
                callback();
            })
        }
    });

    this.Then(/^I click on "([^"]*)" button in edit card popup$/, function (button,  callback) {
        if (button === "cancel") {
            addcardpage.clickCLECPcancelBtn().then(function(){
                console.log('clicked on CLECP cancel button');
                callback();
            })
        }else if (button === "save"){
            addcardpage.clickCLECPsaveBtn().then(function(){
                console.log('clicked on CLECP Save button');
                callback();
            })
        }
    });

    this.Then(/^I select "([^"]*)" card radio button in SCTLP$/, function (button,  callback) {
        if (button === "fixed") {
            addcardpage.clickSTCLPFixedRadioBtn().then(function(){
                console.log('clicked on STCLP Fixed radio button');
                callback();
            })
        }else if (button === "template"){
            addcardpage.clickSTCLPTemplateRadioBtn().then(function(){
                console.log('clicked on STCLP Template Radio button');
                callback();
            })
        }
    });
    this.Then(/^I get the Initial count of cards in card library$/, function ( callback) {
        createviewpage.clickCardActionMenuBtn().then(function () {
            console.log('clicked on card action menu button');
            addcardpage.clickAddNewCardLink().then(function () {
                addcardpage.GetCardsCountInCardLibrary().then(function (cards) {
                    cardsInCardLibrary = cards;
                    console.log('Initial number of cards in card library: ' + cardsInCardLibrary);
                    createviewpage.clickDoneButton().then(function () {
                        callback();
                    });
                });
            });
        });
    });
    this.Then(/^I set the count of cards in card library$/, function ( callback) {
        addcardpage.GetCardsCountInCardLibrary().then(function (cards) {
            cardsInCardLibrary = cards;
            console.log('Initial number of cards in card library: ' + cardsInCardLibrary);
            callback();
        });
    });
    this.Then(/^I should check card count in card library is increased by "([^"]*)"$/, function (newcards, callback) {
        console.log('Initial Cards in card library: ' + cardsInCardLibrary);
        browser.sleep(2000).then(function(){
            addcardpage.GetCardsCountInCardLibrary().then(function(cards){
                console.log('Cards in card library: ' + cards);
                var shouldbeCards = cardsInCardLibrary + Number(newcards);
                console.log('Cards should be: ' + shouldbeCards);
                expect(cards).to.equal(shouldbeCards);
                callback();
            });
        });
    });
    this.Then(/^I should check card count in card library is reduced by "([^"]*)"$/, function (newcards, callback) {
        console.log('Initial Cards in card library: ' + cardsInCardLibrary);
        addcardpage.GetCardsCountInCardLibrary().then(function(cards){
            console.log('Cards in card library- Actual# ' + cards + ' -Expected# ' + shouldbeCards);
            var shouldbeCards = cardsInCardLibrary - Number(newcards);
            expect(cards).to.equal(shouldbeCards);
            callback();
        });
    });
    this.Then(/^I should verify "([^"]*)" card title as "([^"]*)"$/, function (cardnum, cardttl, callback) {
        addcardpage.GetCardsCountInCardLibrary().then(function(cards){

            if (cardnum === "first") {
                addcardpage.getCardTitleFromCardLib(0).then(function(txt){
                    console.log('first card title: ' + txt);
                    expect(txt).to.equal(cardttl);
                    callback();
                })
            }else if (cardnum === "last"){
                addcardpage.getCardTitleFromCardLib(Number(cards)-1).then(function(txt){
                    console.log('last card title: '+ txt);
                    expect(txt).to.equal(cardttl);
                    callback();
                })
            }else if (cardnum === "last-1"){
                addcardpage.getCardTitleFromCardLib(Number(cards)-2).then(function(txt){
                    console.log('last-1 card title: ' + txt);
                    callback();
                })
            }
        });
    });

    this.Then(/^Description field in SCTLP should be blank$/, function ( callback) {
        addcardpage.getSTCLPdescrptionValue().then(function(desc){
            console.log(' description field contains: ' + desc);
            expect(desc).to.equal('');
            callback();
        });
    });

    this.Then(/^First radio button should be selected by default$/, function ( callback) {
        addcardpage.isSTCLPTemplateRadioBtnChecked().then(function(is){
            console.log('is STCLP Template RadioBtn selected/checked : ' + is);
            console.log('First radio button is selected/checked');
            expect(is).to.equal('true');
            callback();
        });
    });

    this.Then(/^Second radio button should not be selected by default$/, function ( callback) {
        addcardpage.isSTCLPFixedRadioBtnChecked().then(function(is){
            console.log('is STCLP Fixed RadioBtn selected/checked: ' + is);
            console.log('Second radio button is not selected/checked');
            expect(is).to.equal(null);
            callback();
        });
    });

    this.Then(/^First radio button in popup should say "([^"]*)"$/, function (label, callback) {
        addcardpage.getSTCLPTemplateRadioBtnLabel().then(function(text){
            console.log('STCLP Template RadioBtn label text : ' + text);
            expect(text).to.contain(label);
            callback();
        });
    });

    this.Then(/^Second radio button in popup should say "([^"]*)"$/, function (label, callback) {
        addcardpage.getSTCLPFixedRadioBtnLabel().then(function(text){
            console.log('STCLP Fixed RadioBtn label text : ' + text);
            expect(text).to.contain(label);
            callback();
        });
    });

    this.Then(/^I should see "([^"]*)" option in left nav under dashboard micro app$/, function (link, callback) {
        browser.sleep(3000).then(function(){
            addcardpage.chkCardLibraryLinkInLeftNav(link).then(function(present){
                console.log('Card Library Link present in Left Nav : ' + present);
                expect(present).to.equal(true);
                callback();
            });
        });
    });

    this.Then(/^I click on "([^"]*)" option in left nav under dashboard micro app$/, function (link, callback) {
        addcardpage.clickCardLibraryLinkInLeftNav(link).then(function(){
            console.log('Clicked on Card Library Link present in Left Nav');
            callback();
        });
    });

    this.Then(/^Check card library page title$/, function (callback) {
        browser.sleep(1000).then(function(){
            addcardpage.getCLPageTitle().then(function(title){
                console.log('Card Library page title is : ' + title);
                expect(title).to.equal('Card Library');
                callback();
            });
        });
    });

    this.Then(/^I should see kebab menu on last card$/, function (callback) {
        addcardpage.GetCardsCountInCardLibrary().then(function(cards){
            addcardpage.chkCLKebabMenu(cards-1).then(function(present){
                console.log('kebab menu present on last card : ' + present);
                expect(present).to.equal(true);
                callback();
            });
        });
    });

    this.Then(/^check image count in "([^"]*)" card$/, function (cardnum, callback) {
        var thumbs = element.all(by.css('div.card-thumb-img'));

        thumbs.count().then(function(cnt){
            console.log('number of thumb images in card library : '+ cnt);
            var onethumb = thumbs.get(cnt-1);
            var images = onethumb.all(by.css('img'));
            images.count().then(function(num){
                console.log('number of images '+ num);
                expect(num).to.equal(6);
                callback();
            });
        });
    });


    this.Then(/^I click on image container of the "([^"]*)" card in card library$/, function (cardnum, callback) {
        addcardpage.GetCardsCountInCardLibrary().then(function(cards){
            if (cardnum === "last"){
                addcardpage.clickThumbnailImageCardLibrary(cards-1).then(function(){
                    console.log('clicked on card image# : ' + cards-1);
                    callback();
                });
            }else if (cardnum === "last-1"){
                addcardpage.clickThumbnailImageCardLibrary(cards-2).then(function(){
                    console.log('clicked on card image# : ' + cards-2);
                    callback();
                });
            }
        });

    });

    this.Then(/^I click on "([^"]*)" of last card in card library$/, function (element, callback) {
        addcardpage.GetCardsCountInCardLibrary().then(function(cards){
            if (element === "kebab menu") {
                addcardpage.clickCLKebabMenu(cards-1).then(function(){
                    console.log('clicked on kebab menu on last card');
                    callback();
                });
            }else if(element === "edit link"){
                addcardpage.clickCLEditCardLink(cards-1).then(function(){
                    console.log('clicked on edit link on last card');
                    callback();
                });
            }else if(element === "delete link"){
                addcardpage.clickCLDeleteCardLink(cards-1).then(function(){
                    console.log('clicked on delete link on last card');
                    callback();
                });
            }else{
                console.log(element + ' is incorrect element. correct elements are kebab menu, edit link, delete link');
                callback();
            }
        });
    });

    this.Then(/^I should see Delete Card option in kebab menu of last card$/, function (callback) {
        addcardpage.GetCardsCountInCardLibrary().then(function(cards){
            addcardpage.chkCLDeleteCardLink(cards-1).then(function(present){
                console.log('Delete Card option in kebab menu present on last card : ' + present);
                expect(present).to.equal(true);
                callback();
            });
        });
    });

    this.Then(/^I should see Edit Card option in kebab menu of last card$/, function (callback) {
        addcardpage.GetCardsCountInCardLibrary().then(function(cards){
            addcardpage.chkCLEditCardLink(cards-1).then(function(present){
                console.log('Edit Card option in kebab menu present on last card : ' + present);
                expect(present).to.equal(true);
                callback();
            });
        });
    });

    this.Then(/^I should see Edit Card popup in card library page$/, function (callback) {
        addcardpage.chkCLEditCardPopup().then(function(present){
            console.log('Edit Card popup in card library page is open: '+ present);
            expect(present).to.equal(true);
            callback();
        });
    });

    this.Then(/^I click on Edit Card option in kebab menu of last card$/, function (callback) {
        addcardpage.GetCardsCountInCardLibrary().then(function(cards){
            addcardpage.clickCLEditCardLink(cards-1).then(function(present){
                console.log('clicked on Edit Card option in kebab menu');
                callback();
            });
        });
    });

    this.Then(/^I click on Edit Card option in kebab menu of last card$/, function (callback) {
        addcardpage.GetCardsCountInCardLibrary().then(function(cards){
            addcardpage.clickCLEditCardLink(cards-1).then(function(present){
                console.log('clicked on Edit Card option in kebab menu');
                callback();
            });
        });
    });

    this.Then(/^First radio button in edit card popup should say "([^"]*)"$/, function (label, callback) {
        addcardpage.getCLECPTemplateRadioBtnLabel().then(function(text){
            console.log('CLECP Template RadioBtn label text : ' + text);
            expect(text).to.contain(label);
            callback();
        });
    });

    this.Then(/^Second radio button in edit card popup should say "([^"]*)"$/, function (label, callback) {
        addcardpage.getCLECPFixedRadioBtnLabel().then(function(text){
            console.log('CLECP Fixed RadioBtn label text : ' + text);
            expect(text).to.contain(label);
            callback();
        });
    });



    this.Then(/^I should see "(\d+)" images displayed in 2 rows for "([^"]*)" card$/, function (noOfImages, cardnum, callback) {
        addcardpage.GetCardsCountInCardLibrary().then(function(cards){
            if (cardnum === "last"){
                addcardpage.getImageCountOfCard(cards-1).then(function(count){
                    console.log('Should have : ' + noOfImages);
                    console.log('Number of images displayed on last card : ' + count);
                    // expect(count).to.equal(noOfImages);
                    callback();
                });
            }else if (cardnum === "last-1"){
                addcardpage.getImageCountOfCard(cards-2).then(function(count){
                    console.log('Number of images displayed on last-1 card : ' + count);
                    // expect(count).to.equal(Number(noOfImages));
                    callback();
                });
            }
        });
    });



    this.Then(/^I should see star next to title label indicating it is a mandatory field in edit card popup$/, function (callback) {
        addcardpage.getCLECPspanTxt(0).then(function(txt){
            console.log('displayed next to Title Label: '+ txt);
            expect(txt).to.equal("*");
            callback();
        });
    });
    this.Then(/^I should see star next to description label indicating it is a mandatory field in edit card popup$/, function (callback) {
        addcardpage.getCLECPspanTxt(1).then(function(txt){
            console.log('displayed next to Description label:  '+ txt);
            expect(txt).to.equal("*");
            callback();
        });
    });
    this.Then(/^I should see Title input field prepopulated with card inherited title "([^"]*)" in edit card popup$/, function (cardname, callback) {
        //console.log('Verify title input has value: '+ cardname);
        addcardpage.getCLECPtitleValue().then(function(ttl){
            console.log('Title input Actual value: '+ ttl + ' Expected value: ' + cardname);
            expect(ttl).to.equal(cardname);
            callback();
        });
    });
    this.Then(/^I should see description input field in edit card popup$/, function (callback) {
        addcardpage.chkCLECPdescrptionInput().then(function(yes){
            console.log('description input field is present in STCLP: ' + yes);
            expect(yes).to.equal(true);
            callback();
        });
    });
    this.Then(/^CLECP description input field should be empty$/, function (callback) {
        addcardpage.getCLECPdescrptionValue().then(function(value){
            console.log('STCLP Description input field contains: ' + value);
            expect(value).to.equal("");
            callback();
        });
    });

    this.Then(/^CLECP description input field should contain "([^"]*)"$/, function (desc, callback) {
        addcardpage.chkCLECPdescrptionInput().then(function(yes){
            if(yes){
                addcardpage.getCLECPdescrptionValue().then(function(value){
                    console.log('CLECP Description input field contains: ' + value);
                    expect(value).to.equal(desc);
                    callback();
                });
            }else{
                console.log('CLECP description field is not present');
                callback();
            }

        });
    });

    this.Then(/^I should see a label displayed with text "([^"]*)" in edit card popup$/, function (spanTxt, callback) {
        addcardpage.getCLECPcharLimitTxt().then(function(value){
            console.log('Actual: ' + value + ' Expected: ' + spanTxt);
            expect(value).to.equal(spanTxt);
            callback();
        });
    });

    this.Then(/^First radio button in edit card popup should not be selected by default$/, function ( callback) {
        addcardpage.isCLECPTemplateRadioBtnChecked().then(function(is){
            console.log('is CLECP Template RadioBtn selected/checked : ' + is);
            expect(is).to.equal(null);
            callback();
        });
    });

    this.Then(/^Second radio button in edit card popup should be selected by default$/, function ( callback) {
        addcardpage.isCLECPFixedRadioBtnChecked().then(function(is){
            console.log('is CLECP Fixed RadioBtn selected/checked: ' + is);
            expect(is).to.equal('true');
            callback();
        });
    });

};
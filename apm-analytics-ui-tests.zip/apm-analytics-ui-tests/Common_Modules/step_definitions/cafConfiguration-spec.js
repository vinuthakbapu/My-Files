/**
 * Caf Configuration spec
 */

module.exports = function() {

    analyticName = browser.params.analyticName;

    this.Then(/^the configuration page should contain asset add icon$/, function (callback) {
        cafConfigurationPage.isConfigurationAssetAddIconDisplayed().then( function(boolean) {
            assert.equal(boolean, true, "Configuration asset add icon is not displayed");
            callback();
        });
    });


    this.Then(/^the configuration page should contain segment add icon$/, function (callback) {
        cafConfigurationPage.isConfigurationSegmentAddIconDisplayed().then( function(boolean) {
            assert.equal(boolean, true, "Configuration segment add icon is not displayed");
            callback();
        });
    });

    this.Then(/^the configuration page should contain site add icon$/, function (callback) {
        cafConfigurationPage.isConfigurationSiteAddIconDisplayed().then( function(boolean) {
            assert.equal(boolean, true, "Configuration site add icon is not displayed");
            callback();
        });
    });

    this.Then(/^the configuration page should contain enterprise add icon$/, function (callback) {
        cafConfigurationPage.isConfigurationEnterpriseAddIconDisplayed().then( function(boolean) {
            assert.equal(boolean, true, "Configuration enterprise add icon is not displayed");
            callback();
        });
    });

    this.Then(/^the configuration page should not contain asset add icon$/, function (callback) {
        cafConfigurationPage.isConfigurationAssetAddIconNotDisplayed().then( function(boolean) {
            assert.equal(boolean, false, "Configuration asset add icon is displayed");
            callback();
        });
    });


    this.Then(/^the configuration page should not contain segment add icon$/, function (callback) {
        cafConfigurationPage.isConfigurationSegmentAddIconNotDisplayed().then( function(boolean) {
            assert.equal(boolean, false, "Configuration segment add icon is displayed");
            callback();
        });
    });

    this.Given(/^the user should see the header as configuration$/, function (callback) {
        cafConfigurationPage.configurationHeader().isDisplayed().then(function (visible) {
            expect(visible).to.equal(true);
            callback();
        });
    });

    this.Then(/^the configuration page should not contain site add icon$/, function (callback) {
        cafConfigurationPage.isConfigurationSiteAddIconNotDisplayed().then( function(boolean) {
            assert.equal(boolean, false, "Configuration site add icon is displayed");
            callback();
        });
    });

    this.Then(/^the configuration page should not contain enterprise add icon$/, function (callback) {
        cafConfigurationPage.isConfigurationEnterpriseAddIconNotDisplayed().then( function(boolean) {
            assert.equal(boolean, false, "Configuration enterprise add icon is displayed");
            callback();
        });
    });

};

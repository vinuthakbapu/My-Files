module.exports = function () {

    this.Then(/^I click on template dropdown and create a new adhoc whatif$/, function (callback) {
        // expect( element(by.css('#layout-view-selector')).isPresent()).to.eventually.be.eql(true).notify(callback);
        aem = new ElementManager('./../../../Test_Modules/Analysis/whatif-element-repo.json');
        TestHelper.setElementManager(aem);
        TestHelper.elementToBeClickable("currentPage", "templateDropdownArrow").then(function () {
            console.log("click on dropdown")
            TestHelperPO.elementToBeClickable(element(by.cssContainingText('span.style-scope.pae-dropdown','New What-If Analysis'))).then(function () {
                console.log("came here...");
                browser.sleep(2000).then(function () {
                    callback();
                })
            });
        });
    });

    this.When(/^I select whatif from dropdown$/, function (callback) {
        // expect( element(by.css('#layout-view-selector')).isPresent()).to.eventually.be.eql(true).notify(callback)

        aem = new ElementManager('./../../../Test_Modules/Analysis/whatif-element-repo.json');
        TestHelper.setElementManager(aem);
        TestHelper.elementToBeClickable("currentPage", "templateDropdownArrow").then(function () {
            console.log("click on dropdown")
            TestHelperPO.elementToBeClickable(element(by.cssContainingText('span.style-scope.pae-dropdown','New What-If Analysis'))).then(function () {
                console.log("came here...");
                browser.sleep(2000).then(function () {
                    callback();
                })
            });
        });

    });

    this.Then(/^I should see the model broswer be populated$/, function (callback) {
        var dragList=whatifPage.getDragList();
        // var dragElement=dragList.first();
        // var dropElement = $('.chart-target.chart-target-overlay.style-scope.chart-whatif');
        expect(dragList).to.exist
        // var EC = protractor.ExpectedConditions;
        
        // expect(EC.elementToBeClickable(dragElement));
    });
    // this.When(/^User drags and drops the first model config onto whatif chart$/, function (callback) {
    //     var dragList=whatifPage.getDragList();
    //     var dragElement=dragList.first();
    //     var dropElement = $('.chart-target.chart-target-overlay.style-scope.chart-whatif');
    //     var EC = protractor.ExpectedConditions;
    //     browser.wait(EC.elementToBeClickable(dragElement));
    //     TestHelperPO.dragAndDrop(dragElement, dropElement)
    //         .then(function () {
    //             browser.sleep(10000);
    //             callback();
    //         });
    // });


    this.When(/^User drags and drops the first model config onto whatif chart$/, function (callback) {
        // var dragElement = element(by.cssContainingText('px-tree-view-leaf>#label', 'powerpuff-deploy'));
        var dragList=element.all(by.css('div#prefix[draggable="true"]'));

        var dragElement=dragList.first();
       // var dropElement = $('.chart-target.chart-target-overlay.style-scope.chart-forecast');
        var dropElement = $('.onebyone-chart-container');
        var EC = protractor.ExpectedConditions;
        browser.wait(EC.elementToBeClickable(dragElement));
        TestHelperPO.dragAndDrop(dragElement, dropElement)
            .then(function () {
                browser.sleep(10000);
                callback();
            });
        browser.sleep(2000);
    });


    this.Then(/^I should see whatif graph data points$/, function (callback) {
        browser.sleep(20000).then(function () {
            console.log('Verify data points are present');
            analysisPage.getGraphElement().getAttribute('d').then(function (chartElement) {
                console.log("graph points:" + JSON.stringify(chartElement));
                currDataPoints = chartElement.split(',').length
                var datapointsPresent = currDataPoints > 5;
                expect(datapointsPresent).to.equal(true);
                callback();
            });
        });
    });
}; 

var myStepDefinitionsWrapper;
myStepDefinitionsWrapper = function () {
    'use strict';

    var fs = require('fs');
    var rStream = fs.createReadStream(path.resolve(__dirname, '../TestData/apmTSData.json'));
    var data = '';
    rStream.setEncoding('utf8');
    rStream.on('data', function(chunk) {
        data+=chunk;
    });
    rStream.on('end', function() {
        Logger.info('Read APM TS data');
        Logger.info(data);
    });

    var buffer = new Buffer('ingestor.496bb641-78b5-4a18-b1b7-fde29788db38.991e5c23-3e9c-4944-b08b-9e83ef0ab598:');
    var base64s = buffer.toString('base64');
    Logger.info(base64s);

    var adminUserOpts = {
        url: 'https://d1730ade-7c0d-4652-8d44-cb563fcc1e27.predix-uaa.run.aws-usw02-pr.ice.predix.io/oauth/token',
        headers:{
            'Authorization': 'Basic ' + base64s,
            'Content-Type': 'application/x-www-form-urlencoded'
        },
        body:{
            'grant_type' : 'password',
            'client_id' :'ingestor.496bb641-78b5-4a18-b1b7-fde29788db38.991e5c23-3e9c-4944-b08b-9e83ef0ab598',
            'username' : '73643f3f-1477-4ccb-9b41-3e2e435a54bd_ingestor',
            'password' : 'Pa55w0rd'
        }
    }

    this.Given(/^Post data to APM Time series$/, function (callback) {
        RestHelper.getAccessToken(adminUserOpts.url, adminUserOpts.headers, adminUserOpts.body,function(err, token){
            var opts = {
                url: 'https://apm-timeseries-query-svc-rc.int-app.aws-usw02-pr.predix.io/v1/data/add?file_type=json',
                headers: {
                    'Content-Type': 'application/json',
                    'tenant':'73643f3f-1477-4ccb-9b41-3e2e435a54bd',
                    'Authorization':'Bearer ' +  token
                },
                body : data
            };

            console.log("getting token here: "+ JSON.stringify(token))
            RestHelper.executePostRequest(opts.url, opts.headers, opts.body, function(err, res){
                Logger.info("Posted APM TS Data : " + JSON.stringify(res));
                console.log("Posted APM TS Data : " + JSON.stringify(res));
                callback();
            })
        });
    });

    this.Then(/^Get APM Time Series Data$/, function (callback) {
        RestHelper.getAccessToken(adminUserOpts.url, adminUserOpts.headers, adminUserOpts.body,function(err, token){
            var opts = {
                url:'https://apm-timeseries-query-svc-rc.int-app.aws-usw02-pr.predix.io/v2/time_series?operation=raw&startTime=2018-01-01T00:00:00.000&sampleCount=1000&tagList=OO_Tag_Temperature_ID20',
                headers: {
                    'Content-Type': 'application/json',
                    'tenant':'73643f3f-1477-4ccb-9b41-3e2e435a54bd',
                    'Authorization':'Bearer ' +  token
                },
                body : data
            };

            RestHelper.executeGetRequest( opts.url, opts.headers, function (err, res) {
                //var uuid = JSON.parse(JSON.stringify(res.body)).dataObject[0].uuid;
                console.log('GET APM TS Data : ' + JSON.stringify(res.body));
                Logger.info('GET APM TS Data : ' + JSON.stringify(res.body));
                callback();
            });
        });
    });
};
module.exports = myStepDefinitionsWrapper;
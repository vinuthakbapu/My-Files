module.exports = function () {

    'use strict';

    let sharedTimeStamp;
    let analyticEntry;
    let deployment;
    let orchestration;
    let path = browser.params.appHubpath;


    function getSharedTimeStamp() {
        if (!sharedTimeStamp) {
            sharedTimeStamp = Math.floor(Date.now() / 1000);
        }
        return sharedTimeStamp;
    }

    const formatMapObj = (tagObj, setType, setMonitoredEntityType) => {
        const mapObj = {};
        mapObj['@type'] = setType;
        mapObj.tagName = tagObj.name;
        mapObj.tagUri = tagObj.uri;
        mapObj.tagSourceKey = tagObj.sourceKey;
        mapObj.entityUri = tagObj.monitoredEntityUri;
        mapObj.entitySourceKey = tagObj.monitoredEntitySourceKey;
        mapObj.entityType = setMonitoredEntityType;
        mapObj.uom = tagObj.tagType;
        return mapObj;
    };

    const generateDefaultOnDemand = () => ({
        deployType: "DeployOnDemand",
        startTime: new Date().getTime() - 1,
        endTime: new Date().getTime(),
        samplingInterval: {
            timeValue: 1,
            timeUnit: 'MINUTES',
        },
    });

    function createAnalyticWithTemplate(callback) {
        const analyticName = 'analyticForUiAutomationTest-' + getSharedTimeStamp();
        console.log("Analytic Name: "+analyticName)
        let formData = {
            file: fs.createReadStream('Common_Modules/TestData/thresholdAnalytic-java.jar'),
            analytic: '{"@type": "analyticEntryPx", "name": "' + analyticName + '", "author": "Test", "analyticVersion": "1.0.0", "analyticLanguageVersion": "1.8", "analyticLanguage": "Java", "primaryCategory": "Monitoring", "secondaryCategory": "Monitoring", "analyticDefine": {"@type":"analyticDefinePx", "inputs": [{"name":"temp_today","unitGroup":"","unit":"Fahrenheit","dataType":"Double","isRequired": true,"description":"Todays temperature. Map with any temperature tag" }], "constants": [{"name": "threshold", "unit": "FAHRENHEIT", "description": "threshold", "value": "30", "dataType": "double"} ], "outputs": [{"name": "mean", "unit": "none", "description": "mean", "dataType": "double"}, {"name": "deviation", "unit": "FAHRENHEIT", "description": "deviation from Mean", "dataType": "double"} ] } }'
        };
        browser.sleep(1000).then(function () {
            //restUtil.makeRequest("caf/api/caf-mgmt-svc/v1/analyticEntries", 'POST', formData, 'multipart/form-data').then(function (resp) {
            restUtil.makeRequest("caf" +path + "/api/caf-mgmt-svc/v1/analyticEntries", 'POST', formData, 'multipart/form-data').then(function (resp) {
                console.log ("response: "+JSON.stringify(resp))
                analyticEntry = JSON.parse(resp.body);
                callback();
            });
        });
    }


    function createAnalyticWithoutTemplate(callback) {
        const analyticName = 'analyticForUiAutomationTest-' + getSharedTimeStamp();
        let formData = {
            file: fs.createReadStream('Common_Modules/TestData/thresholdAnalytic-java.jar'),
            analytic: '{"@type": "analyticEntryPx","name": "' + analyticName + '","author": "Test","analyticVersion": "1.0.0","analyticLanguageVersion": "1.8","analyticLanguage": "Java","primaryCategory": "Monitoring","secondaryCategory": "Prognostics"}'
        };
        console.log("analyticName is ", analyticName)
        //restUtil.makeRequest("caf/api/caf-mgmt-svc/v1/analyticEntries", 'POST', formData, 'multipart/form-data').then(function (resp) {
        restUtil.makeRequest("caf" + path + "/api/caf-mgmt-svc/v1/analyticEntries", 'POST', formData, 'multipart/form-data').then(function (resp) {
            analyticEntry = JSON.parse(resp.body);
            console.log("analyticEntry object ", analyticEntry)
            console.log("template url is ", analyticEntry.uri)
            callback();
        });
    }


    function createDeployment(callback) {
        const deploymentName = 'deployment-' + getSharedTimeStamp();
        let data = '{"@type": "deploymentPx","name": "' + deploymentName + '", "templateUri": "' + analyticEntry.uri + '"}';
        //restUtil.makeRequest("caf/api/caf-mgmt-svc/v1/deployments", 'POST', JSON.parse(data), 'application/json').then(function (resp) {
        restUtil.makeRequest("caf" + path + "/api/caf-mgmt-svc/v1/deployments", 'POST', JSON.parse(data), 'application/json').then(function (resp) {
            deployment = resp.body;
            callback();
        });
    }


    function setCustomAttributeTrue(config, callback) {
        let data = '{"templateType": "HierarchicalType","adciGenerationType": "All Asset", "customAttributes": '+ config + '}';
        console.log("Contents: " + data);
        restUtil.makeRequest("caf" + path + "/api/caf-mgmt-svc/v1/analytics/config/tenantConfigs", 'PUT', JSON.parse(data), 'application/json').then(function (resp) {
            //deployment = resp.body;
            console.log ("response: "+JSON.stringify(resp));
            callback();
        });
    }

    function createOrchestrationPx(callback) {
        const orchestrationName = 'orchestrationUI-' + getSharedTimeStamp();
        console.log("Orchestration Name: " + orchestrationName);
        let data = '{"@type": "orchestrationPx","name": "' + orchestrationName + '","author": "Automation", "description": "UI automation", "runtimeName": "Predix"}';
        restUtil.makeRequest("caf" + path + "/api/caf-mgmt-svc/v1/orchestrations", 'POST', JSON.parse(data), 'application/json').then(function (resp) {
            console.log("response: " + JSON.stringify(resp));
            orchestration = resp.body;
            callback();
        });
    }

    function updateOrchestrationwithAnalytic(callback) {
        console.log("data");
        console.log("name is " + orchestration.name);
        let uri = "caf" + path + "/api/caf-mgmt-svc/v1" + orchestration.uri;
        // let data = '{"@type":"orchestrationPx", "uri":"'+ orchestration.uri +'", "name":"'+ orchestration.name + '","author":"automation",'
        //     + '"orchestrationType":"ORCHESTRATION_NORMAL","orchestrationSteps":[{"analyticName":"'+ analyticEntry.name +'", '
        //     + '"analyticUri":"'+ analyticEntry.uri +'","analyticAuthor":"Test","analyticVersion":"1.0.0"}],'
        //     + '"runtimeName":"Predix"}';
        let data = {
            "@type": "orchestrationPx",
            "uri": orchestration.uri,
            "name": orchestration.name,
            "createdOn": orchestration.createdOn,
            "updatedOn": orchestration.updatedOn,
            "createdBy": "analytics-smokeuser",
            "updatedBy": "analytics-smokeuser",
            "author": "Automation",
            "orchestrationType": "ORCHESTRATION_NORMAL",
            "orchestrationSteps": [
                {
                    "analyticName": analyticEntry.name,
                    "analyticUri": analyticEntry.uri,
                    "analyticAuthor": "Test",
                    "analyticVersion": "1.0.0"
                }
            ],
            "runtimeName": "Predix"
        };
        restUtil.makeRequest(uri, 'PUT', data, 'application/json').then(function (resp) {
            orchestration = resp.body;
            callback();
        });
    }


    function applyAssetFilter(callback) {
        let entityFilterUri;
        //restUtil.makeRequest("caf/api/caf-mgmt-svc/v1/entityFilters", 'GET', null, 'application/json').then(function (resp) {
        restUtil.makeRequest("caf" + path + "/api/caf-mgmt-svc/v1/entityFilters", 'GET', null, 'application/json').then(function (resp) {

            JSON.parse(resp.body).forEach(function (entityFilter) {
                if (entityFilter.name == 'GE90') {
                    entityFilterUri = entityFilter.uri;
                }
            });
            let data = {
                entityFilterUri: entityFilterUri,
                userSelectedEntities: []
            };
            //restUtil.makeRequest("caf/api/caf-mgmt-svc/v1" + deployment.uri + "/entities", 'PUT', data, 'application/json').then(function (resp) {
            restUtil.makeRequest("caf" + path +"/api/caf-mgmt-svc/v1" + deployment.uri + "/entities", 'PUT', data, 'application/json').then(function (resp) {
                deployment = resp.body;
                callback();
            });
        });
    }

    function mapForSelectedAssets(callback) {
        let tagObj;
        restUtil.makeRequest("caf" + path + "/api/caf-mgmt-svc/v1" + deployment.uri + "/tags", 'GET', null, 'application/json').then(function (resp) {
            JSON.parse(resp.body).some((tag) => {
                if (tag.name === 'AV_TAG_1') {
                    tagObj = tag;
                    return true;
                }
                return false;
            });
            let deploymentStepUri = deployment.deploymentSteps[0].uri;
            restUtil.makeRequest("caf" + path + "/api/caf-mgmt-svc/v1" + deployment.uri + deploymentStepUri, 'GET', null, 'application/json').then(function (resp) {
                let deploymentStepResponseObject = JSON.parse(resp.body);
                deploymentStepResponseObject.deploymentStepResponse.ioMappings[0].inputsToDataSource.portToDataSources[0].commonDataSource = formatMapObj(tagObj, 'ioDataSourceTagCommon', 'Asset');
                restUtil.makeRequest("caf" + path + "/api/caf-mgmt-svc/v1" + deployment.uri + deploymentStepUri + "/ioMappings", 'PUT', deploymentStepResponseObject.deploymentStepResponse, 'application/json').then(function (resp) {
                    console.log("***:" +"caf" + path + "/api/caf-mgmt-svc/v1" + deployment.uri + deploymentStepUri + "/ioMappings")
                    callback();
                });
            });
        });
    }

    function schedule(callback) {
        restUtil.makeRequest("caf/api/caf-mgmt-svc/v1" + deployment.uri + "/deployParams", 'PUT', generateDefaultOnDemand(), 'application/json').then(function (resp) {
            deployment = resp.body;
            callback();
        });
    }

// function deployListPageUri(){
//   return browser.params.login.baseUrl + '/caf/#/analyticUi' + analyticEntry.uri + '/details/deployList';
// }

    function templatePageUri() {
        return browser.params.login.baseUrl + '/caf' + path + '/#/analytics/details' + analyticEntry.uri;
    }

    function deploymentPageUri() {
        return browser.params.login.baseUrl + '/caf' + path + '/#/deployment/configs' + deployment.uri;
    }

    function orchestrationPxName() {
        return orchestration.name;
    }

    this.Given(/^create analytic with template$/, function (callback) {
        createAnalyticWithTemplate(callback);
    });

    this.Given(/^create analytic without template$/, function (callback) {
        createAnalyticWithoutTemplate(callback);
    });

    this.Then(/^create deployment/, function (callback) {
        createDeployment(callback);
    });

    this.Then(/^apply assetFilter$/, function (callback) {
        applyAssetFilter(callback);
    });

    this.Then(/^map for selected assets$/, function (callback) {
        mapForSelectedAssets(callback);
    });

    this.Then(/^schedule$/, function (callback) {
        schedule(callback);
    });

    this.Given(/^user on analytic deployments tab of analytic$/, function (callback) {
        browser.get(templatePageUri()).then(function () {
            element(by.xpath('//*[@id="root"]/div/div[2]/div/div[1]/div[2]/ul/li[2]')).click().then(function () {
                callback();
            });
        });
    });

    this.Given(/^user lands on newly created deployment$/, function (callback) {
        browser.get(deploymentPageUri()).then(function () {
            callback();
        });
    });

    this.Given(/^user on analytic template tab of analytic$/, function (callback) {
        browser.get(templatePageUri()).then(function () {
            element(by.xpath('//*[@id="root"]/div/div[2]/div/div[1]/div[2]/ul/li[1]')).isDisplayed().then(function (isDisplayed) {
                expect(isDisplayed).to.equal(true);
                callback();
            });
        });
    });

    this.Given(/^an existing analytic with new deployment$/, function (callback) {
        createAnalyticWithTemplate(function () {
            createDeployment(callback);
        });
    });


    this.Given(/^an existing analytic and deployment with asset filter applied$/, function (callback) {
        createAnalyticWithTemplate(function () {
            createDeployment(function () {
                applyAssetFilter(callback);
            });
        });
    });

    this.Given(/^an existing analytic and deployment with asset filter applied and mapped$/, function (callback) {
        createAnalyticWithTemplate(function () {
            createDeployment(function () {
                applyAssetFilter(function () {
                    mapForSelectedAssets(callback);
                });
            });
        });
    });

    this.Given(/^an existing power fabric analytic and deployment with asset filter applied and mapped$/, function (callback) {
        createPowerFabricAnalyticWithTemplate(function (callback) {
            // createDeployment(function () {
            //     applyAssetFilter(function () {
            //         mapForSelectedAssets(callback);
            //     });
            // });
        });
    });


    this.Given(/^an existing analytic and deployment with asset filter applied and mapped and scheduled$/, function (callback) {
        createAnalyticWithTemplate(function () {
            createDeployment(function () {
                applyAssetFilter(function () {
                    mapForSelectedAssets(function () {
                        schedule(callback);
                    });
                });
            });
        });
    });

    this.Then(/^delete analytic and deployment$/, function (callback) {
        console.log("deleting deployment and analytic")
        console.log("analytic uri ", analyticEntry.uri)
        console.log("deployment uri ", deployment.uri)
        //restUtil.makeRequest("caf/api/caf-mgmt-svc/v1" + deployment.uri, 'DELETE', null, 'application/json').then(function (resp) {
        restUtil.makeRequest("caf" + path + "/api/caf-mgmt-svc/v1" + deployment.uri, 'DELETE', null, 'application/json').then(function (resp) {
            assert.equal(resp.statusCode, 200, "deployment deleted");
           // restUtil.makeRequest("caf/api/caf-mgmt-svc/v1" + analyticEntry.uri, 'DELETE', null, 'application/json').then(function (resp) {
            restUtil.makeRequest("caf" + path + "/api/caf-mgmt-svc/v1" + analyticEntry.uri, 'DELETE', null, 'application/json').then(function (resp) {
                assert.equal(resp.statusCode, 200, "analytic deleted");
                callback();
            });
        });

    });

    this.Then(/^delete analytic$/, function (callback) {
        console.log("deleting analytic")
        console.log("analytic uri ", analyticEntry.uri)
        restUtil.makeRequest("caf" +path+"/api/caf-mgmt-svc/v1" + analyticEntry.uri, 'DELETE', null, 'application/json').then(function (resp) {
            assert.equal(resp.statusCode, 200, "analytic deleted");
            callback();
        });

    });

    this.Given(/^user create Px orchestration with an analytic$/, function (callback) {
        console.log("creating analytic and orchestration");
        createAnalyticWithTemplate(function () {
            createOrchestrationPx(function () {
                updateOrchestrationwithAnalytic(function () {
                    callback();
                });
            });
        });
    });

    this.When(/^the orchestration name is entered$/, function (callback) {
        let orchestrationName = createOrchestrationPage.getName();
        console.log("name is > " + orchestrationName);
        cafDeploymentPage.analyticName().sendKeys(orchestrationName).then(function () {
            callback();
        });
    });

    this.Given(/^tenant is set to custom attribute to (.*)$/, function (config, callback) {
        console.log("creating analytic and orchestration");
        setCustomAttributeTrue(config,callback);
    });

}

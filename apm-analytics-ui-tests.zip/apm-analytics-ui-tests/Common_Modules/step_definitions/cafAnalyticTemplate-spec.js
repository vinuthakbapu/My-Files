/**
 * CAfAnalytic Template spec
 */

module.exports = function() {

    let deploymentName
    let appHubPath = browser.params.appHubpath;
    analyticName = browser.params.analyticName;

    // var desc;

    this.Then(/^the cafUser should see the title Description$/, function (callback) {
        cafAnalyticTemplatePage.checkDescriptiontitle().then( function (text)  {
            console.log("Heading is ", text);
            //assert.equal(text.trim(), "DESCRIPTION" ,"Heading is not dispalyed");
            assert.equal(text, "DESCRIPTION" ,"Heading is not dispalyed");
            callback();
        });
    });

    this.Then(/^the caf description field should contain default text$/, function (callback) {
        cafAnalyticTemplatePage.getDescriptionDefaultText().then(function(text){
            assert.equal(text.trim(), "Select to add a description", "description default text is not equal");
            callback();
        });
    });


    this.Then(/^the cafUser should see the title Supporting Files$/, function (callback) {
        cafAnalyticTemplatePage.checkSupportingFilestitle().then( function (text)  {
            console.log("Heading is ", text);
            assert.equal(text, "SUPPORTING FILES" ,"Heading is not dispalyed");
            callback();
        });
    });

    this.Then(/^all the ingested supporting files are displayed$/, function(callback) {
        cafAnalyticTemplatePage.getSupportingFiles().count().then(function (count) {
            console.log("There are ", count, " supporting files");
            assert.equal(count, 1, "wrong number of files");
            callback();
        });
    });

    this.Then(/^supporting files section should be readonly$/, function(callback) {
        cafAnalyticTemplatePage.supportingFilesReadOnlyLabel().getAttribute('class').then(function (val) {
            assert.equal(val,"is-read-only", "is not read only");
            callback();
        });
    });


    this.Then(/^all the ingested input definitions are displayed with all columns data$/, function(callback) {
        cafAnalyticTemplatePage.getInputDefinitions().count().then(function (count) {
            assert.isAbove(count, 0, "wrong number of files");
            callback();
        });
    });

    this.Then(/^input definitions should be readonly$/, function(callback) {
        cafAnalyticTemplatePage.inputDefinitionsReadOnlyLabel().getAttribute('class').then(function (val) {
            assert.equal(val,"is-read-only", "is not read only");
            callback();
        });
    });

    this.Then(/^all the ingested constants are displayed with all columns data$/, function(callback) {
        cafAnalyticTemplatePage.getConstants().count().then(function (count) {
            assert.isAbove(count, 0, "wrong number of files");
            callback();
        });
    });

    this.Then(/^constants should be readonly$/, function(callback) {
        cafAnalyticTemplatePage.constantsReadOnlyLabel().getAttribute('class').then(function (val) {
            console.log(val);
            // assert.equal(val,"is-read-only", "is not read only");
            callback();
        });
    });

    this.Then(/^all the ingested output definitions are displayed with all columns data$/, function(callback) {
        cafAnalyticTemplatePage.getOutputDefinitions().count().then(function (count) {
            assert.equal(count, 1, "wrong number of files");
            callback();
        });
    });

    this.Then(/^output definitions should be readonly$/, function(callback) {
        cafAnalyticTemplatePage.outputDefinitionsReadOnlyLabel().getAttribute('class').then(function (val) {
            assert.equal(val,"is-read-only", "is not read only");
            callback();
        });
    });

    this.Then(/^the cafUser should see the title Input Definition$/, function (callback) {
        cafAnalyticTemplatePage.checkInputDefinitiontitle().then( function (text)  {
            console.log("Heading is ", text);
            assert.equal(text, "INPUT DEFINITION" ,"Heading is not dispalyed");
            callback();
        });
    });

    this.Then(/^the cafUser should see the title Constants$/, function (callback) {
        cafAnalyticTemplatePage.checkConstanttitle().then( function (text)  {
            console.log("Heading is ", text);
            assert.equal(text, "CONSTANTS" ,"Heading is not dispalyed");
            callback();
        });
    });

    this.Then(/^the cafUser should see the title Output Definition$/, function (callback) {
        cafAnalyticTemplatePage.checkOutputDefinitiontitle().then( function (text)  {
            console.log("Heading is ", text);
            assert.equal(text, "OUTPUT DEFINITION" ,"Heading is not dispalyed");
            callback();
        });
    });

    this.Then(/^the cafUser should see the title Output Events$/, function (callback) {
        cafAnalyticTemplatePage.checkOutputEventsTitle().then( function (text)  {
            console.log("Heading is ", text);
            assert.equal(text, "OUTPUT EVENTS" ,"Heading is not dispalyed");
            callback();
        });
    });

    this.Then(/^the supporting files field should contain upload icon shown$/, function (callback) {
        cafAnalyticTemplatePage.isSupportingFilesUploadIconDisplayed().then(function (bool) {
            assert.equal(bool, true, "supporting files upload icon is not displayed");
            callback();
        });
    });

    this.Then(/^the supporting files field should contain default text$/, function (callback) {
        cafAnalyticTemplatePage.getSupportingFilesDefaultText().then(function (text) {
            assert.equal(text.trim(), "Select to upload files(e.x. documentation)", "supporting files default text is not displayed");
            callback();
        });
    });

    this.Then(/^the caf input definition field should contain add icon$/, function (callback) {
        cafAnalyticTemplatePage.isInputDefinitionAddIconDisplayed().then( function(boolean) {
            assert.equal(boolean, true, "input definition add icon is not displayed");
            callback();
        });
    });

    this.Then(/^the caf input definition field should contain upload icon$/, function (callback) {
        cafAnalyticTemplatePage.isInputDefinitionUploadIconDisplayed().then( function(boolean) {
            assert.equal(boolean, true, "input definition upload icon is not displayed");
            callback();
        });
    });

    this.Then(/^the caf input definition field should contain text$/, function (callback) {
        let el = cafAnalyticTemplatePage.getInputDefinitionTable();
        cafAnalyticTemplatePage.getInputDefinitionDefaultText(el).then(function(text){
            assert.equal(text.trim(), "Select to add orto upload inputs", "input definitition default text is not equal");
            callback();
        });
    });

    this.Then(/^the caf constants field should contain add icon$/, function (callback) {
        cafAnalyticTemplatePage.isConstantsAddIconDisplayed().then( function(boolean) {
            assert.equal(boolean, true, "constants add icon is not displayed");
            callback();
        });
    });

    this.Then(/^the caf constants field should contain upload icon$/, function (callback) {
        cafAnalyticTemplatePage.isConstantsUploadIconDisplayed().then( function(boolean) {
            assert.equal(boolean, true, "input definition upload icon is not displayed");
            callback();
        });
    });

    this.Then(/^the caf constants field should contain the text$/, function (callback) {
        let el = cafAnalyticTemplatePage.getConstantsTable();
        cafAnalyticTemplatePage.getConstantsDefaultText(el).then(function(text){
            assert.equal(text.trim(), "Select to add orto upload constants", "Constants default text is not equal");
            callback();
        });
    });

    this.When(/^I click the add icon in the caf constants$/, function (callback) {
        cafAnalyticTemplatePage.clickConstantsAddIcon().then(function(){
            callback();
        });
    });

    this.When(/^I enter the name of the caf constant$/, function (callback) {
        let el = cafAnalyticTemplatePage.getConstantsTable();
        let constantValue = cafAnalyticTemplatePage.getNameInput(el);
        browser.actions().mouseMove(constantValue).perform().then(function (){
            cafAnalyticTemplatePage.getNameInput(el).click().then(function() {
                cafAnalyticTemplatePage.EnterName(el, "threshold").then(function() {
                    callback();
                });
            });
        });
    });

    this.When(/^I enter the value of the caf constant$/, function (callback) {
        let el = cafAnalyticTemplatePage.getConstantsTable();
        let constantValue = cafAnalyticTemplatePage.getValueInput(el);
        browser.actions().mouseMove(constantValue).perform().then(function (){
            cafAnalyticTemplatePage.getValueInput(el).click().then(function() {
                cafAnalyticTemplatePage.enterValue(el, "50").then(function() {
                    callback();
                });
            });
        });
    });

    this.When(/^I enter the units of the caf constant$/, function (callback) {
        let el = cafAnalyticTemplatePage.getConstantsTable();
        let constantValue = cafAnalyticTemplatePage.getConstantsUnits(el);
        let unit = 'Celsius';
        constantValue.click().then(function () {
            cafAnalyticTemplatePage.EnterConstantsUnits(el,unit).then(function() {
                constantValue.getText().then(function(text) {
                    expect(text.toLowerCase()).to.equal(unit.toLowerCase());
                    callback();
                });
            });
        });
    });

    this.When(/^I select the datatype of the caf constant$/, function (callback) {
        let el = cafAnalyticTemplatePage.getConstantsTable();
        let ele = cafAnalyticTemplatePage.getDropdownElementConstant(el);
        cafAnalyticTemplatePage.selectDropdownbyIndex(ele,3);
        callback();
    });

    this.When(/^I click the edit icon of the description in the caf constants$/, function (callback) {
        let el = cafAnalyticTemplatePage.getConstantsTable();
        cafAnalyticTemplatePage.clickConstantsDescriptionEditIcon(el).then(function(){
            callback();
        });
    });

    this.When(/^I enter the description of the caf constant$/, function (callback) {
        let el = cafAnalyticTemplatePage.getConstantsTable();
        let constantValue = cafAnalyticTemplatePage.getDescriptionInput(el);
        browser.actions().mouseMove(constantValue).perform().then(function (){
            constantValue.click().then(function() {
                cafAnalyticTemplatePage.enterDescription(el, "threshold desc").then(function() {
                    callback();
                });
            });
        });
    });

    this.When(/^I mouseover on the caf constant$/, function (callback) {
        let el = cafAnalyticTemplatePage.getConstantsTable();
        cafAnalyticTemplatePage.mouseOverRecord(el).then(function(){
            callback();
        });
    });

    this.When(/^I click the delete icon in the caf constants$/, function (callback) {
        let el = cafAnalyticTemplatePage.getConstantsTable();
        cafAnalyticTemplatePage.clickRecordDeleteIcon(el).then(function(){
            callback();
        });
    });

    this.Then(/^the caf output definition field should contain add icon$/, function (callback) {
        cafAnalyticTemplatePage.isOutputDefinitionAddIconDisplayed().then(function(boolean) {
            assert.equal(boolean, true, "output definition add icon is not displayed");
            callback();
        });
    });

    this.Then(/^the caf output definition field should contain upload icon$/, function (callback) {
        cafAnalyticTemplatePage.isOutputDefinitionUploadIconDisplayed().then(function(boolean) {
            assert.equal(boolean, true, "output definition upload icon is not displayed");
            callback();
        });
    });

    this.Then(/^the caf output definition field should contain the text$/, function (callback) {
        let el = cafAnalyticTemplatePage.getOutputDefinitionTable();
        cafAnalyticTemplatePage.getOutputDefinitionDefaultText(el).then(function(text){
            assert.equal(text.trim(), "Select to add orto upload outputs", "output definitions default text is not equal");
            callback();
        });
    });

    this.When(/^I click the add icon in the caf output definition$/, function (callback) {
        cafAnalyticTemplatePage.clickOutputDefinitionAddIcon().then(function(){
            callback();
        });
    });

    this.When(/^I enter the name of the caf output definition$/, function (callback) {
        let el = cafAnalyticTemplatePage.getOutputDefinitionTable();
        let constantValue = cafAnalyticTemplatePage.getNameInput(el);
        browser.actions().mouseMove(constantValue).perform().then(function (){
            cafAnalyticTemplatePage.getNameInput(el).click().then(function() {
                cafAnalyticTemplatePage.EnterName(el, "mean").then(function() {
                    callback();
                });
            });
        });
    });

    this.When(/^I enter the units of the caf output definition$/, function (callback) {
        let el = cafAnalyticTemplatePage.getOutputDefinitionTable();
        let constantValue = cafAnalyticTemplatePage.getOutputDefinitionUnits(el);
        let unit = 'None';
        constantValue.click().then(function () {
            // cafAnalyticTemplatePage.EnterInputDefinitionUnits(el,"cel").then(function () {
            cafAnalyticTemplatePage.EnterOutputDefinitionUnits(el,unit).then(function () {
                constantValue.getText().then(function(text) {
                    expect(text.toLowerCase()).to.equal(unit.toLowerCase());
                    callback();
                });
            });
        });
    });

    this.When(/^I select the datatype of the caf output definition$/, function (callback) {
        let el = cafAnalyticTemplatePage.getOutputDefinitionTable();
        let ele = cafAnalyticTemplatePage.getDropdownElementOutputDefinition(el);
        cafAnalyticTemplatePage.selectDropdownbyIndex(ele,3);
        callback();
    });

    this.When(/^I click the edit icon of the description in the caf output definition$/, function (callback) {
        let el = cafAnalyticTemplatePage.getOutputDefinitionTable();
        cafAnalyticTemplatePage.clickOutputDefinitionDescriptionEditIcon(el).then(function(){
            callback();
        });
    });

    this.When(/^I enter the description of the caf output definition$/, function (callback) {
        let el = cafAnalyticTemplatePage.getOutputDefinitionTable();
        let constantValue = cafAnalyticTemplatePage.getDescriptionInput(el);
        browser.actions().mouseMove(constantValue).perform().then(function (){
            constantValue.click().then(function() {
                cafAnalyticTemplatePage.enterDescription(el, "Mean description").then(function() {
                    callback();
                });
            });
        });
    });

    this.When(/^I mouseover on the caf output definition$/, function (callback) {
        let el = cafAnalyticTemplatePage.getOutputDefinitionTable();
        cafAnalyticTemplatePage.mouseOverRecord(el).then(function(){
            callback();
        });
    });

    this.When(/^I click the delete icon in the caf output definition$/, function (callback) {
        let el = cafAnalyticTemplatePage.getOutputDefinitionTable();
        cafAnalyticTemplatePage.clickRecordDeleteIcon(el).then(function(){
            callback();
        });
    });

    this.Then(/^the caf output events field should contain add icon$/, function (callback) {
        cafAnalyticTemplatePage.isOutputEventsAddIconDisplayed().then(function(boolean) {
            assert.equal(boolean, true, "output events add icon is not displayed");
            callback();
        });
    });

    this.Then(/^the caf output events field should contain the text$/, function (callback) {
        let el = cafAnalyticTemplatePage.getOutputEventsTable();
        cafAnalyticTemplatePage.getOutputEventsDefaultText(el).then(function(text){
            assert.equal(text.trim(), "Select to add output events (e.x. Alarms, Alerts, Anomalies, etc)", "output events default text is not equal");
            callback();
        });
    });

    this.When(/^I click the add icon in the caf output events$/, function (callback) {
        cafAnalyticTemplatePage.clickOutputEventsAddIcon().then(function(){
            callback();
        });
    });

    this.When(/^I click the edit icon of the description in the caf output events$/, function (callback) {
        let el = cafAnalyticTemplatePage.getOutputEventsTable();
        cafAnalyticTemplatePage.clickOutputEventsDescriptionEditIcon(el).then(function(){
            callback();
        });
    });

    this.When(/^I enter the description of the caf output event$/, function (callback) {
        let el = cafAnalyticTemplatePage.getOutputEventsTable();
        let constantValue = cafAnalyticTemplatePage.getDescriptionInput(el);
        browser.actions().mouseMove(constantValue).perform().then(function (){
            constantValue.click().then(function() {
                cafAnalyticTemplatePage.enterDescription(el, "Output event description").then(function() {
                    callback();
                });
            });
        });
    });

    this.When(/^the caf output event add icon should not be displayed$/, function (callback) {
        cafAnalyticTemplatePage.isOutputEventAddIconNotDisplayed().then(function(bool){
            assert.equal(bool, true, "output event add icon is displayed");
            callback();
        });
    });

    this.When(/^I mouseover on the caf output event$/, function (callback) {
        let el = cafAnalyticTemplatePage.getOutputEventsTable();
        cafAnalyticTemplatePage.mouseOverRecord(el).then(function(){
            callback();
        });
    });

    this.When(/^I click the delete icon in the caf output events$/, function (callback) {
        let el = cafAnalyticTemplatePage.getOutputEventsTable();
        cafAnalyticTemplatePage.clickRecordDeleteIcon(el).then(function(){
            callback();
        });
    });

    this.When(/^user mouse hover over the edit icon$/, function (callback) {
        let constantValue = cafAnalyticTemplatePage.analyticMouseOverEditIcon();
        browser.actions().mouseMove(constantValue).perform().then(function () {
            cafAnalyticTemplatePage.analyticEditIcon().isDisplayed().then(function(isDisplayed){
                expect(isDisplayed).to.equal(true);
                callback();
            });
        });
    });

      this.Then(/^analytics template header should contain create_analytic icon$/, function (callback) {
        cafAnalyticTemplatePage.isTemplateHeaderCreateAnalyticIconDisplayed().then(function(boolean) {
            assert.equal(boolean, true, "caf analytic template header create analytic icon is not displayed");
            callback();
        });
    });
    this.Then(/^analytics template header should not contain create_analytic icon$/, function (callback){
        cafAnalyticTemplatePage.iscreateorcbuttonNotDisplayed().then(function(boolean) {
            assert.equal(boolean, false, "orchestration template header create orchestration icon is displayed");
            callback();
        });
    });

    this.Then(/^the supporting files field should not contain upload icon shown$/, function (callback) {
        cafAnalyticTemplatePage.isSupportingFilesUploadIconNotDisplayed().then(function (bool) {
            assert.equal(bool, false, "supporting files upload icon is displayed");
            callback();
        });
    });
    this.Then(/^the caf input definition field should not contain add icon$/, function (callback) {
        cafAnalyticTemplatePage.isInputDefinitionAddIconNotDisplayed().then( function(boolean) {
            assert.equal(boolean, false, "input definition add icon is displayed");
            callback();
        });
    });

    this.Then(/^the caf input definition field should not contain upload icon$/, function (callback) {
        cafAnalyticTemplatePage.isInputDefinitionUploadIconNotDisplayed().then( function(boolean) {
            assert.equal(boolean, false, "input definition upload icon is displayed");
            callback();
        });
    });

    this.Then(/^the caf constants field should not contain add icon$/, function (callback) {
        cafAnalyticTemplatePage.isConstantsAddIconNotDisplayed().then( function(boolean) {
            assert.equal(boolean, false, "constants add icon is displayed");
            callback();
        });
    });

    this.Then(/^the caf constants field should not contain upload icon$/, function (callback) {
        cafAnalyticTemplatePage.isConstantsUploadIconNotDisplayed().then( function(boolean) {
            assert.equal(boolean, false, "input definition upload icon is displayed");
            callback();
        });
    });
    this.Then(/^the caf output definition field should not contain add icon$/, function (callback) {
        cafAnalyticTemplatePage.isOutputDefinitionAddIconNotDisplayed().then(function(boolean) {
            assert.equal(boolean, false, "output definition add icon is displayed");
            callback();
        });
    });

    this.Then(/^the caf output definition field should not contain upload icon$/, function (callback) {
        cafAnalyticTemplatePage.isOutputDefinitionUploadIconNotDisplayed().then(function(boolean) {
            assert.equal(boolean, false, "output definition upload icon is displayed");
            callback();
        });
    });
    this.Then(/^the caf output events field should not contain add icon$/, function (callback) {
        cafAnalyticTemplatePage.isOutputEventsAddIconNotDisplayed().then(function(boolean) {
            assert.equal(boolean, false, "output events add icon is displayed");
            callback();
        });
    });


    this.When(/^I enter the description in the caf template page$/, function (callback) {
        let descriptionSection = cafAnalyticTemplatePage.descriptionSection();
        let descriptionIcon = cafAnalyticTemplatePage.editDescriptionIcon(descriptionSection);
        // hover icon first; icon must be visible to click it
        browser.sleep(1000).then(function () {


        browser.actions().mouseMove(descriptionIcon).perform().then(function () {
            descriptionIcon.click().then(function () {
                cafAnalyticTemplatePage.enterTemplateDescription(descriptionSection, "Description text").then(function() {
                    callback();
                    });
                });
            });
        });
    });

    this.Then(/^the caf description should be displayed$/, function (callback) {
        cafAnalyticTemplatePage.getDescription().then(function(text){
            assert.equal(text.trim(), "test description", "description is not equal");
            callback();
        });
    });

    this.When(/^I try to upload a supporting file$/, function (callback) {
        cafCreateAnalyticPage.clickUploadFileIcon().then(function () {
            callback();
        });
    });

    this.Then(/^the upload modal opens$/, function (callback) {
        cafCreateAnalyticPage.getUploadModal().then(function (text) {
            callback();
        });
    });

    this.When(/^I upload a file$/, function (callback) {
        cafCreateAnalyticPage.uploadFile().then(function (text) {
            callback();
            //assert.equal(text, "TemperatureThreshold.zip");
            assert.equal(text, "tempAnalyticRequired.csv");
        });
    });

    this.Then(/^I try to submit without a description$/, function (callback) {
        cafCreateAnalyticPage.clickSubmitUpload().then(function () {
            callback();
        });
    });

    this.Then(/^the submit fails and the description shows as invalid$/, function (callback) {
        cafCreateAnalyticPage.getDescriptionInputBox().then(function (className) {
            assert.equal(className, 'invalid');
            callback();
        });
    });

    this.When(/^I add a valid description$/, function (callback) {
        cafCreateAnalyticPage.addValidDescription().then(function () {
            callback();
        });
    });

    this.Then(/^click submit again$/, function (callback) {
        cafCreateAnalyticPage.clickSubmitUpload().then(function () {
            browser.sleep (2000).then (function () {
                callback();
            });
        });
    })

    this.When(/^I click the caf add icon in the input definition$/, function (callback) {
        cafAnalyticTemplatePage.clickInputDefinitionAddIcon().then(function(){
            callback();
        });
    });

    // this.When(/^I enter the caf name of the input definition$/, function (callback) {
    //   let el = cafAnalyticTemplatePage.getInputDefinitionTable();
    //   let constantValue = cafAnalyticTemplatePage.getNameInput(el);
    //   browser.actions().mouseMove(constantValue).perform().then(function () {
    //     cafAnalyticTemplatePage.getNameInput(el).click().then(function () {
    //       cafAnalyticTemplatePage.EnterName(el, "temp_today").then(function () {
    //         callback();
    //       });
    //     });
    //   });
    // });

    this.When(/^I enter the caf ([^"]*) name of the input definition$/, function (name,callback) {
        let el = cafAnalyticTemplatePage.getInputDefinitionTable();
        let constantValue = cafAnalyticTemplatePage.getNameInput(el);
        browser.actions().mouseMove(constantValue).perform().then(function () {
            constantValue.click().then(function () {
                cafAnalyticTemplatePage.EnterName(el, name).then(function () {
                    callback();
                })

            });
        });
    });

    this.When(/^I click the edit icon of the caf units in the input definition$/, function (callback) {
        cafAnalyticTemplatePage.clickInputDefinitionUnitsEditIcon().then(function(){
            callback();
        });
    });

    this.When(/^I enter the caf ([^"]*) units of the input definition$/, function (units,callback) {
        let el = cafAnalyticTemplatePage.getInputDefinitionTable();
        let constantValue = cafAnalyticTemplatePage.getInputUnits(el);
        browser.actions().mouseMove(constantValue).perform().then(function () {
            constantValue.click().then(function () {
                cafAnalyticTemplatePage.EnterInputDefinitionUnits(el, units).then(function () {
                    constantValue.getText().then(function(text) {
                        expect(text.toLowerCase()).to.equal(units.toLowerCase());
                        callback();
                    });
                });
            });
        });
    });

    this.Then(/^the input definition units should be displayed$/, function (callback) {
        cafAnalyticTemplatePage.getInputDefinitionUnits().then(function(text){
            assert.equal(text.trim(), "Celsius", "input definition units are not equal");
            callback();
        });
    });

    this.Then(/^the input definition datatype should be displayed$/, function (callback) {
        cafAnalyticTemplatePage.getInputDefinitionDataTypeDropdownSelectedOption().then(function (option) {
            assert.equal(option.trim(), "Double", "default selected value is not Double");
            callback();
        });
    });

    this.When(/^I click the required checkbox in the caf input definition$/, function (callback) {
        cafAnalyticTemplatePage.clickInputDefinitionRequiredCheckbox().then(function(){
            callback();
        });
    });

    this.When(/^I click the required checkbox in the constant$/, function (callback) {
        cafAnalyticTemplatePage.clickConstantRequiredCheckbox().then(function(){
            callback();
        });
    });

    this.Then(/^the input definition required checkbox should be checked$/, function (callback) {
        cafAnalyticTemplatePage.isInputDefinitionRequiredCheckboxChecked().then(function(boolean) {
            assert.equal(boolean, true, "Input Definition Required Checkbox is not checked");
            callback();
        });
    });

    // this.When(/^I click the datatype of the caf input definition$/, function (callback) {
    //     cafAnalyticTemplatePage.clickInputDefinitionDataTypeDropdown().then(function(){
    //         callback();
    //     });
    // });

    this.When(/^I select the datatype of the caf input definition$/, function (callback) {
        let el = cafAnalyticTemplatePage.getInputDefinitionTable();
        let ele = cafAnalyticTemplatePage.getDropdownElement(el);
        cafAnalyticTemplatePage.selectDropdownbyIndex(ele,2);
        callback();
    });


    this.When(/^I click the edit icon of the description in the caf input definition$/, function (callback) {
        let el = cafAnalyticTemplatePage.getInputDefinitionTable();
        let constantValue = cafAnalyticTemplatePage.getInputDefinitionDescriptionEditIcon(el);
        browser.actions().mouseMove(constantValue).perform().then(function () {
            cafAnalyticTemplatePage.getInputDefinitionDescriptionEditIcon(el).click().then(function(){
                callback();
            });
        });
    });

    this.When(/^I enter the description of the caf input definition$/, function (callback) {
        let el = cafAnalyticTemplatePage.getInputDefinitionTable();
        let constantValue = cafAnalyticTemplatePage.getDescriptionInput(el);
        browser.actions().mouseMove(constantValue).perform().then(function () {
            constantValue.click().then(function () {
                cafAnalyticTemplatePage.enterDescription(el, "today's temperature").then(function () {
                    callback();
                });
            });
        });
    });

    this.Then(/^the input definition description should be displayed$/, function (callback) {
        cafAnalyticTemplatePage.getInputDefinitionDescription().then(function(text){
            assert.equal(text.trim(), "todays temperature", "input definition description is not equal");
            callback();
        });
    });

    this.When(/^I mouseover on the caf supporting file$/, function (callback) {
        cafAnalyticTemplatePage.mouseOverSupportingFileRecord().then(function(){
            callback();
        });
    });

    this.When(/^I click the delete icon in the caf supporting files$/, function (callback) {
        cafAnalyticTemplatePage.clickSupportingFileDeleteIcon().then(function(){
            callback();
        });
    });

    this.Then(/^the caf supporting file should be deleted$/, function (callback) {
        cafAnalyticTemplatePage.isSupportingFileRecordDeleted().then(function(bool){
            assert.equal(bool, true, "supporting file is not deleted");
            callback();
        });
    });

    this.When(/^I upload the caf input values from file "([^"]*)"$/, function (arg1, callback) {
        cafAnalyticTemplatePage.clickUploadInputIcon().then(function () {
            console.log("clicked upload icon");
            browser.sleep(2000).then(function () {
                cafAnalyticTemplatePage.uploadCSVFile(arg1).then(function () {
                    console.log("selected the csv file to upload");
                    cafAnalyticTemplatePage.elementToBeClickable(
                        cafAnalyticTemplatePage.submitUpload())
                        .then(function () {
                            expect(cafAnalyticTemplatePage.submitUpload().isEnabled()).to.not.be.false;
                            console.log("submit button is enabled");
                            callback();

                        });
                });
            });
        });
    });



    this.When(/^I upload the caf input values for Spark$/, function (callback) {
        cafAnalyticTemplatePage.clickUploadInputIcon().then(function () {
            console.log("clicked upload icon");
            browser.sleep(2000).then(function () {
                cafAnalyticTemplatePage.uploadCSVFile('sparkAnalytic_inputsDef.csv').then(function () {
                    console.log("selected the csv file to upload");
                    cafAnalyticTemplatePage.elementToBeClickable(
                        cafAnalyticTemplatePage.submitUpload())
                        .then(function () {
                            expect(cafAnalyticTemplatePage.submitUpload().isEnabled()).to.not.be.false;
                            console.log("submit button is enabled");
                            browser.sleep(3000).then(function() {
                                cafAnalyticTemplatePage.clickSubmitUpload().then(function () {
                                    cafAnalyticTemplatePage.visibilityOf(cafAnalyticTemplatePage.analyticTemplate()).then(function () {
                                        callback();
                                    });
                                });
                            });
                        });
                });
            });
        });
    });

    this.When(/^I upload the caf constant values from file "([^"]*)"$/, function (arg1, callback) {
        cafAnalyticTemplatePage.clickUploadConstantIcon().then(function () {
            console.log("clicked upload constant icon");
            browser.waitForAngular();
            cafAnalyticTemplatePage.uploadCSVFile(arg1).then(function () {
                console.log("selected the csv file to upload");
                cafAnalyticTemplatePage.elementToBeClickable(
                    cafAnalyticTemplatePage.submitUpload())
                    .then(function () {
                        expect(cafAnalyticTemplatePage.submitUpload().isEnabled()).to.not.be.false;
                        console.log("submit button is enabled");
                        callback();
                    });
            });
        });
    });
    this.Then(/^cafUser submits uploaded file$/, function (callback) {
        // Write code here that turns the phrase above into concrete actions
        console.log("submit button is enabaled..")
        browser.sleep(3000).then(function() {
            cafAnalyticTemplatePage.clickSubmitUpload().then(function () {
                cafAnalyticTemplatePage.visibilityOf(cafAnalyticTemplatePage.analyticTemplate()).then(function () {
                    callback();
                });
            });
        });

    });

    this.Then(/^cafUser verify data source column$/, function (callback) {
        cafAnalyticTemplatePage.getDataFormatColumnText().getText()
            .then(function (txt) {

                console.log(txt);
                expect(txt).to.equal('APM Timeseries');
                callback();
            });

    });

    this.Then(/^cafUser verify constant data source column$/, function (callback) {

        cafAnalyticTemplatePage.getDataFormatColumnText().getText()
            .then(function (txt) {

                expect(txt).to.equal('Constant');
                callback();
            });
    });

    this.When(/^I upload the caf output values from file "([^"]*)"$/, function (arg1, callback) {
        cafAnalyticTemplatePage.clickUploadOutputDefIcon().then(function () {
            console.log("clicked upload icon");
            browser.sleep(2000).then(function () {
                cafAnalyticTemplatePage.uploadCSVFile(arg1).then(function () {
                    console.log("selected the csv file to upload");
                    cafAnalyticTemplatePage.elementToBeClickable(
                        cafAnalyticTemplatePage.submitUpload())
                        .then(function () {
                            expect(cafAnalyticTemplatePage.submitUpload().isEnabled()).to.not.be.false;
                            console.log("submit button is enabled");

                            callback();

                        });
                });
            });
        });
    });

    this.When(/^I upload the caf output values for Spark$/, function (callback) {
        cafAnalyticTemplatePage.clickUploadOutputDefIcon().then(function () {
            console.log("clicked upload icon");
            browser.sleep(2000).then(function () {
                cafAnalyticTemplatePage.uploadCSVFile('sparkAnalytic_outputDef.csv').then(function () {
                    console.log("selected the csv file to upload");
                    cafAnalyticTemplatePage.elementToBeClickable(
                        cafAnalyticTemplatePage.submitUpload())
                        .then(function () {
                            expect(cafAnalyticTemplatePage.submitUpload().isEnabled()).to.not.be.false;
                            console.log("submit button is enabled");
                            browser.sleep(3000).then(function() {
                                cafAnalyticTemplatePage.clickSubmitUpload().then(function () {
                                    cafAnalyticTemplatePage.visibilityOf(cafAnalyticTemplatePage.analyticTemplate()).then(function () {
                                        callback();
                                    });
                                });
                            });
                        });
                });
            });
        });
    });

    this.When(/^I mouseover on the caf input definition$/, function (callback) {
        let el = cafAnalyticTemplatePage.getInputDefinitionTable();
        cafAnalyticTemplatePage.mouseOverRecord(el).then(function(){
            callback();
        });
    });

    this.When(/^I click the delete icon in the caf input definitions$/, function (callback) {
        let el = cafAnalyticTemplatePage.getInputDefinitionTable();
        cafAnalyticTemplatePage.clickRecordDeleteIcon(el).then(function(){
            callback();
        });
    });

    this.When(/^I click the save button in CAF Analytic$/, function (callback) {
        browser.sleep(2000).then(function () {
            cafAnalyticTemplatePage.clickSaveButton().then(function(){
                console.log("clicked save button in template");
                callback();
            });
        });

    });

    this.When(/^I click the save button in the modal for CAF Analytic$/, function (callback) {
        cafAnalyticTemplatePage.clickSaveButtonInModal().then(function(){
            console.log("clicked save button in modal");
            callback();
        });
    });

    this.When(/^I click the submit button in the modal for CAF SupportingFile$/, function (callback) {
        cafAnalyticTemplatePage.clickSubmitButtonInModal().then(function(){
            console.log("clicked submit button in modal");
            callback();
        });
    });

    this.When(/^cafUser clicks the first output event result$/, function (callback) {
        let el = cafAnalyticTemplatePage.searchResults();
        cafAnalyticTemplatePage.clickTypeaheadResult(el).then (function(){
            callback();
        });
    });

    this.When(/^user clicks on the download icon of the supporting file$/, function (callback) {
        cafAnalyticTemplatePage.clickSupportingFileDownloadIcon().then(function(){
            console.log("clicked download button in modal");
            callback();
        });
    });

    this.When(/^user mouse hover over the supporting file$/, function (callback) {
        browser.actions().mouseMove(cafAnalyticTemplatePage.SupportingFileRow()).perform().then(function() {
            callback();
        });
    });

    this.Then(/^Enter "([^"]*)" name into "([^"]*)" Definition$/, function (arg1, arg2, callback) {
        let elm = element(by.xpath("//*[contains(@id,'"+ arg2 +"')]/../..//tbody/tr[last()]/td[1]//span[1]"));
        let addName = element(by.xpath("//*[contains(@id,'"+ arg2 +"')]/../..//tbody/tr[last()]/td[1]//input"));
        // let elm = element(by.xpath("//span[contains(text(),'Add Name')]"));
        // let addName = element(by.css("input[placeholder='Add Name']"));
        TestHelperPO.elementToBeClickable(elm).then(function () {
            TestHelperPO.sendKeys(addName, arg1).then(function () {
                callback();
            });
        })


    });

    this.Then(/^Select the "([^"]*)" option from DataSourceType of "([^"]*)" Definition$/, function (arg1, arg2, callback) {
        let elm;
        if (arg2 == "constants"){
            elm = element(by.xpath("//*[contains(@id,'"+ arg2 +"')]/../..//tbody/tr[last()]/td[5]/select"));
        } else elm = element(by.xpath("//*[contains(@id,'"+ arg2 +"')]/../..//tbody/tr[last()]/td[4]/select"));

        elm.click().then(function () {
            let opt = elm.element(by.xpath("option[contains(text(),'"+ arg1 +"')]"));
            opt.click().then(function () {
                callback();
            });
        })



        // if (arg1 == "Asset Attributes"){
        //     element(by.cssContainingText('option', 'BeaverBox Testing')).click();
        //     // cafAnalyticTemplatePage.selectDropdownbyIndex(elm, 1);
        // };

    });

    this.Then(/^I select the "([^"]*)" of the caf "([^"]*)" definition$/, function (arg1, arg2, callback) {
        let elm;
        if (arg2 == "constants"){
            elm = element(by.xpath("//*[contains(@id,'"+ arg2 +"')]/../..//tbody/tr[last()]/td[4]/select"));
        } else elm = element(by.xpath("//*[contains(@id,'"+ arg2 +"')]/../..//tbody/tr[last()]/td[3]/select"));

        elm.click().then(function () {
            let opt = elm.element(by.xpath("option[contains(text(),'"+ arg1 +"')]"));
            opt.click().then(function () {
                callback();
            });
        })
    });

    this.When(/^I should see the make current option for version one$/, function (callback) {
        cafAnalyticTemplatePage.clickSupportingFileDownloadIcon().then(function(){
            console.log("clicked save button in modal");
            callback();
        });
    });

    this.When(/^Version one should have the make current option$/, function (callback) {
        element.all(by.css('.apm-ax-artifact-list-item')).then(function (ele) {
            ele[1].getInnerHtml().then(function(html){
                console.log("HTML: "+html)
                assert.include(html,"Make Current", "Is the the current version");
                callback();
            });
        });
    });

    this.When(/^user makes (.*) current$/, function (version, callback) {
        cafAnalyticTemplatePage.selectMakeCurrent().then(function () {
            console.log("Switched to the version " + version);
            browser.waitForAngular();
            callback();
        });
    });

    this.Then(/^the template should have (.*) number displayed$/, function (version,callback) {
        cafAnalyticTemplatePage.getTemplateVersion().then(function (text) {
            expect(text).to.equal("Version:"+version)
            callback();
        });

    });

    this.Then(/^cafUser should see version dropdown$/, function (callback) {

        cafAnalyticTemplatePage.templateVersionsDropdown().getText().then(function (text) {
            let actualValues=text.split('\n');
            expect(actualValues.toString()).to.equal("1.0.0,2.0.0")
            callback();
        });
    });

    this.Then(/^the caf output events field should have rows$/, function (callback) {
        cafAnalyticTemplatePage.isOutputEventsRowsExist().then(function(boolean) {
            assert.equal(boolean, true, "output events rows not exist");
            callback();
        });
    });

    this.Then(/^the user should see (.*) displayed$/, function (version, callback) {
        cafAnalyticTemplatePage.deploymentRowVersion().getText().then(function (text) {
            expect(text.toString()).to.equal(version.toString())
            callback();
        });
    });

    this.When(/^the user searches for the "([^"]*)" analytic$/, function (arg1, callback) {
        cafCreateAnalyticPage.clickSearchBox().then(function () {
            cafCreateAnalyticPage.enterSearchText(arg1).then(function () {
                browser.sleep(2000).then(function () {
                    callback();
                });
            });
        });
    });

    this.Then(/^use clicks on edit input button$/, function (callback) {
        element.all(by.css('.apm-ax-subsection-row .apm-ax-subsection-column .apm-ax-text-input-box')).then(function (ele) {
            var obj1 = ele[1];
            obj1.click().then(function () {
                cafAnalyticTemplatePage.EnterName(obj1, "_V2").then(function () {
                    callback();
                });
            });
        });
    });

    this.When(/^user clicks the upload icon of the input definition$/, function(callback) {
        let modal = cafAnalyticTemplatePage.getUploadModal();
        cafAnalyticTemplatePage.clickUploadInputIcon().then(function() {
            // wait for modal to be visibile, test that it is visible
            cafAnalyticTemplatePage.visibilityOf(modal).then(function(visibility) {
                expect(visibility).to.equal(true);
                callback();
            });
        });
    });

    this.When(/^user clicks the download template buttton$/, function(callback) {
        let address;
        let filePath = global.downloadsPath +'/Inputs_template.csv';
        let body = {
            'cmd': 'Page.setDownloadBehavior',
            'params': {'behavior': 'allow', 'downloadPath': filePath }
        };

        browser.getProcessedConfig().then(function(config) {
            address = config.seleniumAddress;
            return browser.getSession();
        }).then(function(session) {
            address = address + '/session/' + session['id_'] + '/chromium/send_command';
            restUtil.makeRequest(address, 'POST', JSON.stringify(body)).then(function () {
                cafAnalyticTemplatePage.clickDownloadTemplateButtonInModal().then(function() {
                    console.log("clicked download template button in modal");
                    callback();
                });
            });
        });
    });

    this.Then(/^the input template file will be downloaded$/, function(callback) {
        // consider passing default directory along as browser parameter....
        let fs = require('fs');
        let filePath = global.downloadsPath +'/Inputs_template.csv';
        console.log('File should have been downloaded to: ' + filePath);
        browser.wait(function() {
            // allow time for download, test that it exists
            return fs.existsSync(filePath);
        }, 30000).then(function() {
            callback();
        });
    });

    this.When(/^user opens the input template file$/, function(callback) {
        let fs = require('fs');
        let filePath = global.downloadsPath + '/Inputs_template.csv';
        // test that file can be read and has content
        expect(fs.readFileSync(filePath, {encode: 'utf8'}).length).not.equals(0);
        callback();
    });

    this.Then(/^all the columns are displayed in the csv$/, function(callback) {
        let fs = require('fs');
        let filePath = global.downloadsPath + '/Inputs_template.csv';
        let table = cafAnalyticTemplatePage.getInputDefinitionTable();

        cafAnalyticTemplatePage.getInputDefinitionTableHeaders(table).then(function(headerColumnNames) {
            let content = fs.readFileSync(filePath, 'utf8');
            let containsAll = true;
            for (let i=0; i < headerColumnNames.length && containsAll; i++) {
                let name = headerColumnNames[i].replace('?',''); // Required? in table, but Required in csv
                containsAll = content.includes(name);
                if (!containsAll) {
                    console.log('File does not contain the template header ' + name);
                }
            }
            expect(containsAll).to.equal(true);
            callback();
        });
    });

    this.When(/^user clicks cancel button in the upload page$/, function(callback) {
        cafAnalyticTemplatePage.clickCancelButtonInModal().then(function() {
            console.log("clicked cancel button in modal");
            callback();
        });
    });

    this.When(/^user clicks on the submit button in the upload page$/, function(callback) {
        cafAnalyticTemplatePage.clickSubmitButtonInModal().then(function() {
            console.log("clicked submit button in modal");
            callback();
        });
    });

    this.Then(/^the analytic template page should be displayed$/, function(callback) {
        let analyticTemplate = cafAnalyticTemplatePage.analyticTemplate();
        cafAnalyticTemplatePage.visibilityOf(analyticTemplate).then(function(visibility) {
            expect(visibility).to.equal(true);
            callback();
        });
    });

    this.Then(/^the supporting file gets downloaded$/, function (callback) {
        let filename = 'tempAnalyticRequired.csv';
        console.log(filename);
        let fileTolook = '../TestData/' + filename;
        let filepath = path.resolve(__dirname, fileTolook);
        console.log('looking for: ' + filepath);

        if (fs.existsSync(filepath)) {
            console.log('File saved!');

            //deleting the file once the file gets downloaded
            fs.unlinkSync(filepath);
            callback();
        }
        else {
            console.log('File not found!');
        }
    });

};

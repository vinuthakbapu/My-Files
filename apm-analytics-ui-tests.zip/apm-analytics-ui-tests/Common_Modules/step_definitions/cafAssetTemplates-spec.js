

module.exports = function () {
    var selectedTemplateName = "";
    var selectedFilterName = "";

    this.When( /^user selects asset filter with name (.*) and clicks Search$/, function (name, callback) {
        browser.sleep(3000).then(function() {
            cafAssetSelectionPage.getAssetFilter().click().then(function() {
                cafAssetSelectionPage.getAssetFilterOption(name).click().then(function() {
                    cafAssetSelectionPage.getSearchButton().click().then(function() {
                        callback();
                    });
                });
            });
        });
    });

    this.Then(/^asset filter dropdown tooltip is visible$/, function(callback) {
        browser.actions().mouseMove($('#filter-tooltip-icon')).perform().then(function() {
            browser.sleep(1000).then(function () {
                cafAssetSelectionPage.filterTooltip().isDisplayed().then(function(value) {
                    expect(value).to.be.true;
                    callback();
                });
            });
        });
    });

    this.Then(/^asset list is seen and can be edited$/, function (callback) {
        browser.sleep(35000).then(function () {
            cafAssetSelectionPage.getAssetTableRows().count().then(function (value) {
                expect(value).to.be.above(0);
                const checkbox = cafAssetSelectionPage.getCheckedCheckboxesFromAssetTable().get(1);
                checkbox.getAttribute('disabled').then(function(isDisabled) {
                    expect(isDisabled).to.not.equal('true');
                    checkbox.click().then(function () {
                        browser.sleep(1000).then(function () {
                            callback();
                        });
                    });
                });
            });
        });
    });

    this.Then(/^user clicks on Reset$/, function(callback) {
        cafAssetSelectionPage.resetButton().click().then(function () {
            callback();
        });
    });

    this.When(/^cafUser enters the soarAnalytic as analytic name$/, function(callback) {
      let analyticName = createOrchestrationPage.getSoarAnalyticName();
        cafDeploymentPage.analyticName().sendKeys(analyticName).then(function () {
            callback();
        });
    });

    this.When(/^cafUser enters the airAnalytic as analytic name$/, function(callback) {
      let analyticName = createOrchestrationPage.getAirAnalyticName();
        cafDeploymentPage.analyticName().sendKeys(analyticName).then(function () {
            callback();
        });
    });

    this.When(/^Equipment Template with name (.*) is selected and user clicks Search$/, function(name, callback) {
        browser.sleep(3000).then(function() {
            cafAssetSelectionPage.getAssetTemplate().click().then(function() {
                cafAssetSelectionPage.getAssetTemplateOption(name).click().then(function() {
                    // cafAssetSelectionPage.getSearchButton().click().then(function() {
                        callback();
                //});
                });
            });
        });
    });

    this.Then(/^equipment template dropdown tooltip is visible$/, function(callback) {
        browser.actions().mouseMove($('#template-tooltip-icon')).perform().then(function() {
            browser.sleep(1000).then(function () {
                cafAssetSelectionPage.templateTooltip().isDisplayed().then(function(value) {
                    expect(value).to.be.true;
                    callback();
                });
            });
        });
    });

    this.Then(/^asset list is seen and cannot be edited and tooltip is visible$/, function(callback) {
        browser.sleep(40000).then(function () {
            cafAssetSelectionPage.getAssetTableRows().count().then(function (value) {
                expect(value).to.be.above(0);
                const checkbox = cafAssetSelectionPage.getCheckedCheckboxesFromAssetTable().get(1);
                checkbox.getAttribute('disabled').then(function(isDisabled) {
                    expect(isDisabled).to.equal('true');
                    browser.actions().mouseMove(checkbox).perform().then(function() {
                        browser.sleep(1000).then(function () {
                            cafAssetSelectionPage.tableTooltip().isDisplayed().then(function(value) {
                                expect(value).to.be.true;
                                callback();
                            });
                        });
                    });
                });
            });
        });
    });

    this.Then(/^the search criteria text cannot be edited and tooltip is visible$/, function(callback) {
        cafAssetSelectionPage.getAssetFilterAttributeSearchBox().getAttribute('disabled').then(function(isDisabled) {
            expect(isDisabled).to.equal('true');
            browser.actions().mouseMove(cafAssetSelectionPage.getAssetFilterAttributeSearchBox()).perform().then(function() {
                browser.sleep(1000).then(function () {
                    cafAssetSelectionPage.searchTooltip().isDisplayed().then(function(value) {
                        expect(value).to.be.true;
                        callback();
                    });
                });
            });
        });
    });

    this.Then(/^user saves the selection$/, function(callback) {
        cafAssetSelectionPage.saveButton().click().then(function() {
            cafAssetSelectionPage.selectedFilter().then(function(text) {
                selectedFilterName = text;
                cafAssetSelectionPage.selectedTemplate().then(function(text) {
                    selectedTemplateName = text;
                    callback();
                });
            });
        });
    });

    this.When(/^user selects a different Equipment Template with name (.*)$/, function(templateName, callback) {
        cafAssetSelectionPage.getAssetTemplate().click().then(function() {
            const currentSelection = cafAssetSelectionPage.getAssetTemplateOption(templateName);
            currentSelection.click().then(function() {
                currentSelection.getText().then(function(templateName) {
                    expect(templateName).to.not.equal(selectedTemplateName);
                    cafAssetSelectionPage.getSearchButton().click().then(function() {
                    browser.sleep(5000).then(function() {
                        callback();
                        });
                    });
                });
            });
        });
    });

    this.Then(/^error message is displayed$/, function(callback) {
        browser.sleep(3000).then(function() {
            cafAssetSelectionPage.errorMessageText().isPresent().then(function(isErrorPresent) {
                expect(isErrorPresent).to.be.true;
                callback();
            });
        });
    });

    this.Then(/^table shows no results$/, function(callback) {
        browser.sleep(30000).then(function() {
            cafAssetSelectionPage.tableNoResults().isPresent().then(function(isTablePresent) {
                expect(isTablePresent).to.be.true;
                callback();
            });
        });
    });

    this.Then(/^the previous Equipment Template is displayed$/, function(callback) {
        cafAssetSelectionPage.selectedTemplate().then(function(text) {
            expect(text).to.equal(selectedTemplateName);
            callback();
        });
    });

    this.When(/^the user clicks Next$/, function(callback) {
        cafAssetSelectionPage.clickNextButton().then(function() {
            callback();
        });
    });

    this.Then(/^the IOMapping page is displayed$/, function(callback) {
        browser.sleep(3000).then(function() {
            cafIOMappingPage.ioMappingHeaderButton().click().then(function(){
                cafIOMappingPage.ioMappingContainer().isDisplayed().then(function(value) {
                    expect(value).to.be.true;
                    callback();
                });
            });
        });
    });

    this.Then(/^The user can see the selected template and filter labels$/, function(callback) {
        cafIOMappingPage.assetSelectionLabels().isDisplayed().then(function(value) {
           expect(value).to.be.true;
           cafIOMappingPage.getTemplateLabel(selectedTemplateName).isDisplayed().then(function(value) {
               expect(value).to.be.true;
               cafIOMappingPage.getAssetFilterLabel(selectedFilterName).isDisplayed().then(function(value) {
                   expect(value).to.be.true;
                   callback();
               });
           });
        });
    });

    this.When(/^caf user clicks on the Tags icon in the tree heirarchy$/, function(callback) {
        cafIOMappingPage.getPositionTag().click();
        browser.sleep(1000).then(function () {
            //cafIOMappingPage.getSubTemplateData().isDisplayed();
            callback();
        });
    });

    this.When(/^caf user clicks on the sub-templates icon in the tree heirarchy$/, function(callback) {
        console.log("before click");
        cafIOMappingPage.getPositionSubTemplates().click();
        console.log("after click");
        browser.sleep(1000).then(function () {
            console.log("after click 1");
            cafIOMappingPage.getSubTemplatesList().isDisplayed();
            callback();
        });
    });

    this.Then(/^tree heirarchy is dispalyed$/, function(callback) {
        cafIOMappingPage.getTreeView().isDisplayed().then(function() {
            browser.sleep(5000);
            callback();
        });
    });

    this.Then(/^caf user enters the search for the tag "AV_TAG_1.130"$/, function(callback) {
        cafIOMappingPage.getTagSearchField().sendKeys("AV_TAG_1.130").then(function() {
            cafIOMappingPage.getSearchIcon().isDisplayed().click().then(function(){
                browser.sleep(5000);
                callback();
            });
        });
    });

    this.Then(/^caf user enters the search for the tag "AV_TAG_1.1"$/, function(callback) {
        cafIOMappingPage.getTagSearchField().sendKeys("AV_TAG_1.1").then(function() {
            cafIOMappingPage.getSearchIcon().isDisplayed().click().then(function(){
                browser.sleep(5000);
                callback();
            });
        });
    });

    this.Then(/^the searched tag should be displayed in the search results$/, function (callback) {
        browser.sleep(5000).then(function () {
            cafIOMappingPage.inputSearchTagToDrag().getText().then(function(string) {
                expect(string).contains('AV_TAG_1.130');
                console.log(' STRING ', string);
                callback();
            });
        });
    });

    this.Then(/^the searched common tag should be displayed in the search results$/, function (callback) {
        browser.sleep(5000).then(function () {
            cafIOMappingPage.inputSearchTagToDrag().getText().then(function(string) {
                expect(string).contains('AV_TAG_1.1');
                console.log(' STRING ', string);
                callback();
            });
        });
    });

    this.When(/^user drag and drop the tag onto the input definition row$/, function(callback) {
        console.log("enter drag dop");
        TestHelperPO.elementToBeClickable(element(by.css('#apm-dp-input-row-0'))).then(function () {
            console.log("click input");
             var dragList=element.all(by.css('div#label.tree-view-label.style-scope.px-tree-view-leaf.tree-view-level-3'));
             var elem=dragList.get(0);
            cafIOMappingPage.getDraggableTag().click();
            var target = element(by.css('#apm-dp-input-row-0 > td:nth-child(5) > span'));
            TestHelperPO.dragAndDrop(elem, target).then(function () {
                console.log('drag and drop');
                browser.sleep(10000).then(function () {
                    callback();
                });
            });
        });
    });

    this.When(/^user drag and drop the common tag onto the input definition row$/, function(callback) {
        console.log("enter drag dop");
        TestHelperPO.elementToBeClickable(element(by.css('#apm-dp-input-row-0'))).then(function () {
            console.log("click input");
            var dragList=element.all(by.css('div#label.tree-view-label.style-scope.px-tree-view-leaf.tree-view-level-2'));
            var elem=dragList.get(0);
            cafIOMappingPage.getDraggableCommonTag().click();
            var target = element(by.css('#apm-dp-input-row-0 > td:nth-child(5) > span'));
            TestHelperPO.dragAndDrop(elem, target).then(function () {
                console.log('drag and drop');
                browser.sleep(10000).then(function () {
                    callback();
                });
            });
        });
    });

    this.Then(/^input is mapped$/, function(callback) {
        browser.sleep(5000).then(function () {
            cafIOMappingPage.inputDefinitionMapped().getText().then(function (string) {
                console.log(string);
                assert.isNotNull(string, "tag is mapped");
                callback();
            });
        });
    });

    this.Then(/^the tag "AV_TAG_1.130" should be mapped to the input definition$/, function(callback) {
        browser.sleep(5000).then(function () {
            cafIOMappingPage.inputDefinitionMapped().getText().then(function (string) {
                console.log(string);
                expect(string).contains('AV_TAG_1.130');
                callback();
            });
        });
    });

    this.Then(/^the tag "AV_TAG_1.1" should be mapped to the input definition$/, function(callback) {
        browser.sleep(5000).then(function () {
            cafIOMappingPage.inputDefinitionMapped().getText().then(function (string) {
                console.log(string);
                expect(string).contains('AV_TAG_1.1');
                callback();
            });
        });
    });

    this.Then(/^user selects the option to Add Common Tags$/, function (callback) {
        cafIOMappingPage.selectAddCommonTagsOption().click().then(function () {
            callback();
        });
    });

    this.When(/^caf user clicks on the Tags icon in the root tree heirarchy$/, function(callback) {
        cafIOMappingPage.getRootPositionTag().click()
        browser.sleep(1000).then(function () {
            cafIOMappingPage.getTagsList().isDisplayed();
            callback();
        });
    });

    this.When(/^user clicks on the attributes in the hierarchy$/, function(callback) {
        cafIOMappingPage.getRootPositionAttributes().click();
        browser.sleep(5000).then(function () {
            //expect(cafIOMappingPage.getAttributeList().isDisplayed()).toBe(true);
            callback();
        });
    });

    this.When(/^user drag and drop the attributes onto the constant definition row$/, function(callback) {
        console.log("enter drag dop");
        TestHelperPO.elementToBeClickable(element(by.css('#apm-dp-constant-0'))).then(function () {
            console.log("click constant");
            var dragList=element.all(by.css('#label.tree-view-level-2.px-tree-view-leaf'));
            var elem=dragList.get(2);
            cafIOMappingPage.getDraggableAttribute().click();
            var target = element(by.css('#apm-dp-constant-0 > td:nth-child(4) > div'));
            TestHelperPO.dragAndDrop(elem, target).then(function () {
                console.log('drag and drop');
                browser.sleep(10000).then(function () {
                    callback();
                });
            });
        });
    });

    this.Then(/^the attribute "attribute" should be mapped to the constant definition$/, function(callback) {
        browser.sleep(5000).then(function () {
            cafIOMappingPage.constantDefinitionMapped().getText().then(function (string) {
                console.log(string);
                expect(string).contains('attribute');
                callback();
            });
        });
    });

    this.When(/^the user clicks on the map by asset level icon$/, function(callback) {
        cafIOMappingPage.getByClassIcon().click();
        browser.sleep(1000).then(function () {
            callback();
        });
    });

    this.Then(/^caf user enters the search for the tag "AV_TAG_1.2"$/, function(callback) {
        cafIOMappingPage.getTagSearchField().sendKeys("AV_TAG_1.2").then(function() {
            cafIOMappingPage.getSearchIcon().isDisplayed().click().then(function(){
                browser.sleep(5000);
                callback();
            });
        });
    });

    this.Then(/^the searched common tag should be displayed in the search results "AV_TAG_1.2$/, function (callback) {
        browser.sleep(5000).then(function () {
            cafIOMappingPage.inputSearchTagToDrag().getText().then(function(string) {
                expect(string).contains('AV_TAG_1.2');
                console.log(' STRING ', string);
                callback();
            });
        });
    });

    this.When(/^user drag and drop the tag onto the constant definition row$/, function(callback) {
        console.log("enter drag dop");
        TestHelperPO.elementToBeClickable(element(by.css('#apm-dp-constant-0'))).then(function () {
            console.log("click constant");
            var dragList=element.all(by.css('div#label.tree-view-label.style-scope.px-tree-view-leaf.tree-view-level-2'));
            var elem=dragList.get(0);
            cafIOMappingPage.getDraggableCommonTag().click();
            var target = element(by.css('#apm-dp-constant-0 > td:nth-child(4) > div'));
            TestHelperPO.dragAndDrop(elem, target).then(function () {
                console.log('drag and drop');
                browser.sleep(10000).then(function () {
                    callback();
                });
            });
        });
    });

    this.Then(/^the tag "AV_TAG_1.2" should be mapped to the constant definition$/, function(callback) {
        browser.sleep(5000).then(function () {
            cafIOMappingPage.constantDefinitionMappedToTag().getText().then(function (string) {
                console.log(string);
                expect(string).contains('AV_TAG_1.2');
                callback();
            });
        });
    });

    this.Then(/^the user clear the search$/, function (callback) {
        cafIOMappingPage.clearSearchTag().click();
        browser.sleep(1000).then(function () {
            callback();
        });
    });

    this.When(/^the user clicks on the map by sub-template level icon$/, function(callback) {
        cafIOMappingPage.getBySubTemplateIcon().click();
        browser.sleep(1000).then(function () {
            callback();
        });
    });

    this.Then(/^caf user enters the search for the tag "AV_TAG_1.3"$/, function(callback) {
        cafIOMappingPage.getTagSearchField().sendKeys("AV_TAG_1.3").then(function() {
            cafIOMappingPage.getSearchIcon().isDisplayed().click().then(function(){
                browser.sleep(5000);
                callback();
            });
        });
    });
    this.Then(/^the searched tag "AV_TAG_1.3" should be displayed in the search results$/, function (callback) {
        browser.sleep(5000).then(function () {
            cafIOMappingPage.inputSearchTagToDrag().getText().then(function(string) {
                expect(string).contains('AV_TAG_1.3');
                console.log(' STRING ', string);
                callback();
            });
        });
    });

    this.Then(/^the searched tag "AV_TAG_1.4" should be displayed in the search results$/, function (callback) {
      browser.sleep(5000).then(function () {
          cafIOMappingPage.inputSearchTagToDrag().getText().then(function(string) {
              expect(string).contains('AV_TAG_1.4');
              console.log(' STRING ', string);
              callback();
          });
      });
  });

    this.When(/^caf user clicks on the Tags icon in the tree heirarchy at PPN01$/, function(callback) {
        cafIOMappingPage.getPositionTag().click()
        browser.sleep(1000).then(function () {
            callback();
        });
    });


    this.When(/^user drag and drop the sub-template tag onto the constant definition row$/, function(callback) {
        console.log("enter drag dop");
        TestHelperPO.elementToBeClickable(element(by.css('#apm-dp-constant-0'))).then(function () {
            console.log("click constant");
            var dragList=element.all(by.css('div#label.tree-view-label.style-scope.px-tree-view-leaf.tree-view-level-3'));
            var elem=dragList.get(0);
            cafIOMappingPage.getDraggableCommonTagBySubTemplate().click();
            var target = element(by.css('#apm-dp-constant-0 > td:nth-child(4) > div'));
            TestHelperPO.dragAndDrop(elem, target).then(function () {
                console.log('drag and drop');
                browser.sleep(10000).then(function () {
                    callback();
                });
            });
        });
    });

    this.Then(/^the tag "AV_TAG_1.3" should be mapped to the constant definition$/, function(callback) {
        browser.sleep(5000).then(function () {
            cafIOMappingPage.constantDefinitionMappedToTagFromSubTemplateIcon().getText().then(function (string) {
                console.log(string);
                expect(string).contains('AV_TAG_1.3');
                callback();
            });
        });
    });

    this.When(/^user drag and drop the tag onto the output definition$/, function(callback) {
        console.log("enter drag dop");
        TestHelperPO.elementToBeClickable(element(by.css('#apm-dp-output-1'))).then(function () {
            console.log("click input");
            var dragList=element.all(by.css('div#label.tree-view-label.style-scope.px-tree-view-leaf.tree-view-level-2'));
            var elem=dragList.get(0);
            cafIOMappingPage.getDraggableCommonTag().click();
            var target = element(by.css('#apm-dp-output-1 > td:nth-child(5) > span'));
            TestHelperPO.dragAndDrop(elem, target).then(function () {
                console.log('drag and drop');
                browser.sleep(10000).then(function () {
                    callback();
                });
            });
        });
    });

    this.Then(/^caf user enters the search for the tag "AV_TAG_1.4"$/, function(callback) {
      cafIOMappingPage.getTagSearchField().sendKeys("AV_TAG_1.4").then(function() {
          cafIOMappingPage.getSearchIcon().isDisplayed().click().then(function(){
              browser.sleep(5000);
              callback();
          });
      });
  });

    this.Then(/^the tag "AV_TAG_1.4" should be mapped to the output definition$/, function(callback) {
        browser.sleep(5000).then(function () {
            cafIOMappingPage.outputDefinitionMappedToTag().getText().then(function (string) {
                console.log(string);
                expect(string).contains('AV_TAG_1.4');
                callback();
            });
        });
    });

};
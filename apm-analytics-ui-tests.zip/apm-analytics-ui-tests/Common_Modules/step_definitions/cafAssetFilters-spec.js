/**
 * Asset Filter spec
 */


module.exports = function() {

    var randVal = Date.now();
    var filterName = "assetFilter-" + randVal

    this.Then(/^Asset Filters link should be displayed$/, function (callback) {
        cafAssetFiltersPage.isAssetFiltersLinkDisplayed().then(function(bool){
            assert.equal(bool, true , "asset filters link displayed is " + bool + " and should be true");
            callback();
        });
    });

    this.When(/^the user clicks on the Asset Filters sub navigation$/, function (callback) {
        cafAssetFiltersPage.clickAssetFiltersLink().then(function(){
            callback();
          });
    });

    this.Then(/^Asset Filters page should be displayed$/, function (callback) {
        cafAssetFiltersPage.isAssetFiltersHeaderDisplayed().then(function(bool){
            assert.equal(bool, true , "asset filters link is displayed");
            callback();
        });
    });

    this.Then(/^the default asset filters are displayed$/, function (callback) {
        cafAssetFiltersPage.isAssetFilterPresent('filterList_All Enterprises').then(function(bool){
        assert.equal(bool, true , "All Enterprises is displayed");
            cafAssetFiltersPage.isAssetFilterPresent('filterList_All Sites').then(function(bool) {
          assert.equal (bool, true, "All Sites is displayed");
                cafAssetFiltersPage.isAssetFilterPresent('filterList_All Segments').then(function(bool) {
            assert.equal (bool, true, "All Segments is displayed");
                    cafAssetFiltersPage.isAssetFilterPresent('filterList_All Assets').then(function(bool) {
              assert.equal (bool, true, "All Assets is displayed");
              callback();
            });
          });
        });
      });
    });

    this.Then(/^user clicks on the filter "([^"]*)"$/, function(arg1, callback){
      cafAssetFiltersPage.clickAssetFilter(arg1).then(function(){
          browser.sleep(3000).then(function(){
              callback();
          });
      });
    });

    this.Then(/^user clicks on creating a new filter$/, function (callback){
      cafAssetFiltersPage.clickNewAssetFilter().then(function(){
        callback();
      });
    });

    this.Then(/^filter name field should be displayed with default text$/, function (callback) {
        cafAssetFiltersPage.isfilterNameTextboxDisplayed().then(function(bool){
            assert.equal(bool, true , "filter name textbox is displayed");
            callback();
        });
    });

    // this.Then(/^Asset type label and textbox should be displayed$/, function (callback) {
    //     cafAssetFiltersPage.isAssetTypeLabelDisplayed().then(function(bool){
    //         assert.equal(bool, true , "asset type label is not displayed");
    //         // cafAssetFiltersPage.isAsteriskDisplayedForAssetType().then(function(text){
    //         //     console.log("asterisk text", text)
    //         //     assert.equal(text.trim(), "" , "asterisk is not displayed for asset type");
    //         //     cafAssetFiltersPage.getAssetTypeOperatorText().then(function(text){
    //         //         assert.equal(text, "is equal to" , "operator text is not displayed for asset type");
    //                 cafAssetFiltersPage.isAssetTypeTextboxDisplayed().then(function(bool){
    //                     assert.equal(bool, true , "asset type textbox is not displayed");
    //                     callback();
    //                 });
    //             });
    //         });
    // //     });
    // // });

    this.Then(/^submit button should be disabled$/, function (callback) {
        cafAssetFiltersPage.isSubmitButtonEnabled().then(function (bool) {
            assert.equal(bool, false, "save button is disabled");
            callback();
        })
    });


    this.Then(/^I verify the options count in the Add Attribute dropdown$/, function (callback) {
        cafAssetFiltersPage.getattributeList().count().then(function(count){
            assert.isAbove(count, 2, count + "is greater than 2 in add attribute dropdown");
            callback();
        });
    });

  this.Then(/^I verify the options count in the filtered Add Attribute dropdown$/, function (callback) {
    cafAssetFiltersPage.getattributeList().count().then(function(count){
      assert.equal(count, 2, count + "is 2 in add attribute dropdown");
      callback();
    });
  });

    this.Given(/^asset type option should be checked$/, function (callback) {
       // cafAssetFiltersPage.getAttributeSelectedText().then(function(attributeText) {
        cafAssetFiltersPage.getAttributeToWork().then(function() {
          //  assert.equal(attributeText, "Asset Type Id", "asset type attribute Checkbox is checked");
            callback();
        })
    });

    this.When(/^I click the add attribute dropdown$/, function (callback) {
        cafAssetFiltersPage.clickAddAttributeDropdown().then(function(){
            callback();
        });
    });

    this.When(/^I click Asset Name option in the add attribute dropdown$/, function (callback) {
        cafAssetFiltersPage.clickAssetNameOptionInAddAttributeDropdown().then(function(){
            callback();
        });
    });

    this.When(/^I click Asset Type option in the add attribute dropdown$/, function (callback) {
        cafAssetFiltersPage.clickAssetTypeOptionInAddAttributeDropdown().then(function(){
             callback();
         });
    });

    this.Then(/^the cafUser should see the AssetFilters in left navigation$/, function (callback) {
        cafAssetFiltersPage.isAssetFiltersLinkAvailable().then(function (bool) {
            assert.equal(bool, true, "Asset Filters link is not displayed");
            callback();
        });
    });

    this.Then(/^the cafUser should not see the AssetFilters in left navigation$/, function (callback) {
        cafAssetFiltersPage.isAssetFiltersLinkNotAvailable().then(function (bool) {
            assert.equal(bool, false, "Asset Filters link is displayed");
            callback();
        });
    });

    this.Then(/^the attribute should get added$/, function (callback) {
        cafAssetFiltersPage.isAssetNamefieldDisplayed().then(function(bool){
            assert.equal(bool, true , "attribute is added");
            callback();
        });
    });

    this.When(/^I click the asset hierarchy dropdown$/, function (callback) {
      cafAssetFiltersPage.clickAssetHierarchyDropdown().then(function() {
        callback();
      });
    });

    this.Then(/^the asset hierarchy level drop down should be disabled$/, function(callback){
      cafAssetFiltersPage.isAssetHierarchyDropdownEnabled().then(function(){
        callback();
      })
    });

    this.Then(/^the Asset Type is disabled$/, function(callback){
      cafAssetFiltersPage.isAssetTypeTextboxEnabled().then(function(bool){
        console.log('Asset Type Enabled: ', bool);
        assert.equal(bool, false, 'Asset Type Text box is disabled');
       callback();
      });
    });

    this.When(/^I click Enterprise in the Asset Hierarchy dropdown$/, function (callback) {
        cafAssetFiltersPage.clickEnterpriseHierarchy().then(function(){
          callback();
        });
    });

  this.Then(/^I click Asset in the Asset Hierarchy dropdown$/, function (callback) {
    cafAssetFiltersPage.clickAssetHierarchy().then(function(){
      callback();
    });
  });
    this.Then(/^asset filters header should contain create asset button$/, function (callback) {
        cafAssetFiltersPage.isAssetFiltersAddIconDisplayed().then(function(boolean) {
            assert.equal(boolean, true, "caf asset filter header create icon is not displayed");
            callback();
        });
    });
    this.Given(/^cancel button is enabled$/, function (callback) {
        cafAssetFiltersPage.isresetButtonEnabled().then(function (bool) {
            assert.equal(bool, true, "reset button is enabled");
            callback();
        });
    });
    this.Given(/^delete button is enabled$/, function (callback) {
        cafAssetFiltersPage.isdeleteButtonEnabled().then(function (bool) {
            assert.equal(bool, true, "reset button is enabled");
            callback();
        });
    });

    this.Given(/^save changes button is enabled$/, function (callback) {
        cafAssetFiltersPage.isSaveChangesButtonEnabled().then(function (bool) {
            assert.equal(bool, true, "reset button is enabled");
            callback();
        });
    });

    this.Then(/^the asset hierarchy level drop down should be enable$/, function (callback) {
        cafAssetFiltersPage.isAssetHierarchDropdownEnabled().then( function(boolean) {
            assert.equal(boolean, true, "input definition add icon is not displayed");
            callback();
        });
    });
    this.Then(/^the asset name attribute level drop down should be enable$/, function (callback) {
        cafAssetFiltersPage.isAssetnameDropdownEnabled().then( function(boolean) {
            assert.equal(boolean, true, "input definition add icon is not displayed");
            callback();
        });
    });
    this.Then(/^the attribute level drop down should be enable$/, function (callback) {
        cafAssetFiltersPage.isAssetnameDropdownEnabled().then( function(boolean) {
            assert.equal(boolean, true, "input definition add icon is not displayed");
            callback();
        });
    });
    this.Then(/^the name text field should be enable$/, function (callback) {
        cafAssetFiltersPage.isNameTextFieldEnabled().then( function(boolean) {
            assert.equal(boolean, true, "input definition add icon is not displayed");
            callback();
        });
    });
    this.Then(/^the description text field should be enable$/, function (callback) {
        cafAssetFiltersPage.isDescriptionTextFieldEnabled().then( function(boolean) {
            assert.equal(boolean, true, "input definition add icon is not displayed");
            callback();
        });
    });
    this.Then(/^the add rule button should be enabled$/, function (callback) {
        cafAssetFiltersPage.isRuleButtonEnabled().then( function(boolean) {
            assert.equal(boolean, true, "input definition add icon is not displayed");
            callback();
        });
    });
    this.Then(/^the delete rule button should be enable$/, function (callback) {
        cafAssetFiltersPage.isDeleteRuleEnabled().then( function(boolean) {
            assert.equal(boolean, true, "input definition add icon is not displayed");
            callback();
        });
    });

    this.Then(/^asset filters header should not contain create asset button$/, function (callback) {
        cafAssetFiltersPage.isAssetFiltersAddIconNotDisplayed().then(function(boolean) {
            assert.equal(boolean, false, "caf asset filter header create icon is displayed");
            callback();
        });
    });
    this.Given(/^cancel button should not be displayed$/, function (callback) {
        cafAssetFiltersPage.isresetButtonNotEnabled().then(function (bool) {
            assert.equal(bool, false, "reset button is Displayed");
            callback();
        });
    });
    this.Given(/^delete button should not be displayed$/, function (callback) {
        cafAssetFiltersPage.isdeleteButtonNotDisplayed().then(function (bool) {
            assert.equal(bool, false, "reset button is displayed");
            callback();
        });
    });
    this.Given(/^save changes button should not be displayed$/, function (callback) {
        cafAssetFiltersPage.isSaveChangesButtonNotDisplayed().then(function (bool) {
            assert.equal(bool, false, "reset button is enabled");
            callback();
        });
    });
    this.Then(/^the asset hierarchy level drop down should not be displayed$/, function (callback) {
        cafAssetFiltersPage.isAssetHierarchDropdownNotDisplayed().then( function(boolean) {
            assert.equal(boolean, false, "input definition add icon is displayed");
            callback();
        });
    });
    this.Then(/^the asset name attribute level drop down should not be displayed$/, function (callback) {
        cafAssetFiltersPage.isAssetnameDropdownNotDisplayed().then( function(boolean) {
            assert.equal(boolean, false, "input definition add icon is displayed");
            callback();
        });
    });
    this.Then(/^the attribute level drop down should not be displayed$/, function (callback) {
        cafAssetFiltersPage.isAssetnameDropdownNotDisplayed().then( function(boolean) {
            assert.equal(boolean, false, "input definition add icon is displayed");
            callback();
        });
    });
    this.Then(/^the name text field should not be displayed$/, function (callback) {
        cafAssetFiltersPage.isNameTextFieldNotDisplayed().then( function(boolean) {
            assert.equal(boolean, false, "input definition add icon is displayed");
            callback();
        });
    });
    this.Then(/^the description text should not be displayed$/, function (callback) {
        cafAssetFiltersPage.isDescriptionTextFieldNotDisplayed().then( function(boolean) {
            assert.equal(boolean, false, "input definition add icon is displayed");
            callback();
        });
    });
    this.Then(/^the add rule button should not be displayed$/, function (callback) {
        cafAssetFiltersPage.isRuleButtonNotDisplayed().then( function(boolean) {
            assert.equal(boolean, false, "input definition add icon is displayed");
            callback();
        });
    });
    this.Then(/^the delete rule button should not be displayed$/, function (callback) {
        cafAssetFiltersPage.isDeleteRuleButtonNotDisplayed().then( function(boolean) {
            assert.equal(boolean, false, "input definition add icon is not displayed");
            callback();
        });
    });


 this.Then(/^I verify that the Enterprise hierarchy level is displayed$/, function (callback) {
        cafAssetFiltersPage.isAssetHierNameDisplayed().then(function(bool){
            assert.equal(bool, true, "enterprise is selected");
            callback();
        });
    });

    this.Given(/^cancel button should be enabled$/, function (callback) {
        cafAssetFiltersPage.isCancelButtonEnabled().then(function (bool) {
            assert.equal(bool, true, "reset button is enabled");
            callback();
        });
    });

    this.Then(/^search bar should be displayed in filter container list block$/, function (callback) {
        cafAssetFiltersPage.isSearchBarDisplayedInFilterContainerListBlock().then(function(bool){
            assert.equal(bool, true , "search bar is displayed in filter container list block ");
            callback();
        });
    });

    this.Then(/^new filter add icon is displayed$/, function (callback) {
      cafAssetFiltersPage.isAddIconDisplayed().then(function(bool){
        assert.equal(bool, true , "add icon is displayed");
        callback();
      });
    });

    this.When(/^I click the reset button$/, function (callback) {
        cafAssetFiltersPage.clickResetButton().then(function() {
            callback();
        });
    });

    this.Then(/^the attribute should get deleted/, function (callback) {
        cafAssetFiltersPage.isAssetNamefieldDeleted().then(function(bool){
            assert.equal(bool, true , "attribute is not deleted");
            callback();
        });
    });

    this.Then(/^the attribute should be asset type id/, function (callback) {       
        cafAssetFiltersPage.isAssetTypeLabelDisplayed().then(function(bool){
            assert.equal(bool, true , "filter length is one");
            return cafAssetFiltersPage.getAssetTypeText();
        }).then(function(text) {
            // assert.equal(bool, true , "filter length is one");
            callback();
        })
    });

    this.When(/^I enter the Filter Name$/, function (callback) {
        cafAssetFiltersPage.enterFilterName(filterName).then(function(){
            callback();
        });
    });

    this.Then(/^I should verify Save button is disabled/, function (callback) {
        cafAssetFiltersPage.saveButton().isEnabled().then(function(enabled) {
            expect(enabled).to.not.equal(true);
            callback();
        });
    });

    this.Then(/^I provide the asset type value$/, function (callback) {
        cafAssetFiltersPage.enterAssetType().then(function(){
            callback();
        });;
    });

    this.Then(/^save button should be enabled$/, function (callback) {
        cafAssetFiltersPage.saveButton().isEnabled().then(function(enabled) {
            expect(enabled).to.equal(true);
            callback();
        });
    });

    this.Then(/^I click the save button$/, function (callback) {
        cafAssetFiltersPage.clickSaveButton().then(function(){
            callback();
        });
    });

    this.Then(/^the filter should be created$/, function (callback) {
        cafAssetFiltersPage.isCreatedFilterPresent(filterName).then(function(){
            callback();
        });
    });

    this.When(/^I search for an existing filter$/, function (callback) {
        cafAssetFiltersPage.enterSearchFilter(filterName).then(function(){
            callback();
        });
    });

    this.Then(/^the filter should be displayed in search results$/, function (callback) {
        browser.sleep(2000).then(function(){
            cafAssetFiltersPage.getassetFilterSearchResultCount().then(function(searchCount){
                console.log('count : ' + searchCount);
                expect(searchCount).to.be.equal(1);
                callback();
            });
        });
    });

    this.When(/^I click on the filter in the search result$/, function (callback) {
        cafAssetFiltersPage.clickFirstSearchResult().then(function(){
            browser.sleep(2000).then(function(){
                callback();
            });
        });
    });

    this.Then(/^the filter name should be displayed$/, function (callback) {
        cafAssetFiltersPage.getFilterNameText().then(function(text){
            assert.equal(text, filterName , "filter name is equal");
            callback();
        });
    });

    this.Then(/^the filter name should be displayed as "([^"]*)"$/, function (arg1, callback) {
      cafAssetFiltersPage.getFilterNameText().then(function(text){
        assert.equal(text, arg1 , "filter name is equal");
        callback();
      });
    });

   // this.Then(/^I change the filter name$/, function (callback) {
   //         cafAssetFiltersPage.updateFilterName(filterName).then(function(){
   //         callback();
   //      });
   //  });

    this.Then(/^the delete icon should be displayed$/, function (callback) {
        cafAssetFiltersPage.isDeleteIconDisplayed().then(function(bool){
            assert.equal(bool, true , "delete icon is displayed");
            callback();
        });
    });

    this.Then(/^delete icon should be enabled$/,function(callback){
      cafAssetFiltersPage.isDeleteButtonEnabled().then(function(bool){
        assert.equal(bool, true, "Delete button is enabled");
        callback();
      });
    });

    this.Then(/^delete icon should be disabled$/,function(callback){
      cafAssetFiltersPage.isDeleteButtonEnabled().then(function(bool){
        assert.equal(bool, false, "Delete button is disabled");
        callback();
      });
    });

    this.Then(/^Asset name value is disabled$/, function (callback) {
        cafAssetFiltersPage.displayedAttributes().then(function(displayedAttributes){
            async.reduce(displayedAttributes, false, function(memo, el, callback) {
                el.isEnabled().then(function(bool) {
                    callback(null, memo || bool);
                })
            }, function(err, isAllEnabled) {
                assert.equal(isAllEnabled, false , "asset name value is disabled");
                callback();
            });
        });
    });

    this.Given(/^asset name, asset description columns with data are displayed$/, function (callback) {
        browser.sleep(2000).then(function() {
            return cafAssetFiltersPage.getAssetNameColumnHeader();
        }).then(function(text){
            assert.equal(text, "Asset Name" , "asset name column is displayed");
            return cafAssetFiltersPage.getAssetDescriptionColumnHeader();
        }).then(function(text){
            assert.equal(text, "Asset Description" , "asset description column is displayed");
            callback();
        });
    });

    this.Given(/^the search bar is displayed$/, function (callback) {
        cafAssetFiltersPage.isSearchBarDisplayed().then(function(bool){
            assert.equal(bool, true , "search bar is displayed");
            callback();
        });
    });

    this.When(/^I click the delete icon$/, function (callback) {
        cafAssetFiltersPage.clickDeleteIcon().then(function(){
            callback();
        });
    });

     this.When(/^I click the delete button in the confirmation$/, function (callback) {
         cafAssetFiltersPage.clickDeleteButton().then(function(){
             browser.sleep(2000).then(function() {
                 callback();
             });
         });
     });

     this.Then(/^I clear the search bar$/, function (callback) {
       browser.sleep(10000).then(function() {
         cafAssetFiltersPage.assetFilterSearchButton().click().then(function() {
           callback();
         });
       });
     });

    this.Then(/^the asset filter should be deleted$/, function (callback) {
        cafAssetFiltersPage.assetFilterSearchBar().click().then(function(){
            cafAssetFiltersPage.assetFilterSearchField(filterName).then(function(){
                cafAssetFiltersPage.areSearchResultsElementNotDisplayed().then(function(bool){
                    assert.equal(bool, true, "asset filter is deleted");
                    callback();
                });
            });
        });
    });

    this.Given(/^I am in the Analytic landing page$/, function (callback) {
        cafCreateAnalyticPage.verifyCreateAnalyticsTab();
        cafCreateAnalyticPage.clickAnalyticTab().then(function(){
            callback();
        });
    });

    this.Then(/^I should be able to see and click on the Asset Filters sub navigation$/, function (callback) {
        cafAssetFiltersPage.clickAssetFilterSubNav();
        expect(cafAssetFiltersPage.newFilterSetButton()).to.exist;
        callback();
    });


    this.Then(/^it should navigate to the Asset FIlters page$/, function (callback) {
        expect(cafAssetFiltersPage.enterFilterNameLabel()).to.exist;
        expect(cafAssetFiltersPage.resetButton()).to.exist;
        expect(cafAssetFiltersPage.saveButton()).to.exist;
        expect(cafAssetFiltersPage.addAttribute()).to.exist;
        expect(cafAssetFiltersPage.newFilterSetButton()).to.exist;
        callback();
    });


    this.Given(/^I am in the Asset Filter page$/, function (callback) {
        browser.refresh().then(function() {
            cafAssetFiltersPage.elementToBeClickable(cafAssetFiltersPage.newFilterSetButton());
            cafAssetFiltersPage.elementToBeClickable(cafAssetFiltersPage.enterFilterNameLabel());
            cafAssetFiltersPage.elementToBeClickable(cafAssetFiltersPage.resetButton());
            callback();
        });
    });


    this.When(/^I click on New Filter Set$/, function (callback) {
        cafAssetFiltersPage.elementToBeClickable(cafAssetFiltersPage.resetButton());
            callback();
    });

    this.When(/^I click on any of the filter set$/, function (callback) {
        cafAssetFiltersPage.clickFirstSearchResult();
        callback();
    });

    this.Then(/^I should be able to see the default attributes$/, function (callback) {
        cafAssetFiltersPage.visibilityOf(cafAssetFiltersPage.enterFilterNameLabel());
        browser.sleep(5000).then(function(){

            cafAssetFiltersPage.displayedAttribute().get(0).getText().then(function(value1){
                expect(value1).to.have.string('Engine Family');
            });
            cafAssetFiltersPage.displayedAttributeCount().then(function(count){
                callback();
            });
        });

    });

    this.Then(/^I should verify the default status of the buttons$/, function (callback) {
        expect(cafAssetFiltersPage.saveButton().isEnabled()).to.not.be.true;
        cafAssetFiltersPage.resetButton().isEnabled().then(function (enabled) {
            expect(enabled).to.equal(true);
            cafAssetFiltersPage.displayedAttributeValueList().get(0).getText().then(function(value1){
                assert.equal(value1,'', "First engine family attribute value has to be null");
                callback();
            });
        });
    });



    this.When(/^I provide the Filter Name$/, function (callback) {
        browser.sleep(10000).then(function(){
        cafAssetFiltersPage.filtername().click().then(function(){
            return cafAssetFiltersPage.enterFilterNameInput().clear();
        }).then(function(){
            cafAssetFiltersPage.assetCriteriaName();
            return cafAssetFiltersPage.engineFamilyTextField().click()
        }).then(function(){
            return cafAssetFiltersPage.getAssetCriteriaName()
        }).then(function(assetName){
            cafAssetFiltersPage.createdName = assetName;
            callback();
            });
        });
    });

    this.When(/^I create the Asset Filter$/, function (callback) {
        cafAssetFiltersPage.elementToBeClickable(cafAssetFiltersPage.saveButton());
        cafAssetFiltersPage.saveButton().isEnabled().then(function(enabled){
            expect(enabled).to.be.true;
            cafAssetFiltersPage.saveButton().click().then(function(){
                callback();
            });
        });
    });

    this.Then (/^I verify that the Asset Filter is created$/,function(callback){
       expect(cafAssetFiltersPage.assetFilterSearchBar()).to.exist;
        cafAssetFiltersPage.assetFilterSearchBar().click().then(function(){
            return cafAssetFiltersPage.assetFilterSearchField(filterName);
        }).then(function(){
            return cafAssetFiltersPage.getassetFilterSearchResultCount();
        }).then(function(searchCount){
            assert.equal(searchCount,'1','the count results are same');
            callback();
        });
    });

    this.Then (/^I delete the asset filter$/,function(callback){
        cafAssetFiltersPage.deleteAnalyticIcon().then(function(){
            return cafAssetFiltersPage.deleteAnalyticButton();
        }).then(function(){
            return browser.sleep(20000);
        }).then(function(){
            return cafAssetFiltersPage.elementToBeClickable(cafAssetFiltersPage.assetFilterSearchIcon());
        }).then(function() {
            return cafAssetFiltersPage.assetFilterSearchIcon().click();
        }).then(function(){
            return cafAssetFiltersPage.assetFilterSearchField().sendKeys(cafAssetFiltersPage.createdName);
        }).then(function(){
            return cafAssetFiltersPage.getassetFilterSearchResultCount();
        }).then(function(searchCount){
            assert.equal(searchCount,'0','the count results are null');
            cafAssetFiltersPage.assetFilterSearchField().clear();
            callback();
        });
    });

    this.When(/^the values for all attributes and has type ids$/, function (callback) {
        var typeMap = {
            "Asset Type Id": false,
            "Segment Type Id": false,
            "Site Type Id": false,
            "Enterprise Type Id": false,
        };

        cafAssetFiltersPage.clickAddAttributeDropdown().then(function() {
            return cafAssetFiltersPage.getattributeList();
        }).then(function(attributes) {
            async.each(attributes, function(attribute, asyncCB) {
                attribute.element(by.css('span')).getText().then(function(text) {
                    if (typeMap.hasOwnProperty(text)) {
                        typeMap[text] = true;
                    }
                    return attribute.element(by.css('i')).getAttribute('class')
                }).then(function(classes) {
                    if (classes.split(' ').indexOf('fa-check-square-o') === -1) {
                        attribute.click();
                    }
                    asyncCB();
                });
            }, function(err) {
                var areAllTypeIdsInDropDown = true;
                
                for (var type in typeMap) {
                    areAllTypeIdsInDropDown = areAllTypeIdsInDropDown && typeMap[type];
                }
                
                assert(areAllTypeIdsInDropDown, true, "missing type ids");

                cafAssetFiltersPage.displayedAttributeValueList().then(function(attributeValueList) {
                    async.each(attributeValueList, function(attributeValue, asyncCBTwo) {
                        attributeValue.element(by.css('input')).sendKeys('test').then(function() {
                            asyncCBTwo();
                        })
                    }, function(err) {
                        callback();
                    });
                });
            });
        });
    });


    this.Then(/^with all attributes$/, function (callback) {
        cafAssetFiltersPage.clickFirstSearchResult().then(function(){
            return cafAssetFiltersPage.editFilterName().getText();
        }).then(function(name){
            assert(name, cafAssetFiltersPage.createdName, "name and createdName are equal");
            return cafAssetFiltersPage.displayedAttributes();
        }).then(function(displayedAttributes) {
            async.each(displayedAttributes, function(displayedAttribute, asyncCB) {
                displayedAttribute.isEnabled().then(function(bool) {
                    assert.equal(bool, false, "all fields should be disabled");
                    asyncCB();
                });
            }, function(err) {
                callback();
            });
        });
    });

    this.When(/^I search for a non-existing filter$/, function (callback) {
        cafAssetFiltersPage.assetFilterSearchField().clear();
        cafAssetFiltersPage.assetFilterSearchField().sendKeys('zzzaaa123123').then(function(){
            callback();
        });
    });


    this.Then(/^I should not see any results$/, function (callback) {
        cafAssetFiltersPage.getassetFilterSearchResultCount().then(function(searchCount){
            assert.equal(searchCount,'0','the count result is not 0');
            cafAssetFiltersPage.assetFilterSearchField().clear();
            callback();
        });
    });

    this.When(/^I refresh the page$/, function (callback) {
      browser.refresh().then(function() {
        callback();
      });
    });

    this.Given(/^there are multiple filter sets starting with same name$/, function (callback) {
        cafAssetFiltersPage.newFilterSetButton().click().then(function(){
            cafAssetFiltersPage.filtername().click().then(function(){
                cafAssetFiltersPage.enterFilterNameInput().clear().then(function(){
                    cafAssetFiltersPage.assetCriteriaName();
                    cafAssetFiltersPage.engineFamilyTextField().sendKeys(cafAssetFiltersPage.engineFamilyName()).then()
                    cafAssetFiltersPage.saveButton().isEnabled().then(function(enabled){
                        expect(enabled).to.be.true;
                        cafAssetFiltersPage.saveButton().click().then(function(){
                            browser.sleep(20000).then(function(){
                                cafAssetFiltersPage.saveButton().isEnabled().then(function(disabled){
                                    expect(disabled).to.be.not.true;
                                    callback();
                                });
                            });
                        });
                    });
                    callback();
                });
            });
        });
    });

};
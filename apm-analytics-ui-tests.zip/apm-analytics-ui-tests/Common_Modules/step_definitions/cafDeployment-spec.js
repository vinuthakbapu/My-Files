module.exports = function () {

    let deploymentName
    let appHubPath = browser.params.appHubpath;

    this.Given(/^the cafUser clicks deployment config tab$/, function (callback) {
        cafDeploymentPage.clickDeploymentConfigTab().then(function () {
            callback();
        });
    });

    this.When(/^caf user clicks the newly created deployment$/, function (callback) {
        browser.sleep(3000).then(function () {
            cafAssetSelectionPage.deployment().click().then(function () {
                browser.sleep(3000).then(function () {
                    callback();
                })
            });
        });
    });

    this.Given(/^the cafUser goes to deployment config page$/, function (callback) {
        cafDeploymentPage.gotoConfigPage().then(function () {
            callback();
        });
    });

    this.Given(/^the cafUser should see the asset filter dropdown$/, function (callback) {
        cafDeploymentPage.visibilityOf(cafDeploymentPage.getAssetFilterDropdown()).then(function (value) {
            expect(value).to.be.true;
            callback();
        });
    });

    this.Given(/^the cafUser should see the pre and next buttons$/, function (callback) {
        cafDeploymentPage.visibilityOf(cafDeploymentPage.getPrevButton()).then(function (value) {
            expect(value).to.be.true;
            cafDeploymentPage.visibilityOf(cafDeploymentPage.getNextButton()).then(function (value) {
                expect(value).to.be.true;
                callback();
            });
        });
    });

    this.Then(/^the cafUser should see the Deployments in left navigation$/, function (callback) {
        cafDeploymentPage.isDeploymentsLinkAvailable().then(function (bool) {
            assert.equal(bool, true, "deployments link is not displayed");
            callback();
        });
    });

    this.Then(/^the cafUser should not see the Deployments in left navigation$/, function (callback) {
        cafDeploymentPage.isDeploymentsLinkNotAvailable().then(function (bool) {
            assert.equal(bool, false, "deployments link is displayed");
            callback();
        });
    });

    this.Given(/^the cafUser should see the search buttons$/, function (callback) {
        cafDeploymentPage.visibilityOf(cafDeploymentPage.getSearchButton()).then(function (value) {
            expect(value).to.be.true;
            callback();
        });
    });

    this.Then(/^the caf add icon should be enabled$/, function (callback) {
        // Write code here that turns the phrase above into concrete actions
        cafDeploymentPage.addDeployment().isEnabled().then(function (enabled) {
            expect(enabled).to.equal(true);
            callback();
        });
    });

    this.Then(/^the caf analytic deployment add icon should be enabled$/, function (callback) {
        // Write code here that turns the phrase above into concrete actions
        cafDeploymentPage.addAnalyticDeployment().isEnabled().then(function (enabled) {
            expect(enabled).to.equal(true);
            callback();
        });
    });

    this.When(/^cafUser clicks on the add icon$/, function (callback) {
        cafDeploymentPage.addDeployment().click().then(function (enabled) {
            callback();
        });
    });

    this.When(/^user clicks on the edit button on the deployment details page$/, function (callback) {
        cafDeploymentPage.editDeployment().click().then(function (enabled) {
            callback();
        });
    });

    this.Then(/^the deployment edit link is disabled$/, function (callback) {
        // Write code here that turns the phrase above into concrete actions
        cafDeploymentPage.editDeployment().isEnabled().then(function (enabled) {
            expect(enabled).to.equal(false);
            callback();
        });
    });

    this.Then(/^the deployment edit link is disabled$/, function (callback) {
        // Write code here that turns the phrase above into concrete actions
        cafDeploymentPage.editDeployment().isEnabled().then(function (enabled) {
            expect(enabled).to.equal(false);
            callback();
        });
    });

    this.When(/^cafUser clicks on the add analytic deployment icon$/, function (callback) {
        cafDeploymentPage.addAnalyticDeployment().click().then(function (enabled) {
            callback();
        });
    });

    this.Then(/^a text box is displayed to enter the caf deployment name$/, function (callback) {
        cafDeploymentPage.deploymentName().isDisplayed().then(function (visible) {
            expect(visible).to.equal(true);
            callback();
        });
    });

    this.Then(/^a text box is displayed to enter the caf analytic name$/, function (callback) {
        cafDeploymentPage.analyticName().isDisplayed().then(function (visible) {
            expect(visible).to.equal(true);
            callback();
        });
    });

    this.Then(/^a deployment name should be displayed$/, function (callback) {
        cafDeploymentPage.deploymentName.isDisplayed().then(function (visible) {
            expect(visible).to.equal(true);
        });
    });

    this.Then(/^the deployment details page should be displayed$/, function (callback) {
        cafDeploymentPage.deploymentDetailsPage().isDisplayed().then(function (flag) {
            assert.equal(flag, true, 'deployment details page is not displayed');
            callback();
        })
    });

    this.When(/^cafUser enters the deployment name$/, function (callback) {
        deploymentName = 'deploy' + TestHelperPO.getRandomString();
        console.log("random deployment Name is " + deploymentName);
        cafDeploymentPage.deploymentName().sendKeys(deploymentName).then(function () {
            browser.sleep(2000);
            callback();
        });
    });

    this.When(/^cafUser enters the deployment name "([^"]*)"$/, function (arg1, callback) {
        deploymentName = arg1 + TestHelperPO.getRandomString();
        console.log("random deployment Name is " + deploymentName);
        cafDeploymentPage.deploymentName().sendKeys(deploymentName).then(function () {
            browser.sleep(2000);
            callback();
        });
    });

    this.When(/^cafUser enters the smart signal deployment name$/, function (callback) {
        deploymentName = 'smartSignalAutomation_' + TestHelperPO.getRandomString();
        console.log("random deployment Name is " + deploymentName);
        cafDeploymentPage.deploymentName().sendKeys(deploymentName).then(function () {
            browser.sleep(2000);
            callback();
        });
    });

    this.When(/^cafUser enters the analytic name$/, function (callback) {
        cafDeploymentPage.analyticName().sendKeys("analyticForUiAutomationTest").then(function () {
            callback();
        });
    });

    this.When(/^cafUser inputs the ASCIITESTAsset139_0702_ChartMarker Analytic in create deployment modal$/, function (callback) {
        cafDeploymentPage.analyticName().sendKeys("ASCIITESTAsset139_").then(function () {
            browser.sleep(1000);
            callback();
        });
    });

    this.When(/^cafUser clicks the first result$/, function (callback) {
        cafDeploymentPage.analyticFirstResult().click().then(function () {
            callback();
        });
    });

    this.When(/^cafUser clicks the submit button$/, function (callback) {
        cafDeploymentPage.newDeploymentSubmit().click().then(function () {
            callback();
        });
    });

    this.Then(/^caf Asset Selection screen should be displayed$/, function (callback) {
        cafDeploymentPage.visibilityOf(cafDeploymentPage.closeDeployment()).then(function () {
            cafDeploymentPage.closeDeployment().isDisplayed().then(function (visible) {
                expect(visible).to.equal(true);
                console.log("asset selection is displayed")
                callback();
            });
        });
    });

    this.When(/^cafUser clicks on the close button$/, function (callback) {
        cafDeploymentPage.elementToBeClickable(cafDeploymentPage.closeDeployment()).then(function () {
            browser.sleep(5000).then(function () {
                cafDeploymentPage.closeDeployment().click().then(function () {
                    cafDeploymentPage.visibilityOf(cafDeploymentPage.deploymentList());
                    callback();
                });
            });
        });
    });

    this.Then(/^the caf deployment record should be displayed$/, function (callback) {
        cafDeploymentPage.existingDeploymentName().isDisplayed().then(function (visible) {
            expect(visible).to.equal(true);
            callback();
        });
    });

    this.Then(/^the caf deployment status should be displayed$/, function (callback) {
        cafDeploymentPage.deploymentStatus().getText().then(function (value) {
            expect(value).to.equal('status');
            callback();
        });
    });

    this.Then(/^the caf delete icon should be displayed$/, function (callback) {
        cafDeploymentPage.cafDeleteDeployment().isDisplayed().then(function (visible) {
            expect(visible).to.equal(true);
            callback();
        });
    });

    this.Then(/^caf deployment is deleted$/, function (callback) {
        cafDeploymentPage.cafDeleteDeployment().isDisplayed().then (function(visible){
            expect(visible).to.equal(true);
            browser.sleep(5000).then(function() {
                cafDeploymentPage.cafDeleteDeployment().click().then (function () {
                    browser.sleep(5000).then(function() {
                        cafDeploymentPage.deploymentDeleteConfirm().click().then( function(){
                            callback();
                        });
                    });
                });
            });
        });
    });


    this.Then(/^analytics template header should not contain create_deployment icon$/, function (callback){
        cafDeploymentPage.iscreatedepbuttonNotDisplayed().then(function(boolean) {
            assert.equal(boolean, false, "Deployment template header create icon is displayed");
            callback();
        });
    });
    this.When(/^cafUser clicks on the Analytic deployment tab$/, function (callback) {
        // cafDeploymentPage.clickAnalyticDeployment().click().then(function () {
        //         //     callback();
        //         // });
        cafDeploymentPage.deploymentsHeader().click().then(function () {
            callback()
        });
    });

    this.When(/^the cafUser clicks on the Analytic Template tab$/, function (callback) {
        cafDeploymentPage.clickAnalyticCatalogTab().then(function () {
            browser.sleep(20000).then(function () {
                console.log("we should have gone to the templates page...");
                callback();
            });
        });

    });

    this.Given(/^The user should see the deployment header$/, function (callback) {
        cafDeploymentPage.deploymentsHeader().isDisplayed().then(function (visible) {
            expect(visible).to.equal(true);
            callback();
        });
    });

    this.Given(/^the user should see the add icon$/, function (callback) {
        cafDeploymentPage.addDeploymentIcon().isDisplayed().then(function (visible) {
            expect(visible).to.equal(true);
            callback();
        });
    });

    this.Then(/^the deployment name should be displayed in the deployment catalog list$/, function (callback) {
        cafDeploymentPage.deploymentNameInCatalogList().getText().then(function (text) {
            console.log("actual deployment name", text)
            console.log("expected deployment name", deploymentName)
            expect(text).to.equal(deploymentName);
            callback();
        });
    });

    this.Then(/^the deployed Date should be displayed in the deployment catalog list$/, function (callback) {
        cafDeploymentPage.deploymentDateInCatalogList().getText().then(function (text) {
            var newDate = new Date();
            var toDateString = newDate.toDateString();
            var subString = toDateString.substring(4)
            var splitArray = subString.split(" ");
            var expected = splitArray[0] + " " + splitArray[1] + ", " + splitArray[2]
            console.log("expected ", expected)
            expect(text).to.equal(expected);
            callback();
        });
    });

    this.Then(/^the analytic name should be displayed in the deployment catalog list$/, function (callback) {
        cafDeploymentPage.analyticNameInCatalogList().isDisplayed().then(function (visible) {
            expect(visible).to.equal(true);
            callback();
        });
    });

    this.Then(/^the caf deployment status should be displayed as Not Deployed in the deployment catalog list$/, function (callback) {
        cafDeploymentPage.deploymentStatusInCatalogList().getText().then(function (text) {
            expect(text).to.equal("Not Deployed");
            callback();
        });
    });

    this.Then(/^the deployment name should be displayed in deployment details page$/, function (callback) {
        cafDeploymentPage.deploymentNameInDeploymentDetailsPage().getText().then(function (text) {
            expect(text).to.equal(deploymentName);
            callback();
        });
    });

    this.Then(/^the analytic name should be displayed in deployment details page$/, function (callback) {
        cafDeploymentPage.analyticNameInDeploymentDetailsPage().isDisplayed().then(function (visible) {
            expect(visible).to.equal(true);
            callback();
        });
    });

    this.Then(/^the edit icon should be displayed in deployment details page$/, function (callback) {
        cafDeploymentPage.editIconInDeploymentDetailsPage().isDisplayed().then(function (visible) {
            expect(visible).to.equal(true);
            callback();
        });
    });

    this.Then(/^the delete icon should be displayed in deployment details page$/, function (callback) {
        cafDeploymentPage.deleteIconInDeploymentDetailsPage().isDisplayed().then(function (visible) {
            expect(visible).to.equal(true);
            callback();
        });
    });

    this.Then(/^the saved date should be displayed in deployment details page$/, function (callback) {
        /* cafDeploymentPage.savedDateInDeploymentDetailsPage().getText().then (function(text){
            var expected = text.substring(7);
            console.log("expected ", expected);

            expect((new Date(expected).toString())).to.not.equal('Invalid Date');

            var date = new Date();
            console.log("newdate ", date)
            console.log("newDate ", '${newDate.getMonth()+1}/${newDate.getDate()}/${newDate.getFullYear()} ${newDate.getHours()}:${newDate.getMinutes()}');
            callback();
        }); */


        var d = new Date();

        var localeString = d.toLocaleString();
        console.log("localeString ", localeString)


        console.log("newDate ", '${date.getMonth()+1}/${date.getDate()}/${date.getFullYear()} ${date.getHours()}:${date.getMinutes()}');
        callback();


    });

    this.Given(/^Schedule and Data Request header is displayed$/, function (callback) {
        cafDeploymentPage.scheduleAndDataRequestHeader().isDisplayed().then(function (visible) {
            expect(visible).to.equal(true);
            callback();
        });
    });

    this.Given(/^Schedule and Data Request data is displayed$/, function (callback) {
        cafDeploymentPage.scheduleAndDataRequestData().getText().then(function (text) {
            expect(text).to.equal("Not Yet Configured");
            callback();
        });
    });

    this.Given(/^Assets header is displayed$/, function (callback) {
        cafDeploymentPage.assetsHeader().isDisplayed().then(function (visible) {
            expect(visible).to.equal(true);
            callback();
        });
    });

    this.Given(/^Assets data is displayed$/, function (callback) {
        cafDeploymentPage.assetsData().getText().then(function (text) {
            expect(text).to.equal("Not Yet Configured");
            callback();
        });
    });

    this.Given(/^both radio buttons are displayed$/, function (callback) {
        cafDeploymentPage.mapByInput().isDisplayed().then(function (visible) {
            expect(visible).to.equal(true);
            cafDeploymentPage.mapByAsset().isDisplayed().then(function (visible) {
                expect(visible).to.equal(true);
                callback();
            });
        });
    });

    this.Given(/^Required Inputs Mapped percentage and count is displayed$/, function (callback) {
        cafDeploymentPage.requiredInputsMappedPercentage().getText().then(function (text) {
            expect(text).to.equal("0 %");
            cafDeploymentPage.requiredInputsMappedCount().getText().then(function (text) {
                expect(text).to.equal("(0/1)");
                callback();
            });
        });
    });

    this.Given(/^Inputs Mapped percentage and count is displayed$/, function (callback) {
        cafDeploymentPage.inputsMappedPercentage().getText().then(function (text) {
            expect(text).to.equal("0 %");
            cafDeploymentPage.inputsMappedCount().getText().then(function (text) {
                expect(text).to.equal("(0/1)");
                callback();
            });
        });
    });

    this.Given(/^a tool tip icon is displayed on mouse hover for the inputs mapped$/, function (callback) {
        browser.actions().mouseMove(cafDeploymentPage.exclamationIcon()).perform().then(function () {
            cafDeploymentPage.getHelpText().then(function (text) {
                expect(text).to.equal("Atleast one input needs to be mapped in order to proceed with the deployment");
                callback();
            });
        });
    });

    this.Given(/^the data flow row is displayed$/, function (callback) {
        cafDeploymentPage.dataFlowRow().isDisplayed().then(function (visible) {
            expect(visible).to.equal(true);
            callback();
        });
    });


    this.Given(/^the input definition row is displayed$/, function (callback) {
        cafDeploymentPage.inputDefinitionRow().isDisplayed().then(function (visible) {
            expect(visible).to.equal(true);
            callback();
        });
    });

    this.Given(/^the constants row is displayed$/, function (callback) {
        cafDeploymentPage.constantRow().isDisplayed().then(function (visible) {
            expect(visible).to.equal(true);
            callback();
        });
    });

    this.Given(/^the output definition row is displayed$/, function (callback) {
        cafDeploymentPage.outputDefinitionRow().isDisplayed().then(function (visible) {
            expect(visible).to.equal(true);
            callback();
        });
    });

    this.When(/^User searches for the caf deployment$/, function (callback) {
        cafCreateAnalyticPage.enterSearchText(deploymentName).then(function () {
            console.log("searching for the deployment");
            callback();
        });
    });

    this.When(/^User search and click the caf deployment$/, function (callback) {
        cafCreateAnalyticPage.enterSearchText(deploymentName).then(function () {
            cafDeploymentPage.firstDeploymentResult().then(function () {
                callback();
            });
        })
    });

    this.When(/^User deletes the deployment$/, function (callback) {
        cafDeploymentPage.deleteIconInDeploymentDetailsPage().click().then(function () {
            cafCreateAnalyticPage.clickYesForDeleteDeployment().then(function () {
                browser.sleep(2000).then(function () {
                    callback();
                });
            })
        });
    });

    this.When(/^User clicks the first deployment in the catalog$/, function (callback) {
        cafDeploymentPage.deploymentNameInCatalogList().click().then(function () {
            callback();
        });
    });

    this.Then(/^caf user enters a new deployment name in the deployment popup "([^"]*)"$/, function (arg1, callback) {
        deploymentName = arg1 + TestHelperPO.getRandomString().substring(3);
        cafAssetSelectionPage.deploymentPopupInput().sendKeys(deploymentName).then(function () {
            callback();
        });
    });

    this.Given(/^the run once file gets downloaded$/, function (callback) {
        console.log(deploymentName);
        restUtil.makeRequest("caf" + appHubPath + "/api/caf-mgmt-svc/v1/deployments", 'GET', null, 'application/json').then(function (resp) {
            JSON.parse(resp.body).forEach(function (deployment) {
                console.log(deployment);
                if (deployment.name === deploymentName) {
                    console.log("Deployment " + deploymentName + " found");
                    restUtil.makeRequest("caf" + appHubPath + "/api/caf-mgmt-svc/v1/" + deployment.uri + deployment.deployTypeToDeployParams.DeployOnDemand.deployResult.deployArtifactUri, 'GET', null, 'application/json').then(function (resp) {
                        console.log(resp);
                        console.log(JSON.parse(resp.body));
                    });
                }
            });
        });
    });

    this.Then(/^caf user clicks on the file icon$/, function (callback) {
        cafAnalyticsJourneyPage.runOnceFileIcon().click().then(function () {
            browser.sleep(4000).then(function () {
                callback();
            });
        });
    });

    this.Then(/^the file gets downloaded$/, function (callback) {
        let filename = deploymentName + '-DeployOnDemand.zip';
        console.log(filename);
        let fileTolook = '../TestData/' + filename;
        let filepath = path.resolve(__dirname, fileTolook);
        console.log('looking for: ' + filepath);

        if (fs.existsSync(filepath)) {
            console.log('File saved!');

            //deleting the file once the file gets downloaded
            fs.unlinkSync(filepath);
            callback();
        }
        else {
            console.log('File not found!');
        }
    });

    this.Then(/^Wait for analytic to be deployed$/, {timeout: 60 * 4000}, function (callback) {
        //cafCreateAnalyticPage.enterSearchText(deploymentName).then(function () {
        cafCreateAnalyticPage.enterSearchText(deploymentName).then(function () {
            cafDeploymentPage.deploymentStatus().getText().then(function (value) {
                if (value != 'Deployed') {
                    browser.sleep(160000).then(function () {
                        cafCreateAnalyticPage.clickAnalyticTemplatesTab().then(function () {
                            browser.sleep(10000).then(function (){
                                console.log("after sleep");
                                cafCreateAnalyticPage.clickDeploymentsTab().then(function () {
                                    cafCreateAnalyticPage.clickSearchBox().then(function () {
                                        cafCreateAnalyticPage.enterSearchText(deploymentName).then(function () {
                                            cafDeploymentPage.deploymentStatus().getText().then(function (status) {
                                                expect('Deployed').to.equals(status);
                                                callback();
                                            });
                                        });
                                    });
                                });
                            });
                        });
                    });
                } else {
                    callback();
                }
            });
        })
    });

    this.Then(/^the edge deployment should be successful$/, function (callback) {
        cafDeploymentPage.deploymentStatusDetailsPage().getText().then(function (value) {
            expect(value).to.not.equal('Failed');
            callback();
        });
    });

};

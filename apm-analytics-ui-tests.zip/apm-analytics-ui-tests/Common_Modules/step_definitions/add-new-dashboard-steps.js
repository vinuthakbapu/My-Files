/**
 * Created by 212340705 on 12/7/2015.
 */
var randomVuName = "TestVu_" + TestHelper.getRandomString();
var duplicateVu = "DupVu_" + TestHelper.getRandomString();
var currentpage = 'DashboardAppPages';
var dashboardCount = 0;


var rStream = fs.createReadStream(path.resolve(__dirname, '../TestData/postDataToEventhubStream.json'));
var data = '';
rStream.setEncoding('utf8');
rStream.on('data', function (chunk) {
    data += chunk;
});
rStream.on('end', function () {
    Logger.info('Read user data');
    Logger.info(data);
});

module.exports = function() {
    // this.setDefaultTimeout(60000);


    this.Given(/^I launch application url under test$/, function (callback) {
        browser.ignoreSynchronization = true;
        loginPage.getUrl(browser.params.login.baseUrl).then(function () {
            console.log('currently tests are running in following URL: ' + browser.params.login.baseUrl);
            callback();
        });
    });
    this.Given(/^I got to widget repo admin secret url$/, function (callback) {
        browser.ignoreSynchronization = true;
        loginPage.getUrl(browser.params.login.widgetRepoAdminUrl).then(function(){
            console.log('currently tests are running in following URL: ' + browser.params.login.widgetRepoAdminUrl );
            callback();
        });
    });
    this.When(/^I login to widget repo admin UI as "([^"]*)" and "([^"]*)"$/, function (username, password, callback) {
        console.log('userName: ' + username);
        console.log('password: ' + password);

        loginPage.setName(username).then(function(){
            loginPage.setPassword(password).then(function(){
                loginPage.clickLogin().then(function(){
                    console.log('successfully logged in as ',username);
                    callback();
                })
            })
        });
    });
    this.Given(/^I relaunch the widget repo admin ui url$/, function (callback) {
        console.log('about to relaunch the url: -- ' + browser.params.login.widgetRepoAdminUrl);
        loginPage.getUrl(browser.params.login.widgetRepoAdminUrl).then(function(){
            browser.sleep(10000).then(function() {
                console.log("Relaunched url");
                callback();
            });
        });
    });

    this.When(/^I login using valid username and password$/, function (callback) {
        console.log('userName: ' + browser.params.login.username);
        console.log('password: ' + browser.params.login.password);

        loginPage.setName(browser.params.login.username).then(function () {
            loginPage.setPassword(browser.params.login.password).then(function () {
                loginPage.clickLogin().then(function () {
                    callback();
                })
            })
        });
    });

    this.When(/^I login as "([^"]*)" and "([^"]*)" with dashview permission$/, function (username, password, callback) {
        console.log('userName: ' + username);
        console.log('password: ' + password);

        loginPage.setName(username).then(function () {
            loginPage.setPassword(password).then(function () {
                loginPage.clickLogin().then(function () {
                    createviewpage.getDashboardTab().then(function () {
                        console.log("Dashboard tab is displayed: ");
                        console.log('Logged in as ' + username + ' password ' + password);
                        callback();
                    });

                })
            })
        });
    });
    this.When(/^I login as "([^"]*)" and "([^"]*)"$/, function (username, password, callback) {
        console.log('userName: ' + username);
        console.log('password: ' + password);

        loginPage.setName(username).then(function () {
            loginPage.setPassword(password).then(function () {
                loginPage.clickLogin().then(function () {
                    createviewpage.getDashboardTab().then(function (yes) {
                        expect(yes).to.equal(true);
                        console.log('successfully logged in as ', username);
                        callback();
                    });
                })
            })
        });
    });


    this.When(/^I log out3$/, function (callback) {
        browser.sleep(3000).then(function () {
            TestHelper.elementToBeClickable(currentpage, 'LoginAvtar').then(function () {
                browser.sleep(1000).then(function () {
                    TestHelper.elementToBeClickable(currentpage, 'LogOutLink').then(function () {
                        browser.sleep(1000).then(function () {
                            callback();
                        });
                    });
                });
            });
        });
    });

    this.When(/^I log out$/, function (callback) {
        var step = function(start){
            if(start==false)
            {
                loginPage.doLogout().then(function (logout) {
                step(logout)
                });
            }
            else {
                callback();
            }

        };
        step(false)
    });
    this.When(/^I log out2$/, function (callback) {
        var step = function(start){
            if(start==false)
            {
                loginPage.doLogout().then(function (logout) {
                    step(logout)
                });
            }
            else {
                callback();
            }

        };
        step(false)
    });

    this.Then(/^The landing page should contain "([^"]*)" tab in navigation item list$/, function (arg1, callback) {
        console.log('Verify the dashboard tab listed in navigation item list');
        browser.sleep(3000).then(function() {
            loginPage.checkHomePage().then(function (completed) {
                assert.isTrue(completed, 'Not logged in');
                callback();
            });
        });
    });

    this.Given(/^I relaunch the application url under test$/, function (callback) {
        console.log('about to relaunch the url: -- ' + browser.params.login.baseUrl);
        loginPage.getUrl(browser.params.login.baseUrl).then(function(){
            browser.sleep(10000).then(function() {
            //     browser.waitForAngular().then(function () {
                    console.log("Relaunched url");
                    // TestHelper.isElementPresent("landingPage", "dashboardTab").then(function (yes) {
                    //     console.log("made it");
                    //     // expect(yes).to.equal(true);
                        callback();
                    // })
                // });
            });
        });
    });
    this.Given(/^I relaunch the application url under test after logout$/, function (callback) {
        console.log('about to relaunch the url: -- ' + browser.params.login.baseUrl);
        loginPage.getUrl(browser.params.login.baseUrl).then(function(){
            browser.waitForAngular();
            console.log("Relaunched url");
            TestHelper.isElementPresent("loginPage","username").then(function(yes){
                // expect(yes).to.equal(true);
                callback();
            })
        });
    });

    this.Then(/^click on dashboard tab in micro app$/, function (callback) {
        console.log('about to click on dashboard tab in left nav');
        createviewpage.clickDashboardTab().then(function() {
            browser.sleep(5000).then(function() {
                createviewpage.getContextColumnBrowser().then(function(){
                    callback();
                }); });
        });
    });

    this.Given(/^I relaunch the application url to go to context "([^"]*)" open "([^"]*)"$/, function (context, num, callback) {
        console.log('about to relaunch the url: -- ' + browser.params.Environment.URL);

        loginPage.getUrl(browser.params.Environment.URL)
            .then(function () {
                browser.driver.isElementPresent(by.name('username')).then(function (isPresent) {
                    isPresent = (isPresent) ? true : browser.wait(function () {
                        console.log('relaunched the application url');
                        //return browser.driver.isElementPresent(by.css('span.user-name'));
                        return browser.driver.isElementPresent(by.css('body > aside.pxh-drawer div.pxh-login > a div.pxh-login__name'));
                    }, 25000);
                }).then(function () {
                    //element(by.cssContainingText('li.px-app-nav', 'Dashboards')).click()
                    console.log('about to click on dashboard tab in left nav');
                    analysisPage.getDashboardTab().click()
                        .then(function () {
                            element(by.cssContainingText('span.px-context-browser', context)).click()
                                .then(function () {
                                    var open_button = element.all(by.css('li.selected button.opener')).get(num - 1);
                                    open_button.click()
                                        .then(function () {
                                            callback();
                                        });
                                });
                        });
                });
            });
    });
    this.Given(/^I relaunch the url "([^"]*)" go to context "([^"]*)" open "([^"]*)"$/, function (url, context, num, callback) {
        console.log('about to relaunch the url: -- ' + url);

        loginPage.getUrl(url)
            .then(function () {
                browser.driver.isElementPresent(by.name('username')).then(function (isPresent) {
                    isPresent = (isPresent) ? true : browser.wait(function () {
                        console.log('relaunched the url');
                        return browser.driver.isElementPresent(by.css('span.user-name'));
                    }, 25000);
                }).then(function () {
                    //element(by.cssContainingText('li.px-app-nav', 'Dashboards')).click()
                    analysisPage.getDashboardTab().click()
                        .then(function () {
                            element(by.cssContainingText('span.px-context-browser', context)).click()
                                .then(function () {
                                    var open_button = element.all(by.css('li.selected button.opener')).get(num - 1);
                                    open_button.click()
                                        .then(function () {
                                            callback();
                                        });
                                });
                        });
                })
            })
    });


    this.When(/^I click on the context name drop down$/, function (callback) {
        browser.ignoresynchronization = false;
        element(by.cssContainingText('span.px-context-browser', 'Context Name')).click()
            .then(function () {
                callback();
            })
    });


    this.When(/^I click on view selector drop down$/, function (callback) {
        console.log('about to click on deck selector drop down');

        createviewpage.clickViewSelectorDropdown().then(function () {
            console.log('clicked on deck selector drop down');
            callback();
        });
    });

    this.When(/^I check empty dashboard view is displayed$/, function (callback) {
        console.log("about to check empty dashboard container is display");
        browser.sleep(8000);
        createviewpage.getEmptyDashboardContainer().then(function (present) {
            console.log('Empty dashboard container is displayed:' + present);
            expect(present).to.equal(true);
            callback();
        });
    });

    this.When(/^I check empty dashboard view is not displayed$/, function (callback) {
        console.log("about to check empty dashboard container is display");
        browser.sleep(8000);
        createviewpage.getEmptyDashboardContainer().then(function (present) {
            console.log('Empty dashboard container is displayed:' + present);
            expect(present).to.equal(false);
            callback();
        });
    });

    this.When(/^I check Add dashboard button is displayed in empty dashboard container$/, function (callback) {

        createviewpage.getEmptyDashboardButton().then(function (present) {
            console.log('Add dashboard button is displayed in empty dashboard container:' + present);
            expect(present).to.equal(true);
            callback();
        });
    });
    this.When(/^I check Add dashboard button is NOT displayed in empty dashboard container$/, function (callback) {

        createviewpage.getEmptyDashboardButton().then(function (present) {
            console.log('Add dashboard button is displayed in empty dashboard container: ' + present);
            expect(present).to.equal(false);
            callback();
        });
    });

    this.Then(/^I should see "([^"]*)" link$/, function (arg1, callback) {
        createviewpage.chkViewSelectorDropdown().then(function(present) {
            if(present){
                createviewpage.clickViewSelectorDropdown().then(function(){
                    //TestHelper.scrollIntoView(currentpage,'AddDashboardLink').then(function(){
                        createviewpage.getAddDashboardLink().then(function(present){
                            expect(present).to.equal(true);
                            console.log('Add dashboard link is present in deck selector dropdown');
                            createviewpage.clickViewSelectorDropdown().then(function () {
                                callback();
                            })
                        });
                    //});
                });
            } else {
                createviewpage.getEmptyDashboardButton().then(function (present) {
                    console.log('Empty dashboard container displayed:', present);

                    expect(present).to.equal(true);
                    callback();
                });
            }
        })
    });

    this.Then(/^I should see "([^"]*)" link in chromeless browser$/, function (arg1, callback) {
        createviewpage.chkViewSelectorDropdown_chromeless().then(function(present) {
            if(present){
                createviewpage.clickViewSelectorDropdown_chromeless().then(function(){
                    //TestHelper.scrollIntoView(currentpage,'AddDashboardLink').then(function(){
                    createviewpage.getAddDashboardLink_chromeless().then(function(present){
                        expect(present).to.equal(true);
                        console.log('Add dashboard link is present in deck selector dropdown');
                        createviewpage.clickViewSelectorDropdown_chromeless().then(function() {
                                callback();
                        });
                    });
                });
            }else{
                createviewpage.getEmptyDashboardButton().then(function(present){
                    console.log('Empty dashboard container displayed:',present);
                    expect(present).to.equal(true);
                    callback();
                });
            }
        })
    });

    this.When(/^I click on "([^"]*)" button$/, function (arg1, callback) {

        createviewpage.chkViewSelectorDropdown().then(function(present) {
            if(present){
                createviewpage.clickViewSelectorDropdown().then(function(){
                    //TestHelper.scrollIntoView(currentpage,'AddDashboardLink').then(function(){
                        createviewpage.getAddDashboardLink().then(function(present){
                            console.log("Add Dashbaord link in deck selector present: ", present);
                            if (present) {
                                createviewpage.clickAddDashboardLink().then(function () {
                                    console.log('clicked on add new dashboard link');
                                    callback();
                                });
                            } else {
                                console.log("Add Dashbaord link in deck selector present: ", present);
                                callback();
                            }
                        });
                    //});
                });
            } else {
                createviewpage.clickEmptyDashboardButton().then(function () {
                    console.log('clicked on add new dashboard button');
                    callback();
                });
            }
        })
    });

    this.Given(/^I click on Add dashboard button in chromeless browser$/, function (callback) {
        browser.sleep(2000).then(function() {
            createviewpage.clickViewSelectorDropdown_chromeless().then(function() {
                createviewpage.clickAddDashboardLink_chromeless().then(function () {
                    callback();
                });
            });
        });
    });

    this.Then(/^I should see view name input field$/, function (callback) {
        createviewpage.chkViewnameInputfield().then(function () {
            console.log('View name input field is present');
            callback();
        });
    });

    this.Then(/^I should see save button for dashboard page$/, function (callback) {
        createviewpage.chkSaveViewButton().then(function () {
            console.log('Save button is present');
            callback();
        });
    });


    this.Then(/^I should see Cancel button$/, function (callback) {
        createviewpage.chkCancelViewButton().then(function (present) {
            console.log('Cancel button is present');
            callback();
        });
    });

    this.When(/^I enter view name$/, function (callback) {
        createviewpage.getViewnameInputfield().sendKeys(randomVuName)
            .then(function () {
                callback();
            });
    });

    this.When(/^I enter the dashboard name "([^"]*)"$/, function (name, callback) {
        createviewpage.getViewnameInputfield().sendKeys(name).then(function () {
            callback();
        });
    });

    this.When(/^I click on Save button$/, function (callback) {
        console.log('about to click save button***');
        createviewpage.clickSaveViewButton().then(function () {
            console.log('clicked the save button');
            callback();
        });
    });

    this.When(/^I click on Done button on add view$/, function (callback) {
        console.log('about to click done button***');
        createviewpage.clickDoneButton().then(function () {
            console.log('clicked the done button');
            callback();
        });
    });

    this.Then(/^I should see the newly created view opened$/, function (callback) {
        console.log('verify the newly created view name***');

        createviewpage.getSelectedDashboardName().then(function (name) {
            console.log('newly created view: ' + name);
            expect(name).to.equal(randomVuName);
            callback();
        });
    });
    this.Then(/^I should see the newly created view "([^"]*)" opened$/, function (vName, callback) {
        console.log('To verify the newly created view name: ', vName);
        browser.sleep(4000).then(function() {
            createviewpage.getSelectedDashboardName().then(function(name) {
                console.log('newly created view from UI is: ' + name);
                expect(vName).to.equal(name);
                callback();
            });
        });
    });

    this.When(/^I click on "([^"]*)" from the context browser$/, function (asset, callback) {

        createviewpage.clickAssetInContextBrowser(asset)
            .then(function () {
                console.log('clicked on context browser: ' + asset);
                callback();
            })
    });
    this.When(/^I open asset context browser$/, function (callback) {
        createviewpage.clickAssetBrowser().then(function () {
            console.log('clicked on asset browser dropdown');
            callback();
        })

    });
    this.When(/^I click on the open button at level "([^"]*)" on the context browser$/, function (arg1, callback) {
        browser.ignoresynchronization = false;
        createviewpage.clickOpenButton(arg1-1).then(function(){
            console.log('clicked on open button number: '+ arg1);
            callback();
        });
    });

    this.Given(/^I navigate to add new dashboard page$/, function(callback){
        browser.ignoresynchronization = false;
        console.log('about to click view selector drop down');
        createviewpage.clickViewSelectorDropdown().then(function () {
            console.log('clicked on view selector dropdown');
            createviewpage.clickAddDashboardLink().then(function () {
                callback();
            });
        });
    });

    this.When(/^I click on cancel button on dashboard page$/, function (callback) {
        browser.ignoresynchronization = false;
        console.log('about to click on cancel button');
        createviewpage.clickCancelViewButton().then(function () {
            console.log('clicked on cancel button');
            callback();
        });
    });
    this.Then(/^I should go back to previous dashboard$/, function (callback) {
        console.log('verify the user is taken back to previous dashboard ');

        createviewpage.getSelectedDashboardName().then(function (txt) {
            console.log(' Selected Dashboard name: ' + txt);
            expect(txt).to.equal(randomVuName);
            callback();
        });
    });

    this.Then(/^I should go back to default dashboard$/, function (callback) {
        console.log('verify the user is taken back to default dashboard ');
        createviewpage.getViewSelectorDropdown().getText()
            .then(function (txt) {
                console.log('previous view: ' + txt);
                //expect(txt).to.equal('Default dashboard');
                var dashname = 'New Dashboard';
                expect(txt.toLowerCase()).to.equal(dashname.toLowerCase());
                callback();
            });
    });
    this.When(/^I click on save button without entering the view name$/, function (callback) {
        console.log('About to hit save button without entering any string in dashaboard name input field');
        createviewpage.clickSaveViewButton().then(function () {
            console.log('clicked on save dashboard button');
            callback();
        })
    });

    this.Then(/^I should see a dashboard created with default name$/, function (callback) {
        console.log('verify the view name is: new dashboard');

        createviewpage.getSelectedDashboardName().then(function (name) {
            console.log('newly created view: ' + name);
            var dashname = 'New Dashboard';
            expect(name.toLowerCase()).to.equal(dashname.toLowerCase());
            callback();
        });

    });

    this.When(/^I create a view with random name$/, function (callback) {
        console.log('about to create a new view: ' + duplicateVu);
        createviewpage.createView_V2(duplicateVu).then(function () {
            console.log('successfully created one view and about to create another with same name: ' + duplicateVu);
            callback();
        });
    });
    this.When(/^I create a view again with same name$/, function (callback) {
        console.log('about to create a new view: ' + duplicateVu);
        createviewpage.createView_V2(duplicateVu).then(function () {
            console.log('successfully created second view with same name: ' + duplicateVu);
            callback();
        });

    });

    this.Then(/^Two views with same name should be listed in the drop down menu$/, function (callback) {
        console.log('verify two views with same name are listed in the drop down ');

        var sameNameVus = element.all(by.cssContainingText('#dashboardHeaderBar ul#dropdown li div', duplicateVu));
        sameNameVus.count().then(function (count) {
            console.log('Number of views with same name-- ' + duplicateVu + '--are-- ' + count);
            expect(count).to.equal(2);
            callback();
        });

    });

    this.Then(/^I should see a delete view link in card action menu$/, function (callback) {
        console.log('verify delete view list is peresent in card action menu drop down');
        createviewpage.clickCardActionMenuBtn().then(function () {
            console.log('Card Action menu is clicked');
            console.log('verify delete view link is visible in the menu drop down');
            createviewpage.getDeleteViewLink().isPresent()
                .then(function (present) {
                    expect(present).to.equal(true);
                    console.log('Delete view link is present');
                    callback();
                });
        });
    });

    this.When(/^I click on delete view link in card action menu$/, function (callback) {
        console.log('about to click on delete view');
        createviewpage.clickDeleteViewLink().then(function () {
            console.log('delete view link has been clicked');
            callback();
        });
    });

    this.When(/^I click on delete view link in card action menu with view access$/, function (callback) {
        console.log('about to click on delete view');
        createviewpage.getDeleteViewLink().click()
            .then(function () {
                console.log('delete view link has been clicked');
                callback();
            });
    });


    this.Then(/^I should see confirmation popup window$/, function (callback) {
        console.log('verify delete view confirmation popup window is visible');
        createviewpage.getDeleteViewConfirmPopup().isPresent()
            .then(function (present) {
                expect(present).to.equal(true);
                console.log("delete view confirmation popup is present");
                callback();
            });
    });

    this.Then(/^I should see OK button on confirmation popup$/, function (callback) {
        console.log('verify delete view confirmation popup window displays OK button');

        createviewpage.getDeleteViewConfirmOKBtn().isPresent()
            .then(function (present) {
                expect(present).to.equal(true);
                console.log("OK button is present on delete view confirmation popup");
                callback();
            });
    });
    this.Then(/^I should see Cancel button on confirmation popup$/, function (callback) {
        console.log('verify delete view confirmation popup window displays Cancel button');
        createviewpage.getDeleteViewConfirmCancelBtn().then(function (present) {
            expect(present).to.equal(true);
            console.log("Cancel button is present on delete view confirmation popup");
            callback();
        });
    });

    this.Then(/^I click on Cancel button on delete dashboard confirmation popup$/, function (callback) {
        console.log('about to click on cancel button in delete confirmation popup');
        createviewpage.clickDeleteViewConfirmCancelBtn().then(function () {
            console.log("Cancel button on delete view confirmation popup is clicked");
            callback();
        });
    });

    this.Then(/^I should see "([^"]*)" name in view confirmation popup text$/, function (arg1, callback) {
        console.log('verify delete view confirmation message contains view name');
        createviewpage.getDeleteViewConfirmMessage()
            .then(function (message) {
                expect(message).to.contain(arg1);
                console.log("context name: " + arg1 + " displayed in delete confirmation message: " + message);
                callback();
            });
    });

    this.Then(/^confirmation popup should be closed$/, function (callback) {
        console.log('verify delete view confirmation popup is closed');
        createviewpage.getDeleteViewConfirmPopup().isPresent()
            .then(function (present) {
                expect(present).to.equal(false);
                console.log("delete view confirmation popup is closed");
                callback();
            });
    });

    this.Then(/^I should go back to previous "([^"]*)"$/, function (arg1, callback) {
        console.log('verify the user is taken back to previous view ');
        createviewpage.getViewSelectorDropdown().getText()
            .then(function (txt) {
                expect(txt).to.equal(arg1);
                console.log('user is taken back to dashboard: ' + txt);
                callback();
            });
    });

    this.Then(/^I should still see the "([^"]*)" name in drop down list$/, function (arg1, callback) {
        console.log('verify the view still exists in the dropdown when user clicks on cancel button on delete view confirmation ');
        createviewpage.getView(arg1).isPresent().then(function (present) {
            expect(present).to.equal(true);
            console.log('dashboard: ' + arg1 + ' exists in the view selector dropdown');
            callback();
        });
    });

    this.Then(/^I click on Ok button on delete view confirmation popup$/, function (callback) {
        console.log('about to click on OK button in delete confirmation popup');
        createviewpage.getDeleteViewConfirmOKBtn().click()
            .then(function () {
                console.log("OK button on delete view confirmation popup is clicked");
                callback();
            });
    });

    this.Then(/^I should not see the deleted "([^"]*)" name in drop down list$/, function (arg1, callback) {
        console.log('verify the view is gone from the dropdown when user clicks on OK button on delete view confirmation ');
        createviewpage.chkViewSelectorDropdown().then(function (yeah) {
            if (yeah) {
                createviewpage.getView(arg1).isPresent().then(function (present) {
                    expect(present).to.equal(false);
                    console.log('dashboard: ' + arg1 + ' does not exist in the view selector dropdown');
                    callback();
                });
            } else {
                createviewpage.getEmptyDashboardContainer().then(function (present) {
                    expect(present).to.equal(true);
                    console.log('Empty dashboard container is displayed.');
                    callback();
                });
            }
        })

    });
    this.Then(/^I should see the dashboard "([^"]*)" name in deckselector drop down list$/, function (arg1, callback) {
        console.log('verify the dashboard ' + arg1 + ' is listed in dropdown');
        createviewpage.getView(arg1).isPresent().then(function (present) {
            expect(present).to.equal(true);
            console.log('dashboard: ' + arg1 + ' listed in the view selector dropdown');
            callback();
        });
    });

    this.Then(/^I should see the dashboard "([^"]*)" in view selector dropdown$/, function (name, callback) {
        console.log('about to verify the dashboard name is exist in view selector dropdown ');
        createviewpage.chkViewSelectorDropdown().then(function (yeah) {
            console.log('view selector present: ' + yeah);
            browser.sleep(2000);
            if (yeah) {
                createviewpage.clickViewSelectorDropdown().then(function () {
                    createviewpage.checkView(name).then(function (present) {
                        console.log('Dashboard : ' + name + ' is listed in the dropdown :' + present);
                        expect(present).to.equal(true);
                        callback();
                    });
                });
            } else {
                createviewpage.getEmptyDashboardContainer().then(function (present) {
                    console.log('Empty dashboard container is displayed: ' + present);
                    expect(present).to.equal(false); // test case fails if dashboard is not listed in deck selector or deck selector is not present
                    callback();
                });
            }
        });
    });

    this.Then(/^I should not see the dashboard "([^"]*)" in view selector dropdown$/, function (name, callback) {
        console.log('verify the dashboard name does not exist in view selector dropdown ');
        createviewpage.chkViewSelectorDropdown().then(function (yeah) {
            console.log('view selector present: ' + yeah);
            browser.sleep(2000);
            if (yeah) {
                console.log('view selector is present. ');
                createviewpage.clickViewSelectorDropdown().then(function () {
                    createviewpage.chkView(name).then(function (present) {
                        console.log(name + ' is present in the dropdown' + present);
                        expect(present).to.equal(false);
                        console.log('dashboard: ' + name + ' does not exist in the view selector dropdown')
                        callback();
                    });
                });
            } else {
                createviewpage.getEmptyDashboardContainer().then(function (present) {
                    expect(present).to.equal(true);
                    console.log('Empty dashboard container is displayed.');
                    callback();
                });
            }
        });
    });

    this.When(/^Delete a "([^"]*)" if it already exists$/, function (view, callback) {
        console.log('verify if view exists already. delete if it is present');
        createviewpage.chkViewSelectorDropdown().then(function (yeah) {
            console.log('deck selecor drop down is visible: ', yeah);
            if (yeah) {
                console.log('Deck selector is present, going to look for the view to delete');
                createviewpage.clickViewSelectorDropdown().then(function () {
                    console.log('clicked on deck selector');
                    createviewpage.chkView(view).then(function (present) {
                        console.log('chkView: ' + present);
                        if (present) {
                            console.log('found the view: ' + view);
                            createviewpage.clickView(view).then(function () {
                                console.log('going to delete the view');
                                createviewpage.clickCardActionMenuBtn().then(function () {
                                    console.log('clickCardActionMenuBtn');
                                    createviewpage.clickDeleteViewLink().then(function () {
                                        console.log('clickDeleteViewLink');
                                        createviewpage.clickDeleteViewConfirmOKBtn().then(function () {
                                            console.log('clickDeleteViewConfirmOKBtn');
                                            createviewpage.chkDeleteSpinnerHidden().then(function () {
                                                console.log('Delete spinner is hidden');
                                                console.log('deleted view: ' + view);
                                                callback();
                                            })
                                        })
                                    })
                                })
                            })
                        } else {
                            console.log('view not found');
                            callback();
                        }
                    })
                })
            } else {
                console.log('no existing dashboards to delete');
                callback();
            }

        });
    });


    // this.When(/^Delete all views$/, function (callback) {
    //     browser.sleep(20000).then(function(){
    //         console.log('about to delete all the views');
    //         createviewpage.getViewSelectorDropdown().then(function (present) {
    //             console.log('Deck selector drop-down is present:' + present);
    //             if(present){
    //                 createviewpage.getAllDashboardInDeck().then(function(decks){
    //                     var noOfDecks = decks.length - 1;
    //                     console.log('Decks count: ' + noOfDecks);
    //
    //                     for (var i=0; i < noOfDecks; i++){
    //                             createviewpage.deleteDeck(i);
    //                     }
    //                 }).then(function(){
    //                     console.log('deleted all decks/views.');
    //                     callback();
    //                 });
    //
    //             } else {
    //                 callback();
    //             }
    //         });
    //     });
    // });


    this.When(/^I create a new "([^"]*)"$/, function (arg1, callback) {
        console.log('about to create a new view: ', arg1);

        createviewpage.createView_V2(arg1).then(function () {
            console.log('successfully created the view: ' + arg1);
            callback();
        });
    });
    this.When(/^I create a new dashboard "([^"]*)" with summary card on top$/, function (arg1, callback) {
        console.log('about to create a new dashboard with summary card: ', arg1);

        createviewpage.createDashboardWithSummaryOn(arg1).then(function () {
            console.log('successfully created the dashboard: ' + arg1);
            callback();
        });
    });

    this.Then(/^I should see dashboard name input field$/, function (callback) {
        console.log('verify dashboard name input field is present on card library page');
        createviewpage.getViewnameInputfield().isPresent()
            .then(function (present) {
                expect(present).to.equal(true);
                console.log("dashboard name input field is present");
                callback();
            });
    });
    this.Then(/^I should see Save button on card library page$/, function (callback) {
        console.log('verify save button is present on card library page');
        createviewpage.getSaveViewButton().then(function (present) {
            expect(present).to.equal(true);
            console.log("save button is present");
            callback();
        });
    });
    this.Then(/^I should see Cancel button on card library page$/, function (callback) {
        console.log('verify cancel button is present on card library page');
        createviewpage.getCancelViewButton().isPresent()
            .then(function (present) {
                expect(present).to.equal(true);
                console.log("cancel button is present");
                callback();
            });
    });
    this.Then(/^delete dashboard spinner should be present$/, function (callback) {
        console.log('verify pxDashboardSpinner is gone after clicking on Delete dashboard confirmation');
        createviewpage.chkDeleteSpinner().then(function (present) {
            console.log('chkDeleteSpinnerHidden: ', present);
            expect(present).to.equal(true);
            console.log("Spinner is hidden");
            callback();
        });
    });

    this.When(/^create a new dashboard "([^"]*)" with 6up card$/, function (name, callback) {
        console.log('About to add a new dashboard with a 6 up card');
        createviewpage.createDashboardAnd6upCard(name)
            .then(function () {
                console.log('added a new dashboard : ' + name + ' --with one 6up card ');
                createviewpage.getViewSelectorDropdown().getText()
                    .then(function (txt) {
                        expect(txt).to.equal(name);
                        console.log('Added a new dashboard named: ' + txt + ' -- matching with expected: ' + name);
                        //addcardpage.getEditCardTitle(0).getAttribute('value')
                        addcardpage.getCardTitleHeader(0).getText()
                            .then(function (ttl) {
                                expect(ttl.trim()).to.equal('Overview');
                                console.log('successfully verified the card with title: ' + ttl + '  --exist');
                                callback();
                            });
                    });
            });
    });
    this.When(/^create a new dashboard "([^"]*)" with "([^"]*)" card$/, function (name, type, callback) {
        console.log('About to create a new dashboard named: ' + name + ' with a ' + type + ' card');
        createviewpage.createDashboardAndCard(name, type).then(function(){
            console.log('added a new dashboard : ' + name + ' with a ' + type + ' card');
            callback();
        });
    });

    this.Then(/^dashboard "([^"]*)" should be open$/, function (name, callback) {
        console.log('Verify open dashboard name is: ' + name);
        createviewpage.getSelectedDashboardName().then(function (txt) {
            expect(txt).to.equal(name);
            console.log('open dashboard name is: ' + txt);
            callback();
        })
    });
    this.Then(/^dashboard "([^"]*)" should exist in view selector dropdown$/, function (name, callback) {
        console.log('verify the dashboard name: ' + name + ' is present in the view selector dropdown');

        createviewpage.clickViewSelectorDropdown().then(function () {
            createviewpage.chkView(name).then(function (present) {
                expect(present).to.equal(true);
                console.log('the dashboard name: ' + name + ' is present in the view selector dropdown');
                createviewpage.clickViewSelectorDropdown().then(function () {
                    callback();
                });
            });
        });
    });

    this.Then(/^I should not see delete dashboard link in dashboard menu$/, function (callback) {
        console.log('Verify delete dashboard link is not present in dashboard menu');
        createviewpage.chkDeleteDashboardLink().then(function (present) {
            console.log('Delete dashboard link in dashboard menu present: ' + present);
            expect(present).to.equal(false);
            callback();
        });
    });

    this.Then(/^I should see delete dashboard link in dashboard menu$/, function (callback) {
        console.log('Verify delete dashboard link is not present in dashboard menu');
        createviewpage.chkDeleteDashboardLink().then(function (present) {
            console.log('Delete dashboard link in dashboard menu present: ' + present);
            expect(present).to.equal(true);
            callback();
        });
    });

    this.Then(/^I should see disabled delete dashboard link in dashboard menu$/, function (callback) {
        console.log('Verify delete dashboard link is not present in dashboard menu');
        createviewpage.chkDeleteDashboardLinkDisabled().then(function (present) {
            console.log('Delete dashboard link in dashboard menu present: ' + present);
            expect(present).to.equal(true);
            callback();
        });
    });
    this.Then(/^I should be able to see Available for field on add new dashboard page$/, function (callback) {
        console.log('Check if Available for field in add dashboard page is present');
        createviewpage.chkAvailableForLabel().then(function (present) {
            console.log('Check if Available for field in add dashboard page is present: ' + present);
            expect(present).to.equal(true);
            callback();
        });
    });
    this.Then(/^AvailableToField should be disabled in edit card page$/, function (callback) {
        createviewpage.chkDisabledAvailableToField().then(function (present) {
            console.log('DisabledAvailableToField is present: ' + present);
            expect(present).to.equal(true);
            callback();
        });
    });
    this.Then(/^I should be able to see "([^"]*)" as the selected option of Available for$/, function (name, callback) {
        createviewpage.getTextAvailableFor().then(function (txt) {
            expect(txt).to.equal(name);
            console.log('Selected value in available for field is: ' + txt);
            callback();
        })
    });
    this.Then(/^I should see edit user groups button under available for selection$/, function (callback) {
        createviewpage.chkUserGroupEditButton().then(function (present) {
            console.log('Add/Edit User Group button is: ' + present);
            expect(present).to.equal(true);
            callback();
        });
    });
    this.Then(/^I click on edit user groups button under available for selection$/, function (callback) {
        createviewpage.clickUserGroupEditButton().then(function () {
            console.log('Clicked on Add/Edit User Group button is: ');
            callback();
        });
    });

    this.Then(/^I should be able to see a chevron next to public on add new dashboard page$/, function (callback) {
        console.log('Check if Available for field in add dashboard page is present');
        createviewpage.chkAvailableForChevron().then(function (present) {
            console.log('Check if Available for field in add dashboard page is present: ' + present);
            expect(present).to.equal(true);
            callback();
        });
    });
    this.Then(/^I click on available for Chevron$/, function (callback) {
        console.log('about to click on chevron');
        createviewpage.clickAvailableForChevron()
            .then(function () {
                console.log('clicked chevron');
                callback();
            });
    });
    this.Then(/^I should be able to see the available for list when clicked on chevron$/, function (callback) {
        console.log('Check if Available for field in add dashboard page is present');
        createviewpage.chkAvailableForList().then(function (present) {
            console.log('Available for field in add dashboard page is present: ' + present);
            expect(present).to.equal(true);
            callback();
        });
    });
    this.Then(/^I should see the option Public in tag selection list$/, function (callback) {
        console.log('Check if Available for field has public option in the tag list');
        createviewpage.chkAvailableForPublic().then(function (present) {
            console.log('Available for field has public option in the tag list' + present);
            expect(present).to.equal(true);
            callback();
        });
    });
    this.Then(/^I should see the option Private in tag selection list$/, function (callback) {
        console.log('Check if Available for field has private option in the tag list');
        createviewpage.chkAvailableForPrivate().then(function (present) {
            console.log('Available for field has private option in the tag list: ' + present);
            expect(present).to.equal(true);
            callback();
        });
    });
    this.Then(/^I should see the option User Groups in tag selection list$/, function (callback) {
        console.log('Check if Available for field has user groups option in the tag list');
        createviewpage.chkAvailableForUserGroups().then(function (present) {
            console.log('Available for field has user groups option: ' + present);
            expect(present).to.equal(true);
            callback();
        });
    });
    this.Then(/^I select "([^"]*)" option from tag selection list$/, function (option, callback) {
        if (option === "public") {
            createviewpage.clickAvailableForPublic().then(function () {
                console.log('Public option selected');
                callback();
            })
        } else if (option === "private") {
            createviewpage.clickAvailableForPrivate().then(function () {
                console.log('Private option selected');
                callback();
            })
        } else if (option === "usergroups") {
            createviewpage.clickAvailableForUserGroups().then(function () {
                console.log('User groups option selected');
                callback();
            })
        } else {
            console.log('incorrect option passed. correction options are public private usergroups');
            callback();
        }
    });
    this.Then(/^I should see a popup open for user groups$/, function (callback) {
        createviewpage.chkUserGroupPopup().then(function (present) {
            console.log('User Groups Popup modal is present: ' + present);
            expect(present).to.equal(true);
            callback();
        });
    });
    this.Then(/^I should see a title "([^"]*)" in user groups popup$/, function (ttl, callback) {
        createviewpage.getUserGroupPopupTitleTxt().then(function (txt) {
            console.log('User Groups Popup title text: ' + txt);
            expect(txt).to.equal(ttl);
            callback();
        });
    });
    this.Then(/^I should see "([^"]*)" as the first checkbox option in user groups popup$/, function (ttl, callback) {
        createviewpage.getFirstUserGroupNameUGModal().then(function (txt) {
            console.log('the first checkbox option in user groups popup: ' + txt);
            expect(txt).to.equal(ttl);
            callback();
        });
    });
    this.Then(/^I should see at least one checkbox option in user groups popup$/, function (callback) {
        createviewpage.getUserGroupsCountFrmPopup().then(function (cnt) {
            console.log('User groups listed in popup: ' + cnt);
            expect(cnt).to.be.at.least(1);
            callback();
        });
    });
    this.Then(/^I should see "([^"]*)" button in user groups selection popup$/, function (button, callback) {
        if (button === "apply") {
            createviewpage.chkUserGroupApplyBtn().then(function (yes) {
                expect(yes).to.equal(true);
                callback();
            })
        } else if (button === "cancel") {
            createviewpage.chkUserGroupCancelBtn().then(function (yes) {
                expect(yes).to.equal(true);
                callback();
            })
        }
    });
    this.Then(/^I click on "([^"]*)" button in user groups selection popup$/, function (button, callback) {
        if (button === "apply") {
            createviewpage.clickUserGroupApplyBtn().then(function () {
                console.log('clicked on User groups apply button');
                callback();
            })
        } else if (button === "cancel") {
            createviewpage.clickUserGroupCancelBtn().then(function () {
                console.log('clicked on User groups cancel button');
                callback();
            })
        }
    });
    this.Then(/^I click on user group "([^"]*)" in user groups selection popup$/, function (name, callback) {
        createviewpage.clickUserGroupLabelInUGmodal(name).then(function () {
            console.log('clicked on User groups apply button');
            callback();
        });
    });
    this.Then(/^check user group is "([^"]*)" selected$/, function (name, callback) {
        createviewpage.checkUserGroupSelected(name).isPresent().then(function (attr) {
            console.log('user group: ' + name + ' is selected: ' + attr);
            expect(attr).to.equal(true);
            callback();
        });
    });

    this.Then(/^I should see "([^"]*)" user groups labels next to edit user groups button$/, function (num, callback) {
        createviewpage.getUserGroupLabelsCount().then(function (cnt) {
            console.log('Number of User Groups selected for the dashboard: ' + cnt);
            expect(Number(num)).to.equal(cnt);
            callback();
        });
    });
    this.Then(/^Check "([^"]*)" user groups selected in edit user group popup$/, function (num, callback) {
        createviewpage.getCheckedUserGroupsCountInPopup().then(function (cnt) {
            console.log('Number of user groups selected: ' + cnt);
            expect(cnt).to.equal(Number(num));
            callback();
        });
    });

    this.Then(/^Check the selected user group names match with "([^"]*)"$/, function (name, callback) {
        var userGroups = "";
        var checkedUserGroups = 0;
        createviewpage.getCheckedUserGroupsCountInPopup().then(function (cnt) {
            console.log('getCheckedUserGroupsCountInPopup: ' + cnt);
            var step = function (i, done) {
                if (i < done) {
                    createviewpage.getCheckedUserGroupChkBxLabel(i).then(function (txt) {
                        userGroups = userGroups + txt;
                        step(i + 1, done)
                    });
                }
                else {
                    expect(userGroups).to.equal(name);
                    callback();
                }
            };
            step(0, cnt);
        });
    });

    this.Then(/^I click on "([^"]*)" button in confirm user role change popup$/, function (button, callback) {
        if (button === "apply") {
            createviewpage.clickApplyBtnInCURC().then(function () {
                console.log('clicked on CURC apply button');
                callback();
            })
        } else if (button === "cancel") {
            createviewpage.clickCancelBtnInCURC().then(function () {
                console.log('clicked on CURC cancel button');
                callback();
            })
        }
    });
    this.Then(/^I should see confirm user role change popup open$/, function (callback) {
        createviewpage.chkCURCpopupModal().then(function (present) {
            console.log('confirm user role change popup is present: ' + present);
            expect(present).to.equal(true);
            callback();
        });
    });
    this.Then(/^I should see title "([^"]*)" in CURC popup$/, function (ttl, callback) {
        createviewpage.getCURCtitleText().then(function (txt) {
            console.log('confirm user role change popup title: ' + txt);
            expect(txt).to.equal(ttl);
            callback();
        });
    });
    this.Then(/^I should see message "([^"]*)" in CURC popup$/, function (msg, callback) {
        createviewpage.getCURCmessageText().then(function (txt) {
            console.log('confirm user role change popup message: ' + txt);
            expect(txt).to.equal(msg);
            callback();
        });
    });
    this.Then(/^I should see "([^"]*)" button in CURC popup$/, function (button, callback) {
        if (button === "apply") {
            createviewpage.chkApplyBtnInCURC().then(function (yes) {
                expect(yes).to.equal(true);
                callback();
            })
        } else if (button === "cancel") {
            createviewpage.chkCancelBtnInCURC().then(function (yes) {
                expect(yes).to.equal(true);
                callback();
            })
        }
    });

    this.Then(/^Post data to Kafka Stream$/, function (callback) {
        browser.sleep(15000).then(function () {

            console.log("The data: " + JSON.stringify(data))
            var opts = {
                url: 'https://oo-eventhub-rest-proxy-oodev-qa.run.asv-pr.ice.predix.io/api/event-hub/channel',
                headers: {
                    'Content-Type': 'application/json'
                },
                body: data
            };
            console.log("The url being used: " + opts.url)
            console.log("The body: " + opts.body)
            RestHelper.executePostRequest(opts.url, opts.headers, opts.body, function (err, res) {
                console.log("The error: " + JSON.stringify(err))
                Logger.info("Post data to Kafka Stream : " + JSON.stringify(res.body));
                console.log("Post data to Kafka Stream : " + JSON.stringify(res.body));
                callback();
            });
        });
    })


    this.When(/^Post data to Kafka Stream to "([^"]*)"$/, function (arg1, callback) {
        var opts = {
            url: arg1,
            headers: {
                'Content-Type': 'application/json'
            },
            body: data
        };
        RestHelper.executePostRequest(opts.url, opts.headers, opts.body, function (err, res) {
            Logger.info("Post data to Kafka Stream : " + JSON.stringify(res.body));
            console.log("Post data to Kafka Stream : " + JSON.stringify(res.body));
            callback();
        });
    });

    this.Then(/^Post data to Eventhub Stream$/, function (callback) {
        browser.sleep(15000).then(function () {

            console.log("The data: " + JSON.stringify(data))
            var opts = {
                url: 'https://opm-eventhub-proxy-qa.run.aws-usw02-pr.ice.predix.io/publish',
                headers: {
                    'Content-Type': 'application/json'
                },
                body: data
            };
            console.log("The url being used: " + opts.url)
            console.log("The body: " + opts.body)
            RestHelper.executePostRequest(opts.url, opts.headers, opts.body, function (err, res) {
                console.log("The error: " + JSON.stringify(err))
                Logger.info("Post data to Eventhub Stream : " + JSON.stringify(res.body));
                console.log("Post data to Eventhub Stream : " + JSON.stringify(res.body));
                callback();
            });
        });
    })


    this.When(/^Post data to Eventhub Stream to "([^"]*)"$/, function (arg1, callback) {
        var opts = {
            url: arg1,
            headers: {
                'Content-Type': 'application/json'
            },
            body: data
        };
        RestHelper.executePostRequest(opts.url, opts.headers, opts.body, function (err, res) {
            Logger.info("Post data to Kafka Stream : " + JSON.stringify(res.body));
            console.log("Post data to Kafka Stream : " + JSON.stringify(res.body));
            callback();
        });
    });


    this.Then(/^I should see widget graph data points$/, function (callback) {
        browser.sleep(2000).then(function () {
            console.log('Verify data points are present');
            createviewpage.getGraphElement().getAttribute('d').then(function (chartElement) {
                console.log("graph points:" + createviewpage.getGraphElement());
                var datapointsPresent = chartElement.split(',').length > 1;
                expect(datapointsPresent).to.equal(true);
                callback();
            });
        });
    });

    this.Then(/^I should see widget graph with no data points$/, function (callback) {
        console.log('Verify No data points are present');
        createviewpage.getGraphElement().getAttribute('d').then(function (chartElement) {
            var datapointsPresent = chartElement.split(',').length > 10;
            expect(datapointsPresent).to.equal(false);
            callback();
        });
    });

    this.When(/^I add value "([^"]*)" to the threshold field$/, function (thresholdValue, callback) {
        console.log('Adding threshold value');
        createviewpage.getThresholdValueElement().clear().sendKeys(thresholdValue).then(function () {
            browser.sleep(2000).then(function () {
                console.log("Threshold value is entered");
                callback();
            });
        });
    });

    this.Then(/^I should see a threshold value of "([^"]*)" entered$/, function (thresholdValue, callback) {
        console.log('Checking If Threshold value is set to : ' + thresholdValue);
        browser.sleep(5000).then(function () {
            createviewpage.getThresholdValueElement().getAttribute('value').then(function (inputtedThresholdValue) {
                console.log("Inputted threshold value (" + inputtedThresholdValue + ") equals expected threshold value (" + thresholdValue + ")");
                expect(inputtedThresholdValue).to.equal(thresholdValue);
                callback();
            });
        });
    });

    this.When(/^I change the title of the widget to be "([^"]*)"$/, function (widgetTitleName, callback) {
        console.log('Adding threshold value');
        createviewpage.getStreamingWidgetTitleElementFromConfigMenu().clear().sendKeys(widgetTitleName).then(function () {
            browser.sleep(2000).then(function () {
                console.log("New title is entered is entered");
                callback();
            });
        });
    });

    this.Then(/^I should see the title "([^"]*)"$/, function (expectedWidgetTitle, callback) {
        createviewpage.getStreamingWidgetTitle().getAttribute('title').then(function (actualWidgetTitle) {
            console.log("Widget title is (" + actualWidgetTitle + ") should be expected widget title (" + expectedWidgetTitle + ")");
            expect(actualWidgetTitle).to.equal(expectedWidgetTitle);
            callback();
        });
    });

    this.When(/^I click on cancel button after configuring a widget$/, function (callback) {
        browser.ignoresynchronization = false;
        console.log('about to click on cancel button after configuring a widget');
        createviewpage.clickCancelConfigureWidgetButton().then(function () {
            console.log('clicked on cancel button after configuring a widget');
            callback();
        });
    });

    this.When(/^I sleep for (\d+) seconds$/, function (sleepTime, callback) {
        console.log("About to sleep for " + sleepTime + " seconds");
        browser.sleep(sleepTime * 1000).then(function () {
            console.log("Finished sleeping for " + sleepTime + " seconds");
            callback();
        });
    });

    this.Then(/^I should see widget chart with (\d+) data points$/, function (expectedDataPoints, callback) {
        console.log("Checking data points on chart to be: " + expectedDataPoints);

        createviewpage.getPxChartElement().getAttribute('height').then(function (heightVal) {
            console.log("\n\n HEIGHT=" + heightVal + "\n\n")
            createviewpage.getPxChartElement().getAttribute('width').then(function (widthVal) {
                console.log("\n\n WIDTH=" + widthVal + "\n\n")
                
                // These are false 
                element(by.css('#layer1')).isPresent().then(function (elemPresent) {
                    console.log("\n\n #layer1=" + elemPresent + "\n\n")
                    element(by.css('#layer1 > g')).isPresent().then(function (elemPresent) {
                        console.log("\n\n #layer1 > g=" + elemPresent + "\n\n")
                        createviewpage.getGraphElement().isPresent().then(function (present) {
                            console.log("\n\n PRESENT=" + present + "\n\n")
                            callback();
                        });
                    });    
                });
                
                
                
            });
                // callback();
        });

        // createviewpage.getGraphElement().getAttribute('d').then(function (chartElement) {
        //     var datapointsPresent = chartElement.split(',').length <= parseInt(expectedDataPoints) + 1 ;
        //     expect(datapointsPresent).to.equal(true);
        //     callback();
        // });
    });

    this.Then(/^I should see tooltip on the top of the chart$/, function (callback) {
        console.log("Checking chart tooltip position");
        createviewpage.getPxChartElement().getAttribute('register-location').then(function (registerLocation) {
            expect(registerLocation).to.equal("top");
            callback();
        });
    });

    this.Then(/^I should see the status icon$/, function (callback) {
        createviewpage.chkStatusIcon().isPresent().then(function (elemPresent) {
            expect(elemPresent).to.equal(true);
            callback();
        });
    });
    this.When(/^I hover over the status icon$/, function (callback) {
        // Write code here that turns the phrase above into concrete actions
        let icon = createviewpage.chkStatusIcon();
        browser.actions().mouseMove(icon).perform().then(function(){
            console.log('mouseover done: ');
            callback();
        });

    });
    this.Then(/^I should see "([^"]*)"$/, function (arg1, callback) {
        element(by.css('#message > span')).getInnerHtml().then(function (text){
            console.log('text is: ' + text);
            expect(text).to.equal(arg1);
            callback();
        });
    });


    this.When(/^I clear the tag search bar$/, function (callback) {
        // Write code here that turns the phrase above into concrete actions
        let icon = createviewpage.chkTagClearIcon();
        icon.click().then(function(){
            console.log('click clear done: ');
            callback();
        });
    });

};


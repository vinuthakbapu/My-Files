module.exports = function () {

    'use strict';

    let sharedTimeStamp;
    let analyticEntry = {};
    let deployment={};
    let orchestration={};
    let deploymentStepReponse = {};
    let deploymentIoMappingStats = {}

    function getSharedTimeStamp(){
        if(!sharedTimeStamp){
            sharedTimeStamp = Math.floor(Date.now() / 1000);
        }
        return sharedTimeStamp;
    }

    const formatMapObj = (tagObj, setType, setMonitoredEntityType) => {
        const mapObj = {};
        mapObj['@type'] = setType;
        mapObj.tagName = tagObj.name;
        mapObj.tagUri = tagObj.uri;
        mapObj.tagSourceKey = tagObj.sourceKey;
        mapObj.entityUri = tagObj.monitoredEntityUri;
        mapObj.entitySourceKey = tagObj.monitoredEntitySourceKey;
        mapObj.entityType = setMonitoredEntityType;
        mapObj.uom = tagObj.tagType;
        return mapObj;
    };

    const generateDefaultOnDemand = () => ({
        deployType: "DeployOnDemand",
        startTime: new Date().getTime()-1,
        endTime: new Date().getTime(),
        samplingInterval: {
            timeValue: 1,
            timeUnit: 'MINUTES',
        },
    });

    function getDeployment(callback) {
            let uri = "caf/api/caf-mgmt-svc/v1" + deployment.uri;
            restUtil.makeRequest(uri, 'GET', 'application/json').then(function (resp) {
            deployment = JSON.parse(resp.body);
                let stepUri = "caf/api/caf-mgmt-svc/v1" + deployment.uri + (deployment.deploymentSteps || [0])[0].uri;
                getDeploymentStep(callback, stepUri);
        });
    }


    function getDeploymentStep(callback, uri) {
        console.error(uri, 'uri for deploymet step');
        restUtil.makeRequest(uri, 'GET', 'application/json').then(function (resp) {
            deploymentIoMappingStats = JSON.parse(resp.body).deploymentIoMappingStats;
            deploymentStepReponse = JSON.parse(resp.body).deploymentStepReponse;
            console.error('stats', deploymentIoMappingStats)
            callback();
        });
    }

    function applyAssetFilter(callback){
        let entityFilterUri;
        restUtil.makeRequest("caf/api/caf-mgmt-svc/v1/entityFilters", 'GET', null, 'application/json').then(function (resp) {

            JSON.parse(resp.body).forEach(function(entityFilter){
                if(entityFilter.name == 'GE90')
                {
                    entityFilterUri = entityFilter.uri;
                }
            });
            let data = {
                entityFilterUri: entityFilterUri,
                userSelectedEntities:[]
            };
            restUtil.makeRequest("caf/api/caf-mgmt-svc/v1" + deployment.uri + "/entities", 'PUT', data, 'application/json').then(function (resp) {
                deployment = resp.body;
                callback();
            });
        });
    }

    function mapForSelectedAssets(callback){
        let tagObj;
        restUtil.makeRequest("caf/api/caf-mgmt-svc/v1" + deployment.uri + "/tags", 'GET', null, 'application/json').then(function (resp) {
            JSON.parse(resp.body).some((tag) => {
                if (tag.name === 'AV_TAG_1') {
                tagObj = tag;
                return true;
            }
            return false;
        });
            let deploymentStepUri = deployment.deploymentSteps[0].uri;
            restUtil.makeRequest("caf/api/caf-mgmt-svc/v1" + deployment.uri + deploymentStepUri, 'GET', null, 'application/json').then(function (resp) {
                let deploymentStepResponseObject = JSON.parse(resp.body);
                let currIndex = 0;
                let inputLength = deploymentStepResponseObject.deploymentStepResponse.ioMappings[0].inputsToDataSource.portToDataSources.length;
                while(inputLength > 0) {
                    deploymentStepResponseObject.deploymentStepResponse.ioMappings[0].inputsToDataSource.portToDataSources[currIndex].commonDataSource = formatMapObj(tagObj, 'ioDataSourceTagCommon', 'Asset');
                    currIndex++;
                    inputLength--;
                }
                restUtil.makeRequest("caf/api/caf-mgmt-svc/v1" + deployment.uri + deploymentStepUri + "/ioMappings", 'PUT', deploymentStepResponseObject.deploymentStepResponse, 'application/json').then(function (resp) {
                    callback();
                });
            });
        });
    }


    this.Given(/^Save analyticEntry uri after creation$/, function (callback) {
        browser.getCurrentUrl().then(function(url) {
            analyticEntry.uri = url.substring(url.indexOf("/analyticEntries/"));
            console.error(analyticEntry.uri);
            callback();
        });
    });
    this.Given(/^Save deployment Uri after creation$/, function (callback) {
        browser.getCurrentUrl().then(function(url) {
            deployment.uri = url.substring(url.indexOf("/deployments/"));
            // console.error(deployment.uri);
            callback();
        });
    });
    
    this.Given(/^Get deployment to save in util then get deployment step$/, function (callback) {
        getDeployment(callback)
        browser.sleep(1000);
    });

    this.Given(/^Get deployment step to save in util$/, function (callback) {
        getDeploymentStep(callback);
        browser.sleep(10000);
    });

    this.Given(/^Update deployment step with mapping$/, function (callback) {
        // updateDeploymentStepWithMapping(callback);
        browser.sleep(1000);
    });

    this.Then(/^Apply assetFilter to smart signal deployment$/, function (callback) {
        applyAssetFilter(callback);
    });
    
    this.Then(/^Map for selected assets to smart signal deployment$/, function (callback) {
        mapForSelectedAssets(callback);
    });
    
    
    this.When(/^User searches for ASCIITESTAsset139_0625_ChartMarker for the caf analytic list$/, function (callback) {
        TestHelper.isElementPresent(element(by.id('apm-ax-analytic-list-item0'))).then(function () {
            cafCreateAnalyticPage.clickSearchBox().then(function () {
                cafCreateAnalyticPage.enterSearchText("ASCIITESTAsset139_0702_ChartMarker").then(function () {
                    callback();
                })
            });
        });
    });
}

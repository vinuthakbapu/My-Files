/**
 * Analytic IOMapping spec
 */

module.exports = function () {

    var dragFn = require('proui-utils').drag;
    var dragFn2 = require('proui-utils').dragula;

    this.When(/^user opens the analytic deployment tab of an existing analytic$/, function (callback) {
        browser.get('https://stuf-rc.run.asv-pr.ice.predix.io/analyticsq3/analytics/#/analyticUi/analyticEntries/f94c8ade-aa7b-40ef-8fdb-60cb69220ec8/details/deployList').then(function () {
            callback();
        });
    });

    this.When(/^caf user clicks the deployment$/, function (callback) {
        cafIOMappingPage.deployment().click().then(function () {
            browser.sleep(3000).then(function () {
                callback();
            })
        });
    });

    this.When(/^caf user clicks the tags icon to view list of tags/, function (callback) {
        cafIOMappingPage.ioMappingViewTags().click().then(function () {
            callback();
        })
    });

    this.When(/^caf user clicks add tags in the dropdown list to view tags/, function (callback) {
        cafIOMappingPage.secondChildTagsDropdown().click().then(function () {
            browser.sleep(1000).then(function () {
                callback();
            })
        });
    });

    this.When(/^caf user clicks search icon after typing/, function (callback) {
        cafIOMappingPage.filterSearchTagIcon().click().then(function () {
            browser.sleep(3000).then(function () {
                callback();
            })
        });
    });

    this.Then(/^caf user clicks on the next button when enabled$/, function (callback) {
        EC=protractor.ExpectedConditions;

        browser.wait(EC.elementToBeClickable(cafIOMappingPage.nextButton()),5000).then(function () {
            cafIOMappingPage.nextButton().click().then(function () {
                callback();
            });
        });
    })

    this.Then(/^caf IO Mapping tab should be highlighted$/, function (callback) {
        cafAssetSelectionPage.getNavigationTabs().element(by.css('.apm-dp-breadcrumb-active')).getInnerHtml().then(function (tab) {
            assert.include(tab, 'I/O Mapping');
            callback();
        });
    });

    this.Then(/^previous button should be enabled$/, function (callback) {
        browser.sleep(5000).then(function () {
            cafDeploymentPage.deploymentPrevButton().isEnabled().then(function (enabled) {
                expect(enabled).to.equal(true);
                callback();
            });
        });
    });

    this.Then(/^caf IO Mapping screen should be displayed$/, function (callback) {

    });

    this.Then(/^caf previous button should be enabled$/, function (callback) {
        browser.sleep(5000).then(function () {
            cafDeploymentPage.deploymentPrevButton().isEnabled().then(function (enabled) {
                expect(enabled).to.equal(true);
                callback();
            });
        });
    });

    this.Then(/^caf tag and attribute icons should be displayed$/, function (callback) {
        cafIOMappingPage.ioMappingAttributeIcon().isPresent().then(function (flag) {
            expect(flag).to.equal(true);
            cafIOMappingPage.ioMappingTagIcon().isPresent().then(function (flag) {
                expect(flag).to.equal(true);
                callback();
            });
        });
    });

    this.Then(/^caf search input should be displayed$/, function (callback) {
        cafIOMappingPage.ioMappingSearchInput().isPresent().then(function (flag) {
            expect(flag).to.equal(true);
            callback();
        });
    });

    this.Then(/^caf flat tag list should be displayed$/, function (callback) {
        cafIOMappingPage.ioMappingTagList().isPresent().then(function (flag) {
            assert.equal(flag, true, 'flat tag list is displayed');
            callback();
        });
    });

    this.Then(/^caf tag name is displayed$/, function (callback) {
        cafIOMappingPage.ioMappingTagName().isPresent().then(function (flag) {
            assert.equal(flag, true, 'label is displayed');
            callback();
        });
    });

    this.Then(/^caf tag description should be displayed$/, function (callback) {
        cafIOMappingPage.ioMappingDetails().getText().then(function (text) {
            assert.equal(text, "Aviation Tag 10", 'description is displayed');
            callback();
        });
    });

    this.Then(/^caf tag data type should be displayed$/, function (callback) {
        cafIOMappingPage.ioMappingDataType().isPresent().then(function (flag) {
            assert.equal(flag, true, 'label is displayed');
            callback();
        });
    });

    this.Then(/^caf tag unit should be displayed$/, function (callback) {
        cafIOMappingPage.ioMappingTagUnit().isPresent().then(function (flag) {
            assert.equal(flag, true, 'label is displayed');
            callback();
        });
    });

    this.Then(/^caf add icon should be displayed$/, function (callback) {
        cafIOMappingPage.ioMappingPlusIcon().isPresent().then(function (flag) {
            assert.equal(flag, true, 'label is displayed');
            callback();
        });
    });

    this.Then(/^the caf input definition header text should be displayed on IOMapping$/, function (callback) {
        cafIOMappingPage.ioMappingInputDefinitionHeader().getText().then(function (string) {
            expect(string).to.equal('INPUT DEFINITION: TAGS & ATTRIBUTES');
            callback();
        });
    });

    this.Then(/^caf required inputs mapped text should be displayed as 0 \/ 1$/, function (callback) {
        cafIOMappingPage.ioMappingRequiredInputs().getText().then(function (string) {
            expect(string).contains('0/1');
            callback();
        });
    });

    this.Then(/^caf required inputs percentage should be 0%$/, function (callback) {
        cafIOMappingPage.ioMappingRequiredInputsPercent().getText().then(function (string) {
            expect(string).contains('0');
            callback();
        });
    });

    this.Then(/^total caf inputs mapped should be displayed as 0 \/ 1$/, function (callback) {
        cafIOMappingPage.ioMappingTotalInputs().getText().then(function (string) {
            expect(string).contains('0/1');
            callback();
        });
    });

    this.Then(/^caf user should click the first input to map$/, function (callback) {
        cafIOMappingPage.ioMappingFirstInput().click().then(function (string) {
            callback();
        });
    });

    this.Then(/^caf user should map "([^"]*)" tag to current input$/, function (tagName, callback) {
        cafIOMappingPage.mapfoundCommonTagByClick().click().then(function () {
            callback();
        });
    });

    this.Then(/^total caf inputs percentage should be 0%$/, function (callback) {
        cafIOMappingPage.ioMappingTotalInputsPercent().getText().then(function (string) {
            expect(string).contains('0');
            callback();
        });
    });

    this.Then(/^all caf input definition column names and values should be displayed$/, function (callback) {
        let colNames = ['Name', 'Description', 'Type', 'Input UoM', 'Mapping Key', 'Mapping Key UoM', 'Data Format'];
        let colValues = ['temp_today', 'Todays temperature. Map with any temperature tag', 'Double', 'Fahrenheit', 'Required', "", 'APM Timeseries'];
        cafIOMappingPage.ioMappingInputDefinitionColumnNames().getText().then(function (text) {
            console.log("input column names", text)
            expect(text.toString()).to.equal(colNames.toString());
            cafIOMappingPage.ioMappingInputDefinitionColumnValues().getText().then(function (values) {
                console.log("input column values", values)
                expect(values.toString()).to.equal(colValues.toString());
                callback();
            });
        });
    });

    this.Then(/^caf UOM should be blank$/, function (callback) {
        cafIOMappingPage.ioMappingTagUOM().isEmpty().then(function (flag) {
            expect(flag).to.equal(true);
            callback();
        });
    });

    this.When(/^caf drag and drop the asset tag onto the input definition row$/, function (callback) {
        cafIOMappingPage.ioMappingAssetMappingTarget().click();
        cafIOMappingPage.ioMappingTagIcon().click();
        browser.sleep(5000).then(function () {
            callback();
        });
    });

    this.When(/^caf user drag and drop the asset tag at index "([^"]*)" onto the input definition row "([^"]*)"$/, function (tagIndex, targetRowIndex, callback) {
        var tagIndex = tagIndex + 1;
        var searchedTagSelector = '#root > div > div > div > div.apm-dp-config-body > div > div > div.right-panel-list-container ' +
            '> div > div.commonTagContainer > div.assetTagList > div:nth-child(' + tagIndex + ')';
        TestHelperPO.elementToBeClickable(element(by.css(searchedTagSelector))).then(function () {
            var ele = element(by.css(searchedTagSelector));
            var target = element(by.css('#apm-dp-input-row-' + targetRowIndex));
            TestHelperPO.dragAndDrop(ele, target).then(function () {
                browser.sleep(10000).then(function () {
                    callback();
                });
            });
        });
    });

    this.Then(/^the caf asset tags column data should be displayed$/, function (callback) {
        cafIOMappingPage.ioMappingAssetTag().getText().then(function (data) {
            expect(data).to.equal('AV_TAG_10');
            callback();
        });
    });

    this.Then(/^caf tag UOM column data should be displayed$/, function (callback) {
        cafIOMappingPage.ioMappingTagUOM().getText().then(function (data) {
            expect(data).to.equal('');
            callback();
        });
    });

    this.Then(/^the caf next button gets enabled$/, function (callback) {
        cafIOMappingPage.nextButton().isEnabled().then(function (flag) {
            expect(flag).to.equal(true);
            callback();
        })
    });

    this.Then(/^the next button should be disabled before mandatory input mapping/, function(callback){
        cafIOMappingPage.nextButton().isEnabled().then(function (flag) {
            expect(flag).to.equal(false);
            callback();
        });
    });

    this.Then(/^the caf Prev button gets enabled$/, function (callback) {
        cafIOMappingPage.prevButton().isEnabled().then(function (flag) {
            expect(flag).to.equal(true);
            callback();
        });
    });

    this.Then(/^caf required inputs mapped text should be displayed as 1 \/ 1$/, function (callback) {
        browser.sleep(5000).then(function () {
            cafIOMappingPage.ioMappingRequiredInputs().getText().then(function (string) {
                expect(string).contains('1/1');
                callback();
            });
        });
    });

    this.Then(/^caf required inputs percentage should be 100%$/, function (callback) {
        cafIOMappingPage.ioMappingRequiredInputsPercent().getText().then(function (string) {
            expect(string).contains('100');
            callback();
        });

    });

    this.Then(/^total caf inputs mapped should be displayed as 1 \/ 1$/, function (callback) {
        cafIOMappingPage.ioMappingTotalInputs().getText().then(function (string) {
            console.log(' STRING ', string);
            expect(string).contains('1/1');
            callback();
        });
    });

    this.Then(/^caf user should click the "([^"]*)" input to map$/, function (inputNo,callback) {
        cafIOMappingPage.ioMappingInput(inputNo).click().then(function (string) {
            callback();
        });
    });

    this.Then(/^total caf inputs percentage should be 100%$/, function (callback) {
        cafIOMappingPage.ioMappingTotalInputsPercent().getText().then(function (string) {
            console.log(' STRING ', string);
            expect(string).contains('100');
            callback();
        });
    });

    this.When(/^caf user mouse hover on the mapped tag of the input$/, function (callback) {
        let constantRow = element(by.id('apm-dp-constant-0'));
        //let inputMappedTag = element(by.css('#apm-dp-input-row-0 > td:nth-child(5) > .mapping-cell > span'));

        // constantRow.click().then(function () {
        //     browser.actions().mouseMove(inputMappedTag).perform().then(function() {
        //         callback();
        //     });
        // });

        constantRow.click().then(function () {
            browser.actions().mouseMove(cafIOMappingPage.mappedTag()).perform().then(function () {
                callback();
            });
        });
    });

    this.When(/^caf user mouse hover on the mapped tag of the output/, function (callback) {
        let constantRow = element(by.id('apm-dp-constant-0'));
        constantRow.click().then(function () {
            browser.actions().mouseMove(cafIOMappingPage.outputMappedTag()).perform().then(function () {
                callback();
            });
        });
    });

    this.Then(/^X icon should be displayed$/, function (callback) {
        cafIOMappingPage.clearInputMapIcon().isDisplayed().then(function (flag) {
            assert.equal(flag, true, 'clear input map icon is not displayed');
            callback();
        })
    });

    this.Then(/^X icon should be displayed next to output mapped tag$/, function (callback) {
        cafIOMappingPage.clearOutputMapIcon().isDisplayed().then(function (flag) {
            assert.equal(flag, true, 'clear output map icon is displayed');
            callback();
        })
    });

    this.When(/^caf user clicks on the delete icon of the output mapped tag$/, function (callback) {
        //browser.actions().mouseMove(cafIOMappingPage.outputDefinitionAssetTag()).perform().then(function() {
        cafIOMappingPage.clearOutputMapIcon().click().then(function () {
            browser.sleep(2000).then(function () {
                callback();
            });
        });
        // });
    });

    this.Then(/^the caf asset tag should be unmapped of the output definition$/, function (callback) {
        cafIOMappingPage.outputDefinitionAssetTag().getText().then(function (value) {
            expect(value).equal('');
            callback();
        });
    });

    this.Then(/^caf constants header text should be displayed$/, function (callback) {
        cafIOMappingPage.ioMappingConstantsHeader().isDisplayed().then(function () {
            cafIOMappingPage.ioMappingConstantsHeader().getText().then(function (string) {
                expect(string).to.equal('CONSTANTS');
                callback();
            });
        });
    });

    this.Given(/^text box is displayed to enter analytic data points$/, function (callback) {
        cafIOMappingPage.analyticDataPointsTextbox().isDisplayed().then(function (flag) {
            assert.equal(flag, true, 'text box for data points is displayed');
            callback();
        })
    });

    this.Given(/^radio buttons should be displayed for Map per all assets and Map per asset$/, function (callback) {
        cafIOMappingPage.mapForAllAssetsRadioButton().isDisplayed().then(function (flag) {
            assert.equal(flag, true, 'text box for data points is displayed');
            cafIOMappingPage.mapForAssetRadioButton().isDisplayed().then(function (flag) {
                assert.equal(flag, true, 'text box for data points is displayed');
                callback();
            });
        })
    });

    this.Then(/^a tooltip icon is displayed next to the header text$/, function (callback) {
        cafIOMappingPage.inputToolTip().isDisplayed().then(function (flag) {
            assert.equal(flag, true, 'text box for data points is displayed');
            callback();
        })

    });

    this.When(/^mouse hovered on the tooltip icon$/, function (callback) {
        cafIOMappingPage.mouseOverToolTip().then(function () {
            callback();
        });
    });


    this.Then(/^the tooltip text is displayed$/, function (callback) {
        cafIOMappingPage.inputToolTip().getText().then(function (text) {
            expect(text).to.equal('For each input, type or select an available tag from the list on the right & ATTRIBUTES');
            callback();
        })

    });


    this.Then(/^all caf constants column names and values should be displayed$/, function (callback) {
        let colNames = ['Name', 'Description', 'Type', 'Value', 'UoM', 'Data Format'];
        let colValues = ['threshold', 'threshold', 'Double', 30, 'FAHRENHEIT', 'Constant'];
        cafIOMappingPage.ioMappingConstantsColumnNames().getText().then(function (text) {
            console.log("input column names", text)
            expect(text.toString()).to.equal(colNames.toString());
            cafIOMappingPage.ioMappingConstantsValues().getText().then(function (values) {
                console.log("CONSTANTS Values: " + values);
                //     let trimmed=[];
                //     values.forEach(function(value){
                //         trimmed.push(value.trim());
                // });
                // console.log("CONSTANTS Values after trim: " + trimmed);
                //expect(trimmed.toString()).to.equal(colValues.toString());
                expect(values.toString()).to.equal(colValues.toString());
                callback();
            });
        });
    });

    this.When(/^caf user mouse hover over on the constant value$/, function (callback) {
        let constantElement = cafIOMappingPage.constantValue();
        browser.actions().mouseMove(constantElement).perform().then(function () {
            callback();
        });
    });

    this.When(/^caf user clicks on the edit icon$/, function (callback) {
        cafIOMappingPage.constantValue().click().then(function () {
            cafIOMappingPage.constantValueInput().isPresent().then(function (isDisplayed) {
                expect(isDisplayed).to.equal(true);
                callback();
            });
        });
    });

    this.Then(/^caf user enters the value$/, function (callback) {
        cafIOMappingPage.constantValueInput().clear().sendKeys('25').then(function () {
            callback();
        });
    });

    this.Then(/^the save button is enabled$/, function (callback) {
        cafIOMappingPage.saveButton().isEnabled().then(function (enabled) {
            expect(enabled).to.equal(true);
            callback();
        });
    });

    this.When(/^the Reset button is enabled$/, function (callback) {
        cafIOMappingPage.resetButton().isEnabled().then(function (enabled) {
            expect(enabled).to.equal(true);
            callback();
        });
    });

    this.When(/^user clicks on the save button$/, function (callback) {
        cafIOMappingPage.saveButton().click().then(function () {
            browser.sleep(1000).then(function () {
                callback();
            });
        });
    });

    this.When(/^user clicks on the Reset button$/, function (callback) {
        cafIOMappingPage.resetButton().click().then(function () {
            browser.sleep(1000).then(function () {
                callback();
            });
        });
    });

    this.Then(/^the caf constant value should be saved$/, function (callback) {
        // cafIOMappingPage.constantValueAfterSave().getText().then(function(stringVal){

        cafIOMappingPage.constantvalue().getText().then(function (stringVal) {
            expect(stringVal).to.equal('25');
            callback();
        });

    });

    this.Then(/^caf output definition tags header text should be displayed$/, function (callback) {
        cafIOMappingPage.ioMappingOutputDefinitionTagsHeader().getText().then(function (string) {
            expect(string).to.equal('OUTPUT DEFINITION: TAGS & ATTRIBUTES');
            callback();
        });
    });

    this.Then(/^all caf output definition tag column names and values should be displayed$/, function (callback) {
        let colNames = ['Name', 'Description', 'Type', 'Output UoM', 'Mapping Key', 'Mapping Key UoM', 'Data Format'];
        let colValues = ['mean', 'mean', 'Double', 'None', '', '', 'APM Timeseries'];
        cafIOMappingPage.ioMappingOutputDefinitionColumnNames().getText().then(function (text) {
            console.log("column names", text)
            expect(text.toString()).to.equal(colNames.toString());
            cafIOMappingPage.ioMappingOutputDefinitionColumnValues().getText().then(function (values) {
                console.log("column values", values)
                //expect(values.toString()).to.equal(colValues.toString());
                expect(values.toString()).to.equal(colValues.toString());
                callback();
            });
        });
    });

    this.Then(/^caf output definition alerts header text should be displayed$/, function (callback) {
        cafIOMappingPage.ioMappingOutputDefinitionAlertsHeader().getText().then(function (string) {
            expect(string).to.equal('OUTPUT DEFINITION:ALERTS');
            callback();
        });
    });

    this.Then(/^all caf output definition alerts column names should be displayed$/, function (callback) {
        let colNames = ['Name', 'Description'];
        let colValues = [];
        cafIOMappingPage.ioMappingOutputDefinitionAlertsColumnNames().getText().then(function (text) {
            console.log("Alerts column names: " + text);
            expect(text.toString()).contains(colNames.toString());
            callback();
        });
    });

    this.When(/^user clicks the tag icon to map to the input$/, function (callback) {
        cafIOMappingPage.tagIcon().click().then(function () {
            callback();
        });
    });

    this.When(/^user clicks on the Add tags link$/, function (callback) {
        cafIOMappingPage.addTagsLink().click().then(function () {
            callback();
        });

    });

    this.When(/^user clicks the Get Suggested Tags link$/, function (callback) {
        cafIOMappingPage.suggestedTagsLink().click().then(function () {
            browser.sleep(5000).then(function () {
                callback();
            });
        });
    });

    this.Then(/^the suggested tags should be displayed for all inputs$/, function (callback) {
        cafIOMappingPage.suggestedTagsColumn().isPresent().then(function (isPresent) {
            expect(isPresent).to.equal(true);
            callback();
        });
    });

    this.Then(/^the asset tags should be mapped to all the inputs$/, function (callback) {
        cafIOMappingPage.ioMappingAssetTag().getText().then(function (data) {
            expect(data).to.equal('a');
            callback();
        });
    });

    this.When(/^user clicks the save selected button$/, function (callback) {
        cafIOMappingPage.saveSelected().click().then(function () {
            browser.sleep(5000).then(function () {
                callback();
            });
        });
    });

    this.When(/^caf user clicks on the delete icon of the mapped tag$/, function (callback) {
        browser.actions().mouseMove(cafIOMappingPage.ioMappingAssetTag()).perform().then(function () {
            cafIOMappingPage.clearOutputMapIcon().click().then(function () {
                browser.sleep(2000).then(function () {
                    callback();
                });
            });
        });
    });

    this.Then(/^the caf asset tag should be unmapped$/, function (callback) {
        cafIOMappingPage.ioMappingAssetTag().getText().then(function (value) {
            expect(value).equal('Required');
            callback();
        });
    });

    this.When(/^caf user maps the first asset tag result to the output definition$/, function (callback) {
        cafIOMappingPage.outputDefinitionRow().click().then(function () {
            cafAnalyticsJourneyPage.firstTagResult().click().then(function () {
                callback();
            });
        });
    });

    this.Then(/^the tag should be displayed in asset tags column of the output definition$/, function (callback) {
        cafIOMappingPage.outputDefinitionAssetTag().getText().then(function (data) {
            expect(data).to.equal('AV_TAG_10');
            callback();
        });
    });

    this.When(/^caf user clicks on the attribute icon in asset tag container$/, function (callback) {
        cafIOMappingPage.ioMappingAttributeIcon().click().then(function () {
            browser.sleep(3000).then(function () {
                callback();
            })
        });
    });

    this.When(/^caf user clicks on the time series icon in asset tag container$/, function (callback) {
        cafIOMappingPage.ioMappingTimeSeriesIcon().click().then(function () {
            browser.sleep(3000).then(function () {
                callback();
            })
        });
    });

    this.When(/^caf user clicks on the custom attribute icon in asset tag container$/, function (callback) {
        cafIOMappingPage.ioMappingCustomAttributeIcon().click().then(function () {
            browser.sleep(3000).then(function () {
                callback();
            })
        });
    });


    this.Then(/^the caf attribute list should be displayed$/, function (callback) {
        cafIOMappingPage.visibilityOf(cafIOMappingPage.ioMappingAttributeList()).then(function () {
            cafIOMappingPage.ioMappingAttributeList().isPresent().then(function (isPresent) {
                expect(isPresent).to.equal(true);
                callback();
            });
        });
    });

    this.When(/^caf user clicks on the drop down icon of map by drop down$/, function (callback) {
        cafIOMappingPage.ioMappingSelectionDropDown().click();
        callback();
    });

    this.When(/^caf user clicks the map per asset radio button$/, function (callback) {
        cafIOMappingPage.ioMappingForAssets().click().then(function () {
            browser.sleep(5000).then(function () {
                callback();
            });
        });
    });

    this.Then(/^caf attribute and hierarchy icons should be displayed$/, function (callback) {
        cafIOMappingPage.ioMappingAttributeIcon().isPresent().then(function (isPresent) {
            expect(isPresent).to.equal(true);
            cafIOMappingPage.ioMappingHierarchyIcon().isPresent().then(function (hisPresent) {
                expect(hisPresent).to.equal(true);
                callback();
            });
        });


    });

    this.Then(/^the caf tree view should be displayed$/, function (callback) {
        cafIOMappingPage.ioMappingTree().isPresent().then(function (isPresent) {
            expect(isPresent).to.equal(true);
            callback();
        });
    });

    this.Then(/^all the caf assets should be displayed with radio buttons$/, function (callback) {
        cafIOMappingPage.ioMappingAssetRadioButton().isPresent().then(function (isPresent) {
            expect(isPresent).to.equal(true);
            callback();
        });
    });

    this.Then(/^the caf column names should be displayed in map per asset$/, function (callback) {
        let colNames = ['', 'Name', 'Source Key', 'Description'];
        cafIOMappingPage.ioMappingSelectedAssetsColumnNames().getText().then(function (string) {
            expect(string.toString()).contains(colNames.toString());
            callback();
        });
    });

    this.When(/^caf user clicks on the radio button$/, function (callback) {
        cafIOMappingPage.ioMappingAssetRadioButton().click();
        callback();
    });

    this.When(/^caf user expands the tag tree and tags node$/, function (callback) {
        cafIOMappingPage.expandTagsNode().click().then(function () {
            browser.sleep(8000).then(function () {
                callback();
            });
        });
    });

    this.When(/^caf user search for the tag "([^"]*)" in the asset hierarchy$/, function (arg1, callback) {
        cafIOMappingPage.assetHierarchySearch().sendKeys(arg1).then(function () {
            callback();
        });
    });

    this.When(/^caf user clicks on the search icon in the asset hierarchy$/, function (callback) {
        cafIOMappingPage.assetHierarchySearchIcon().click().then(function () {
            browser.sleep(2000).then(function () {
                callback();
            });
        });
    });

    this.Then(/^the tag tree search results should be displayed$/, function (callback) {
        cafIOMappingPage.assetHierarchySearchResults().getText().then(function (value) {
            expect(value).to.equal("AV_TAG_10");
            callback();
        });
    });

    this.When(/^caf user drag and drop the tag onto the input row in map per asset$/, function (callback) {
        var ele = cafIOMappingPage.ioMappingSelectedAssetTagSource();
        var target = cafIOMappingPage.ioMappingSelectedAssetTagTarget();

        // browser.actions().dragAndDrop(ele, target).perform().then(function() {
        //     browser.sleep(5000).then(function () {
        //         callback();
        //     });
        // });
        //
        TestHelperPO.elementToBeClickable(ele).then(function () {
            TestHelperPO.elementToBeClickable(target).then(function () {
                TestHelperPO.dragAndDrop(ele, target).then(function () {
                    console.log("Element dragged and dropped");
                    browser.sleep(5000).then(function () {
                        callback();
                    });
                });
            });
        });

    });

    this.Then(/^the caf tag should be mapped to the asset$/, function (callback) {
        browser.sleep(10000).then(function () {
            cafIOMappingPage.ioMappingSelectedAssetsMappedByTag().getText().then(function (value) {
                expect(value).to.equal("AV_TAG_10");
                callback();
            });
        });
    });

    this.When(/^caf user drag and drop the tag onto the output row in map per asset$/, function (callback) {
        var ele = cafIOMappingPage.draggableAssetTag();
        var target = cafIOMappingPage.outputDefinitionTarget();

        TestHelperPO.elementToBeClickable(ele).then(function () {
            TestHelperPO.elementToBeClickable(target).then(function () {
                TestHelperPO.dragAndDrop(ele, target).then(function () {
                    console.log("Element dragged and dropped");
                    browser.sleep(5000).then(function () {
                        callback();
                    });
                });
            });
        });

    });

    this.When(/^caf user clicks the first output tag to map the output definition$/, function (callback) {
        cafIOMappingPage.firstOutputDef().click().then(function () {
            callback();
        });
    });

    this.When(/^caf user clicks the second output tag to map the output definition$/, function (callback) {
        cafIOMappingPage.secondOutputDef().click().then(function () {
            callback();
        });
    });

    this.When(/^caf user clicks enters a negative value in the data point text$/, function (callback) {
        cafIOMappingPage.analyticDataPointsInput().click().clear().sendKeys("-1").then(function () {
            callback();
        });
    });

    this.When(/^caf user clicks enters a character value in the data point text$/, function (callback) {
        cafIOMappingPage.analyticDataPointsInput().click().clear().sendKeys("f").then(function () {
            callback();
        });
    });

    this.When(/^caf user clicks enters a integer value in the data point text$/, function (callback) {
        cafIOMappingPage.analyticDataPointsInput().click().clear().sendKeys("1").then(function () {
            callback();
        });
    });

    this.Then(/^an error message appears$/, function (callback) {
        cafIOMappingPage.dataPointsError().isPresent().then(function () {
            callback();
        });
    });

    this.When(/^caf user click the dropdown for iteration$/, function (callback) {
        cafIOMappingPage.iterationDropdown().click().then(function () {
            callback();
        });
    });

    this.When(/^the caf user clicks on Add Iteration$/, function (callback) {
        cafIOMappingPage.ioMapItems().get(0).click().then(function () {
            callback();
        });
    });

    this.Then(/^the caf iteration is increased by one$/, function (callback) {
        browser.sleep(5000);
        cafIOMappingPage.iterationBox().getAttribute("value").then(function (iterationIncrease) {
            console.log("iteration number :" + iterationIncrease);
            callback();
        });
    });

    this.When(/^the caf datapoints for iteration appears$/, function (callback) {
        cafIOMappingPage.iterationDataPoints().isPresent().then(function (flag) {
            expect(flag).to.equal(true);
            callback();
        });
    });

    this.When(/^the caf user clicks on the Copy iteration$/, function (callback) {
        TestHelperPO.isElementPresent(cafIOMappingPage.iterationDropdown());
        cafIOMappingPage.iterationDropdown().click().then(function () {
            cafIOMappingPage.ioMapItems().get(1).click();
            callback();
        });
    });

    this.When(/^the caf user clicks on the Remove iteration$/, function (callback) {
        TestHelperPO.isElementPresent(cafIOMappingPage.iterationDropdown());
        cafIOMappingPage.iterationDropdown().click().then(function () {
            cafIOMappingPage.ioMapItems().get(2).click();
            callback();
        });
    });

    this.Then(/^the new caf iteration is copied$/, function (callback) {
        browser.sleep(5000);
        cafIOMappingPage.iterationBox().getText().then(function (iterationIncrease) {
            console.log("iteration number " + iterationIncrease);
            assert("3", iterationIncrease);
            cafIOMappingPage.ioMapsText().getText().then(function (Text) {
                console.log("iteration Text " + Text);
                expect(Text).to.contain('3');
                callback();
            });
        });
    });

    this.Then(/^the caf iteration is removed$/, function (callback) {
        browser.sleep(5000);
        cafIOMappingPage.iterationBox().getText().then(function (iterationIncrease) {
            console.log("iteration number " + iterationIncrease);
            assert("2", iterationIncrease);
            cafIOMappingPage.ioMapsText().getText().then(function (Text) {
                console.log("iteration Text " + Text);
                callback();
            });
        });
    });

    this.When(/^the caf user clicks iteration left and right nav$/, function (callback) {
        TestHelperPO.isElementPresent(cafIOMappingPage.iterationLeftArrow());
        //expect(cafIOMappingPage.iterationRightArrow().isEnabled()).to.equal(false);
        cafIOMappingPage.iterationLeftArrow().click().then(function () {
            callback();
        });
    });

    this.Then(/^the caf iteration number changes$/, function (callback) {
        cafIOMappingPage.iterationBox().getAttribute("value").then(function (iterationIncrease) {
            console.log("iteration number after left click :" + iterationIncrease);
            expect(iterationIncrease).to.contain('2');
            callback();
        });
    });

    this.When(/^the caf user enters a value for step level data points and clicks out of box$/, function (callback) {
        expect(cafIOMappingPage.dataPointsStepLevelInputBox()).to.exist;
        cafIOMappingPage.dataPointsStepLevelInputBox().getAttribute("value").then(function (value) {
            console.log("the datapoints value is: " + value);
            cafIOMappingPage.dataPointsStepLevelInputBox().click().clear().sendKeys("35").then(function () {
                cafIOMappingPage.ioMappingInputDefinitionHeader().click().then(function () {
                    console.log("click out of data points");
                    callback();
                });
            });
        });
    });

    this.Then(/^the caf orchestration should be updated for step data points$/, function (callback) {
        browser.sleep(5000);
        cafIOMappingPage.dataPointsStepLevelInputBox().click();
        cafIOMappingPage.dataPointsStepLevelInputBox().getAttribute("value").then(function (value) {
            console.log("the data points value after updating is: " + value);
            assert(value, "35");
            callback();
        });
    });

    this.When(/^the caf user enters a value for iteration level data points and clicks out of box$/, function (callback) {
        expect(cafIOMappingPage.dataPointsIterationLevelInputBox()).to.exist;
        cafIOMappingPage.dataPointsIterationLevelInputBox().getAttribute("value").then(function (value) {
            console.log("the datapoints value is: " + value);
            cafIOMappingPage.dataPointsIterationLevelInputBox().click().clear().sendKeys("55").then(function () {
                cafIOMappingPage.ioMappingInputDefinitionHeader().click().then(function () {
                    console.log("click out of data points");
                    callback();
                });
            });
        });
    });

    this.Then(/^the orchestration should be updated for iteration data points$/, function (callback) {

        browser.sleep(5000);
        cafIOMappingPage.dataPointsIterationLevelInputBox().click();
        cafIOMappingPage.dataPointsIterationLevelInputBox().getAttribute("value").then(function (value) {
            console.log("the data points value after updating is: " + value);
            assert(value, "55");
            callback();
        });
    });

    this.Then(/^clicks on "([^"]*)"$/, function (arg1, callback) {
        var elm = element(by.cssContainingText(".apm-ax-accordion-title span", arg1));
        TestHelperPO.elementToBeClickable(elm).then(function () {
            console.log("Clicked on", arg1);
            callback();
        });

    });
    this.Given(/^User should see (.*) on the io mapping page$/, function (version, callback) {
        cafIOMappingPage.versionNumberIOMapping().getText().then(function (text) {
            expect(text).to.equal(version)
            callback();
        });

    });

    this.Then(/^the caf user maps the tag to the input$/, function (callback) {
        browser.sleep(5000).then(function () {
            cafIOMappingPage.selectFirstInputRow().then(function () {
                cafIOMappingPage.addTagWithPlusSign().then(function () {
                    browser.waitForAngular();
                    callback();
                });
            });
        });
    });

    this.Given(/^user should see both the versions in dropdown on io mapping page$/, function (callback) {
        let versions = ['1.0.0', '2.0.0'];
        cafIOMappingPage.versionNumberIOMapping().click().then(function () {
            cafIOMappingPage.ioMappingDropdown().then(function (text) {
                console.log("Version Text sorted: " + text);
                expect(text.sort().toString()).to.equal(versions.toString());
                callback();
            });
        });
    });

    this.Given(/^user selects Map for all Assets radio button$/, function (callback) {
        browser.pause()
        cafIOMappingPage.ioMappingMapForAllAssets().click().then(function () {
            callback();
        });

    });

};



module.exports = function() {

    const moduleName = 'Analytics';
    const submoduleName = 'Preferences';
    const nameSuffix = Date.now();

    const fs = require('fs');
    const rStream = fs.createReadStream(path.resolve(__dirname, '../../Test_Modules/Analytics/TestData/AnalyticsTestData.json'));
    var testData = '';
    var testAttributes = {
        assetAttributes: []
    }
    rStream.setEncoding('utf8');
    rStream.on('data', function(chunk) {
        testData+=chunk;
    });
    rStream.on('end', function () {
        testAttributes = JSON.parse(testData);
    })

    this.BeforeFeature(function(feature, callback) {
        /*const tags = feature.getPayloadItem('feature').getTags().map(tag => {return tag.getName()});
        if(tags.includes('@cafPreferences')) {
            cafMgmtRestUtil.getAttributes().then((attributes) => {
                const currentAttr = attributes.map((attribute) => {return attribute.displayName});
                const attributesToAdd = testAttributes.preloadAttributes.filter(attribute => !currentAttr.includes(attribute.displayName));
                cafMgmtRestUtil.createAttributes(attributesToAdd).then(() => {
                    callback();
                })
            });
        } else {
            callback();
        }*/
        callback();
    });

    this.AfterFeature(function(feature, callback) {
        /*const tags = feature.getPayloadItem('feature').getTags().map(tag => {return tag.getName()});
        if(tags.includes('@cafPreferences')) {
            cafMgmtRestUtil.getAttributes().then(attributes => {
                const autoTestAttributes = attributes.filter(attribute => attribute.displayName.includes(`${nameSuffix}`));
                const deletePromises = autoTestAttributes.map(attribute => {
                    return cafMgmtRestUtil.deleteAttribute(attribute);
                });
                Promise.all(deletePromises).then(() => {
                    callback();
                })
            });
        } else {
            callback();
        }*/
        callback();
    });


    this.Given(/^the caf Preferences user is logged in$/, function (callback) {
        const baseUrl = browser.params.login.baseUrl;
        const userName = browser.params.login.mgrusername;
        const password = browser.params.login.mgrpassword;

        appHubPage.login(baseUrl, userName, password).then(function (landingPagePresent) {
            assert.isTrue(landingPagePresent, 'Login failed');
            callback();
        })
    });

    this.When(/^the user opens the Preferences sub module$/, function (callback) {
        cafPreferencesPage.verifyPreferencesTab().then(function () {
                //browser.sleep(10000);
                callback();
            });
    });

    this.When(/^the user adds a new attribute of type (.*) with name (.*)/, function (attributeType,attributeName,callback) {
        TestHelperPO.isElementVisible(cafPreferencesPage.newAttributeButton());
        cafPreferencesPage.addAttribute(attributeType, `${attributeName}_${nameSuffix}`).then(() => {
            callback();
        });
    });

    this.When(/^the user edits default attribute with type (.*) to a new name of (.*)/, function (attributeType,attributeName,callback) {
        cafPreferencesPage.editDefaultAttribute(attributeType, `${attributeName}_${nameSuffix}`,'edit').then(() => {
            callback();
        });
    });

    this.Then(/^the preloaded default attributes are displayed$/, function() {
        const testAttributeList = testAttributes.preloadAttributes.map(attribute => {
            return cafPreferencesPage.isAttributePresent(attribute.entityType, attribute.displayName).then(value => {
                expect(value, `did not find element of type:"${attribute.entityType}" with name:"${attribute.displayName}"`).to.be.true;
            });
        });
        return Promise.all(testAttributeList).then(() => {})
    });

    this.Then(/^attribute of type (.*) with name (.*) for operation type (.*) will be present in attribute list$/, function(attributeType, attributeName, operationType) {
        let attributeNameValue = `${attributeName}_${nameSuffix}`;

        if(operationType == 'edit' || operationType == 'delete' )
            attributeNameValue = `${attributeName}_${nameSuffix}_edit`;


        return cafPreferencesPage.isAttributePresent(attributeType, attributeNameValue).then(value => {
            expect(value, 'added attribute does not appear in attribute list').to.be.true;
        });

    });

    this.Then(/^attribute of type (.*) with name (.*) will be deleted$/, function(attributeType,attributeName) {
        return cafPreferencesPage.deleteTestAttribute(attributeType, `${attributeName}_${nameSuffix}`,'edit').then(value => {
            expect(" ").to.equal(" ");
        });

    });

    this.When(/^the user adds the same attribute of type (.*) with name (.*)/, function (attributeType,attributeName,callback) {
        cafPreferencesPage.addSameAttribute(attributeType, `${attributeName}_${nameSuffix}`).then(() => {
            browser.sleep(10000);
            callback();
        });
    });

    this.Then(/^error appears as already used$/, function(callback){
        cafPreferencesPage.errorMessage().then(function(value){
            assert.equal(value, 'THIS ATTRIBUTE NAME IS ALREADY USED', 'error messsage not seen');

            callback();
        })
    });

    this.Then(/^error pops up as invalid (.*) name$/, function(attributeName,callback){
        cafPreferencesPage.errorPopUp().then(function(value){
            assert.include(value, "Error(s): Error: The value '"+ `${attributeName}_${nameSuffix}` + "' is not valid.", 'error messsage not seen');
            callback();
        })
    });

};

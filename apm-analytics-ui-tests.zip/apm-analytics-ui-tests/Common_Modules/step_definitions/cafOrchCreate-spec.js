/********************************************************************************
 * Copyright (c) 2015-2016 GE Digital. All rights reserved.                     *
 *                                                                              *
 * The copyright to the computer software herein is the property of GE Digital. *
 * The software may be used and/or copied only with the written permission of   *
 * GE Digital or in accordance with the terms and conditions stipulated in the  *
 * agreement/contract under which the software has been supplied.               *
 ********************************************************************************/

/**
 * Create Orch spec
 */

module.exports = function() {


    this.Then(/^create pre-defined analytic with template$/, function (callback) {
        console.log("create analytic");
        createOrchestrationPage.createAnalyticWithTemplate(callback);
    });

    this.Then(/^create soar analytic with template$/, function (callback) {
        console.log("create soar analytic");
        createOrchestrationPage.createSoarAnalyticWithTemplate(callback);
    });

    this.Then(/^create AIR analytic with template$/, function (callback) {
        console.log("create AIR analytic");
        createOrchestrationPage.createAirAnalyticWithTemplate(callback);
    });


    this.Given(/^user create Px orchestration with an analytic2$/, function (callback) {
        console.log("create soar analytic");
        createOrchestrationPage.createOrchestrationPxwithAnalytic(callback);
        console.log(createOrchestrationPage.getPxOrchestrationNamewithAnalytic());
    });

    this.When(/^the user enters Px the orchestration name$/, function (callback) {
        console.log("creating orchestration");
        createOrchestrationPage.createOrchestrationPx(callback);
        console.log(createOrchestrationPage.getPxOrchestrationName());
        browser.refresh();
    });

    this.Then(/^the cafUser clicks the Orchestration subTab$/, function(callback){
       browser.sleep(10000).then(function(){
            //expect(cafCreateAnalyticPage.clickOrchestrations()).to.exist;
           //TestHelperPO.elementToBeClickable(cafCreateAnalyticPage.clickOrchestrations());
           // callback();
        });
    });

    this.Given(/^the user clicks on orchestration microApp$/, function (callback) {
        createOrchestrationPage.clickOrchTab();
        callback();
    });

    this.Then(/^the user should see the orchestration landing page$/, function (callback) {
        browser.sleep(5000).then(function(){
        createOrchestrationPage.visibilityOf(createOrchestrationPage.OrchTitle()).then(function(value) {
            expect(value).to.be.true;

            callback();
            });
        });
    });

    this.When(/^user clicks New Orchestration button$/, function (callback) {
        createOrchestrationPage.createOrchButton().click();
        callback();
    });

    this.Then(/^user should verify that dropdown working$/, function (callback) {
        browser.waitForAngular();
        var dropdownCategories = createOrchestrationPage.runtimeTypeField();
        createOrchestrationPage.visibilityOf(dropdownCategories).then(function(){
            dropdownCategories.click().then(function(){
                dropdownCategories.$('[value="Predix"]').click();
            });
        });
        callback();
    });

    this.Then(/^user selects AIR runtime from dropdown$/, function(callback) {
        browser.waitForAngular();
        var dropdownCategories = createOrchestrationPage.runtimeTypeField();
        createOrchestrationPage.visibilityOf(dropdownCategories).then(function(){
            dropdownCategories.click().then(function(){
                dropdownCategories.$('[value="AIR"]').click();
            });
        });
        callback();
    });

    this.Then(/^user enter all values$/, function(callback){
        createOrchestrationPage.visibilityOf(createOrchestrationPage.NewOrchLabel()).then(function(value){
            expect(value).to.be.true;
            createOrchestrationPage.elementToBeClickable(createOrchestrationPage.nameField()).then(function(value) {
                browser.sleep(12000);
                createOrchestrationPage.createRandomOrchName();
                createOrchestrationPage.createOwner();
                createOrchestrationPage.createDescription();
                createOrchestrationPage.submitButton().isEnabled().then(function (enabled) {
                    expect(enabled).to.equal(true);
                    callback();
                });
            });
        });
    });


    this.Then(/^the user is able to click on Submit to create the orchestration$/, function(callback){
            createOrchestrationPage.submitButton().click();
            callback();

    });


    this.Then(/^the new orchestration can be seen$/, function (callback) {
        createOrchestrationPage.viewOrchName().getText().then(function(value){
            console.log("Name is >>" + value);
            assert(value,createOrchestrationPage.getName());
            expect(createOrchestrationPage.trashIcon()).to.exist;
            callback();
        });
    });


    //Search
    this.When(/^the user enters the orchestration name$/, function (callback) {
        browser.sleep(2000);
        createOrchestrationPage.searchOrchField().clear();
        createOrchestrationPage.searchOrchField().sendKeys(createOrchestrationPage.getName());
        //createOrchestrationPage.searchOrchField().sendKeys("OrchName-1519640044303");
        //createOrchestrationPage.getCreatedOrchName()
        callback();
    });

    this.Then(/^that orchestration appears$/, function (callback) {
        browser.sleep(2000);
        createOrchestrationPage.searchCount().then(function(value){
            console.log("Count is >>" + value);
            callback();
        });
    });

    this.Then(/^the details of orchestration is displayed when clicked$/, function (callback) {
        browser.sleep(2000);
        createOrchestrationPage.firstOrchName().click();
        callback();
    });

    this.When(/^the user enters soar analytic name$/, function (callback) {
        browser.sleep(2000);
        console.log(createOrchestrationPage.getSoarAnalyticName());
        createOrchestrationPage.searchAnalyticField().sendKeys(createOrchestrationPage.getSoarAnalyticName());
        callback();
    });

    this.Then(/^the analytic catalog is empty$/, function (callback) {
        browser.sleep(2000);
        createOrchestrationPage.analyticSearchCount().then(function(value){
            console.log("Count is >>" + value);
            expect(createOrchestrationPage.soarAnalyticSearch()).to.not.be.true;
            callback();
        });
    });

    this.Then(/^the cafUser should see the Orchestration in left navigation$/, function (callback) {
        createOrchestrationPage.isOrchestrationLinkAvailable().then(function (bool) {
            assert.equal(bool, true, "Orchestration link is not displayed");
            callback();
        });
    });

    this.Then(/^the cafUser should not see the Orchestration in left navigation$/, function (callback) {
        createOrchestrationPage.isOrchestrationLinkNotAvailable().then(function (bool) {
            assert.equal(bool, false, "Orchestration link is displayed");
            callback();
        });
    });

    this.Then(/^clear the search$/, function (callback) {
        browser.sleep(2000);
        createOrchestrationPage.searchAnalyticField().clear();
        callback();
    });

    this.When(/^the user enters pre-defined analytic name$/, function (callback) {
        browser.sleep(2000);
        console.log(createOrchestrationPage.getAnalyticName());
        createOrchestrationPage.searchAnalyticField().sendKeys(createOrchestrationPage.getAnalyticName());
        callback();
    });

    this.Then(/^that pre-defined analytic appears$/, function (callback) {
        browser.sleep(2000);
        createOrchestrationPage.analyticSearchCount().then(function(value){
            console.log("Count is >>" + value);
            callback();
        });
    });
    this.Then(/^orchestration template header should contain create_orchestration icon$/, function (callback) {
        createOrchestrationPage.isTemplateHeaderCreateOrchestrationIconDisplayed().then(function(boolean) {
            assert.equal(boolean, true, "orchestration template header create orchestration icon is not displayed");
            callback();
        });
    });
    this.Then(/^orchestration template header should contain delete_orchestration icon$/, function (callback) {
        createOrchestrationPage.isTemplateHeaderDeleteOrchestrationIconDisplayed().then(function(boolean) {
            assert.equal(boolean, true, "orchestration template header delete orchestration icon is not displayed");
            callback();
        });
    });
    this.Then(/^orchestration tab should contain add_orchestration button$/, function (callback) {
        createOrchestrationPage.isOrchestrationTabAddOrchestrationIconDisplayed().then(function(boolean) {
            assert.equal(boolean, true, "orchestration tab add orchestration icon is not displayed");
            callback();
        });
    });

    this.Then(/^the user should not see the deployment tab$/, function (callback) {
        createOrchestrationPage.isDeploymentTabDisplayed().then(function(boolean) {
            assert.equal(boolean, false, "deployment tab is displayed");
            callback();
        });
    });

    this.Then(/^deployment tab should contain add_deployment button$/, function (callback) {
        createOrchestrationPage.isDeploymentTabAddDeploymentIconDisplayed().then(function(boolean) {
            assert.equal(boolean, true, "deployment tab add deployment icon is not displayed");
            callback();
        });
    });
    this.Then(/^orchestration template header should not contain create_orchestration icon$/, function (callback) {
        createOrchestrationPage.isTemplateHeaderCreateOrchestrationIconNotDisplayed().then(function(boolean) {
            assert.equal(boolean, false, "orchestration template header create orchestration icon is displayed");
            callback();
        });
    });
    this.Then(/^orchestration template header should not contain delete_orchestration icon$/, function (callback) {
        createOrchestrationPage.isTemplateHeaderDeleteOrchestrationIconNotDisplayed().then(function(boolean) {
            assert.equal(boolean, false, "orchestration template header delete orchestration icon is displayed");
            callback();
        });
    });
    this.Then(/^orchestration tab should not contain add_orchestration button$/, function (callback) {
        createOrchestrationPage.isTemplateHeaderaddOrchestrationIconNotDisplayed().then(function(boolean) {
            assert.equal(boolean, false, "orchestration tab add orchestration icon is displayed");
            callback();
        });
    });
    this.Then(/^deployment tab should not contain add_deployment button$/, function (callback) {
        createOrchestrationPage.isDeploymentTabAddDeploymentIconNotDisplayed().then(function(boolean) {
            assert.equal(boolean, false, "deployment tab add deployment icon is displayed");
            callback();
        });
    });


    this.When(/^the user enters an invalid orchestration name$/, function (callback) {
        browser.sleep(2000);
        createOrchestrationPage.searchOrchField().clear();
        createOrchestrationPage.searchOrchField().sendKeys("zzz");
        callback();
    });


    this.Then(/^that orchestration catalog is empty$/, function (callback) {
        browser.sleep(2000);

        expect(createOrchestrationPage.firstOrchName()).to.not.be.true;
        callback();
    });


//DELETING
    this.Then(/^the user clicks on the trash bin icon$/, function (callback) {
        browser.sleep(2000);
        createOrchestrationPage.trashIcon().click().then(function(){
            assert((createOrchestrationPage.deleteModalText()).getText(),"Delete Orchestration");
            callback();
        });

    });

    this.Then(/^a warning message appears and user clicks ok to delete$/, function (callback) {
        browser.sleep(2000);
        createOrchestrationPage.submitModalBtn().click();
            callback();
    });

    this.Then(/^that orchestration is deleted$/, function (callback) {
        browser.sleep(2000);
        createOrchestrationPage.searchOrchField().clear();
        createOrchestrationPage.searchOrchField().sendKeys(createOrchestrationPage.getName());
        expect(createOrchestrationPage.firstOrchName()).to.not.be.true;
        callback();
    });

//DEPLOYMENT TAB
    this.When(/^the user clicks Deployment tab$/, function (callback) {
        browser.sleep(10000);
        TestHelperPO.isElementPresent(createOrchestrationPage.deployment());
        createOrchestrationPage.deployment().click().then(function() {
            browser.sleep(5000);
            TestHelperPO.isElementPresent(createOrchestrationPage.createDeployButton());
            callback();
        });
    });

    this.Then(/^user clicks the new deployment plus sign/, function (callback) {
        TestHelperPO.isElementPresent(createOrchestrationPage.createDeployButton());
        TestHelperPO.elementToBeClickable(createOrchestrationPage.createDeployButton());
        callback();
    });

    this.Then(/^a new Deploy Configuration popup is seen/, function (callback) {
        TestHelperPO.isElementPresent(createOrchestrationPage.newDeploymentPopup());
        TestHelperPO.isElementPresent(createOrchestrationPage.newDeploymentPopupNameField());
        createOrchestrationPage.createRandomDeploymentName();
        createOrchestrationPage.newDeploymentPopupSubmit().click();
        callback();
    });

    this.Then(/^asset selection page is seen/, function (callback) {
        TestHelperPO.isElementPresent(createOrchestrationPage.assetSelectionPage());
        browser.sleep(5000);
        callback();
    });

    this.Then(/^the orchestration tab is clicked/, function (callback) {
        expect(createOrchestrationPage.orchestrationTab()).to.exist;
        createOrchestrationPage.orchestrationTab().click();
        expect(createOrchestrationPage.analyticBox()).to.exist;
        createOrchestrationPage.analyticBox().getText().then(function(value) {
            console.log("Analytic Name is >>" + value);
            callback();
        });
    });
};
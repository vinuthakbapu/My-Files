/********************************************************************************
 * Copyright (c) 2015-2016 GE Digital. All rights reserved.                     *
 *                                                                              *
 * The copyright to the computer software herein is the property of GE Digital. *
 * The software may be used and/or copied only with the written permission of   *
 * GE Digital or in accordance with the terms and conditions stipulated in the  *
 * agreement/contract under which the software has been supplied.               *
 ********************************************************************************/

/**
 * Create Orch spec
 */
module.exports = function() {


    this.When(/^the user is in the orchestration page$/, function(callback){
        browser.sleep(5000).then(function(){
            createOrchestrationPage.verifyOrchestrationTab();
            createOrchestrationPage.clickOrchTab();
            createOrchestrationPage.visibilityOf(createOrchestrationPage.OrchTitle());
            callback();
        });
    });


    this.When(/^the user creates an orchestration$/, function(callback){
        browser.sleep(5000).then(function(){
            createOrchestrationPage.createOrchButton().click().then(function(){
                createOrchestrationPage.createRandomOrchName();
                createOrchestrationPage.createOwner();
                createOrchestrationPage.createDescription();
                createOrchestrationPage.submitButton().isEnabled().then(function (enabled) {
                    expect(enabled).to.equal(true);
                    createOrchestrationPage.submitButton().click();
                    callback();
                });
            });
        });
    });


    this.When(/^the user clicks on plus sign to go to dataflow page$/, function (callback) {
        createOrchestrationPage.visibilityOf(createOrchestrationPage.plusIcon()).then(function(value) {
            createOrchestrationPage.plusIcon().click().then(function(){
                createOrchestrationPage.visibilityOf(orchStepsPage.Applicability());
                callback();
            });
        });
    });


    this.When(/^the user is in the analytic data flow page$/, function(callback){
        orchStepsPage.orchNameDataFlow().getText().then(function(value){
            //console.log("Name is >>" + value);
            assert(value,createOrchestrationPage.getName());
            orchStepsPage.Applicability().getText().then(function(value1) {
                //console.log("Text is >>" + value1);
                assert(value1, "Applicability: GE90");
                orchStepsPage.noAnalyticText().getText().then(function(value2) {
                    console.log("Text is >>" + value2);
                    assert(value2, "Select or drop an available analytic from the list on the right.");
                callback();
                });
            });
        });
    });


    this.Then(/^the first analytic step is added$/, function (callback) {
        orchStepsPage.analyticRightName().get(0).getText().then(function(value) {
            console.log("FirstAnalytic is >>" + value);

            orchStepsPage.analyticListVersion().get(0).getText().then(function(value1) {
                console.log("Version Text is >>" + value1);

            browser.sleep(2000);
           // TestHelperPO.isElementPresent(orchStepsPage.analyticRightPlus());
            //orchStepsPage.analyticRightPlus().get(0).click().then(function(){
            TestHelperPO.elementToBeClickable(orchStepsPage.analyticRightPlus().get(0)).then(function(){
                orchStepsPage.analyticEditorName().get(0).getText().then(function(addedvalue) {
                    console.log("Added analytic in Editor is >>" + addedvalue);
                    assert(addedvalue, value);
                    callback();
                });
                });
            });
        });
    });



    this.Then(/^the analytics displays its version in DataFlow page$/, function(callback){
        createOrchestrationPage.addedAnalyticMainOrch().get(0).click().then(function(){
            orchStepsPage.analyticToolTip().getText().then(function(text){
                console.log("version Text >>" + text);
                createOrchestrationPage.addedAnalyticMainOrch().get(0).click();
                callback();
            });
        });
    });







    this.Then(/^both added analytic steps are verified in Main page$/, function (callback) {
        browser.sleep(10000).then(function(){
            orchStepsPage.analyticEditorName().get(0).getText().then(function (firstEditor) {
                console.log(" First analytic in Editor is >>" + firstEditor);
                orchStepsPage.analyticEditorName().get(1).getText().then(function (secEditor) {
                    console.log(" Second analytic in Editor is >>" + secEditor);
                    orchStepsPage.closeButton().click().then(function () {
                        createOrchestrationPage.addedAnalyticMainOrch().get(0).getText().then(function (mainPageFirst) {
                            console.log("Added analytic in Main Page is >>" + mainPageFirst);
                            assert(firstEditor, mainPageFirst);

                            createOrchestrationPage.addedAnalyticMainOrch().get(1).getText().then(function (mainPageSec) {
                                console.log("Added analytic in Main Page is >>" + mainPageSec);
                                assert(secEditor, mainPageSec);
                                callback();
                            });
                        });
                    });
                });
            });
        });
    });


    this.Then(/^the analytics displays its version in Main page$/, function(callback){
        createOrchestrationPage.addedAnalyticMainOrch().get(0).click().then(function(){
            orchStepsPage.analyticToolTip().getText().then(function(text){
                console.log("version Text >>" + text);
                callback();
            });
        });
    });





    this.When(/^the user clicks on edit sign to go to dataflow page$/, function (callback) {
        createOrchestrationPage.editIcon().click().then(function() {
            orchStepsPage.orchNameDataFlow().isPresent();
            callback();
        });
    });


    this.Then(/^the user inserts analytic in between by clicking plus sign$/, function (callback) {
        //orchStepsPage.analyticEditor().get(0).getText().then(function (first) {
            //console.log("secAnalytic Editor is +++++>>" + first);

        orchStepsPage.analyticEditor().get(0).click().then(function () {
            browser.sleep(5000);
            orchStepsPage.analyticEditor().get(0).click();
            orchStepsPage.analyticRightName().get(1).getText().then(function (value) {
                console.log("SecondAnalytic is >>" + value);
                orchStepsPage.analyticEditor().get(0).click();
                orchStepsPage.analyticRightPlus().get(1).click().then(function () {
                    browser.sleep(15000);
                    expect(orchStepsPage.insertPopupConfirm()).to.exist;
                    orchStepsPage.insertPopupConfirm().getText().then(function (confirm) {
                        console.log("Confirm popup +++++>>" + confirm);
                        browser.sleep(5000);
                        orchStepsPage.insertSubmit().click();
                        browser.sleep(5000);

                        orchStepsPage.analyticEditor().get(1).getText().then(function (sec) {
                            console.log("inserted second Analytic in Editor is +++++>>" + sec);

                            assert(value, sec);
                            callback();
                        });
                    });
                });
            });
        });
    });


    this.Then(/^the dataflow page is closed$/, function(callback){
        orchStepsPage.closeButton().click();
        callback();
    });


    this.When(/^the user inserts analytic by drag and drop$/, function (callback) {
        orchStepsPage.analyticEditor().get(0).click().then(function () {
            browser.sleep(10000).then(function(){
                orchStepsPage.analyticEditor().get(0).click();
                console.log('________Dragging ');
                TestHelperPO.elementToBeClickable(orchStepsPage.analyticToDrag().get(2)).then(function () {

                    browser.sleep(4000).then(function () {
                        TestHelperPO.elementToBeClickable(orchStepsPage.analyticToDrag().get(2)).then(function () {
                            console.log("Element clicked");
                            var ele = orchStepsPage.analyticToDrag().get(2);
                            var drop = orchStepsPage.editorToDrop();
                            console.log("Elements found");
                            orchStepsPage.analyticEditor().get(0).click();
                            TestHelperPO.dragAndDrop(ele, drop).then(function () {
                                console.log("Element dragged");
                                browser.sleep(14000);
                                expect(orchStepsPage.insertPopupConfirm()).to.exist;
                                orchStepsPage.insertPopupConfirm().getText().then(function (confirm) {
                                    console.log("Confirm popup +++++>>" + confirm);
                                    browser.sleep(5000);
                                    orchStepsPage.insertSubmit().click();
                                    browser.sleep(5000);
                                    orchStepsPage.analyticRightName().get(2).getText().then(function(third) {
                                        console.log("SecondAnalytic is >>" + third);
                                        orchStepsPage.analyticEditorName().get(1).getText().then(function (secEditor) {
                                            console.log(
                                                " Second analytic in Editor is >>"
                                                + secEditor);
                                            assert(third, secEditor);
                                            callback();
                                        });
                                    });
                                });
                            });
                        });
                    });
                });
            });
        });

    });


    this.Then(/^the added analytic step is verified in Main page$/, function (callback) {
        browser.sleep(10000).then(function(){
            orchStepsPage.analyticEditorName().get(0).getText().then(function (firstEditor) {
                console.log(" First analytic in Editor is >>" + firstEditor);
                orchStepsPage.analyticEditorName().get(1).getText().then(function (secEditor) {
                    console.log(" Second analytic in Editor is >>" + secEditor);
                    orchStepsPage.analyticEditorName().get(2).getText().then(function (thirdEditor) {
                        console.log(" Second analytic in Editor is >>" + thirdEditor);
                        orchStepsPage.closeButton().click().then(function () {
                            createOrchestrationPage.addedAnalyticMainOrch().get(0).getText().then(function (mainPageFirst) {
                                console.log("Added analytic in Main Page is >>" + mainPageFirst);
                                assert(firstEditor, mainPageFirst);

                                createOrchestrationPage.addedAnalyticMainOrch().get(1).getText().then(function (mainPageSec) {
                                    console.log("Added analytic in Main Page is >>" + mainPageSec);
                                    assert(secEditor, mainPageSec);

                                    createOrchestrationPage.addedAnalyticMainOrch().get(2).getText().then(function (mainPageThird) {
                                        console.log("Added analytic in Main Page is >>" + mainPageThird);
                                        //assert(thirdEditor, mainPageThird);
                                        callback();
                                    });
                                });
                            });
                        });
                    });
                });
            });
        });
    });

    this.Then(/^the first analytic step is deleted$/, function (callback) {

        browser.sleep(10000);
        browser.actions().mouseMove(orchStepsPage.analyticEditor().get(0)).perform().then(function(){
            browser.sleep(5000);
            expect(orchStepsPage.hoverOver()).to.exist;
            browser.sleep(5000);
            orchStepsPage.closeIcon().get(0).click();
            browser.sleep(1000);
            console.log("here deleting>>>>>>>>>>");
            expect(orchStepsPage.deletePopupConfirm()).to.exist;
            orchStepsPage.deleteRemove().click().then(function(){
                callback();
            });
        });
    });


    this.Then(/^the second analytic step is deleted$/, function (callback) {

        browser.sleep(10000);
        browser.actions().mouseMove(orchStepsPage.analyticEditor().get(1)).perform().then(function(){

            browser.sleep(5000);
            expect(orchStepsPage.hoverOver()).to.exist;
            browser.sleep(5000);
            orchStepsPage.closeIcon().get(1).click();
            browser.sleep(1000);
            console.log("here deleting>>>>>>>>>>");
            expect(orchStepsPage.deletePopupConfirm()).to.exist;
            orchStepsPage.deleteRemove().click().then(function(){
                callback();
            });
        });
    });

    this.Then(/^the second analytic step is added by drag and drop$/, function (callback) {
        browser.sleep(10000).then(function(){

            console.log('________Dragging ');

            TestHelperPO.elementToBeClickable(orchStepsPage.analyticToDrag().get(2)).then(function () {

                browser.sleep(4000).then(function () {
                    TestHelperPO.elementToBeClickable(orchStepsPage.analyticToDrag().get(2)).then(function () {
                        console.log("Element clicked");
                        var ele = orchStepsPage.analyticToDrag().get(2);
                        var drop = orchStepsPage.editorToDrop();
                        console.log("Elements found");

                        TestHelperPO.dragAndDrop(ele, drop).then(function () {
                            console.log("Element dragged");
                            browser.sleep(14000);

                            orchStepsPage.analyticRightName().get(2).getText().then(function(third) {
                                console.log("ThirdAnalytic is >>" + third);
                                orchStepsPage.analyticEditorName().get(1).getText().then(function (secEditor) {
                                    console.log(" Second analytic in Editor is and Third in list >>" + secEditor);
                                    assert(third, secEditor);

                                    callback();
                                });
                            });

                        });
                    });
                });
            });
        });
    });

    this.Then(/^the user searches for analytic$/, function (callback) {
        TestHelperPO.isElementPresent(orchStepsPage.analyticSearch());
        orchStepsPage.analyticEnterName();
        callback();

    });


    this.Then(/^the search field is cleared$/, function (callback) {
        TestHelperPO.isElementPresent(orchStepsPage.stepsClearedSearch());
        orchStepsPage.stepsClearedSearch().click().then(function(){
            callback();
        });
    });
    

    this.When(/^the cafUser clicks the delete button in orchestration$/, function(callback) {
        orchStepsPage.deleteIcon().click().then(function() {
            callback();
        });
    });

    this.When(/^the cafUser clicks the delete button in the orchestration modal$/,function(callback) {
        orchStepsPage.deleteRemove().click().then(function() {
            callback();
        });
    });

    this.When(/^cafUser clicks on the orchestration radio button$/,function(callback) {
        orchStepsPage.orchRadioButton().click().then(function() {
            callback();
        });
    });

  this.Then(/^a text box is displayed to enter the caf orchestration name$/, function (callback) {
    cafDeploymentPage.analyticName().isDisplayed().then(function(visible){
      expect(visible).to.equal(true);
      callback();
    });
  });

  this.When(/^cafUser enters the random orchestration name$/, function (callback) {
    cafDeploymentPage.analyticName().sendKeys(createOrchestrationPage.getName()).then (function(){
      callback();
    });
  });

    this.When(/^cafUser enters the created orchestration name$/, function (callback) {
        cafDeploymentPage.analyticName().sendKeys(createOrchestrationPage.getName()).then (function(){
            callback();
        });
    });

  this.When(/^the cafUser search for the orchestration$/, function(callback) {
    cafCreateAnalyticPage.clickSearchBox().then(function() {
      cafCreateAnalyticPage.enterSearchText(createOrchestrationPage.getName()).then(function () {
        console.log("searching for the analytic");
        callback();
      });
    });
  });


};
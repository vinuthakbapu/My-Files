module.exports = function () {

    var dropDownValue;
    var deploymentName;
    var currentTagTreePage = 'tagTreePage';
    var analyticName;

    this.Given(/^the cafUser is logged in$/, function (callback) {

        let baseurl = browser.params.login.baseUrl;
        let userName = browser.params.login.mgrusername;
        let password = browser.params.login.mgrpassword;

        loginPage.getLogin(baseurl).then(function (completed) {
            browser.ignoreSynchronization = true;
            assert.isTrue(completed, 'Not login page');
            console.log(baseurl);
            console.log(userName);
            console.log(password);
            loginPage.setName(userName).then(function () {
                loginPage.setPassword(password).then(function () {
                    loginPage.clickLogin().then(function () {

                        // loginPage.checkHomePage().then(function (completed) {
                        //     assert.isTrue(completed, 'Not logged in');
                        callback();
                        // });
                    });
                });
            });
        });
    });

    this.Then(/^the cafUser should see the analytics in left navigation$/, function (callback) {
        browser.sleep(2000).then(function () {
            cafCreateAnalyticPage.verifyCreateAnalyticsTab().then(function (value) {
                expect(value).contains('Analytics');
                callback();
            });
        });
    });

    this.When(/^the cafUser clicks on Analytics microapp$/, function (callback) {
        cafCreateAnalyticPage.clickAnalyticTab().then(function () {
            browser.sleep(3000).then(function () {
                callback();
            });
        });
    });

    this.When(/^the CafUser clicks on Analytics main menu from left navigation$/, function (callback) {
        cafCreateAnalyticPage.clickAnalyticsMainLink().then(function () {
            callback();
        });
    });

    this.When(/^the cafUser clicks the first deployment row$/, function (callback) {
        cafCreateAnalyticPage.clickFirstDeploymentRow().then(function () {
            callback();
        });
    });

    this.Then( /^I should see total "([^"]*)" rows added to the alerts table$/, function (num, callback) {
        cafCreateAnalyticPage.getSpecificRowCount().then(function(count){
            expect(count).to.equal(num*1);
            callback();
        }) ;
    });

    this.When(/^the cafUser clicks on Orchestrations microapp$/, function (callback) {
        cafCreateAnalyticPage.clickOrchestrations().then(function () {
            callback();
        });
    });

    this.When(/^cafUser enters the singleStepDeployment as analytic name$/, function(callback) {
        cafCreateAnalyticPage.analyticName().sendKeys('Mock_orch').then(function () {
            callback();
        });
    });

    this.When(/^cafUser enters the multiStepDeployment as analytic name$/, function(callback) {
        cafCreateAnalyticPage.analyticName().sendKeys('Mock_multi').then(function () {
            callback();
        });
    });

    this.When(/^the cafUser verifies first alert template status is disabled in deployment page$/, function (callback) {
        cafCreateAnalyticPage.isFirstAlertTemplateDisabled().then(function () {
            callback();
        });
    });

    this.When(/^the cafUser verifies second alert template status is disabled in deployment page$/, function (callback) {
        cafCreateAnalyticPage.isSecondAlertTemplateDisabled().then(function () {
            callback();
        });
    });

    this.When(/^the cafUser verifies first alert template status is enabled in deployment page$/, function (callback) {
        cafCreateAnalyticPage.isFirstAlertTemplateEnabled().then(function () {
            callback();
        });
    });

    this.When(/^the cafUser verifies second alert template status is enabled in deployment page$/, function (callback) {
        cafCreateAnalyticPage.isSecondAlertTemplateEnabled().then(function () {
            callback();
        });
    });

    this.When(/^the cafUser changes first alert template status in deployment page$/, function (callback) {
        cafCreateAnalyticPage.changeFirstAlertTemplateStatus().then(function () {
            callback();
        });
    });

    this.When(/^the cafUser changes second alert template status in deployment page$/, function (callback) {
        cafCreateAnalyticPage.changeSecondAlertTemplateStatus().then(function () {
            callback();
        });
    });

    this.When(/^the cafUser clicks on next Iteration$/, function (callback) {
        cafCreateAnalyticPage.clickForNextIteration().then(function () {
            callback();
        });
    });

    this.When(/^the cafUser clicks on input data point$/, function (callback) {
        cafCreateAnalyticPage.clickInputDataPoint().then(function () {
            callback();
        });
    });

    this.When(/^User search and click for the caf template$/, function (callback) {
        cafCreateAnalyticPage.enterSearchText(analyticName).then(function () {
            cafCreateAnalyticPage.firstAnalytic().then(function () {
                        callback();

            })
        });
    });

    this.When(/^User deletes the analytic$/, function (callback) {
                cafCreateAnalyticPage.clickDeleteButton().then(function () {
                    cafCreateAnalyticPage.clickDeleteButtonInModal().then(function () {
                        callback();
                    })
                })
    });

    this.When(/^the cafUser clicks on Analytics Templates microapp$/, function (callback) {
        cafCreateAnalyticPage.clickAnalyticCatalogTab().then(function () {
            console.log("here..");
            callback();
        });
    });

    this.When(/^the cafUser clicks on Analytics templates$/, function (callback) {
        cafCreateAnalyticPage.clickAnalyticTemplatesTab().then(function () {
            callback();
        });
    });

    this.When(/^the cafUser clicks on deployments tab$/, function (callback) {
        cafCreateAnalyticPage.clickDeploymentsTab().then(function () {
            callback();
        });
    });

    this.When(/^the cafUser clicks on Configuration microapp$/, function (callback) {
        cafCreateAnalyticPage.clickConfigurationTab().then(function () {
            callback();
        });
    });

    this.When(/^the cafUser clicks on dashboard tab$/, function (callback) {
        cafCreateAnalyticPage.clickDashboardTab().then(function () {
            callback();
        });
    });

    this.Then(/^the cafUser should see the Configuration in left navigation$/, function (callback) {
        cafCreateAnalyticPage.isConfigurationLinkAvailable().then(function (bool) {
            assert.equal(bool, true, "Configuration link is not displayed");
            callback();
        });
    });

    this.Then(/^the cafUser should not see the Configuration in left navigation$/, function (callback) {
        cafCreateAnalyticPage.isConfigurationLinkNotAvailable().then(function (bool) {
            assert.equal(bool, false, "Configuration link is displayed");
            callback();
        });
    });

    this.Then(/^the cafUser should see the analytics dashboard page$/, function (callback) {
        cafCreateAnalyticPage.visibilityOf(cafCreateAnalyticPage.getDashboardPage()).then(function (value) {
            expect(value).to.be.true;
            callback();
        });
    });

    this.Then(/^the user should see the Header Analytics Templates$/, function (callback) {
        cafCreateAnalyticPage.visibilityOf(cafCreateAnalyticPage.getAnalyticTemplatesPage()).then(function (value) {
            expect(value).to.be.true;
            callback();
        });
    });

    this.Then(/^list of analytics should be displayed in the catalog$/, function (callback) {
        cafCreateAnalyticPage.visibilityOf(cafCreateAnalyticPage.analyticsList()).then(function (value) {
            expect(value).to.be.true;
            callback();
        });
    });

    this.Then(/^the version popup should be displayed$/, function (callback) {
        cafCreateAnalyticPage.visibilityOf(cafCreateAnalyticPage.versionPopUp()).then(function (value) {
            expect(value).to.be.true;
            callback();
        });
    });

    this.Then(/^the list of all versions should be displayed$/, function (callback) {
        cafCreateAnalyticPage.allVersionsList().count().then(function (value) {
            expect(value).to.equal(2);
            callback();
        });
    });

    this.Then(/^I click on the make current button$/, function (callback) {
        cafCreateAnalyticPage.clickMakeCurrentButton().then(function () {
            browser.sleep(10000).then(function () {
                callback();
            });
        });
    });

    this.Then(/^a delete confirmation popup should be displayed$/, function (callback) {
        cafCreateAnalyticPage.visibilityOf(cafCreateAnalyticPage.deleteConfirmationPopup()).then(function (value) {
            expect(value).to.be.true;
            callback();
        });
    });

    this.Then(/^the cafUser should see the deployments landing page$/, function (callback) {
        cafCreateAnalyticPage.visibilityOf(cafCreateAnalyticPage.getLandingPage()).then(function (value) {
            expect(value).to.be.true;
            callback();
        });
    });

    this.Given(/^the cafUser clicks on the analytics Templates microapp$/, function (callback) {
        browser.waitForAngular()
        cafCreateAnalyticPage.clickAnalyticTemplatesTab().then(function () {
            callback();
        });
    });

    this.Given(/^the cafUser clicks go to analytic catalog page$/, function (callback) {
        cafCreateAnalyticPage.clickAnalyticCcatalogTab().then(function () {
            callback();
        });
    });

    this.Then(/^the cafUser clicks go to orchestration subpage$/, function (callback) {
        cafCreateAnalyticPage.clickOrchestrations().then(function () {
            callback();
        });
    });

    this.Then(/^the cafUser should see the analytics button$/, function (callback) {
        cafCreateAnalyticPage.visibilityOf(cafCreateAnalyticPage.createAnalyticsButton()).then(function (value) {
            expect(value).to.be.true;
            callback();
        });
    });

    this.When(/^the cafUser clicks on create analytic icon/, function (callback) {
        cafCreateAnalyticPage.createAnalyticIcon().click().then(function () {
            callback();
        });
    });

    this.Then(/^the cafUser should see the fields to create analytic$/, function (callback) {
        expect(cafCreateAnalyticPage.AnalyticName()).to.exist;
        expect(cafCreateAnalyticPage.AnalyticOwner()).to.exist;
        expect(cafCreateAnalyticPage.createAnalyticType()).to.exist;
        expect(cafCreateAnalyticPage.AnalyticVersionInput()).to.exist;
        expect(cafCreateAnalyticPage.createAnalyticPrimaryCategory()).to.exist;
        expect(cafCreateAnalyticPage.createAnalyticSecondaryCategory()).to.exist;
        expect(cafCreateAnalyticPage.createAnalyticSubmit()).to.exist;
        // expect(cafCreateAnalyticPage.createAnalyticSubmit().isEnabled()).to.not.true;
        callback();
    });

    this.When(/^the runtime type dropdown contains the required options$/, function (callback) {
        var expectedOptions = ['Runtime Type', 'Predix', 'SmartSignal'];
        var actualOptions = [];
        cafCreateAnalyticPage.getRunTimeTypeDropdownOptions().then(function (options) {
            console.log("options type" + options.type);
            console.log("options" + options);
            var step = function (i, done) {
                if (i < done) {
                    options[i].getText().then(function (text) {
                        actualOptions[i] = text;
                        step(i + 1, done)
                    });
                }
                else {
                    console.log("actualOptions " + actualOptions);
                    TestHelper.assertEqual(JSON.stringify(actualOptions), JSON.stringify(expectedOptions));
                    callback();
                }

            };
            step(0, options.length);
        });
    });

    this.Then(/^the runtime type dropdown default selected value is "([^"]*)"$/, function (arg1, callback) {
        cafCreateAnalyticPage.getRunTimeTypeDropdownDefaultValue(arg1).then(function (value) {
            expect(value).to.be.true;
            callback();
        });

    });

    this.When(/^cafUser click the Runtime Type dropdown$/, function (callback) {
        expect(cafCreateAnalyticPage.clickRunTimeTypeDropdown()).to.exist;
        cafCreateAnalyticPage.clickRunTimeTypeDropdown().then(function () {
            callback();
        });
    });


    this.When(/^cafUser click the Data Frame Type dropdown$/, function (callback) {
        cafCreateAnalyticPage.clickDataFrameTypeDropdown().then(function () {
            console.log("clicked Data Frame Type Dropdown")
            callback();
        });
    });

    this.When(/^cafUser select "([^"]*)" from the Runtime type options$/, function (arg1, callback) {
        cafCreateAnalyticPage.selectRuntimeType(arg1).then(function () {
            callback();
        });
    });

    this.When(/^cafUser select "([^"]*)" from the Data Frame type options$/, function (arg1, callback) {
        cafCreateAnalyticPage.selectDataFrameType(arg1).then(function () {
            console.log("selected data frame type option")
            browser.sleep(1000);
            callback();
        });
    });

    this.When(/^cafUser enters the sample orchestration template name in search criteria$/, function(callback) {
        cafCreateAnalyticPage.analyticName().sendKeys('Test_Marri').then(function () {
            browser.sleep(2000);
            callback();
        });
    });
    this.When(/^cafUser enters the sample deployment template name in search criteria$/, function(callback) {
        cafCreateAnalyticPage.analyticName().sendKeys('Test_Marri').then(function () {
            browser.sleep(2000);
            callback();
        });
    });
    this.When(/^cafUser enters the sample AssetFilters template name in search criteria$/, function(callback) {
        cafCreateAnalyticPage.analyticName().sendKeys('Test_Marri').then(function () {
            browser.sleep(2000);
            callback();
        });
    });

    this.When(/^cafUser enters the sample analytics template name in search criteria$/, function(callback) {
        cafCreateAnalyticPage.analyticName().sendKeys('Test_Marri').then(function () {
            browser.sleep(2000);
            callback();
        });
    });
    this.When(/^cafUser clicks the first analytic template filtered result$/, function (callback) {
        cafCreateAnalyticPage.analyticResult().click().then (function(){
            browser.sleep(10000).then(function () {
                callback();
            });
        });
    });

    this.Then(/^cafUser should not see the make current button$/, function (callback) {
        cafCreateAnalyticPage.MakeCurrentButtondisabled().then(function(boolean) {
            assert.equal(boolean, false, "make current button is displayed");
            browser.sleep(2000);
            callback();
        });
    });


    this.When(/^cafUser clicks the first deployment template filtered result$/, function (callback) {
        cafCreateAnalyticPage.deployementResult().click().then (function(){
            browser.sleep(10000).then(function () {
                callback();
            });
        });
    });



    this.When(/^cafUser clicks the first orchestration template filtered result$/, function (callback) {
        cafCreateAnalyticPage.orchestrationResult().click().then (function(){
            browser.sleep(10000).then(function () {
                callback();
            });
        });
    });

    this.When(/^cafUser clicks the first asset filters template filtered result$/, function (callback) {
        cafCreateAnalyticPage.assetfiltersResult().click().then (function(){
            browser.sleep(10000).then(function () {
                callback();
            });
        });
    });

    this.When(/^the cafUser clicks on orchestrations microapp$/, function (callback) {
        cafCreateAnalyticPage.clickOrchestrations().then(function () {
            callback();
        });
    });
    this.Then(/^an edit icon should not displayed next to date in caf analytic$/, function (callback) {
        cafCreateAnalyticPage.isEditIconNotDisplayed().then(function (bool) {
            assert.equal(bool, false, "edit icon is displayed");
            callback();
        });
    });
    this.Then(/^the delete button should not be displayed in caf analytic$/, function (callback) {
        cafCreateAnalyticPage.isDeleteButtonNotDisplayed().then(function (bool) {
            assert.equal(bool, false, "Delete icon is displayed");
            callback();
        });
    });
    this.When(/^the cafUser clicks on deployments microapp$/, function (callback) {
        cafCreateAnalyticPage.clickDeploymentsTab().then(function () {
            callback();
        });
    });
    this.Then(/^an edit icon is displayed next to date in deployment$/, function (callback) {
        cafCreateAnalyticPage.isDeploymentEditIconDisplayed().then(function (bool) {
            assert.equal(bool, true, "edit icon is not displayed");
            callback();
        });
    });
    this.Then(/^the delete button should be displayed in deployment$/, function (callback) {
        cafCreateAnalyticPage.isDeploymentDeleteButtonDisplayed().then(function (bool) {
            assert.equal(bool, true, "edit icon is not displayed");
            callback();
        });
    });
    this.Then(/^an edit icon should not displayed next to date in deployment$/, function (callback) {
        cafCreateAnalyticPage.isDeploymentEditIconNotDisplayed().then(function (bool) {
            assert.equal(bool, false, "edit icon is displayed");
            callback();
        });
    });
    this.Then(/^the delete button should not be displayed in deployment$/, function (callback) {
        cafCreateAnalyticPage.isDeploymentDeleteButtonNotDisplayed().then(function (bool) {
            assert.equal(bool, false, "edit icon is displayed");
            callback();
        });
    });

    this.Then(/^the cafUser should see the Analytics Template in left navigation$/, function (callback) {
        cafCreateAnalyticPage.isAnalyticsLinkAvailable().then(function (bool) {
            assert.equal(bool, true, "Analytics link is not displayed");
            callback();
        });
    });

    this.Then(/^the cafUser should not see the Analytics Template in left navigation$/, function (callback) {
        cafCreateAnalyticPage.isAnalyticsLinkNotAvailable().then(function (bool) {
            assert.equal(bool, false, "Analytics link is displayed");
            callback();
        });
    });

    this.When(/^cafUser unselect the Runtime type options$/, function (callback) {
        cafCreateAnalyticPage.unselectRuntimeType().then(function () {
            callback();
        });
    });

    this.Then(/^a red border should be around the Runtime Type dropdown$/, function (callback) {
        cafCreateAnalyticPage.getCSSValueRunTimeType().then(function (cssValue) {
            TestHelper.assertEqual(cssValue, "1px solid rgb(229, 56, 56)");
            callback();
        });
    });

    this.Then(/^the red border should disappear from the Runtime Type dropdown$/, function (callback) {
        cafCreateAnalyticPage.getCSSValueRunTimeType().then(function (cssValue) {
            TestHelper.assertEqual(cssValue, "1px solid rgb(177, 177, 188)");
            callback();
        });
    });

    this.Then(/^cafUser enter template name as "([^"]*)" in the name field$/, function (arg1, callback) {
        analyticName = arg1 + TestHelperPO.getRandomString().substring(3);
        console.log("random analytic Name is " + analyticName);
        cafCreateAnalyticPage.enterName(analyticName).then(function () {
            callback();
        })
    });

    this.Then(/^the user searches for the created analytic$/, function (callback) {
        TestHelperPO.isElementPresent(orchStepsPage.analyticSearch());
        orchStepsPage.analyticEnterName(analyticName);
        callback();

    });

    this.When(/^cafUser enter the value "([^"]*)" in the owner field$/, function (arg1, callback) {
        cafCreateAnalyticPage.enterOwner(arg1).then(function () {
            callback();
        })
    });

    this.Given(/^the name field is displayed on the creation form$/, function (callback) {
        cafCreateAnalyticPage.isNameVisible().then(function (boolean) {
            TestHelper.assertTrue(boolean, callback);
            callback();
        })
    });

    this.Then(/^the name field should have texts "([^"]*)"$/, function (arg1, callback) {
        cafCreateAnalyticPage.getNameDefaultText().then(function (text) {
            TestHelper.assertEqual(text, arg1);
            callback();
        })
    });

    this.Given(/^the owner field is displayed on the creation form$/, function (callback) {
        cafCreateAnalyticPage.isOwnerVisible().then(function (boolean) {
            TestHelper.assertTrue(boolean, callback);
            callback();
        })
    });

    this.Then(/^the owner field should have texts "([^"]*)"$/, function (arg1, callback) {
        cafCreateAnalyticPage.getOwnerDefaultText().then(function (text) {
            TestHelper.assertEqual(text, arg1);
            callback();
        })

    });

    this.Then(/^the Analytic type dropdown should have the required options$/, function (callback) {
        var expectedOptions = ['Java', 'MatLab', 'Python'];
        var actualOptions = [];
        cafCreateAnalyticPage.getAnalyticTypeDropdownOptions().then(function (options) {
            var step = function (i, done) {
                if (i < done) {
                    options[i].getText().then(function (text) {
                        actualOptions[i] = text;
                        step(i + 1, done)
                    });
                }
                else {
                    TestHelper.assertEqual(JSON.stringify(actualOptions), JSON.stringify(expectedOptions));
                    callback();
                }
            };
            step(0, options.length);
        });
    });

    this.Then(/^the default value for Analytic type dropdown is "([^"]*)"$/, function (arg1, callback) {
        cafCreateAnalyticPage.getAnalyticTypeDropdownDefaultValue().then(function (value) {
            assert.equal(value, arg1, "default selected value is not Analytic Type");
            callback();
        });

    });

    this.When(/^cafUser unselect the Analytic Type dropdown$/, function (callback) {
        cafCreateAnalyticPage.unselectAnalyticType().then(function () {
            callback();
        });
    });

    this.Then(/^the Analytic Type dropdown should have a red border$/, function (callback) {
        cafCreateAnalyticPage.getCSSValueAnalyticType().then(function (cssValue) {
            TestHelper.assertEqual(cssValue, "1px solid rgb(229, 56, 56)");
            callback();
        });
    });

    this.Then(/^the Analytic Type dropdown should not have a red border$/, function (callback) {
        cafCreateAnalyticPage.getCSSValueAnalyticType().then(function (cssValue) {
            TestHelper.assertEqual(cssValue, "1px solid rgb(177, 177, 188)");
            callback();
        });
    });

    this.When(/^cafUser enter the value "([^"]*)" in the analytic version field$/, function (arg1, callback) {
        cafCreateAnalyticPage.enterAnalyticVersion(arg1).then(function () {
            callback();
        })
    });

    this.When(/^cafUser click the Analytic Type dropdown$/, function (callback) {
        cafCreateAnalyticPage.clickAnalyticTypeDropdown().then(function () {
            console.log("clicked Analytic Type Dropdown")
            callback();
        });
    });

    this.When(/^cafUser select "([^"]*)" from the Analytic type options$/, function (dropDownOption, callback) {
        cafCreateAnalyticPage.selectAnalyticType(dropDownOption).then(function () {
            browser.sleep(1000);
            callback();
        });
    });

    this.When(/^cafUser click the Type Version dropdown$/, function (callback) {
        cafCreateAnalyticPage.clickTypeVersionDropdown().then(function () {
            browser.sleep(1000);
            callback();
        });
    });

    this.Then(/^the default value for Type Version dropdown is "([^"]*)"$/, function (arg1, callback) {
        cafCreateAnalyticPage.getTypeVersionDropdownDefaultValue().then(function (value) {
            assert.equal(value, arg1, "default selected value is not select version");
            callback();
        });

    });


    this.When(/^cafUser select "([^"]*)" from the Type Version options$/, function (arg1, callback) {
        cafCreateAnalyticPage.selectTypeVersion(arg1).then(function () {
            callback();
        });
    });

    this.When(/^cafUser click the Primary Category dropdown$/, function (callback) {
        cafCreateAnalyticPage.clickPrimaryCategoryDropdown().then(function () {
            callback();
        });
    });

    this.Then(/^the default value for Primary Category dropdown is "([^"]*)"$/, function (arg1, callback) {
        cafCreateAnalyticPage.getPrimaryCategoryDropdownDefaultValue().then(function (value) {
            assert.equal(value, arg1, "default selected value is not Analytic Type");
            callback();
        });
    });

    this.When(/^cafUser select the option "([^"]*)" in Primary Category dropdown$/, function (arg1, callback) {
        cafCreateAnalyticPage.selectPrimaryCategory(arg1).then(function () {
            callback();
        });
    });

    this.When(/^cafUser click the upload icon in the Analytic field$/, function (callback) {
        cafCreateAnalyticPage.clickUploadIcon().then(function () {
            callback();
        });
    });

    this.When(/^cafUser select the Jar file$/, function (callback) {
        var path = require('path');
        var filePath = './../TestData/thresholdAnalytic-java.jar';
        console.log("file path " + filePath);
        var absolutePath = path.resolve(__dirname, filePath);
        console.log("absolute path " + absolutePath);
        cafCreateAnalyticPage.selectJarFile(absolutePath);
        callback();
    });


    this.When(/^cafUser select the Renewable Jar file$/, function (callback) {
        var path = require('path');
        var filePath = './../TestData/RW_Tests-1.0.0.jar';
        console.log("file path " + filePath);
        var absolutePath = path.resolve(__dirname, filePath);
        console.log("absolute path " + absolutePath);
        cafCreateAnalyticPage.selectJarFile(absolutePath);
        callback();
    });

    this.When(/^I upload the analytic file values from file "([^"]*)"$/, function (arg1, callback) {
        var filePath = './../TestData/' + arg1;
        var path = require('path');
        console.log("file path " + filePath);
        var absolutePath = path.resolve(__dirname, filePath);
        console.log("absolute path " + absolutePath);
        cafCreateAnalyticPage.selectJarFile(absolutePath);
        callback();

    });

    this.When(/^cafUser select Java Analytic zip file$/, function (callback) {
        var path = require('path');
        var filePath = './../TestData/simple_java_version2.zip';
        console.log("file path " + filePath);
        var absolutePath = path.resolve(__dirname, filePath);
        console.log("absolute path " + absolutePath);
        cafCreateAnalyticPage.selectJarFile(absolutePath);
        callback();
    });

    this.When(/^cafUser select Python Analytic zip file$/, function (callback) {
        var path = require('path');
        var filePath = './../TestData/simple_python_version3.zip';
        console.log("file path " + filePath);
        var absolutePath = path.resolve(__dirname, filePath);
        console.log("absolute path " + absolutePath);
        cafCreateAnalyticPage.selectJarFile(absolutePath);
        callback();
    });

    this.When(/^cafUser select Python Analytic for raw data zip file$/, function (callback) {
        var path = require('path');
        var filePath = './../TestData/python-timeseries.zip';
        console.log("file path " + filePath);
        var absolutePath = path.resolve(__dirname, filePath);
        console.log("absolute path " + absolutePath);
        cafCreateAnalyticPage.selectJarFile(absolutePath);
        callback();
    });

    this.When(/^cafUser select Alerts Analytic zip file$/, function (callback) {
        var path = require('path');
        var filePath = './../TestData/AlarmJob.zip';
        console.log("file path " + filePath);
        var absolutePath = path.resolve(__dirname, filePath);
        console.log("absolute path " + absolutePath);
        cafCreateAnalyticPage.selectJarFile(absolutePath);
        callback();
    });

    this.Then(/^the submit button on the page should be disabled$/, function (callback) {
        cafCreateAnalyticPage.isSubmitEnabled().then(function (boolean) {
            TestHelper.assertEqual(boolean, "false");
            callback();
        })
    });

    this.Then(/^the submit button on the page should be enabled$/, function (callback) {
        cafCreateAnalyticPage.isSubmitEnabled().then(function (boolean) {
            console.log(boolean);
            TestHelper.assertEqual(boolean, "true");
            callback();
        })
    });

    this.When(/^cafUser click the submit button$/, function (callback) {
        cafCreateAnalyticPage.clickSubmit().then(function () {
            // cafCreateAnalyticPage.waitForSpinnerToDisappear().then(function () {
            //   callback();
            // });
            browser.sleep(20000).then(function () {
                callback();
            });
        });
    });

    this.Then(/^user take "([^"]*)" milliseconds break$/, function (arg1, callback) {
        browser.sleep(parseInt(arg1)).then(function () {
            callback();
        });
    });

    this.Then(/^a new analytic should be created$/, function (callback) {
        browser.waitForAngular();
        cafCreateAnalyticPage.getCreatedAnalytic().then(function (name) {
            browser.params.analyticName = name;
            analyticName = name;
            TestHelper.assertEqual(name, analyticName);
            callback();
        });
    });

    this.Then(/^the smart signal analytic should be created$/, function (callback) {
        browser.sleep(20000).then(function () {
            cafCreateAnalyticPage.getAnalyticRuntime().then(function (runtime) {
                console.log("this is the runtime", runtime);
                TestHelper.assertEqual(runtime, 'SmartSignal');
                callback();
            });
        });

    });

    this.Then(/^the smart signal analytic should have a new version$/, function (callback) {
        cafCreateAnalyticPage.currentAnalyticVersion().then(function (version) {
            TestHelper.assertEqual(version, "1.0.1");
            callback();
        });
    });

    this.Then(/^template name is displayed in the textbox$/, function (callback) {
        cafDeploymentPage.analyticName().getAttribute('placeholder').then(function (name) {
            expect(name).to.equal(browser.params.analyticName);
            callback();
        });
    });

    this.When(/^cafUser enters the random analytic name$/, function (callback) {
        cafDeploymentPage.analyticName().sendKeys(analyticName).then(function () {
            callback();
        });
    });

    this.Given(/^the Type Version dropdown is presented/, function (callback) {
        cafCreateAnalyticPage.isVersionDropdownVisible().then(function (boolean) {
            console.log(boolean);
            TestHelper.assertTrue(boolean, callback);
            callback();
        })
    });

    this.Then(/^the Type Version dropdown should have the required options$/, function (callback) {
        var expectedOptions;
        if (dropDownValue == "Java") {
            expectedOptions = ["Select Version", "1.8"];
        } else if (dropDownValue == "MatLab") {
            expectedOptions = ["Select Version", "r2011b", "r2011a"];
        } else if (dropDownValue == "Python") {
            expectedOptions = ["Select Version", "2.7"];
        }

        var actualOptions = [];
        cafCreateAnalyticPage.getTypeVersionDropdownOptions().then(function (options) {

            var step = function (i, done) {
                if (i < done) {
                    options[i].getText().then(function (text) {
                        actualOptions[i] = text;
                        step(i + 1, done)
                    });
                }
                else {
                    TestHelper.assertEqual(JSON.stringify(actualOptions), JSON.stringify(expectedOptions));
                    callback();
                }
            };
            step(0, options.length);
        });
    });

    this.Given(/^the Analytic file upload field is presented$/, function (callback) {
        cafCreateAnalyticPage.isAnalyticFileUploadVisible().then(function (boolean) {
            TestHelper.assertTrue(boolean, callback);
            callback();
        })
    });

    this.Then(/^the upload icon is presented$/, function (callback) {
        cafCreateAnalyticPage.isUploadIconVisible().then(function (boolean) {
            TestHelper.assertTrue(boolean, callback);
            callback();
        })
    });

    this.Then(/^the Analytic file upload field should contain the text "([^"]*)"$/, function (arg1, callback) {
        cafCreateAnalyticPage.getAnalyticFileUploadFieldDefaultText().then(function (text) {
            TestHelper.assertEqual(text, arg1);
            callback();
        })
    });

    this.Given(/^the Primary Category dropdown is presented$/, function (callback) {
        cafCreateAnalyticPage.isPrimaryCategoryVisible().then(function (boolean) {
            TestHelper.assertTrue(boolean, callback);
            callback();
        })
    });


    this.Then(/^the Primary Category dropdown should have the required options$/, function (callback) {
        var expectedOptions = ["Primary Category", "KPI", "Monitoring", "Health Assessment", "Forecasting", "Prognostics", "Simulation", "Decision Support", "Optimization", "Supervised Learning", "Unsupervised Learning", "Reinforcement Learning"];
        var actualOptions = [];
        cafCreateAnalyticPage.getPrimarycategoryDropdownOptions().then(function (options) {
            var step = function (i, done) {
                if (i < done) {
                    options[i].getText().then(function (text) {
                        actualOptions[i] = text;
                        step(i + 1, done)
                    });
                }
                else {
                    TestHelper.assertEqual(JSON.stringify(actualOptions), JSON.stringify(expectedOptions));
                    callback();
                }
            };
            step(0, options.length);
        });
    });

    this.Given(/^the Secondary Category dropdown should not be enabled$/, function (callback) {
        cafCreateAnalyticPage.isSecondaryCategoryEnabled().then(function (boolean) {
            assert.equal(boolean, false, "Secondary Category dropdown is not disabled");
            callback();
        })
    });

    this.Then(/^the Secondary Category dropdown should not be disabled$/, function (callback) {
        cafCreateAnalyticPage.isSecondaryCategoryEnabled().then(function (boolean) {
            TestHelper.assertTrue(boolean, callback);
            callback();
        })
    });

    this.Then(/^a red border should be around the Primary Category dropdown$/, function (callback) {
        cafCreateAnalyticPage.getCSSValuePrimaryCategory().then(function (cssValue) {
            TestHelper.assertEqual(cssValue, "1px solid rgb(229, 56, 56)");
            callback();
        });
    });

    this.Then(/^the red border should not be around the Primary Category dropdown$/, function (callback) {
        cafCreateAnalyticPage.getCSSValuePrimaryCategory().then(function (cssValue) {
            console.log(cssValue);
            TestHelper.assertEqual(cssValue, "1px solid rgb(177, 177, 188)");
            callback();
        });
    });

    this.Then(/^cafUser unselect in Primary Category dropdown$/, function (callback) {
        cafCreateAnalyticPage.unselectPrimaryCategory().then(function () {
            callback();
        });
    });

    this.When(/^cafUser click the Secondary Category dropdown$/, function (callback) {
        cafCreateAnalyticPage.clickSecondaryCategoryDropdown().then(function () {
            console.log("clicked Secondary Category Dropdown")
            callback();
        });
    });

    this.Then(/^the default value for Secondary Category dropdown is "([^"]*)"$/, function (arg1, callback) {
        cafCreateAnalyticPage.getSecondaryCategoryDropdownDefaultValue().then(function (value) {
            assert.equal(value, arg1, "default selected value is not Analytic Type");
            callback();
        });
    });

    this.Then(/^the Secondary Category dropdown should display required options$/, function (callback) {
        var expectedOptions = ["Secondary Category", "Health Assessment", "Forecasting", "Prognostics", "Simulation", "Decision Support", "Optimization", "Supervised Learning", "Unsupervised Learning", "Reinforcement Learning"];
        var actualOptions = [];
        cafCreateAnalyticPage.getSecondarycategoryDropdownOptions().then(function (options) {
            var step = function (i, done) {
                if (i < done) {
                    options[i].getText().then(function (text) {
                        actualOptions[i] = text;
                        step(i + 1, done)
                    });
                }
                else {
                    TestHelper.assertEqual(JSON.stringify(actualOptions), JSON.stringify(expectedOptions));
                    callback();
                }
            };
            step(0, options.length);
        });
    });

    this.When(/^cafUser select the option "([^"]*)" in Secondary Category dropdown$/, function (arg1, callback) {
        cafCreateAnalyticPage.selectSecondaryCategory(arg1).then(function () {
            callback();
        });
    });

    this.When(/^cafUser unselect in Secondary Category dropdown$/, function (callback) {
        cafCreateAnalyticPage.unselectSecondaryCategory().then(function () {
            callback();
        });
    });

    this.Then(/^the red border should not be around the Secondary Category dropdown$/, function (callback) {
        cafCreateAnalyticPage.getCSSValueSecondaryCategory().then(function (cssValue) {
            TestHelper.assertEqual(cssValue, "1px solid rgb(177, 177, 188)");
            callback();
        });
    });

    this.Given(/^the name of the newly created analytic is correct$/, function (callback) {
        cafCreateAnalyticPage.getAnalyticName().then(function (text) {
            assert.equal(text, analyticName, "analytic name is not displayed");
            callback();
        });
    });

    this.Given(/^the owner name in the analytic list page should be correct$/, function (callback) {
        cafCreateAnalyticPage.getAnalyticOwner().then(function (text) {
            assert.equal(text, "Automation", "analytic owner is not displayed");
            callback();
        });
    });

    this.Given(/^the creation date displayed should be correct$/, function (callback) {
        cafCreateAnalyticPage.getAnalyticDate().then(function (text) {
            console.log("analytic actual date is ", text);
            var today = new Date();
            var creationDate = new Date(text);
            assert.equal(today.getFullYear(), creationDate.getFullYear(), "analytic date is not displayed");
            assert.equal(today.getMonth(), creationDate.getMonth(), "analytic date is not displayed");
            assert.equal(today.getDate(), creationDate.getDate(), "analytic date is not displayed");
            callback();
        });
    });

    this.Given(/^the publish status of the analytic should be correct$/, function (callback) {
        cafCreateAnalyticPage.getAnalyticPublishStatus().then(function (text) {

            assert.equal(text, "Queued", "analytic owner is not displayed");
            callback();
        });
    });

    this.When(/^User search for the caf analytic$/, function (callback) {
        console.log("Searching for analytic: " + analyticName);
        TestHelper.isElementPresent(element(by.id('apm-ax-analytic-list-item0'))).then(function () {
            cafCreateAnalyticPage.clickSearchBox().then(function () {
                cafCreateAnalyticPage.enterSearchText(analyticName).then(function () {
                    // console.error("searching for the analytic", analyticName);
                    callback();
                })
            });
        });
    });

    this.Given(/^I enter tag search in tag toolbox$/, function (callback) {
        console.log('Entering search criteria in to tag search input field ');
        editWidgetPage.getTagToolboxInput().sendKeys(analyticName).then(function () {
            editWidgetPage.getTagToolboxInput().click().then(function () {
                browser.sleep(5000).then(function () {
                    callback();
                });
            });
        });
    });

    this.Then(/^cafUser enter the value in the name field to create analytic$/, function (callback) {
        analyticName = 'cafCreateTest' + TestHelperPO.getRandomString();
        console.log("random analytic Name is " + analyticName);
        cafCreateAnalyticPage.enterName(analyticName).then(function () {
            callback();
        })
    });

    // this.When(/^User searches for the caf deployment$/, function (callback) {
    //     cafCreateAnalyticPage.clickSearchBox().then(function () {
    //         cafCreateAnalyticPage.enterSearchText(deploymentName).then(function () {
    //             console.log("searching for the deployment");
    //             callback();
    //         })
    //     });
    // });

    this.When(/^I clear search for the caf analytic$/, function (callback) {
        cafCreateAnalyticPage.clearSearchBox().then(function () {
            console.log("clearing search box");
            callback();
        });
    });

    this.Then(/^newly created analytic should be displayed in search results$/, function (callback) {
        browser.sleep(2000).then(function () {
            cafCreateAnalyticPage.getSearchResultsCount().then(function (searchCount) {
                console.log("count value is ", searchCount);
                assert.equal(searchCount, 1, "search results are not displayed");
                callback();
            });
        })
    });

    this.When(/^I click the caf analytic in search results$/, function (callback) {
        cafCreateAnalyticPage.clickFirstOrchSearchResult().then(function () {
            browser.sleep(2000).then(function () {
                callback();
            });
        });
    });

    this.When(/^I click the Deployments tab$/, function (callback) {
        cafCreateAnalyticPage.clickDeploymentsTabOnAnalyticPage().then(function () {
            browser.sleep(2000).then(function () {
                callback();
            });
        });
    });

    this.When(/^I click the caf orchestration in search results$/, function (callback) {
        cafCreateAnalyticPage.clickFirstOrchSearchResult().then(function () {
            browser.sleep(2000).then(function () {
                callback();
            });
        });
    });

    this.Then(/^the name of the caf analytic in template is correct$/, function (callback) {
        cafCreateAnalyticPage.getAnalyticNameInTemplate().then(function (text) {
            console.log("analytic name is ", text)
            var arr = text.split('\n')
            console.log(" split array is", arr);
            var actualAnalyticName = arr[0];
            console.log(" expected name is", actualAnalyticName);
            assert.equal(actualAnalyticName, analyticName, "analytic name is not displayed");
            callback();
        });
    });

    this.Then(/^the version of the caf analytic in template is "([^"]*)"$/, function (arg1, callback) {
        cafCreateAnalyticPage.getAnalyticVersionInTemplate().then(function (text) {
            console.log("analytic version is ", text);
            if (!arg1) {
                arg1 = '1.0.0';
            }
            // assert.equal(text, `Version: ${arg1}`, "analytic version is not displayed");
            callback();
        });
    });

    this.Then(/^the version of the caf analytic in template is correct$/, function (callback) {
        cafCreateAnalyticPage.getAnalyticVersionInTemplate().then(function (text) {
            console.log("analytic version is ", text);
            assert.equal(text, "Version: 1.0.0", "analytic version is not displayed");
            callback();
        });
    });

    this.Then(/^an edit icon is displayed next to date in caf analytic$/, function (callback) {
        cafCreateAnalyticPage.isEditIconDisplayed().then(function (bool) {
            assert.equal(bool, true, "edit icon is not displayed");
            callback();
        });
    });

    this.Then(/^the delete button should be displayed in caf analytic$/, function (callback) {
        cafCreateAnalyticPage.isDeleteButtonDisplayed().then(function (bool) {
            assert.equal(bool, true, "edit icon is not displayed");
            callback();
        });
    });

    this.Then(/^the owner of the caf analytic in template is correct$/, function (callback) {
        cafCreateAnalyticPage.getAnalyticOwnerInTemplate().then(function (text) {
            console.log("analytic owner is ", text)
            assert.include(text, "Automation", "analytic owner is not displayed");
            callback();
        });
    });

    this.Then(/^the Primary Category of the caf analytic in template is correct$/, function (callback) {
        cafCreateAnalyticPage.getAnalyticPrimaryCategoryInTemplate().then(function (text) {
            console.log("analytic primary category is ", text)
            assert.equal(text, "Monitoring", "analytic primary category is not displayed");
            callback();
        });
    });


    this.Then(/^the Primary Category "([^"]*)" of the caf analytic in template is correct$/, function (arg1, callback) {
        cafCreateAnalyticPage.getAnalyticPrimaryCategoryInTemplate().then(function (text) {
            console.log("analytic primary category is ", text)
            assert.equal(text, arg1, "analytic primary category is not displayed");
            callback();
        });
    });


    this.Then(/^the saved date displayed for the caf analytic should be correct$/, function (callback) {
        cafCreateAnalyticPage.getSavedDateInTemplate().then(function (text) {
            console.log("analytic saved date is ", text)
            var d = new Date();
            //var day = d.getDate();
            var day = (d.getDate() < 10 ? '0' : '') + d.getDate();
            //var month = d.getMonth()+ 1;
            var month = ((d.getMonth() + 1) < 10 ? '0' : '') + (d.getMonth() + 1);
            var year = d.getFullYear();
            var y1 = year.toString();
            var arr = [month, day, y1];
            var expectedDate = arr.join('/');
            console.log("expected date is", expectedDate);
            assert.include(text, expectedDate, "saved date is not displayed");
            callback();
        });
    });

    this.Then(/^the modal closes and the request is sent$/, function (callback) {
        cafCreateAnalyticPage.getUploadSpinner().then(function (className) {
            assert.equal(className, 'pxh-spinner pxh-spinner--small')
            callback();
        });
    })

    this.Given(/^the cafUser clicks Asset Filters tab$/, function (callback) {
        cafCreateAnalyticPage.clickAssetFilterTab().then(function () {
            callback();
        });
    });

    this.Then(/^the cafUser should see the title of Asset Filters page$/, function (callback) {
        cafCreateAnalyticPage.getAssetFilterstext().then(function (text) {
            console.log("Title is ", text);
            assert.equal(text, "Asset Filters", "Title is not displayed");
            callback();
        });
    });

    this.Given(/^the cafUser clicks Orchestrations tab$/, function (callback) {
        cafCreateAnalyticPage.clickOrchestrations().then(function () {
            callback();
        });
    });

    this.Then(/^the cafUser should see the title of Orchestrations page$/, function (callback) {
        cafCreateAnalyticPage.getOrchestrationtext().then(function (text) {
            console.log("Title is ", text);
            assert.equal(text, "Orchestrations", "Title is not displayed");
            callback();
        });
    });

    this.Given(/^the cafUser clicks Deployments tab$/, function (callback) {
        cafCreateAnalyticPage.clickDeployments().then(function () {
            callback();
        });
    });

    this.Then(/^the cafUser should see the title of Deployments page$/, function (callback) {
        cafCreateAnalyticPage.getDeploymenttext().then(function (text) {
            console.log("Title is ", text);
            assert.equal(text, "Deployments", "Title is not displayed");
            callback();
        });
    });

    this.When(/^I click the Secondary Category dropdown in caf analytic$/, function (callback) {
        cafCreateAnalyticPage.clickSecondaryCategoryDropdown().then(function () {
            console.log("clicked Secondary Category Dropdown")
            callback();
        });
    });

    this.When(/^I select an option from the Secondary Category dropdown in caf analytic$/, function (callback) {
        cafCreateAnalyticPage.clickSecondaryCategoryDropdownOption().then(function () {
            callback();
        });
    });

    this.Then(/^the submit button in edit analytic page should be enabled in caf analytic$/, function (callback) {
        cafCreateAnalyticPage.isSubmitButtonEnabled().then(function (boolean) {
            assert.equal(boolean, true, "submit button is not enabled");
            callback();
        });
    });

    this.When(/^I click the submit button in edit analytic page in caf analytic$/, function (callback) {
        cafCreateAnalyticPage.clickSubmitButtonInEditAnalyticPage().then(function () {
            callback();
        });
    });

    this.Then(/^the analytic should be updated in caf analytic$/, function (callback) {
        cafCreateAnalyticPage.isAnalyticTemplatePageDisplayed().then(function (bool) {
            assert.equal(bool, true, "analytic template page is not displayed");
            callback();
        })
    });

    this.When(/^I click on the edit icon of the caf analytic$/, function (callback) {
        cafCreateAnalyticPage.clickEditIcon().then(function () {
            browser.sleep(2000).then(function () {
                callback();
            });
        });
    });

    this.When(/^I click the delete button in CAF Analytic$/, function (callback) {
        browser.sleep(7000).then(function () {
            cafCreateAnalyticPage.clickDeleteButton().then(function () {
                console.log("clicked delete button in template");
                callback();
            });
        });
    });

    this.When(/^I click the delete button in the modal for CAF Analytic$/, function (callback) {
        cafCreateAnalyticPage.clickDeleteButtonInModal().then(function () {
            console.log("clicked delete button in modal");
            //cafCreateAnalyticPage.waitForSpinnerToDisappear().then(function () {
            callback();
            //});
        });
    });

    this.When(/^I click the delete button in the deployments for CAF Analytic$/, function (callback) {
        cafCreateAnalyticPage.clickDeleteIconOfDeployments().then(function () {
            console.log("clicked delete button in modal");
            //cafCreateAnalyticPage.waitForSpinnerToDisappear().then(function () {
            cafCreateAnalyticPage.clickYesForDeleteDeployment().then(function () {
                callback();
                //});
            });
        });
    });


    this.Then(/^the CAF analytic should be deleted$/, function (callback) {
        cafCreateAnalyticPage.isTemplatePageBlank().then(function (bool) {
            assert.equal(bool, true, "analytic is not deleted");
            console.log("blank template page is displayed");
            callback();
        })
    });

    this.Then(/^the CAF analytic should not be displayed in search results$/, function (callback) {
        browser.sleep(2000).then(function () {

            cafCreateAnalyticPage.getSearchResultsCount().then(function (searchCount) {
                console.log("count value is ", searchCount);
                assert.equal(searchCount, 0, "search result is not zero");
                callback();
            });
        })
    });

    this.When(/^I click the cancel button in CAF Analytic$/, function (callback) {
        cafCreateAnalyticPage.clickCancelButton().then(function () {
            callback();
        });
    });

    this.When(/^cafuser clicks on the version number in the template$/, function (callback) {
        cafCreateAnalyticPage.clickVersionLink().then(function () {
            callback();
        });
    });

    this.When(/^I click the submit button in caf analytic$/, function (callback) {
        cafCreateAnalyticPage.clickSubmit().then(function () {
            console.log("clicked submit button");
            cafCreateAnalyticPage.waitForSpinnerToDisappear().then(function () {
                callback();
            });
        });
    });

    this.Then(/^the Runtime Type field should be disabled and value is correct in caf analytic$/, function (callback) {
        cafCreateAnalyticPage.isRunTimeTypeDropdownEnabled().then(function (boolean) {
            assert.equal(boolean, false, "runtime type dropdown is not disabled");
            cafCreateAnalyticPage.getRunTimeTypeDropdownSelectedValue().then(function (text) {
                console.log("analytic runtime type is ", text);
                cafCreateAnalyticPage.getRunTimeTypeDropdownSelectedLabel(text).then(function (textLabel) {
                    console.log("analytic runtime type lable is ", textLabel);
                    assert.equal(textLabel, "Predix", "analytic runtime type is not displayed");
                    callback();
                });
            });
        })
    });

    this.Then(/^the name should be disabled and value is correct in caf analytic$/, function (callback) {
        cafCreateAnalyticPage.isNameEnabled().then(function (boolean) {
            assert.equal(boolean, false, "owner is not disabled");
            cafCreateAnalyticPage.getName().then(function (text) {
                console.log("analytic name is ", text);
                assert.equal(text, analyticName, "name is not displayed");
                callback();
            });
            callback();
        })
    });

    this.Then(/^the owner name in edit analytic page should be correct in caf analytic$/, function (callback) {
        cafCreateAnalyticPage.getOwner().then(function (text) {
            console.log("analytic owner is ", text);
            assert.equal(text, "Automation", "owner is not displayed");
            callback();
        });
    });

    this.Then(/^Analytic Type should be disabled and value is correct in caf analytic$/, function (callback) {
        cafCreateAnalyticPage.isAnalyticTypeDropdownEnabled().then(function (boolean) {
            assert.equal(boolean, false, "runtime type dropdown is not disabled");
            cafCreateAnalyticPage.getAnalyticTypeDropdownSelectedValue().then(function (text) {
                console.log("analytic type value is ", text);
                cafCreateAnalyticPage.getAnalyticTypeDropdownSelectedLabel(text).then(function (textLabel) {
                    console.log("analytic type label is ", textLabel);
                    assert.equal(textLabel, "Java", "analytic type value is not displayed");
                    callback();
                });
            });
        })
    });

    this.Then(/^Type Version should be disabled and value is correct in caf analytic$/, function (callback) {
        cafCreateAnalyticPage.isVersionTypeDropdownEnabled().then(function (boolean) {
            assert.equal(boolean, false, "version type dropdown is not disabled");
            cafCreateAnalyticPage.getVersionTypeDropdownSelectedValue().then(function (text) {
                console.log("version type is ", text);
                cafCreateAnalyticPage.getVersionTypeDropdownSelectedValue(text).then(function (textLabel) {
                    console.log("version type label is ", text);
                    assert.equal(textLabel, "1.8", "version type is not displayed");
                    callback();
                });
            });
        })
    });

    this.Given(/^Analytic Version should be disabled and value is "([^"]*)" in caf analytic$/, function (arg1, callback) {
        cafCreateAnalyticPage.isAnalyticVersionEnabled().then(function (boolean) {
            console.log(boolean);
            assert.equal(boolean, false, "analytic version is not disabled");
            cafCreateAnalyticPage.getAnalyticVersion().then(function (text) {
                console.log("analytic version is ", text)
                assert.equal(text, arg1, "analytic version value is not equal");
                callback();
            });

        })
    });

    this.Given(/^Analytic Version Update should be disabled in caf analytic$/, function (callback) {
        cafCreateAnalyticPage.isAnalyticVersionUpdateEnabled().then(function (boolean) {
            console.log(boolean);
            assert.equal(boolean, false, "analytic version update is not disabled");
            callback();
        })
    });

    this.When(/^I click the upload icon in the Analytic field in caf analytic$/, function (callback) {
        cafCreateAnalyticPage.clickUploadIcon().then(function () {
            callback();
        });
    });

    this.Then(/^Primary Category value should be correct in caf analytic$/, function (callback) {
        cafCreateAnalyticPage.getPrimaryCategoryDropdownSelectedValue().then(function (text) {
            console.log("primary category value is ", text);
            cafCreateAnalyticPage.getPrimaryCategoryDropdownSelectedLabel(text).then(function (textLabel) {
                console.log("primary category label is ", textLabel);
                assert.equal(textLabel, "Monitoring", "primary category is not displayed");
                callback();
            });
        });
    });

    this.Then(/^the submit button in edit analytic page should be disabled in caf analytic$/, function (callback) {
        cafCreateAnalyticPage.isSubmitButtonEnabled().then(function (boolean) {
            assert.equal(boolean, false, "submit button is not disabled");
            callback();
        });
    });

    this.Then(/^the Secondary Category value should be correct in caf analytic$/, function (callback) {
        cafCreateAnalyticPage.getSecondaryCategoryDropdownSelectedValue().then(function (text) {
            console.log("secondary category value is ", text);
            AnalyticPage.getSecondaryCategoryDropdownSelectedValue(text).then(function (textLabel) {
                console.log("secondary category label is ", textLabel);
                assert.equal(textLabel, "Health Assessment", "secondary category is not displayed");
                callback();
            });
        });
    });

    this.When(/^the cafUser clicks the first analytic$/, function (callback) {
        cafCreateAnalyticPage.clickAnalytic().then(function () {
            callback();
        });
    });

    this.Given(/^I created "([^"]*)" Edge Analytic Template$/, function (arg1,callback) {
        var path = require('path');
        var filePath = './../TestData/'+arg1;
        var absolutePath = path.resolve(__dirname, filePath);
        cafAnalyticTemplatePage.clickIngestButton().then(function() {
            cafCreateAnalyticPage.selectZipFile(absolutePath);
            browser.sleep(2000).then(function () {
                analyticName = cafCreateAnalyticPage.headerName();
                browser.sleep(2000).then(function () {
                    callback();
                });
            });
        });
    });

    this.Given(/^I created SmartSignal Analytic Template$/, function (callback) {
        var path = require('path');
        var filePath = './../TestData/ASCIITESTAsset139_0702_ChartMarker.zip';
        var absolutePath = path.resolve(__dirname, filePath);
        cafCreateAnalyticPage.selectZipFile(absolutePath);
        // browser.sleep(2000).then(function () {
        browser.sleep(2000).then(function () {
            callback();
        });
        // });
        //});
    });

    this.Then(/^the analytic ingestion icon should be displayed$/, function (callback) {

        cafCreateAnalyticPage.visibilityOf(cafCreateAnalyticPage.ingestionIcon()).then(function (value) {
            console.log("this is the value ...", value);
            expect(value).to.be.true;
            callback();
        });

    });

    this.When(/^I enter template name on the search input box on tag tree$/, function (callback) {
        TestHelper.isElementPresent(currentTagTreePage, "tagTree_SearchInputBox").then(function (boolean) {
            browser.sleep(1000).then(function () {
                console.log('Search input box present: ' + boolean);
                TestHelper.elementToBeClickable(currentTagTreePage, "tagTree_SearchInputBox").then(function () {
                    element(by.css('#tagsubpanels tag-tree input')).clear().sendKeys(analyticName).then(function () {
                        console.log("Tag name entered to search input field: " + analyticName);
                        browser.sleep(1000).then(function () {
                            callback();
                        })
                    })
                })
            })
        })
    });


    this.When(/^User drags and drops the created model config onto forecast chart$/, function (callback) {
        TestHelper.setElementManager(analysisRepo);
        browser.sleep(1000).then(function () {
            TestHelper.isElementPresent(currentTagTreePage, "modelTree_SearchInputBox").then(function (boolean) {
                browser.sleep(1000).then(function () {
                    console.log('Search input box present: ' + boolean);
                    TestHelper.elementToBeClickable(currentTagTreePage, "modelTree_SearchInputBox").then(function () {
                        element(by.css('input.tags-search.text-input.style-scope.forecast-tag-tree')).clear().sendKeys(analyticName).then(function () {
                            console.log("Tag name entered to search input field: " + analyticName);
                            browser.sleep(1000).then(function () {
                                var dropElement = element(by.css('.chart-target.chart-target-overlay.style-scope.chart-forecast'));
                                var ele = element(by.css('.tree-view-label.style-scope.px-tree-view-leaf.tree-view-level-2'));
                                TestHelperPO.dragAndDrop(ele, dropElement)
                                    .then(function () {
                                        browser.sleep(10000);
                                        callback();
                                    })
                            })
                        })
                    })
                })
            })
        })
    });

    this.Then(/^I click on fromDate input field$/, function (callback) {

        analysisPage.getFromField_DateRange().then(function () {
            console.log('Clicked on From Date field');
            callback();
        })
    });

    this.Then(/^I enter a date "([^"]*)" on fromDate field$/, function (arg1, callback) {
        TestHelperPO.elementToBeClickable(element.all(by.css('#icon')).get(1)).then(function () {
            analysisPage.getFromField_DateRange().then(function () {
                element(by.id('fromFields')).clear().sendKeys(arg1).then(function () {
                    browser.sleep(1000).then(function () {
                        callback();
                    })
                })
            })
        })
    });

    this.Then(/^I click on toDate input field$/, function (callback) {
        analysisPage.getToField_DateRange().then(function () {
            console.log('Clicked on To Date field');
            callback();
        })
    });

    this.Then(/^I enter a date "([^"]*)" on toDate field$/, function (arg1, callback) {
        TestHelperPO.elementToBeClickable(element.all(by.css('#icon')).get(1)).then(function () {
            analysisPage.getToField_DateRange().then(function () {
                element(by.id('toFields')).clear().sendKeys(arg1).then(function () {
                    browser.sleep(1000).then(function () {
                        callback();
                    })
                })
            })
        })
    });

    // this.When(/^cafUser enters the airAnalytic as analytic name$/, function(callback) {
    //     cafCreateAnalyticPage.analyticName().sendKeys('Test_Marri').then(function () {
    //         callback();
    //     });
    // });

    // this.Then(/^I enter a date "([^"]*)" on fromDate field$/, function (arg1, callback) {
    //     // TestHelperPO.elementToBeClickable(element.all(by.css('.fa.fa-fw.dtIcon.style-scope.px-datetime-entry.x-scope.iron-icon-0')).get(0)).then(function () {
    //     TestHelperPO.elementToBeClickable(element.all(by.css('#icon')).get(1)).then(function () {
    //         analysisPage.getFromField_DateRange().then(function () {
    //             element.all(by.css('#dtEntry')).get(0).sendKeys(arg1.split('/')[0]).then(function () {
    //                 element.all(by.css('#dtEntry')).get(1).sendKeys(arg1.split('/')[1]).then(function (count) {
    //                     element.all(by.css('#dtEntry')).get(2).sendKeys(arg1.split('/')[2]).then(function (count) {
    //                         //            element.all(by.css('#fromDate > div > label > input')).get(0).clear().sendKeys(arg1).then(function () {
    //                         console.log("From Date entered new date");
    //                         callback();
    //                     });
    //                 });
    //             });
    //         });
    //     })
    // });
    //
    // this.Then(/^I click on toDate input field$/, function (callback) {
    //     analysisPage.getToField_DateRange().then(function () {
    //         console.log('Clicked on To Date field');
    //         callback();
    //     })
    // });
    //
    // this.Then(/^I enter a date "([^"]*)" on toDate field$/, function (arg1, callback) {
    //     analysisPage.getToField_DateRange().then(function () {
    //         element.all(by.css('#dtEntry')).get(7).sendKeys(arg1.split('/')[0]).then(function (count) {
    //             element.all(by.css('#dtEntry')).get(8).sendKeys(arg1.split('/')[1]).then(function (count) {
    //                 element.all(by.css('#dtEntry')).get(9).sendKeys(arg1.split('/')[2]).then(function (count) {
    //                     // element.all(by.css('#toDate > div > label > input')).get(0).clear().sendKeys(arg1).then(function () {
    //                     console.log("To Date clear and entered new date");
    //                     browser.sleep(6000);
    //                     callback();
    //                 });
    //             });
    //         });
    //     });
    // });

    this.Then(/^I click on Apply button to submit date change$/, function (callback) {
        // browser.sleep(6000);
        analysisPage.getApplyBTN_DateRange().then(function () {
            console.log('Clicked on Apply button');
            callback();
        })
    });
};

(function () {
  'use strict';


  var restUtil = function () {

    var getUrl = function (relativeUrl) {
      return browser.params.login.baseUrl + "/" + relativeUrl;
    };
    var cookieValue = function (cookie) {
      var value = '';
      cookie.forEach(function (c) {
        value += c.name + "=" + c.value + ";";
      });
      return value;
    }

    //let proxy = browser.params.restUtilProxy.proxy;
    console.log('PROCESS ENV PROXY: ', process.env.https_proxy);
    var request = require('request');

    return {
      makeRequest: function (url, method, data, contentType) {
        var defer = protractor.promise.defer();

        browser.manage().getCookies().then(function (cookie){
          var options = {
            uri: getUrl(url),
            method: method,
            gzip: true,
            headers: {'Cookie': cookieValue(cookie)}
          };
          if(data){
            switch (contentType){
              case 'application/json':
                options.json = data;
                break;
              case 'multipart/form-data':
                options.formData = data;
                break;
            }
          }
          request(options,function (error, message, body) {
            // if (error || message.statusCode >= 400) {
            //   defer.reject({
            //     error: error,
            //     message: message
            //   });
            // }
            // else {
              defer.fulfill(message);
            // }
          });
        });
        return defer.promise;
      }
    };
  };
  module.exports = new restUtil();

}());

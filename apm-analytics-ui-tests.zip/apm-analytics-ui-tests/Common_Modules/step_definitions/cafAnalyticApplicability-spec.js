/**
 * Analytic Applicability spec
 */


module.exports = function() {

    const moduleName = 'AnalyticsAdmirals(DEV2)';
    const submoduleName = 'Analytic Applicability';
    const nameSuffix = Date.now();

    const CONDITION_OPERATOR = {
        '=': {
            operator: '=',
            operatorLabel: 'is equal to',
            name: 'OPERATOR_EQUALS'
        },
        '!=': {
            operator: '!=',
            operatorLabel: 'is not equal to',
            name: 'OPERATOR_IS_NOT_EQUALS'
        },
        'in': {
            operator: 'in',
            operatorLabel: 'ini',
            name: 'OPERATOR_IN'
        },
        'like': {
            operator: 'like',
            operatorLabel: 'like',
            name: 'OPERATOR_LIKE'
        }
    };

    const createCondition = function(attribute,operator,value,values) {
        return {
            entityFilterFieldUri: attribute.uri,
            operator: operator,
            value: value,
            values: values,
        };
    }

    const fs = require('fs');
    const rStream = fs.createReadStream(path.resolve(__dirname, '../../Test_Modules/Analytics/TestData/AnalyticsTestData.json'));
    var testData = '';
    var testFilters = {
        filters: []
    }
    rStream.setEncoding('utf8');
    rStream.on('data', function(chunk) {
        testData+=chunk;
    });
    rStream.on('end', function () {
        testFilters = JSON.parse(testData);
    })

    var existingAttributes = [];

    this.BeforeFeature(function(feature, callback) {
       /*const tags = feature.getPayloadItem('feature').getTags().map(tag => {return tag.getName()});
       if(tags.includes('@cafAnalyticApplicability')) {
           cafMgmtRestUtil.getAttributes().then((attributes) => {
               existingAttributes = attributes;

               const currentAttr = attributes.map((attribute) => {return attribute.displayName});
               const attributesToAdd = testFilters.preloadAttributes.filter(attribute => !currentAttr.includes(attribute.displayName));
               cafMgmtRestUtil.createAttributes(attributesToAdd).then((attributes) => {
                   existingAttributes.push(attributes);
                   testFilters.preloadFilters.map(filter => {
                       filter.name = `${filter.name}${nameSuffix}`;
                       filter.entityFilterConditions.map(condition => {
                           condition.entityFilterFieldUri = existingAttributes.filter(attribute => attribute.name === condition.entityFilterFieldName)[0].uri;
                       });
                    });

                   // cafMgmtRestUtil.createFilters(testFilters.preloadFilters).then(() => {
                   //   callback();
                   // })
                   callback();
               })
           });
       } else {
           callback();
       }*/
        callback();
    });

    this.AfterFeature(function(feature, callback) {
        callback();
    });


    this.Given(/^the caf Analytic Applicability user is logged in$/, function (callback) {

        const baseUrl = browser.params.login.baseUrl;
        const userName = browser.params.login.mgrusername;
        const password = browser.params.login.mgrpassword;

        appHubPage.login(baseUrl, userName, password).then(function (landingPagePresent) {
            assert.isTrue(landingPagePresent, 'Login failed');
            callback();
        })
    });

    this.Then(/^the user opens the Analytic Applicability sub module$/, function (callback) {
        browser.sleep(3000).then(function () {
                cafAnalyticApplicabilityPage.verifyAnalyticApplicabilityTab().then(function () {
                    browser.sleep(10000);
                    TestHelperPO.isElementPresent(element(By.id('filterList'))).then(function () {
                        callback();
                    });
                });
        });
    });

    this.When(/^the user selects the filter named (.*)$/, function (filterName, callback) {
        cafAnalyticApplicabilityPage.selectFilter(`${filterName}${nameSuffix}`).then(() => {
           callback();
        });
    });

    this.When(/^the user initiates creating a new filter$/, function (callback) {
        cafAnalyticApplicabilityPage.initiateNewFiler().then(() => {
            callback();
        });
    });

    this.When(/^the user populates basic filter data with name:(.*),description:(.*),hierarchy level:(.*)$/, function (name,description,hierarchyLevel,callback) {
        cafAnalyticApplicabilityPage.populateBasicMetadata(`${name}${nameSuffix}`,description,hierarchyLevel).then(() => {
            callback();
        });
    });

    /*this.When(/^the user adds a condition with attribute:(.*),condition:(.*),value:(.*)$/, function (attributeName,condition,value,callback) {
        cafAnalyticApplicabilityPage.addCondition(attributeName,condition,value).then(() => {
            callback();
        });
    });*/

    this.When(/^the user adds a condition with attribute:(.*),condition:(.*),value:(.*) for rule level:(.*)$/, function (attributeName,condition,value, ruleLevel,callback) {
        cafAnalyticApplicabilityPage.addCondition(`${attributeName}_${nameSuffix}`,condition,value, ruleLevel).then(() => {
            callback();
        });
    });

    this.When(/^the user adds a condition with custom attribute:(.*),condition:(.*),value:(.*) for rule level:(.*)$/, function (attributeName,condition,value, ruleLevel,callback) {
        cafAnalyticApplicabilityPage.addCustomCondition(`${attributeName}_${nameSuffix}`,condition,value, ruleLevel).then(() => {
            callback();
        });
    });

    this.When(/^the user saves the filter$/, function (callback) {
        cafAnalyticApplicabilityPage.saveFilter().then(() => {
            callback();
        });
    });

    this.When(/^the user deletes rule with attribute:(.*),operator:(.*),value:(.*) at level:(.*)$/, function (attributeName,operator,value,ruleLevel, callback) {
        cafAnalyticApplicabilityPage.deleteRule(`${attributeName}_${nameSuffix}`,operator,value, ruleLevel).then(() => {
            callback();
        });
    });

    this.When(/^the user opens the preview modal$/, function (callback) {
        cafAnalyticApplicabilityPage.openPreviewModal().then(() => {
            callback();
        });
    });

    this.Then(/^the preloaded default filters are shown in the filters list$/, function () {
        const filterListPromises = testFilters.preloadFilters.map(filter => {
           return cafAnalyticApplicabilityPage.isFilterPresent(filter.name).then(value => {
              expect(value, `did not find filter named:"${filter.name}" in filter list`).to.be.true;
           });
        });
        return Promise.all(filterListPromises).then(()=> {});
    });

    this.Then(/^the data for preloaded filter named (.*) is displayed$/, function (filterName) {
        return cafAnalyticApplicabilityPage.getCurrentDisplayedFilter(null).then((displayedFilter) => {
            var expectedFilter = testFilters.preloadFilters.filter(filter => filter.name === `${filterName}${nameSuffix}`)[0];
            expect(expectedFilter.name, 'displayed filter name not equal to saved filter name').to.eql(displayedFilter.name);
            expect(expectedFilter.description, 'displayed filter description not equal to saved filter description').to.eql(displayedFilter.description);
            expect(expectedFilter.entityFilterResponseType, 'displayed filter level not equal to saved filter level').to.eql(displayedFilter.entityFilterResponseType);
            expect(expectedFilter.entityFilterConditions, 'displayed filter conditions not equal to saved filter conditions').to.eql(displayedFilter.entityFilterConditions);
        })
    });

    this.Then(/^the displayed filter will have name:(.*),description:(.*),hierarchyLevel:(.*)$/, function (name,description,level) {
        return cafAnalyticApplicabilityPage.getCurrentDisplayedFilter(null).then((displayedFilter) => {
            //expect(displayedFilter.name, 'displayed filter name not equal to saved filter name').to.eql(`${name}${nameSuffix}`);
            //expect(displayedFilter.description, 'displayed filter description not equal to saved filter description').to.eql(description);
            expect(displayedFilter.entityFilterResponseType, 'displayed filter level not equal to saved filter level').to.eql(level);
        })
    });

    this.Then(/^the displayed filter will have (\d+) rules at level:(.*)$/, function (numberOfRules, ruleLevel) {
        return cafAnalyticApplicabilityPage.getCurrentDisplayedFilter(ruleLevel).then((displayedFilter) => {
           expect(displayedFilter.entityFilterConditions.length, 'incorrect number of rules found').to.eql(parseInt(numberOfRules,10));
        });
    });


    this.Then(/^the displayed custom filter will have (\d+) rules at level:(.*)$/, function (numberOfRules, ruleLevel) {
        return cafAnalyticApplicabilityPage.getCurrentCustomDisplayedFilter(ruleLevel).then((displayedFilter) => {
            expect(displayedFilter.entityFilterConditions.length, 'incorrect number of rules found').to.eql(parseInt(numberOfRules,10));
        });
    });

    this.Then(/^the displayed filter will contain rule with attribute:(.*),condition:(.*),value:(.*) at level:(.*)$/, function (attributeName,condition,value, ruleLevel) {
        const splitValue = value.split(',');
        const conditionValue = splitValue.length > 1 ? '' : splitValue[0];
        const conditionValues = splitValue.length > 1 ? splitValue : [];
        const conditionOperator = condition === 'Is not' ? '!=' : conditionValues < 1 ? '=' : 'in';

        return cafAnalyticApplicabilityPage.getCurrentDisplayedFilter(ruleLevel).then((displayedFilter) => {

            const matchingRules = displayedFilter.entityFilterConditions.filter(function(condition) {
                 return condition.entityFilterFieldName === `${attributeName}_${nameSuffix}` &&
                    condition.value === conditionValue &&
                    condition.values.length === conditionValues.length &&
                     condition.values.every(value => {return conditionValues.includes(value)}) &&
                    condition.operator.operator === conditionOperator});
            expect(matchingRules.length, 'incorrect number of matching rules found').to.eql(1);
        });
    });

    this.Then(/^the displayed custom filter will contain rule with attribute:(.*),condition:(.*),value:(.*) at level:(.*)$/, function (attributeName,condition,value, ruleLevel) {
        const splitValue = value.split(',');
        const conditionValue = splitValue.length > 1 ? '' : splitValue[0];
        const conditionValues = splitValue.length > 1 ? splitValue : [];
        const conditionOperator = condition === 'Is not' ? '!=' : conditionValues < 1 ? '=' : 'in';

        return cafAnalyticApplicabilityPage.getCurrentCustomDisplayedFilter(ruleLevel).then((displayedFilter) => {

            const matchingRules = displayedFilter.entityFilterConditions.filter(function(condition) {
                return condition.entityFilterFieldName === `${attributeName}_${nameSuffix}` &&
                    condition.value === conditionValue &&
                    condition.values.length === conditionValues.length &&
                    condition.values.every(value => {return conditionValues.includes(value)}) &&
                    condition.operator.operator === conditionOperator});
            expect(matchingRules.length, 'incorrect number of matching rules found').to.eql(1);
        });
    });

    this.Then(/^the preview modal window will be displayed$/, function () {
        return cafAnalyticApplicabilityPage.isPreviewModalOpen().then((isPreviewOpen) => {
            /*browser.refresh();*/
            expect(isPreviewOpen, 'preview modal not open').to.be.true;
        });
    });

    this.Then(/^the preview results export all button is clicked$/, function () {
        var filename = 'export.csv';
        default_directory = path.resolve(__dirname, '../TestData');

        var fileTolook = '../TestData/' + filename;
        var  filepath = path.resolve(__dirname, fileTolook);
        console.log('looking for : '+filepath);

		if (fs.existsSync(filepath)) {
            // delete if there is existing file with same name
			console.log("DELETING THE FILE");
            fs.unlinkSync(filepath);
        }
		return cafAnalyticApplicabilityPage.previewResultsExportAsCSV().then( () => {
				browser.sleep(2000).then(function(){});

        });
    });

	    this.Then(/^I should see the CSV file saved$/, function () {
		var filename = 'export.csv';
        default_directory = path.resolve(__dirname, '../TestData');

        var fileTolook = '../TestData/' + filename;
        var  filepath = path.resolve(__dirname, fileTolook);
        console.log('looking for : '+filepath);
        if (fs.existsSync(filepath)) {
            console.log('File saved!');
			expect(" ").to.equal(" ");
			//deleteing the file once the file gets downloaded
			fs.unlinkSync(filepath);
        }
        else{
            console.log("file not found");
            expect(" ").to.equal(" ");
        }

    });

    this.When(/^the user deletes the filter$/, function (callback) {
        cafAnalyticApplicabilityPage.deleteCurrentFilter().then(() => {
            callback();
        });
    });

    this.When(/^the user cancels the preview modal$/, function (callback) {
        cafAnalyticApplicabilityPage.cancelPreviewWindow().then(() => {
            callback();
        });
    });

    this.When(/^the user adds a attribute of type (.*) with name (.*) for filter$/, function (attributeType,attributeName,callback) {
        cafPreferencesPage.addAttribute(attributeType, `${attributeName}_${nameSuffix}`).then(() => {
            callback();
        });
    });

    this.Then(/^attribute of type (.*) with name (.*) will be present in attribute list for filter$/, function(attributeType, attributeName) {
        let attributeNameValue = `${attributeName}_${nameSuffix}`;
        return cafPreferencesPage.isAttributePresent(attributeType, attributeNameValue).then(value => {
            expect(value, 'added attribute does not appear in attribute list').to.be.true;
        });

    });

    this.Then(/^attribute of type (.*) with name (.*) will be deleted for filter$/, function(attributeType,attributeName) {
        return cafPreferencesPage.deleteTestAttribute(attributeType, `${attributeName}_${nameSuffix}`, null).then(value => {
            expect(" ").to.equal(" ");
        });

    });

    this.Then(/^I should see delete failure error for attribute (.*) associated with filter (.*)$/, function(attributeName, filterName, callback) {
        let errorMessage = "Error: Cannot delete Attribute '" +
            attributeName + "_" + nameSuffix  +"' as it is associated with asset filter(s) '[" + filterName + nameSuffix +"]'";
        element(by.css('#message > span:nth-child(2)')).getInnerHtml().then(function (text){
            console.log('Error Message is: ' + text);
            console.log('Expected Error Message is: ' + errorMessage);
            //expect(text).to.equal(errorMessage);
            expect(text).to.contains("Cannot delete Attribute");
            expect(text).to.contains("associated with asset filter(s)");
            callback();
        });
    });


    this.Then(/^attribute of type (.*) with name (.*) will be edited for filter$/, function(attributeType,attributeName) {
        return cafPreferencesPage.editDefaultAttribute(attributeType, `${attributeName}_${nameSuffix}`, 'edit').then(value => {
            expect(" ").to.equal(" ");
        });

    });

    this.Then(/^I should see edit attribute failure error for attribute (.*) associated with filter (.*)$/, function(attributeName, filterName, callback) {
        let errorMessage = "Error: Cannot edit Attribute '" +
            attributeName + "_" + nameSuffix  +"' as it is associated with asset filter(s) '[" + filterName + nameSuffix +"]'";
        element(by.css('#message > span:nth-child(2)')).getInnerHtml().then(function (text){
            console.log('Error Message is: ' + text);
            console.log('Expected Error Message is: ' + errorMessage);
            //expect(text).to.equal(errorMessage);
            expect(text).to.contains("Cannot edit Attribute");
            expect(text).to.contains("associated with asset filter(s)");
            callback();
        });
    });

    this.Then(/^the user cannot edit and delete the filter$/, function(callback) {
        expect(cafAnalyticApplicabilityPage.DeleteFilter().isDisplayed()).to.be.not.true;
        expect(cafAnalyticApplicabilityPage.CancelFilterButton().isDisplayed()).to.be.not.true;
        expect(cafAnalyticApplicabilityPage.SaveChangesButton().isDisplayed()).to.be.not.true;
        callback();
    });
    
    this.When(/^refreshing the page$/, function (callback) {
        browser.refresh().then(function() {
            callback();
        });
    });

    this.When(/^the user waits for sometime$/, function (callback) {
        browser.sleep(6000).then(function(){
            callback();
        })
    });

};

module.exports = function () {


    var currentPage = "parallelAxisPage";
    var currentTSPage = "timeSeriesPage";
    var currentTagTreePage = "tagTreePage";

    this.When(/^I click on the "([^"]*)" microapp link on the left nav$/, function (arg1, callback) {
        browser.sleep(5000).then(function () {
            navPage.clickMicroApp(arg1).then(function () {
                //browser.executeScript('sessionStorage.setItem("avid-chartTypes","true");').then(function(result){

                callback();
            });
        });
    });

    this.When(/^I click inner node "([^"]*)" from the context browser$/, function (arg1, callback) {
        browser.ignoreSynchronization = true;
        analysisPage.getContextBrowser().then(function (isPresent) {
            console.log("Context browser is displayed: " + isPresent);
            browser.sleep(2000);
            analysisPage.clickAsset(arg1).then(function () {
                callback();
            });
        });
    });

    this.When(/^I click on the open button$/, function (callback) {
        browser.sleep(1000).then(function () {
            TestHelperPO.isElementPresent((element.all(by.css('li.selected button.opener')).last())).then(function () {
                analysisPage.getOpenAssetButton().then(function () {
                    callback();
                })
            })

        })
    });
    this.When(/^the page is loaded$/, function (callback) {
        browser.sleep(5000).then(function () {
            console.log("Entering page loading")
            callback();
        })
    });

    this.Then(/^I click on template dropdown and create a new adhoc forecasting$/, function (callback) {
        // browser.sleep(2000);
        aem = new ElementManager('./../../../Test_Modules/Analysis/forecast-element-repo.json');
        TestHelper.setElementManager(aem);
        TestHelper.elementToBeClickable("currentPage", "templateDropdownArrow").then(function () {
            console.log("click on dropdown")
            TestHelperPO.elementToBeClickable(element(by.cssContainingText('span.style-scope.pae-dropdown','New Forecast Analysis'))).then(function () {
                console.log("came here...");
                //browser.pause
                browser.sleep(2000).then(function () {
                    callback();
                })
            });
        });
    });

    this.When(/^User drags and drops the first model config onto forecast chart$/, function (callback) {
        // var dragElement = element(by.cssContainingText('px-tree-view-leaf>#label', 'powerpuff-deploy'));
        var dragList=element.all(by.css('div#prefix[draggable="true"]'));

        var dragElement=dragList.first();
        var dropElement = $('.chart-target.chart-target-overlay.style-scope.chart-forecast');
        var EC = protractor.ExpectedConditions;
        browser.wait(EC.elementToBeClickable(dragElement));
        TestHelperPO.dragAndDrop(dragElement, dropElement)
            .then(function () {
                browser.sleep(10000);
                callback();
            });
        browser.sleep(2000);
    });


    this.Then(/^I should see forecasting graph data points$/, function (callback) {
        debugger;
        browser.sleep(20000).then(function () {
            console.log('Verify data points are present');
            analysisPage.getGraphElement().getAttribute('d').then(function (chartElement) {
                console.log("graph points:" + JSON.stringify(chartElement));
                // console.log("graph points:" + analysisPage.getGraphElement());
                var datapointsPresent = chartElement.split(',').length > 5;

                expect(datapointsPresent).to.equal(true);
                // browser.sleep(2000);
                callback();
            });
        });
    });

    this.Then(/^I click on template dropdown and create a new adhoc$/, function (callback) {
        // browser.sleep(2000);
        aem = new ElementManager('./../../../Test_Modules/Analysis/analysis-element-repo.json');
        TestHelper.setElementManager(aem);
        TestHelper.elementToBeClickable(currentPage, "templateDropdownArrow").then(function () {
            console.log("click on dropdown")
            TestHelper.elementToBeClickable(currentPage, "newAdHocOption").then(function () {
                // callback();
                browser.sleep(2000).then(function () {
                    callback();
                })
            });
        });
    });

    this.When(/^I click on the chart list$/, function (callback) {
        aem = new ElementManager('./../../../Test_Modules/Analysis/analysis-element-repo.json');
        TestHelper.setElementManager(aem);
        // browser.sleep(1000).then(function () {
        TestHelper.elementToBeClickable(currentPage, "chartTypeDropdown").then(function () {
            callback();
        })
        // })
    });

    this.When(/^I select the "([^"]*)" from the dropdown list$/, function (arg1, callback) {
        var selectedChart;
        if(arg1=="TimeSeries"){
            selectedChart = "Time-Series (Line)";
        } else if (arg1=="ParallelAxis"){
            selectedChart = "Parallel Axis";
        } else if (arg1=="Spider"){
            selectedChart = "Spiderweb";
        } else if (arg1=="XY line"){
            selectedChart = "X-Y (Line)";
        } else if (arg1=="XY scatter"){
            selectedChart = "X-Y (Scatter)";
        } else if (arg1=="Polar"){
            selectedChart = "Polar";
        }
        analysisPA.selectChartType(selectedChart).then(function () {
            callback();
        });
    });

    this.Then(/^I store the count for number of Time Series charts in view$/, function (callback) {
        element.all(by.css('div.chart-target.chart-target-overlay.style-scope.chart-ts-line')).count()
            .then(function (count) {
                console.log('count of the plotted Time Series charts: ' + count)
                plotted_ts_chart_count = count;
            })
            .then(function () {
                callback();
            })
    });

    this.Then(/^A hint message for TS charts should pop up saying "([^"]*)"$/, function (arg1, callback) {
        analysisTS.getTS_HintMessage().then(function (text) {
            TestHelper.assertEqual(text, arg1, callback);
            console.log('Hint text for timeseries chart displayed.');
            callback();
        });
    });

    this.Then(/^a timeseries chart container is added$/, function (callback) {
        TestHelper.isElementPresent(currentTSPage, "timeseriesChartContainer").then(function (boolean) {
            console.log(boolean);
            TestHelper.assertTrue(boolean, callback);
            console.log('An empty chart timeseries is displayed.');
            callback();
        })
    });


    this.When(/^I expand the All Tags section on the tag tree$/, function (callback) {
        browser.sleep(1000).then(function () {
            element.all(by.css('a#text.tree-view-text.style-scope.px-tree-view-branch')).count().then(function (count) {
                var countBranch = count;
                var position = 0;
                for (i = 0; i < countBranch; i++) {
                    TestHelperPO.getText(element.all(by.css('a#text.tree-view-text.style-scope.px-tree-view-branch')).get(i)).then(function (text) {
                        if (text == 'All Tags') {
                            var toggle = element.all(by.css("#label.tree-view-label.style-scope.px-tree-view-branch")).get(position);
                            toggle.getAttribute("class").then(function (toggleAttribute) {
                                if (!toggleAttribute.includes("expanded")){
                                    element.all(by.css('#toggleicon')).get(position).click().then(function () {
                                        console.log('All Tags found');
                                        console.log('Clicked to Expand the toggle');
                                        callback();
                                    })
                                } else {
                                    console.log("No Click on toggle since it's been expanded already");
                                    callback();
                                }
                            })
                        }
                        else {
                            position++;
                        }
                    })
                }
            })
        })
    });

    this.Then(/^the system displays a list of tags as a list item based on the visual design below$/, function (callback) {
        // browser.sleep(6000);

        element( by.css( 'div#Wrapper' ) );
        expect(element.all(by.css( 'a#text.tree-view-text.style-scope.px-tree-view-leaf' )).count()).to.not.equal(0).notify(callback);
    });

    this.When(/^the user drags (\d+) tags from the tag tree to Timeseries chart area$/, function (arg1, callback) {
        // Write code here that turns the phrase above into concrete actions
        var step = function (i, done) {
            if (i < arg1) {
                // Find the index where the tag list starts
                // TestHelperPO.elementToBeClickable(element.all(by.css('#label')).get(i + 4)).then(function () {
                TestHelperPO.elementToBeClickable(element.all(by.css('.leaftype-tag.tree-view-leaf.style-scope.px-tree-view-node.x-scope.px-tree-view-leaf-0')).get(i)).then(function () {
                    browser.sleep(1000).then(function () {
                        // TestHelperPO.elementToBeClickable(element.all(by.css('#label')).get(i + 4)).then(function () {
                        TestHelperPO.elementToBeClickable(element.all(by.css('.leaftype-tag.tree-view-leaf.style-scope.px-tree-view-node.x-scope.px-tree-view-leaf-0')).get(i)).then(function () {
                            console.log("Element clicked");
                            // var ele = element.all(by.css('#label')).get(i + 4);
                            var ele = element.all(by.css('.leaftype-tag.tree-view-leaf.style-scope.px-tree-view-node.x-scope.px-tree-view-leaf-0')).get(i);
                            var drop = element(by.css('.chart-target.chart-target-overlay.style-scope.chart-ts-line'));
                            console.log("Elements found");
                            TestHelperPO.dragAndDrop(ele, drop).then(function () {
                                console.log("I: " + i + " arg: " + arg1);
                                step(i + 1, done)
                            })
                        })
                    })
                })
            }
            else callback();
        }
        step(0, arg1);
    });



    this.Then(/^User drags and drops "([^"]*)" onto Parallel Axis chart$/, function (arg1, callback) {
        var dragElement = element(by.cssContainingText('px-tree-view-leaf>#label', arg1));
        var dropElement = $('.chart-target.chart-target-overlay');
        TestHelperPO.dragAndDrop(dragElement, dropElement)
            .then(function () {
                callback();
            });
        browser.sleep(2000);
    });

    this.Then(/^i verify the timeseries data is plotted on the chart$/, function (callback) {

        //This function returns a promise with the percentage that shows difference
        browser.protractorImageComparison.checkElement(element.all(by.css('#chartSVG')).get(0), 'ExpectedChart').then(function (percentDifferent) {

            console.log("The percentage difference: " + percentDifferent)

            //Asserting if the percentage is 0 meaning that there are no differences between the two images
            expect(percentDifferent).to.be.below(1);
            callback();
        });
    });

}

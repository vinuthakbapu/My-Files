/********************************************************************************
 * Copyright (c) 2015-2016 GE Digital. All rights reserved.                     *
 *                                                                              *
 * The copyright to the computer software herein is the property of GE Digital. *
 * The software may be used and/or copied only with the written permission of   *
 * GE Digital or in accordance with the terms and conditions stipulated in the  *
 * agreement/contract under which the software has been supplied.               *
 ********************************************************************************/

/**
 * Create Orch spec
 */
module.exports = function() {


    this.When(/^the user is in IO Map page$/, function (callback) {
        browser.sleep(10000).then(function () {
            /*TestHelperPO.isElementPresent(orchIOMapPage.stepName());
             TestHelperPO.isElementPresent(orchIOMapPage.assetTagBox());

             expect(orchIOMapPage.assetTagSearch()).to.exist;
             expect(orchIOMapPage.closeButton()).to.exist;*/
            orchIOMapPage.inputDefinitionText().getText().then(function (value1) {
                console.log("Input def: " + value1);
                orchIOMapPage.percentRequired().getText().then(function (value2) {
                    console.log("required % : " + value2);
                    assert.equal(value2, "0 %", "Not same");
                    orchIOMapPage.percentInputMapped().getText().then(function (value3) {
                        console.log("Input mapped %: " + value3);
                        assert.equal(value3, "0 %", "Not same");
                        callback();
                    });
                });
            });
        });
    });


    this.Then(/^the IOMap screen is displayed$/, function (callback) {
        expect(orchIOMapPage.stepName()).to.exist;
        expect(orchIOMapPage.IOApplicabilityText()).to.exist;
        orchIOMapPage.IOApplicabilityText().getText().then(function (text) {
            console.log("the version and applicbilyt is " + text);
            callback();
        });
    });


    this.Then(/^half the tags are mapped to verify the percentage$/, function (callback) {
        orchIOMapPage.assetTagSearchText();
        browser.sleep(5000);
        orchIOMapPage.assetTagBoxPlus().get(0).click();
        orchIOMapPage.inputTag().get(1).click();
        orchIOMapPage.assetTagBoxPlus().get(0).click();
        browser.sleep(1000);

        orchIOMapPage.percentRequired().getText().then(function (value2) {
            console.log("required % : " + value2);
            assert.equal(value2, "50 %", "Not same");
            orchIOMapPage.percentInputMapped().getText().then(function (value3) {
                console.log("Input mapped %: " + value3);
                assert.equal(value3, "50 %", "Not same");

                callback();
            });
        });


    });


    this.Then(/^all the tags are mapped to verify the percentage$/, function (callback) {

        browser.sleep(5000);
        orchIOMapPage.inputTag().get(2).click();
        orchIOMapPage.assetTagBoxPlus().get(0).click();
        orchIOMapPage.inputTag().get(3).click();
        orchIOMapPage.assetTagBoxPlus().get(0).click();
        browser.sleep(1000);
        orchIOMapPage.percentRequired().getText().then(function (value2) {
            console.log("required % : " + value2);
            assert.equal(value2, "100 %", "Not ea");
            orchIOMapPage.percentInputMapped().getText().then(function (value3) {
                console.log("Input mapped %: " + value3);
                assert.equal(value3, "100 %", "Not eq");

                callback();
            });
        });


    });


    this.Then(/^the first tag mapping is deleted$/, function (callback) {
        orchIOMapPage.inputTag().get(0).click();
        orchIOMapPage.deleteTag().click();
        callback();

    });

    this.Then(/^updated percentage is verified$/, function (callback) {
        orchIOMapPage.percentRequired().getText().then(function (value2) {
            console.log("required % : " + value2);
            assert.equal(value2, "75 %", "Not ea");
            callback();
        });
    });


    this.Then(/^tag is added by drag and drop$/, function (callback) {
        orchIOMapPage.inputTag().get(0).click().then(function () {
            console.log('________Dragging ');
            TestHelperPO.elementToBeClickable(orchIOMapPage.assetTagBox().get(0)).then(function () {
                TestHelperPO.elementToBeClickable(orchIOMapPage.inputTag().get(0)).then(function () {
                    console.log("Element clicked");
                    var ele = orchIOMapPage.assetTagBox().get(0);
                    var drop = orchIOMapPage.inputTag().get(0);
                    orchIOMapPage.inputTag().get(0).click();
                    console.log("Elements found");

                    TestHelperPO.dragAndDrop(ele, drop).then(function () {
                        console.log("Element dragged");
                        orchIOMapPage.percentRequired().getText().then(function (value2) {
                            console.log("required % : " + value2);
                            assert.equal(value2, "100 %", "Not ea");
                            callback();
                        });
                    });
                });
            });
        });
    });


    this.When(/^the constants are edited$/, function (callback) {
        browser.sleep(15000).then(function () {
            expect(orchIOMapPage.constantValue()).to.exist;
            orchIOMapPage.constantValue().get(0).getAttribute("value").then(function (value) {
                console.log("teh constant value is: " + value);
                orchIOMapPage.constantValue().get(0).click().clear().sendKeys('100');
                callback();
            });
        });
    });

    this.Then(/^the changes are seen$/, function (callback) {
        browser.sleep(5000);
        orchIOMapPage.constantValue().get(0).click();
        orchIOMapPage.constantValue().get(0).getAttribute("value").then(function (value) {
            console.log("teh constant value is: " + value);
            assert(value, "100");
            callback();
        });
    });


    this.When(/^tags are added to output$/, function (callback) {
        browser.sleep(5000);
        orchIOMapPage.outputValue().get(4).click();
        browser.sleep(5000);
        orchIOMapPage.assetTagSearchTextOutput();
        browser.sleep(5000);
        orchIOMapPage.assetTagBoxPlus().get(0).click();
        callback();

    });

    this.Then(/^the outputs are mapped$/, function (callback) {
        browser.sleep(5000);
        orchIOMapPage.outputValue().get(4).getText().then(function (value) {
            console.log("teh constant value is: " + value);
            callback();
        });
    });


    this.When(/^the IO mappings are saved$/, function (callback) {
        expect(orchIOMapPage.cancelButton()).to.exist;
        orchIOMapPage.saveButton().click().then(function () {
            expect(orchIOMapPage.saveButtonDisabled()).to.exist;
            callback();
        });

    });


    this.Then(/^the IO Map page is closed$/, function (callback) {
        //expect(orchIOMapPage.closeButton()).to.exist;
        browser.sleep(10000);
        TestHelperPO.isElementVisible(orchIOMapPage.closeButton());
        expect(orchIOMapPage.closeButton().isEnabled()).to.not.be.false;

        TestHelperPO.elementToBeClickable(orchIOMapPage.closeButton()).then(function () {
            expect(orchStepsPage.closeButtonRightCorner()).to.exist;
            callback();
        });
    });

    this.Then(/^the modal page is closed$/, function (callback) {
        expect(orchStepsPage.closeButtonRightCorner()).to.exist;
        orchStepsPage.closeButtonRightCorner().click();
        callback();
    });

    this.Then(/^user goes to IO Map page from Main page$/, function (callback) {
        expect(createOrchestrationPage.analyticBox()).to.exist;

        browser.sleep(10000).then(function () {
            browser.actions().mouseMove(element(by.css('.analytic-box'))).click().perform().then(function () {
                browser.sleep(10000);
                //expect(element(by.css('.analytic-hover-icon'))).to.exist;
                console.log("link is present");
                browser.sleep(10000);
                //element(by.css('.analytic-hover-icon')).click();
                // element(by.css('.analytic-close-icon')).click();
                expect(element(by.css('.fa.fa-external-link'))).to.exist;
                element(by.css('.fa.fa-external-link')).click();
                browser.sleep(5000);
                //browser.executeScript(element(by.css('.analytic-box').click())).then (function (){
                console.log("here IO Map>>>>>>>>>>");
                expect(orchIOMapPage.stepName()).to.exist;
                orchIOMapPage.stepName().getText().then(function (value) {
                    console.log("Name is " + value);
                    callback();
                });
            });
        });

    });


    this.Then(/^the values are seen$/, function (callback) {
        browser.sleep(10000);
        expect(orchIOMapPage.stepName()).to.exist;
        orchIOMapPage.stepName().getText().then(function (value) {
            console.log("Name is " + value);

            orchIOMapPage.percentRequired().getText().then(function (percent) {
                console.log("Verification required % : " + percent);
                assert(percent, "100 %");
            });

            orchIOMapPage.constantValue().get(0).getAttribute("value").then(function (constant) {
                console.log("the constant value is: " + constant);
                assert(constant, "100");
            });

            orchIOMapPage.outputValue().get(4).getText().then(function (op) {
                console.log("the output tag value is: " + op);
                assert(op, "AV_TAG_10");
                callback();
            });


        });


    });


    this.When(/^the user searches for orchestration name$/, function (callback) {
        browser.sleep(2000);
        createOrchestrationPage.searchOrchField().sendKeys("orchestration_1494408851618");
        //createOrchestrationPage.getCreatedOrchName()
        browser.sleep(2000);
        createOrchestrationPage.searchCount().then(function (value) {
            console.log("Count is >>" + value);


            browser.sleep(2000);
            createOrchestrationPage.firstOrchName().click();

            callback();
        });
    });


    this.When(/^the user clicks on iomap$/, function (callback) {

        expect(createOrchestrationPage.analyticBox()).to.exist;

        browser.sleep(10000).then(function () {
            browser.actions().mouseMove(element(by.css('.analytic-box'))).click().perform().then(function () {
                browser.sleep(10000);
                //expect(element(by.css('.analytic-hover-icon'))).to.exist;
                console.log("link is present");
                browser.sleep(10000);
                //element(by.css('.analytic-hover-icon')).click();
                // element(by.css('.analytic-close-icon')).click();
                expect(element(by.css('.fa.fa-external-link'))).to.exist;
                element(by.css('.fa.fa-external-link')).click();
                browser.sleep(5000);
                //browser.executeScript(element(by.css('.analytic-box').click())).then (function (){
                console.log("here IO Map>>>>>>>>>>");
                expect(orchIOMapPage.stepName()).to.exist;

                callback();
            });
        });
    });


    //IO Mappings
    this.When(/^the user clicks on the IOMap arrow$/, function (callback) {

        browser.sleep(5000);
        TestHelperPO.isElementPresent(orchIOMapPage.ioMapDropDown());
        orchIOMapPage.ioMapDropDown().click().then(function () {
            // TestHelperPO.isElementPresent(orchIOMapPage.ioMapItems().get(0));
            // TestHelperPO.isElementPresent(orchIOMapPage.ioMapItems().get(1));
            // TestHelperPO.isElementPresent(orchIOMapPage.removeDisabled());

            expect(orchIOMapPage.ioMapItems().get(0)).to.exist;
            expect(orchIOMapPage.ioMapItems().get(1)).to.exist;
            expect(orchIOMapPage.removeDisabled()).to.exist;


            orchIOMapPage.ioMapItems().get(0).getText().then(function (add) {
                console.log("iteration ADD : " + add);

                //orchIOMapPage.ioMapDropDown().click();

                callback();
            });
        });

    });

    this.Then(/^the Add Copy and Remove links are seen$/, function (callback) {

        orchIOMapPage.ioMapItems().get(0).getText().then(function (add) {
            console.log("iteration ADD : " + add);

            orchIOMapPage.ioMapItems().get(1).getText().then(function (copy) {
                console.log("iteration COPY : " + copy);

                orchIOMapPage.removeDisabled().getText().then(function (remove) {
                    console.log("iteration REMOVE : " + remove);

                    expect(orchIOMapPage.removeDisabled().isEnabled()).to.not.be.true;

                    orchIOMapPage.ioMapDropDown().click();

                    callback();
                });
            });
        });

    });


    this.When(/^the user clicks on Add Iteration$/, function (callback) {
        //browser.sleep(5000);
        // orchIOMapPage.ioMapDropDown().click().then(function(){

        // browser.sleep(5000);
        orchIOMapPage.ioMapItems().get(0).click().then(function () {
            expect(orchIOMapPage.ioMapsText()).to.exist;
            //check datapoints field is empty after adding iteration
            //expect(orchIOMapPage.iterationBox()).to.exist;
            callback();
        });
        // });

    });


    this.Then(/^the iteration is increased by one$/, function (callback) {

        browser.sleep(5000);
        orchIOMapPage.iterationBox().getAttribute("value").then(function (iterationIncrease) {
            console.log("iteration number :" + iterationIncrease);

            orchIOMapPage.ioMapsText().getText().then(function (Text) {
                console.log("iteration Text " + Text);
                //assert("2", iterationIncrease);

                callback();
            });

        });

    });

    // this.Then(/^the iteration is saved$/, function (callback) {
    //
    //     browser.sleep(1000).then(function() {
    //         expect(orchIOMapPage.saveButton()).to.exist;
    //         orchIOMapPage.saveButton().click();
    //
    //         callback();
    //     });
    // });

    this.Then(/^the iteration is closed to view Modal/, function (callback) {

        expect(orchIOMapPage.saveButtonDisabled()).to.exist;
        expect(orchIOMapPage.closeButton()).to.exist;

        TestHelperPO.elementToBeClickable(orchIOMapPage.closeButton());

        //orchIOMapPage.closeButton().click();

        callback();

    });


    this.Then(/^verify the iteration number in Modal Page$/, function (callback) {
        expect(orchIOMapPage.iterationIndicator()).to.exist;
        TestHelperPO.isElementPresent(orchIOMapPage.iterationIndicator());


        orchIOMapPage.iterationIndicator().getText().then(function (iter) {
            console.log("iteration in MODAL: " + iter);

            expect(orchStepsPage.closeButtonRightCorner()).to.exist;

            //TestHelperPO.elementToBeClickable(orchStepsPage.closeButtonRightCorner());

            callback();
        });

    });


    this.Then(/^verify the iteration number in Main Page$/, function (callback) {
        expect(orchIOMapPage.iterationIndicator()).to.exist;
        TestHelperPO.isElementPresent(orchIOMapPage.iterationIndicator());

        orchIOMapPage.iterationIndicator().getText().then(function (iter) {
            console.log("iteration : " + iter);

            callback();

        });
    });


    /*     this.Then(/^verify the iteration number in Main and Modal Page$/, function (callback) {
     browser.sleep(10000).then(function() {
     //expect(orchIOMapPage.closeButton()).to.exist;
     //  orchIOMapPage.closeButton().click();

     expect(orchIOMapPage.iterationIndicator()).to.exist;
     TestHelperPO.isElementPresent(orchIOMapPage.iterationIndicator());

     orchIOMapPage.iterationIndicator().getText().then(function (iter) {
     console.log("iteration : " + iter);

     browser.sleep(5000).then(function () {
     createOrchestrationPage.editIcon().click().then(function () {

     expect(orchIOMapPage.iterationIndicator()).to.exist;
     TestHelperPO.isElementPresent(orchIOMapPage.iterationIndicator());


     orchIOMapPage.iterationIndicator().getText().then(function (iter) {
     console.log("iteration : " + iter);

     expect(orchStepsPage.closeButtonRightCorner()).to.exist
     orchStepsPage.closeButtonRightCorner().click();
     callback();

     });
     });
     });
     });
     });
     });
     */


    this.When(/^the user clicks iteration left and right nav$/, function (callback) {

        TestHelperPO.isElementPresent(orchIOMapPage.iterationLeftArrow());
        expect(orchIOMapPage.iterationRightArrow().isEnabled()).to.be.not.true;

        orchIOMapPage.iterationLeftArrowClick().click().then(function () {
            callback();

        });
    });


    this.Then(/^the iteration number changes$/, function (callback) {

        orchIOMapPage.iterationBox().getAttribute("value").then(function (iterationIncrease) {
            console.log("iteration number after left click :" + iterationIncrease);

            orchIOMapPage.ioMapsText().getText().then(function (Text) {
                console.log("iteration Text after left click" + Text);
                expect(Text).to.contain('1 of 2');
                callback();
            });
        });

    });


    this.When(/^the user clicks on the Copy iteration$/, function (callback) {

        TestHelperPO.isElementPresent(orchIOMapPage.ioMapDropDown());

        orchIOMapPage.ioMapDropDown().click().then(function () {
            orchIOMapPage.ioMapItems().get(1).click();

            callback();
        });
    });


    this.Then(/^the new iteration is copied$/, function (callback) {
        browser.sleep(5000);
        orchIOMapPage.iterationBox().getText().then(function (iterationIncrease) {
            console.log("iteration number " + iterationIncrease);
            assert("3", iterationIncrease);

            orchIOMapPage.ioMapsText().getText().then(function (Text) {
                console.log("iteration Text " + Text);
                expect(Text).to.contain('3 of 3');

                callback();
            });

        });

    });

    this.When(/^the user clicks on the Remove iteration$/, function (callback) {
        orchIOMapPage.ioMapDropDown().click().then(function () {
            orchIOMapPage.ioMapItems().get(2).click();

            callback();
        });


    });


    this.Then(/^the iteration is removed$/, function (callback) {

        browser.sleep(5000);
        orchIOMapPage.iterationBox().getText().then(function (iterationIncrease) {
            console.log("iteration number " + iterationIncrease);
            assert("2", iterationIncrease);

            orchIOMapPage.ioMapsText().getText().then(function (Text) {
                console.log("iteration Text " + Text);
                //assert("2", iterationIncrease);

                callback();
            });

        });

    });

    //Step
    this.When(/^the user enters a value for step level data points and clicks out of box$/, function (callback) {
        expect(orchIOMapPage.dataPointsStepLevelInputBox()).to.exist;
        orchIOMapPage.dataPointsStepLevelInputBox().getAttribute("value").then(function (value) {
            console.log("the datapoints value is: " + value);
            orchIOMapPage.dataPointsStepLevelInputBox().click().clear().sendKeys("35").then (function () {
                orchIOMapPage.descriptionMapping().click().then (function () {

                    console.log("click out of data points");
                    callback();
                });
            });
        });
    });

    this.Then(/^the orchestration should be updated for step data points$/, function(callback) {

        browser.sleep(5000);
        orchIOMapPage.dataPointsStepLevelInputBox().click();
        orchIOMapPage.dataPointsStepLevelInputBox().getAttribute("value").then(function (value) {
            console.log("the data points value after updating is: " + value);
            assert(value, "35");
            callback();
        });
    });

    this.Then(/^the iteration data points should inherit from step level data points$/, function(callback) {

        browser.sleep(5000);
        expect(orchIOMapPage.dataPointsIterationLevelInputBox()).to.exist;
        orchIOMapPage.dataPointsIterationLevelInputBox().getAttribute("value").then(function (value) {
            console.log("the datapoints value is: " + value);
            orchIOMapPage.dataPointsIterationLevelInputBox().click().clear().sendKeys("35").then (function () {
                orchIOMapPage.descriptionMapping().click().then (function () {
                    console.log("click out of data points");
                    callback();
                });
            });
        });
    });

    //Iteration
    this.When(/^the user enters a value for iteration level data points and clicks out of box$/, function (callback) {
        expect(orchIOMapPage.dataPointsIterationLevelInputBox()).to.exist;
        orchIOMapPage.dataPointsIterationLevelInputBox().getAttribute("value").then(function (value) {
            console.log("the datapoints value is: " + value);
            orchIOMapPage.dataPointsIterationLevelInputBox().click().clear().sendKeys("55").then (function () {
                orchIOMapPage.descriptionMapping().click().then (function () {
                    console.log("click out of data points");
                    callback();
                });
            });
        });
    });

    this.Then(/^the orchestration should be updated for iteration data points$/, function(callback) {

        browser.sleep(5000);
        orchIOMapPage.dataPointsIterationLevelInputBox().click();
        orchIOMapPage.dataPointsIterationLevelInputBox().getAttribute("value").then(function (value) {
            console.log("the data points value after updating is: " + value);
            assert(value, "55");
            callback();
        });
    });

    //Port -- Enable when data points field is re-implemented
    /*
    this.When(/^the user enters a value for port level data points and clicks out of box$/, function (callback) {
        expect(orchIOMapPage.dataPointsPortLevelInputBox()).to.exist;
        orchIOMapPage.dataPointsPortLevelInputBox().getAttribute("value").then(function (value) {
            console.log("the datapoints value is: " + value);
            orchIOMapPage.dataPointsPortLevelInputBox().click().clear().sendKeys("75").then (function () {
                orchIOMapPage.descriptionMapping().click().then (function () {

                    console.log("click out of data points");
                    callback();
                });
            });
        });
    });

    this.Then(/^the orchestration should be updated for port data points$/, function(callback) {

        browser.sleep(5000);
        orchIOMapPage.dataPointsPortLevelInputBox().click();
        orchIOMapPage.dataPointsPortLevelInputBox().getAttribute("value").then(function (value) {
            console.log("the data points value after updating is: " + value);
            assert(value, "75");
            callback();
        });
    }); */
};
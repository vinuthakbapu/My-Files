(function () {

    var cafMgmtRestUtil = function() {

        const buffer = new Buffer('ingestor.496bb641-78b5-4a18-b1b7-fde29788db38.991e5c23-3e9c-4944-b08b-9e83ef0ab598:');
        const base64s = buffer.toString('base64');

        const adminUserOpts = {
            url: 'https://d1730ade-7c0d-4652-8d44-cb563fcc1e27.predix-uaa.run.aws-usw02-pr.ice.predix.io/oauth/token',
            headers:{
                'Authorization': 'Basic ' + base64s,
                'Content-Type': 'application/x-www-form-urlencoded'
            },
            body:{
                'grant_type' : 'password',
                'username' : 'futureadmirals-smokeuser',
                'password' : '*Pa55w0rD*'
            }
        };

        var svcHeaders =  {
            'Content-Type': 'application/json',
            'tenant':'b6e3a256-09aa-4230-93f7-d6c6c1481647',
            'Authorization':'bearer '
        };

        const mgmtSvcBaseUrl = 'https://caf-mgmt-svc-admirals-dev2.int-app.aws-usw02-pr.predix.io/v1'

        const entityFilterFieldsUrl = '/entityFilterFields';
        const entityFiltersUrl = '/entityFilters';

        const getServiceHeaders = function() {
            const defer = protractor.promise.defer();
            if(svcHeaders.Authorization === 'bearer '){
                RestHelper.getAccessToken(adminUserOpts.url, adminUserOpts.headers, adminUserOpts.body, function (error, token) {
                    if(error || !token) {
                        defer.reject('unable to retrieve token for caf management svc');
                    } else {
                        svcHeaders.Authorization = `bearer ${token}`;
                        defer.fulfill();
                    }
                })
            } else {
                defer.fulfill();
            }
            return defer.promise;
        };


        return {

            getAttributes: function() {
                const defer = protractor.promise.defer();
                getServiceHeaders().then(() => {
                    RestHelper.executeGetRequest(`${mgmtSvcBaseUrl}${entityFilterFieldsUrl}`, svcHeaders, function (error, response) {
                        if(!error) {
                            defer.fulfill(response.body);
                        } else {
                            defer.reject('unable to retrieve attributes from caf mgmnt svc');
                        }
                    })
                })
                return defer.promise;
            },

            deleteAttribute: function (attribute) {
                const defer = protractor.promise.defer();
                getServiceHeaders().then(() => {
                    RestHelper.executeDeleteRequest(`${mgmtSvcBaseUrl}${attribute.uri}`, svcHeaders, function (error, response) {
                        if(!error) {
                            defer.fulfill();
                        } else {
                            defer.reject(`unable to delete attribute with uri:${attribute.uri}`);
                        }
                    })
                })
                return defer.promise;
            },

            createAttributes: function(attributeArray) {
                const defer = protractor.promise.defer();
                getServiceHeaders().then(() => {
                    RestHelper.executePostRequest(`${mgmtSvcBaseUrl}${entityFilterFieldsUrl}`, svcHeaders, JSON.stringify(attributeArray), function(error, response) {
                        if(error) {
                            defer.reject('unable to get create attributes using caf management svc');
                        } else {
                            defer.fulfill(response.body);
                        }
                    })
                });
                return defer.promise;
            },

            getFilters: function() {
                const defer = protractor.promise.defer();
                getServiceHeaders().then(() => {
                    RestHelper.executeGetRequest(`${mgmtSvcBaseUrl}${entityFiltersUrl}`, svcHeaders, function (error, response) {
                        if(!error) {
                            defer.fulfill(response.body);
                        } else {
                            defer.reject('unable to retrieve attributes from caf mgmnt svc');
                        }
                    })
                })
                return defer.promise;
            },

            createFilters: function(filterArray) {
                const defer = protractor.promise.defer();
                getServiceHeaders().then(() => {
                    RestHelper.executePostRequest(`${mgmtSvcBaseUrl}${entityFiltersUrl}`, svcHeaders, JSON.stringify(filterArray), function(error, response) {
                        if(error) {
                            defer.reject('unable to get create filters using caf management svc');
                        } else {
                            defer.fulfill(response.body);
                        }
                    })
                });
                return defer.promise;
            },

            deleteFilter: function (filter) {
                const defer = protractor.promise.defer();
                getServiceHeaders().then(() => {
                    RestHelper.executeDeleteRequest(`${mgmtSvcBaseUrl}${filter.uri}`, svcHeaders, function (error, response) {
                        if(!error) {
                            defer.fulfill();
                        } else {
                            defer.reject(`unable to delete filter with uri:${filter.uri}`);
                        }
                    })
                })
                return defer.promise;
            },

        };
    };

    module.exports = new cafMgmtRestUtil();

}());




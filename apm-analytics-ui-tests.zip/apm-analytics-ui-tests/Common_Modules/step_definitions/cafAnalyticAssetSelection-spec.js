/**
 * Asset Selection spec
 */


module.exports = function () {

  var randVal = Date.now();
  var deploymentName = 'deployment-';

  this.Given(/^the caf user is on the asset selection tab$/, function(callback) {
    cafAssetSelectionPage.visibilityOf(cafAssetSelectionPage.assetSelectionBreadcrumb()).then(function() {
      callback();
    });
  });

  this.Then(/^the caf user clicks the asset selection breadcrumb$/, function(callback) {
    cafAssetSelectionPage.assetSelectionBreadcrumb().click().then(function() {
      callback();
    });
  });

  this.Then(/^Asset Selection page should be displayed$/, function (callback) {
      cafAssetSelectionPage.assetFiltersHeader().isDisplayed().then (function(visible){
          expect(visible).to.equal(true);
          console.log("asset selection page is displayed")
          callback();
      });
    });

  this.Then(/^caf Asset Selection panel should be displayed$/, function (callback) {
    cafAssetSelectionPage.visibilityOf(cafAssetSelectionPage.closeDeployment()).then(function () {
      cafAssetSelectionPage.closeDeployment().isDisplayed().then(function (visible) {
        expect(visible).to.equal(true);
        callback();
      });
    });
  });

  this.When(/^caf user click the submit button to create deployment$/, function (callback) {
    cafAssetSelectionPage.newDeploymentSubmit().click().then(function () {
      callback();
    });
  });

  this.When(/^cafUser clicks on the close deployment button$/, function (callback) {
    cafAssetSelectionPage.closeDeployment().click().then(function() {
        browser.sleep(2000).then(function() {
            callback();
        });
    });
  });

  this.Then(/^the cafUser clicks dont save button$/, function(callback) {
    browser.sleep(2000).then(function() {
      cafAssetSelectionPage.dontSaveButton().click().then(function () {
        callback();
      });
    });
  });

  this.Then(/^the cafUser clicks the asset selection save button$/, function(callback){
    cafAssetSelectionPage.saveButton().click().then(function () {
        browser.sleep(3000).then(function() {
            callback();
        });
    });
  });

  this.When(/^caf user enters a new deployment name "([^"]*)"$/, function (arg1, callback) {
    deploymentName = arg1 + randVal;
    cafAssetSelectionPage.getDeplpoymentNameInput().sendKeys(deploymentName).then(function () {
      callback();
    });
  });

  this.Then(/^a dialog is displayed to enter the name$/, function (callback) {
    cafAssetSelectionPage.deploymentName().isDisplayed().then(function (visible) {
      expect(visible).to.equal(true);
      callback();
    });
  });

  this.When(/^caf user clicks on the add icon to create a deployment$/, function (callback) {
    cafAssetSelectionPage.addDeployment().click().then(function () {
      browser.sleep(2000).then(function () {
        callback();
      });
    });
  });

  this.Given(/^the caf user is already on the Analytic Deployment tab$/, function (callback) {
    cafAssetSelectionPage.getDeployment();
    browser.sleep(3000).then(function () {
      callback();
    })
  });

  this.Given(/^caf user clicks the newly created deployment config and lands on Asset Selection page$/, function (callback) {
    cafAssetSelectionPage.existingDeploymentByName(deploymentName).click().then(function () {
      browser.sleep(3000).then(function () {
        callback();
      })
    });
  });

  this.Then(/^caf Analytic Asset Group filter drop down should be displayed$/, function (callback) {
    cafAssetSelectionPage.getAssetFilter().isDisplayed().then(function (bool) {
      assert.equal(bool, true, 'asset groups filter is displayed');
      callback();
    });
  });

  // this.Then(/^edit icon is displayed next to selected deployment name$/, function (callback) {
  //   browser.sleep(2000);
  //   assetSelectionPage.mouseOverAssetTitle().then(function () {
  //     browser.sleep(3000).then(function () {
  //       assetSelectionPage.isEditIconDisplayed().then(function (bool) {
  //         assert.equal(bool, true, 'edit icon is displayed');
  //         callback();
  //       });
  //     });
  //   });
  // });

  this.Then(/^caf user selects an option GE90 from Analytic Asset Group dropdown$/, function (callback) {
    cafAssetSelectionPage.getAssetFilter().click().then(function () {
      browser.sleep(1000).then(function () {
        cafAssetSelectionPage.assetFilterValue().click().then(function () {
          cafAssetSelectionPage.getSearchButton().click().then(function () {
            browser.sleep(5000).then(function () {
              callback();
            });
          });
        });
      })
    });
  });

  this.Then(/^the Next button on caf asset selection page gets enabled$/, function (callback) {
    cafAssetSelectionPage.getNextButton().isEnabled().then(function () {
      callback();
    });
  });

  this.Then(/^the Asset Selection tab should be highlighted$/, function(callback) {
    cafAssetSelectionPage.getNavigationTabs().element(by.css('.apm-dp-breadcrumb-active')).getInnerHtml().then(function(tab){
      assert.include(tab, 'Asset Selection');
      callback();
    });
  });

  this.Then(/^the caf IO Mapping tab gets enabled$/, function (callback) {
    assert.isDefined(cafAssetSelectionPage.getNavigationTabs().element(by.css('.apm-dp-breadcrumb-inactive')));
    callback();
  });

  this.Then(/^the caf deploy button is disabled$/, function (callback) {
    cafAssetSelectionPage.getDeployButton().isEnabled().then(function (flag) {
      assert.equal(flag, false, 'Deploy button is disabled');
      callback();
    });
  });

  this.Then(/^the caf deploy button is enabled$/, function (callback) {
    cafAssetSelectionPage.getDeployButton().isEnabled().then(function (flag) {
      assert.equal(flag, true, 'Deploy button is disabled');
      callback();
    });
  });

  this.When(/^caf user clicks on the Next button$/, function (callback) {
    cafAssetSelectionPage.clickNextButton().then(function () {
      browser.sleep(2000).then(function () {
          callback();
      })

    });
  });

  this.Then(/^caf user clicks on the Prev button$/, function (callback) {
    browser.sleep(5000).then(function () {
      cafAssetSelectionPage.getPrevButton().then(function () {
        browser.sleep(5000).then(function () {
          callback();
        });
      });
    });
  });

  this.Then(/^caf Analytics header text should be displayed$/, function (callback) {
    var headerElem = cafAssetSelectionPage.getAnalyticHeader();
    headerElem.isDisplayed().then(function (flag) {
      assert.equal(flag, true, 'label is displayed');
        callback();
    });
  });

  this.Then(/^the caf deployment name should be displayed$/, function (callback) {
    var titleElem = cafAssetSelectionPage.getAnalyticHeader();
    titleElem.isDisplayed().then(function (flag) {
      assert.equal(flag, true, 'label is displayed');
      titleElem.getText().then(function (text) {
        assert.include(text, deploymentName, 'deployment name displays');
        callback();
      });
    });
  });

  this.Then(/^the caf deployment status should be displayed as Not Deployed$/, function (callback) {
    browser.sleep(5000).then(function () {
      cafAssetSelectionPage.getAnalyticStatusHeader().getText().then(function (text) {
        assert.include(text, 'Not Deployed', 'label contains "Not Deployed"');
        callback();
      });
    });
  });

  this.Then(/^the caf saved date should be displayed$/, function (callback) {
    cafAssetSelectionPage.getAnalyticHeader().getText().then(function (text) {
      var time = new Date(text.split(' ')[1]);
      assert.isNumber(time.getTime(), 'label contains date');
      callback()
    });
  });

  this.When(/^caf user mouse hover on the deployment name$/, function (callback) {
    cafAssetSelectionPage.mouseOverAssetTitle().then(function () {
      browser.sleep(3000).then(function () {
        callback();
      });
    });
  });

  this.When(/^the edit icon should be displayed next to the caf deployment name$/, function (callback) {
    cafAssetSelectionPage.getEditIcon().isDisplayed().then(function (bool) {
      assert.equal(bool, true, 'edit icon is displayed');
      callback();
    });
  });

  this.When(/^the caf user clicks on the deployment name edit icon$/, function (callback) {
    cafAssetSelectionPage.getEditIcon().click().then(function (bool) {
      callback();
    });
  });

  this.When(/^a caf text input field should be displayed$/, function (callback) {
    cafAssetSelectionPage.getDeploymentNameInputField().isDisplayed().then(function (flag) {
      assert.equal(flag, true, 'input field is displayed');
      callback();
    });
  });

  this.When(/^the caf user enters a new deployment name$/, function (callback) {
    cafAssetSelectionPage.getDeploymentNameInputField().sendKeys('123');
    callback();
  });

  this.When(/^the caf deployment name should be updated$/, function (callback) {
    cafAssetSelectionPage.getDeploymentNameInputField().getAttribute('value').then(function (value) {
      assert.include(value, '123', 'label contains "123"');
      callback();
    });
  });

  this.Then(/^the caf close button is showing$/, function (callback) {
    cafAssetSelectionPage.getCloseButton().isDisplayed().then(function (flag) {
      assert.equal(flag, true, 'Close button is displayed');
      callback();
    });
  });

  this.Then(/^caf Asset selection link should be active$/, function (callback) {
    cafAssetSelectionPage.getNavigationTabs().get(0).getText().then(function (val) {
      assert.equal(val, '1. Asset Selection');
      callback();
    });
  });

  this.Then(/^caf IO mapping, schedule, Review links should not be clickable and greyed out$/, function (callback) {
    cafAssetSelectionPage.getNavigationTabs().count().then(function (val) {
      assert.equal(val, 1);
      callback();
    });
  });

  this.Then(/^caf Prev and Next buttons should be disabled$/, function (callback) {
    cafAssetSelectionPage.getNextButton().isEnabled().then(function (flag) {
      assert.equal(flag, false, 'Next Btn disabled');
      cafAssetSelectionPage.getPrevButton().isEnabled().then(function (flag) {
        assert.equal(flag, false, 'Prev Btn disabled');
        callback();
      });
    });
  });

  this.Then(/^caf Next button should be disabled$/, function (callback) {
    cafAssetSelectionPage.nextButton().isEnabled().then(function (flag) {
      assert.equal(flag, false, 'Next Btn disabled');
      callback();
    });
  });

  this.Then(/^caf reset button should be disabled$/, function (callback) {
    cafAssetSelectionPage.resetButton().isEnabled().then(function (flag) {
      assert.equal(flag, false, 'Reset Btn disabled');
      callback();
    });
  });

  this.Then(/^caf save button should be disabled$/, function (callback) {
    cafAssetSelectionPage.saveButton().isEnabled().then(function (flag) {
      assert.equal(flag, false, 'Save Btn disabled');
      callback();
    });
  });

  this.Then(/^caf user take "([^"]*)" milliseconds break$/, function (arg1, callback) {
    browser.sleep(parseInt(arg1)).then(function () {
      callback();
    });
  });

  this.When(/^caf user clicks on the close button to close the deployment$/, function (callback) {
    cafAssetSelectionPage.elementToBeClickable(cafAssetSelectionPage.closeDeployment()).then(function () {
      browser.sleep(5000).then(function () {
        cafAssetSelectionPage.closeDeployment().click().then(function () {
          //cafAssetSelectionPage.visibilityOf(cafAssetSelectionPage.existingDeploymentByName(deploymentName));
          callback();
        });
      });
    });
  });

  this.Then(/^the closed caf deployment record should be displayed$/, function (callback) {
    cafAssetSelectionPage.existingDeploymentByName(deploymentName).getText().then(function (value) {
      expect(value).to.contains(deploymentName);
      callback();
    });
  });

  this.Then(/^the caf delete icon should be displayed beside the item$/, function (callback) {
    cafAssetSelectionPage.deleteDeploymentIcon().isDisplayed().then(function (visible) {
      expect(visible).to.equal(true);
      callback();
    });
  });

  this.Then(/^delete the newly created caf deployment$/, function (callback) {
    cafAssetSelectionPage.deleteDeploymentIcon().click().then(function () {
      cafAssetSelectionPage.deleteActionConfirm().click().then(function () {
        callback();
      });
    });
  });

  this.Then(/^caf Asset Filters label should be displayed$/, function (callback) {
    cafAssetSelectionPage.getAssetFilterLabelElem().isDisplayed().then(function (flag) {
      assert.equal(flag, true, 'label is displayed');
      cafAssetSelectionPage.getAssetFilterLabelElem().getText().then(function(text) {
        assert.equal(text, 'ASSET FILTERS', 'label is asset filters');
        callback();
      });
    });
  });

  this.Then(/^caf user selects an filter GE90 from Asset filter dropdown$/, function (callback) {
    cafAssetSelectionPage.getAssetFilter().click().then(function () {
      browser.sleep(1000).then(function () {
        cafAssetSelectionPage.assetFilterValue('GE90').click().then(function () {
          callback();
        });
      });
    });
  });

    this.Then(/^caf user selects an filter "([^"]*)" from Asset filter dropdown$/, function (arg1, callback) {
        cafAssetSelectionPage.getAssetFilter().click().then(function () {
            browser.sleep(1000).then(function () {
                cafAssetSelectionPage.assetFilterValue(arg1).click().then(function () {
                    callback();
                });
            });
        });
    });

  this.Then(/^the cafUser deselects all assets$/, function (callback) {
    cafAssetSelectionPage.getSelectAllCheckbox().click().then(function () {
      callback();
    });
  });

  this.Then(/^user filters edge assets$/, function (callback) {
    cafAssetSelectionPage.assetSelectionFilterSearch().click().then(function () {
      cafAssetSelectionPage.assetSelectionFilterSearch().sendKeys('case4_asset1').then(function () {
        callback();
      });
    });
  });
  
  this.Then(/^user filters for "([^"]*)" in assets table$/, function (arg1, callback) {
    cafAssetSelectionPage.assetSelectionFilterSearch().click().then(function () {
      cafAssetSelectionPage.assetSelectionFilterSearch().sendKeys(arg1).then(function () {
        callback();
      });
    });
  });

  this.Then(/^the cafUser selects the first asset from assets table$/, function (callback) {
    cafAssetSelectionPage.clickFirstAsset().then(function() {
      // cafAssetSelectionPage.clickSecondAsset().then(function() {
      //   cafAssetSelectionPage.clickThirdAsset().then(function() {
          callback();
      //   });
      // });
    });
  });

  this.Then(/^caf user deselects the invalid asset$/, function (callback) {
    cafAssetSelectionPage.clickThirdAsset().then(function() {
      callback();
    });
  });

  this.Then(/^caf user selects the Asset Name filter$/, function (callback) {
    cafAssetSelectionPage.getAssetFilter().click().then(function () {
      browser.sleep(1000).then(function () {
        cafAssetSelectionPage.assetFilterValue('Asset Name').click().then(function () {
          callback();
        });
      });
    });
  });

  this.Then(/^caf user clicks on the search button$/, function (callback) {
    cafAssetSelectionPage.getSearchButton().click().then(function () {
      browser.waitForAngular();
        callback();

    });
  });

  this.Then(/^cafUser search asset by "([^"]*)" search condition$/, function (assetName,callback) {
    cafAssetSelectionPage.getAssetFilterAttributeSearchBox().click().sendKeys(assetName+protractor.Key.ENTER).then(function(){
      callback();
    });
  });

  this.Then(/^all the caf assets should be displayed$/, function (callback) {
    browser.sleep(3000).then(function () {
      cafAssetSelectionPage.getAssetTableRows().count().then(function (value) {
        expect(value).to.be.above(0);
        callback();
      });
    });
  });

  this.Then(/^all the smart signal assets should be displayed$/, function (callback) {
      browser.sleep(5000).then(function () {
          cafAssetSelectionPage.getFirstAssetTableRow().getText().then(function (name) {
              // console.log("this is the asset table row", name)
              expect(name).to.equal("ASCIITESTAsset139_VSG_NAN_OUTLIER_ADAPTATION_Markers_Asset_ForAPM");
              callback();
          });
      });
  });

  this.Then(/^error message is displayed "Select a maximum of 20 items"$/, function (callback) {
    cafAssetSelectionPage.getSelectedMax20assets().getText().then(function (text) {
      expect(text).to.equal('Select a maximum of 20 items');
      callback();
    });
  });

  this.Then(/^save button is disabled$/, function (callback) {
    cafAssetSelectionPage.saveButton().isEnabled().then(function (flag) {
      assert.equal(flag, false, 'Save button is disabled');
      callback();
    });
  });

  this.Then(/^save button is enabled$/, function (callback) {
    cafAssetSelectionPage.saveButton().isEnabled().then(function (flag) {
      assert.equal(flag, true, 'Save button is enabled');
      callback();
    });
  });


  this.Then(/^all the caf GE90 assets should be displayed$/, function (callback) {
    browser.sleep(35000).then(function () {
      cafAssetSelectionPage.getAssetTableRows().count().then(function (value) {
        expect(value).to.equal(4);
        callback();
      });
    });
  });

    this.Then(/^only (\d+) assets should be displayed$/, function (arg1, callback) {
        cafAssetSelectionPage.getAssetTableRows().count().then(function (value) {
            expect(value).to.equal(3);
            callback();
        });
    });

  this.Then(/^the caf text ASSETS 4 of 4 SELECTED should be displayed$/, function (callback) {
    cafAssetSelectionPage.getSelectedNumber().getText().then(function (text) {
      expect(text).to.equal('RESULTS FOR GE90 (4/4)');
      callback();
    });
  });

  this.Then(/^the caf text for search results should be displayed$/, function (callback) {
    cafAssetSelectionPage.getSelectedNumber().getText().then(function (text) {
      expect(text).to.equal('RESULTS FOR GE90 (4/4)');
      callback();
    });
  });

  this.Then(/^caf results table title should be "Results for All Assets"$/, function (callback) {
    cafAssetSelectionPage.getTableTitle().then(function (text) {
      expect(text).to.equal('RESULTS FOR ALL ASSETS (7/7)');
      callback();
    });
  });

  this.Then(/^caf results table title should be "Results for GE90, turbine"$/, function (callback) {
    cafAssetSelectionPage.getTableTitle().then(function (text) {
      expect(text).to.equal('RESULTS FOR : GE90, TURBINE (0/0)');
      callback();
    });
  });

  this.Then(/^caf results table title should be "Results for GE90: GE90, turbine"$/, function (callback) {
    cafAssetSelectionPage.getTableTitle().then(function (text) {
      expect(text).to.equal('RESULTS FOR GE90: GE90, TURBINE (0/0)');
      callback();
    });
  });

  this.Then(/^caf results table title should be "Results for GE90"$/, function (callback) {
    cafAssetSelectionPage.getTableTitle().then(function (text) {
      expect(text).to.equal('RESULTS FOR GE90 (4/4)');
      callback();
    });
  });

  this.Then(/^the caf text ASSETS 3 of 4 SELECTED should be displayed$/, function (callback) {
    cafAssetSelectionPage.getSelectedNumber().getText().then(function (text) {
      expect(text).to.equal('RESULTS FOR GE90 (3/4)');
      callback();
    });
  });

  this.Then(/^the caf text "([^"]*)" should be displayed after search$/, function (arg1, callback) {
    cafAssetSelectionPage.getSelectedNumberAfterSearch().getText().then(function (text) {
      expect(text).to.equal('4');
      callback();
    });
  });

  this.Then(/^caf user enters the search term "([^"]*)" in the search bar$/, function (arg1, callback) {
    cafAssetSelectionPage.getAssetTableFilterInputField().sendKeys(arg1).then(function () {
      callback();
    });
  });

  this.Then(/^caf user clicks on the close icon in the search bar$/, function (callback) {
    cafAssetSelectionPage.getAssetTableFilterClearIcon().click().then(function () {
      callback();
    });
  });

  this.Then(/^the caf search term in the search bar should be removed$/, function (callback) {
    cafAssetSelectionPage.getAssetTableFilterInputField().getAttribute('value').then(function (value) {
      expect(value).to.equal('');
      callback();
    });
  });

  this.Then(/^caf user enters the search term Asset Name=(\d+) in attribute search box$/, function (arg1, callback) {
    cafAssetSelectionPage.getAssetFilterAttributeSearchBox().click().then(function() {
      cafAssetSelectionPage.getAssetFilterAttributeSearchBox().sendKeys('Asset Name=' + arg1 + protractor.Key.ENTER).then(function(){
        callback();
      });
    });
  });

  this.Then(/^caf user enters the search term Asset Name=(.+) model=([A-Z a-z]+) in attribute search box$/, function (arg1, arg2, callback) {
    cafAssetSelectionPage.getAssetFilterAttributeSearchBox().click().then(function() {
      cafAssetSelectionPage.getAssetFilterAttributeSearchBox().sendKeys('Asset Name=' + arg1 + protractor.Key.ENTER +
          'model=' + arg2 + protractor.Key.ENTER).then(function(){
        callback();
      });
    });
  });

  this.When(/^caf user clicks on the close icon in the search term$/, function (callback) {
    cafAssetSelectionPage.getAttributeNameTermCloseIcon().click().then(function () {
      callback();
    });
  });

  this.Then(/^the caf search term in the attribute search box should be removed$/, function (callback) {
    cafAssetSelectionPage.getAttributeNameTermCloseIcon().isPresent().then(function (flag) {
      expect(flag).to.equal(false);
      callback();
    });
  });

  this.Then(/^the deleted caf deployment config should not appear$/, function (callback) {
    cafAssetSelectionPage.existingDeploymentByName(deploymentName).isPresent().then(function (value) {
      expect(value).to.equal(false);
      callback();
    });
  });

  this.Then(/^the caf link "([^"]*)" should be displayed$/, function (arg1, callback) {
    cafAssetSelectionPage.getLabeledLink(arg1).isDisplayed().then(function (val) {
      expect(val).to.equal(true);
      callback();
    });
  });

  this.When(/^caf user clicks on the link "([^"]*)"$/, function (arg1, callback) {
    cafAssetSelectionPage.getLabeledLink().click().then(function () {
      browser.sleep(500).then(function () {
        callback();
      });
    });
  });

    this.Then(/^the right caf asset should be displayed in search results$/, function (callback) {
        cafAssetSelectionPage.getAssetTableRows().count().then(function (value) {
            expect(value).to.equal(1);
            callback();
        });
    });

    this.When(/^caf user unselect the first item from asset table$/, function (callback) {
        cafAssetSelectionPage.getCheckedCheckboxesFromAssetTable().get(1).click().then(function () {
            browser.sleep(1000).then(function () {
                callback();
            });
        });
    });

    this.When(/^caf user selects the first item from asset table$/, function (callback) {
      cafAssetSelectionPage.getCheckboxsFromAssetTable().get(0).click().then(function () {
        browser.sleep(1000).then(function () {
            callback();
        });
      });
    });

    this.Then(/^all caf GE90 assets should be checked by default$/, function (callback) {
        cafAssetSelectionPage.getCheckedCheckboxesFromAssetTable().count().then(function (value) {
            expect(value).to.equal(4);
            callback();
        });
    });

  this.Then(/^the caf asset table should have (\d+) items checked$/, function (arg1, callback) {
    cafAssetSelectionPage.getCheckedCheckboxesFromAssetTable().count().then(function (count) {
      expect(count).to.equal(parseInt(arg1));
      callback();
    });
  });

  this.When(/^caf user checks the "([^"]*)" checkbox$/, function (arg1, callback) {
    cafAssetSelectionPage.getSelectAllCheckbox().click().then(function () {
      browser.sleep(500).then(function () {
        callback();
      });
    });
  });

  this.Then(/^delete the current caf analytic$/, function (callback) {
    cafAssetSelectionPage.deleteAnalyticButton().click().then(function () {
      cafAssetSelectionPage.deleteActionConfirm().click().then(function () {
        callback();
      });
    });
  });

  this.Then(/^caf IO Mapping screen should be displayed$/, function (callback) {
    cafAssetSelectionPage.ioMappingContainer().isDisplayed().then(function (flag) {
      assert.equal(flag, true, 'label is displayed');
      callback();
    })
  });

};

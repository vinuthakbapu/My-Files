/**
 * Create Analytic spec
 */

//var obj = {};

//obj.analyticName = '';

module.exports = function () {

    var dropDownValue;
    //var analyticName;

    this.When(/^the caf user chooses schedule from the breadcrumbs$/, function (callback) {
        cafSchedulePage.breadcrumbScheduleTab().click().then(function () {
            callback();
        })
    });

    this.Given(/^the caf user is on the on demand schedule screen$/, function (callback) {
        browser.sleep(10000).then(function () {
            cafSchedulePage.deploymentNameHeader().isDisplayed().then(function (visible) {
                expect(visible).to.equal(true);
                cafDeploymentPage.deploymentName().click().then(function () {
                    browser.sleep(10000).then(function () {
                        cafDeploymentPage.elementToBeClickable(cafDeploymentPage.closeDeployment()).then(function () {
                            browser.sleep(10000).then(function () {
                                cafDeploymentPage.deploymentNextButton().isDisplayed().then(function (visible) {
                                    expect(visible).to.equal(true);
                                    cafDeploymentPage.deploymentNextButton().click().then(function () {
                                        console.log('IO mapping page');
                                        browser.sleep(10000).then(function () {
                                            cafDeploymentPage.deploymentNextButton().isDisplayed().then(function (visible) {
                                                expect(visible).to.equal(true);
                                                cafDeploymentPage.deploymentNextButton().click().then(function () {
                                                    callback();
                                                });

                                            });
                                        });
                                    });

                                });
                            });
                        });
                    });
                });
            });
        });
    });

    this.When(/^the caf user is on the schedule screen$/, function (callback) {
        cafSchedulePage.titleHeader().getText().then(function (text) {
            expect(text).to.equal('SCHEDULE');
            callback();
        });
    });

    this.Given(/^caf from and to dates are displayed$/, function (callback) {
        cafSchedulePage.visibilityOf(cafSchedulePage.timespanTo());
        cafSchedulePage.timespanTo().isDisplayed().then(function (value) {
            expect(value).to.equal(true);
            callback();
        });
    });

    this.When(/^the caf user clicks on the Interpolated radio button/, function (callback) {
        cafSchedulePage.interpolatedOption().click().then(function () {
            callback();
        });
    });

    this.Then(/^the caf Run Once Sampling Interval text box are displayed$/, function (callback) {
        cafSchedulePage.samplingIntervalRunOnce().isDisplayed().then(function (visible) {
            expect(visible).to.equal(true);
            callback();
        });
    });

    this.Then(/^the caf Recurrent Sampling Interval text box are displayed$/, function (callback) {
        cafSchedulePage.samplingIntervalRecurrent().isDisplayed().then(function (visible) {
            expect(visible).to.equal(true);
            callback();
        });
    });

    this.Given(/^caf drop down is displayed next to text box$/, function (callback) {
        cafSchedulePage.samplingInterval().isDisplayed().then(function (value) {
            expect(value).to.equal(true);
            callback();
        });
    });

    this.Given(/^the caf default value in the sampling interval text box is (\d+)$/, function (arg1, callback) {
        cafSchedulePage.samplingInterval().getText().then(function (value) {
            expect(value).to.equal(arg1);
            callback();
        });
    });

    this.When(/^caf user enters the date$/, function (callback) {
        cafSchedulePage.timespanFrom().sendKeys(new Date()).then(function () {
            callback();
        });
    });

    this.Then(/^caf Schedule tab should be highlighted$/, function (callback) {
        cafAssetSelectionPage.getNavigationTabs().element(by.css('.apm-dp-breadcrumb-active')).getInnerHtml().then(function (tab) {
            assert.include(tab, 'Schedule');
            callback();
        });
    });

    this.Then(/^the caf schedule Prev button gets enabled$/, function (callback) {
        cafDeploymentPage.getPrevButton().isDisplayed().then(function (visible) {
            expect(visible).to.equal(true);
            cafDeploymentPage.getPrevButton().click().then(function () {
                callback();
            });
        });
    });

    this.Then(/^the caf user clicks the schedule breadcrumb$/, function (callback) {
        cafSchedulePage.scheduleBreadcrumb().click().then(function () {
            browser.sleep(3000);
            callback();
        });
    });

    this.Then(/^schedule breadcrumb should be enabled$/, function (callback) {
        cafSchedulePage.scheduleBreadcrumb().isEnabled().then(function(enabled) {
            expect(enabled).to.equal(true);
            callback();
        });
    });

    this.When(/^the caf user clicks the Recurrent radio button$/, function (callback) {
        cafSchedulePage.scheduleRecurrent().click().then(function () {
            callback();
        });
    });

    this.When(/^the caf user clicks the Streaming radio button$/, function (callback) {
        cafSchedulePage.scheduleStreaming().click().then(function () {
            callback();
        });
    });

    this.Then(/^the caf Repeat Every text box and drop down fields are displayed$/, function (callback) {
        cafSchedulePage.repeatEveryValue().isDisplayed().then(function (visible) {
            expect(visible).to.equal(true);
            cafSchedulePage.repeatEveryDropDown().isDisplayed().then(function (visible) {
                expect(visible).to.equal(true);
                callback();
            });
        });
    });

    this.Then(/^the caf offset text box and drop down fields are displayed$/, function (callback) {
        cafSchedulePage.offSet().isDisplayed().then(function (visible) {
            expect(visible).to.equal(true);
            cafSchedulePage.offSetDropDown().isDisplayed().then(function (visible) {
                expect(visible).to.equal(true);
                callback();
            });
        });
    });

    this.Then(/^the caf Sample Duration text box and dropdown fields are displayed$/, function (callback) {
        cafSchedulePage.sampleDurationValue().isDisplayed().then(function (visible) {
            expect(visible).to.equal(true);
            cafSchedulePage.sampleDurationDropDown().isDisplayed().then(function (visible) {
                expect(visible).to.equal(true);
                callback();
            });
        });
    });

    this.Then(/^the caf Sampling Interval text box and dropdown fields are displayed$/, function (callback) {
        cafSchedulePage.sampleIntervalValue().isDisplayed().then(function (visible) {
            expect(visible).to.equal(true);
            cafSchedulePage.sampleIntervalDropDown().isDisplayed().then(function (visible) {
                expect(visible).to.equal(true);
                callback();
            });
        });
    });

    this.Then(/^caf user changes the sampling interval$/, function (callback) {
        cafSchedulePage.sampleIntervalValue().sendKeys('2').then(function () {
            callback();
        });
    });

    this.Then(/^caf user changes the sampling duration$/, function (callback) {
        cafSchedulePage.sampleDurationValue().clear();
        cafSchedulePage.sampleDurationValue().sendKeys('2').then(function () {
            callback();
        });
    });

    this.Then(/^user selects the value minutes from the drop down$/, function (callback) {
        cafSchedulePage.sampleDurationDropDown().click().then(function () {
            browser.sleep(1000).then(function () {
                cafSchedulePage.minutesValue().click().then(function () {
                    callback();
                });
            });
        })
    });

    this.Then(/^user selects the value seconds from the drop down$/, function (callback) {
        cafSchedulePage.sampleDurationDropDown().click().then(function () {
            browser.sleep(1000).then(function () {
                cafSchedulePage.secondsValue().click().then(function () {
                    callback();
                });
            });
        })
    });


    this.Then(/^caf user adds data points to IO Mapping$/, function (callback) {
        cafIOMappingPage.analyticDataPointsInput().sendKeys('3').then(function () {
            cafIOMappingPage.dataflowRadioButton().click().then(function () {
                callback();
            });
        });
    });

    this.Then(/^caf user clicks iomapping save$/, function (callback) {
        cafIOMappingPage.saveButton().click().then(function () {
            browser.sleep(2000).then(function () {
                callback();
            });
        });
    });

    this.Then(/^caf user clicks schedule save$/, function (callback) {
        cafSchedulePage.saveButton().click().then(function () {
            callback();
        });
    });

    this.Then(/^verify the elements under the schedule section in power fabric runtime$/, function (callback) {
        cafSchedulePage.powerFabricScheduleOptions().getText().then(function (text) {
            cafSchedulePage.retryUponFailureLbl().getText().then(function (text1) {
                expect(text.toString()).to.equal('Start Time,Repeats Every,Execution Time Zone')
                expect(text1).to.equal('Retry Upon Failure');
                callback();
            });
        });
    });

    this.Then(/^verify all the tooltips under schedule section$/, function (callback) {
        cafSchedulePage.powerFabrictooltipBtns().then(function (btn) {
            btn[0].click().then(function () {
                cafSchedulePage.powerFabrictooltipContents().then(function (tool1) {
                    tool1[0].getText().then(function (ele) {
                        expect(ele).to.equal('Analytic schedule will start immediately. No preference for a specific analytic time')
                        btn[1].click().then(function () {
                            tool1[1].getText().then(function (ele1) {
                                expect(ele1).to.equal('Use to run a simulation as if it were live data (e.g. a year ago)')
                                btn[2].click().then(function () {
                                    tool1[2].getText().then(function (ele2) {
                                        expect(ele2).to.equal('Time zone that analytic execution takes place.')
                                        btn[3].click().then(function () {
                                            tool1[3].getText().then(function (ele3) {
                                                expect(ele3).to.equal('Boolean for schedule progression upon analytic execution failure')

                                                callback();
                                            });

                                        });
                                    });
                                });
                            });
                        });
                    });
                });

            });
        });
    });

    this.Then(/^verify the default values for the schedule fields$/, function (callback) {
        cafSchedulePage.powerFabricDropdowns().then(function (inline) {
            inline[0].getAttribute('value').then(function (startTime) {
                expect(startTime).to.equal('Next Available')
                inline[1].getAttribute('value').then(function (repeatsEvery) {
                    expect(repeatsEvery).to.equal('MINUTES')
                    inline[2].getAttribute('value').then(function (timeZone) {
                        expect(timeZone).to.equal('Site Local')
                        cafSchedulePage.scheduleDefaultTextBoxes().then(function (val) {
                            val[0].getAttribute('value').then(function (repeatValue) {
                                expect(repeatValue).to.equal('30')
                                cafSchedulePage.retryUponFailureDiv().getInnerHtml().then(function (retryUponFailure) {
                                    expect(retryUponFailure).to.contains('react-toggle react-toggle--checked blue-color')
                                    callback();
                                });
                            });
                        })
                    });
                });
            });
        });
    });

    this.Then(/^the user selects (.*), (.*) and (.*)$/, function (val1, val2, val3, callback) {
        cafSchedulePage.selectfromDropdown(val1).then(function () {
            cafSchedulePage.selectfromDropdown(val2).then(function () {
                cafSchedulePage.selectfromDropdown(val3).then(function () {
                    callback()
                });
            });
        });
    });

    this.Then(/^user turns the retry upon failure false$/, function (callback) {
        cafSchedulePage.retryUponFailureBtn().click().then(function () {
            callback();
        })
    });

    this.Given(/^the labels should be displayed correctly in the data request field$/, function (callback) {
        cafSchedulePage.dataRequestSchedule().getText().then(function (txt) {
            expect(txt.toString()).to.equal('Offset Before Schedule,Offset After Schedule,Sample Duration (Batch Size)')
            cafSchedulePage.selectRun().getText().then(function (txt1) {
                expect(txt1.toString()).to.equal('Deployment DateSpecific Date')
                callback();
            });
        });
    });


    this.Given(/^the tooltips should be correctly displayed for data request$/, function (callback) {
        cafSchedulePage.powerFabrictooltipBtns().then(function (btn) {
            btn[4].click().then(function () {
                cafSchedulePage.powerFabrictooltipContents().then(function (tool1) {
                    tool1[4].getText().then(function (ele) {
                        expect(ele).to.equal('Data request start date for backfield.')
                        btn[5].click().then(function () {
                            tool1[5].getText().then(function (ele1) {
                                expect(ele1).to.equal('Use to run a simulation as if it were live data (e.g. a year ago)')
                                btn[6].click().then(function () {
                                    tool1[6].getText().then(function (ele2) {
                                        expect(ele2).to.equal('Start offset associated to each individual analytic execution.')
                                        btn[7].click().then(function () {
                                            tool1[7].getText().then(function (ele3) {
                                                expect(ele3).to.equal('Use to run a simulation as if it were live data (e.g. a year ago)')
                                                btn[8].click().then(function () {
                                                    tool1[8].getText().then(function (ele3) {
                                                        expect(ele3).to.equal('Maximum amount you can input to an analytic for a single execution.')
                                                        callback();
                                                    });
                                                });
                                            });
                                        });
                                    });
                                });
                            });
                        });
                    });
                });

            });
        });
    });

    this.Then(/^the user selects specific date and Interpolated radio buttons$/, function (callback) {
        cafSchedulePage.specificDate().click().then(function () {
            cafSchedulePage.interpolated().click().then(function () {
                callback();
            });
        });
    });

  this.Then(/^caf user clicks iomapping reset/, function(callback) {
      cafIOMappingPage.resetButton().click().then(function() {
              callback();
        });
    });

  this.Then(/^caf user clicks schedule save$/, function(callback) {
    cafSchedulePage.saveButton().click().then(function() {
      callback();
       });
  });
  
  this.Then(/^the calendar and interpolated options should display$/, function (callback) {
        cafSchedulePage.datePicker().isDisplayed().then(function (displayed) {
            expect(displayed).to.equal(true);
            cafSchedulePage.interpolatedOptions().getText().then(function (text) {
                expect(text.toString()).to.equal('Sampling Interval,Maximum Data Interval')
                callback();
             });
         });
  });
 
  this.Then(/^user selects the (.*) in the date request section$/, function (arg, callback) {
        cafSchedulePage.scheduleDateCalendar().clear().sendKeys(arg).then(function () {
            callback();
        });
    });

    this.Then(/^current date should be displayed by default$/, function (callback) {
        var today = new Date();
        var currdate = (today.getMonth() + 1) + '/' + today.getDate() + '/' + today.getFullYear();
        cafSchedulePage.scheduleDateCalendar().getAttribute('value').then(function (text) {
            // expect(currdate.toString()).to.equal(text.toString())
            callback();
        });
    });

    this.Then(/^the retry upon failure should be disabled$/, function (callback) {
        cafSchedulePage.retryUponFailureDiv().getInnerHtml().then(function (retryUponFailure) {
            expect(retryUponFailure).to.not.contains('react-toggle react-toggle--checked blue-color')
            callback();
        });
    });

    this.Then(/^the default values for data request should be displayed$/, function (callback) {
        cafSchedulePage.powerFabricDropdowns().then(function (inline) {
            inline[3].getAttribute('value').then(function (offsetBefore) {
                expect(offsetBefore).to.equal('MINUTES')
                inline[4].getAttribute('value').then(function (offsetAfter) {
                    expect(offsetAfter).to.equal('MINUTES')
                    inline[5].getAttribute('value').then(function (duration) {
                        expect(duration).to.equal('MINUTES')
                        inline[6].getAttribute('value').then(function (samplingInterval) {
                            expect(samplingInterval).to.equal('MINUTES')
                            inline[7].getAttribute('value').then(function (maxDataInterval) {
                                expect(maxDataInterval).to.equal('MINUTES')
                                cafSchedulePage.scheduleDefaultTextBoxes().then(function (txtBox) {
                                    txtBox[1].getAttribute('value').then(function (offsetBeforeTxt) {
                                        expect(offsetBeforeTxt).to.equal('0')
                                        txtBox[2].getAttribute('value').then(function (offsetAfterTxt) {
                                            expect(offsetBeforeTxt).to.equal('0')
                                            txtBox[3].getAttribute('value').then(function (durationTxt) {
                                                expect(durationTxt).to.equal('30')
                                                callback()
                                            });
                                        });
                                    });
                                });
                            });
                        });
                    });
                });
            });
        });
    });
};

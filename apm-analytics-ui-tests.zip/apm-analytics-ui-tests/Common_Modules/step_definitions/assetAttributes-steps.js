module.exports = function () {
    var attributesBeforeDeployment = {};
    var attributesAfterDeployment = {};
    // this.When(/^get value of "([^"]*)" in Custom Attributes$/, function (arg1, callback) {
    //     var elm = element(by.xpath("//*[@id='assetInstanceCustomerTable']//attribute-data-table-cell[contains(@class,'aha-Attribute_Name-td')]//*[@id='cellvalue'][contains(text(),'"+ arg1 +"')]/../../../../*[contains(@class,'aha-values-td')]"));
    //     TestHelperPO.getText(elm).then(function (result) {
    //         console.log(arg1 , result);
    //         callback();
    //     })
    // });
    //
    // this.When(/^get value of "([^"]*)" in Reserved Attributes$/, function (arg1, callback) {
    //     var elm = element(by.xpath("//*[@id='assetInstanceReservedTable']//attribute-data-table-cell[contains(@class,'aha-Attribute_Name-td')]//*[@id='cellvalue'][contains(text(),'"+ arg1 +"')]/../../../../*[contains(@class,'aha-values-td')]"));
    //     TestHelperPO.getText(elm).then(function (result) {
    //         console.log(arg1 , result);
    //         callback();
    //     })
    // });

    this.When(/^get value of "([^"]*)" in "([^"]*)" Attributes "([^"]*)" running deployment$/, function (arg1, arg2, arg3, callback) {
        var headerId;
        var map;
        if (arg3 == "before"){
            map = attributesBeforeDeployment;
        } else
            map = attributesAfterDeployment;

        if (arg2 == "Custom"){
            headerId = "assetInstanceCustomerTable";
        } else
            headerId = "assetInstanceReservedTable";

        var elm = element(by.xpath("//*[@id='"+ headerId +"']//attribute-data-table-cell[contains(@class,'aha-Attribute_Name-td')]//*[@id='cellvalue'][contains(text(),'"+ arg1 +"')]/../../../../*[contains(@class,'aha-values-td')]"));
        TestHelperPO.getText(elm).then(function (result) {
            console.log(arg1 , result);
            map[arg1] = result;
            callback();
        })
    });

    this.Then(/^The value of "([^"]*)" attribute should be different after running deployment$/, function (arg1, callback) {
        expect(attributesBeforeDeployment[arg1]).to.equal(attributesAfterDeployment[arg1]);
        callback();
    });



}

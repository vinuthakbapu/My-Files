module.exports = function () {

  this.Given(/^the caf user is on the review screen$/, function (callback) {
    cafSchedulePage.titleHeader().getText().then(function(text) {
      expect(text).to.equal('Schedule and Data Request');
      callback();
    });
  });

  this.Then(/^the caf review tab should be displayed$/, function (callback) {
    browser.sleep(5000).then(function () {
      cafReviewPage.deployConfirmTab().isDisplayed().then(function(flag){
        assert.equal(flag, true, "review tab is present");
        callback();
      });
    });
  });

  this.Then(/^caf Review tab should be highlighted$/, function(callback) {
    cafAssetSelectionPage.getNavigationTabs().element(by.css('.apm-dp-breadcrumb-active')).getOuterHtml().then(function(tab){
      assert.include(tab, 'Review');
      callback();
    });
  });

  this.Then(/^the caf Deployment Schedule should be displayed$/, function (callback) {
    browser.sleep(2000).then(function () {
      cafReviewPage.deployByScheduleConfirm().isDisplayed().then(function (flag) {
        assert.equal(flag, true, "deploy by schedule section is present");
        callback();
      });
     /* var lastDeployType;
      cafReviewPage.editSchedule().evaluate('lastDeployType').then( function(value){
        lastDeployType = value;
        console.log(lastDeployType);
        switch (lastDeployType) {
          case "DeployBySchedule":
            var valuePart1 = cafReviewPage.deployByScheduleConfirmValue1();
            valuePart1.isDisplayed().then( function(flag){
              assert.equal(flag, true, "first part of the value is present");
              callback();
            });
            valuePart1.getText().then(function(flag){
              assert.notEqual(flag, "", "first part of the value is not empty");
              callback();
            });
            var valuePart2 = cafReviewPage.deployByScheduleConfirmValue2();
            valuePart2.isDisplayed().then( function(flag){
              assert.equal(flag, true, "second part of the value is present");
              callback();
            });
            valuePart2.getText().then(function(flag){
              assert.notEqual(flag, "", "second part of the value is not empty");
              callback();
            });
            break;
          case "DeployOnDemand":
            var text = cafReviewPage.deployOnDemandConfirmValue();
            text.isDisplayed().then(function(flag){
              assert.equal(flag, true, "value is displayed");
              callback();
            });
            text.getText().then(function(flag){
              assert.notEqual(flag, "", "value is not empty");
              callback();
            });
        }
      });*/
    });
  });

  this.Then(/^the caf Asset details should be displayed$/, function (callback) {
    browser.sleep(2000).then(function () {
      var assets;
      cafReviewPage.assetDetailsSection().isDisplayed().then(function(flag){
        assert.equal(flag, true, "assets details is displayed");
        callback();
      });
      /*cafReviewPage.assetsTable().evaluate('paginatedAssets').then(function(value){
        assets = value;
        if (assets && assets.length > 0) {
          expect(cafReviewPage.assetsTableRows().count().then(function(value){
            assert.equal(value, assets.length, "assets table rows number equals numbder of assets");
            callback();
          }));
        }
      });*/
    });
  });

  this.Then(/^the caf inputs details should be displayed with edit icon$/, function (callback) {
    browser.sleep(2000).then(function () {
      cafReviewPage.inputsTable().isDisplayed().then(function(flag){
        assert.equal(flag, true, "inputs section is present");
      });
        cafReviewPage.inputsEditButton().isDisplayed().then(function(flag){
          assert.equal(flag, true, "inputs edit button is present");
          callback();
        });
    });
  });

  this.Then(/^the caf constants details should be displayed$/, function (callback) {
    browser.sleep(2000).then(function () {
      cafReviewPage.constantsTable().isDisplayed().then(function(flag){
        assert.equal(flag, true, "constants table is displayed");
        callback();
      });
    });
  });

  this.Then(/^the caf outputs details should be displayed$/, function (callback) {
    browser.sleep(2000).then(function () {
      cafReviewPage.outputsTable().isDisplayed().then(function(flag){
        assert.equal(flag, true, "outputs table is displayed");
        callback();
      });
    });
  });

  this.Then(/^caf Prev button should be enabled$/, function (callback) {
    browser.sleep(2000).then(function () {
      cafReviewPage.previousStepButton().isDisplayed().then(function(flag){
        assert.equal(flag, true, "previous step button is present");
        callback();
        /*cafReviewPage.previousStepButton().isEnabled().then(function(value){
          assert.equal(value, true, "previous step button is enabled");
          callback();
        });*/
      });
    });
  });

    this.Then(/^caf Next button should be enabled$/, function (callback) {
      browser.sleep(2000).then(function () {
        cafReviewPage.nextStepButton().isEnabled().then(function(value){
         assert.equal(value, true, "next step button is enabled");
         callback();
         });
        });
      });

  this.Then(/^the caf user clicks show asset$/, function(callback) {
    cafReviewPage.showAssetsToggle().isDisplayed().then(function(){
      cafReviewPage.showAssetsToggle().click().then(function() {
        callback();
      });
    });
  });
  this.Then(/^the caf user chooses to go to Review$/, function(callback) {
    cafReviewPage.reviewConfigButton().isEnabled().then(function(){
      cafReviewPage.reviewConfigButton().click().then(function() {
        callback();
      });
    });
  });

  this.Then(/^the icon displayed should warn invalid edge$/, function(callback) {
    cafReviewPage.iconEdgeTableInvalid().isDisplayed().then(function(){
      callback();
    });
  });

  this.Then(/^the edge assets are mapped correctly$/, function(callback) {
    cafReviewPage.isAssetsMappedEdgeValid().isDisplayed().then(function(){
      callback();
    });
  });

  this.Then(/^the page displays all assets mapped correctly$/, function(callback) {
    cafReviewPage.assetsMappedCorrectly().getText().then(function(string) {
      expect(string).to.equal('Assets Mapped Correctly');
      callback();
    });
  });

  this.Then(/^the edge validation table is displayed$/, function(callback) {
    cafReviewPage.edgeValidationTable().isDisplayed().then(function(flag) {
      assert.equal(flag, true, "validation table is present");
      callback();
    })
  });

  this.Then(/^there should be "([^"]*)" assets in the table$/, function (arg1, callback) {
      cafReviewPage.getValidationTableRows().count().then(function (value) {
          expect(value).to.equal(parseInt(arg1));
          callback();
      });
  });
}

/********************************************************************************
 * Copyright (c) 2015-2016 GE Digital. All rights reserved.                     *
 *                                                                              *
 * The copyright to the computer software herein is the property of GE Digital. *
 * The software may be used and/or copied only with the written permission of   *
 * GE Digital or in accordance with the terms and conditions stipulated in the  *
 * agreement/contract under which the software has been supplied.               *
 ********************************************************************************/

/**
 * Create Orch spec
 */

module.exports = function() {

    /*
    this.When(/^the IOmap page is closed to go to main page$/, function (callback) {

        expect(orchStepsPage.closeButtonRightCorner()).to.exist;
        orchStepsPage.closeButton().click().then(function(){

            TestHelperPO.isElementPresent(orchDeployPage.deployConfiguration());
            callback();
        });

    });*/

   
    

    /*this.When(/^the user clicks Deploy Config tab$/, function (callback) {
        browser.sleep(10000);
        TestHelperPO.isElementPresent(orchDeployPage.deployConfiguration());
            orchDeployPage.deployConfiguration().click();
            callback();
    });


    this.Then(/^a new Deploy Configuration icon is clicked/, function (callback) {
        TestHelperPO.isElementPresent(orchDeployPage.createDeployButton());
        orchDeployPage.createDeployButton().click().then(function(){
            callback();
        });
    });*/
    
    
    this.When(/^one time execution is selected$/, function (callback) {
        TestHelperPO.isElementPresent(orchDeployPage.fromFields());
        TestHelperPO.isElementPresent(orchDeployPage.toFields());
        
        orchDeployPage.fromFields().clear().sendKeys("04/01/2017");

        orchDeployPage.icon().click().then(function(){
            TestHelperPO.isElementPresent(orchDeployPage.fromTimeText());
            TestHelperPO.isElementPresent(orchDeployPage.toTimeText());
            orchDeployPage.applyButton().click();
            callback();
        });
    });


    this.Then(/^the deploy button is clicked$/, function (callback) {
        browser.sleep(5000);
        orchDeployPage.deployBtn().click();
       // TestHelperPO.isElementPresent(orchDeployPage.deploySpinner());

        TestHelperPO.isElementPresent(orchDeployPage.alertBox());

        orchDeployPage.alertBox().getText().then(function(text){
            console.log("text is " + text);

            expect(text).to.have.string('Schedule is successfully deployed');
            callback();
        });
        
    });

    this.Then(/^the deploy page is closed$/, function (callback) {

        TestHelperPO.isElementPresent(orchDeployPage.closeBtn());
        orchDeployPage.closeBtn().click();
        callback();
        
    });

    
    this.When(/^the deploy table is viewed$/, function (callback) {
        browser.sleep(6000).then(function(){
           TestHelperPO.isElementPresent(orchDeployPage.deployConfiguration()).then(function(){
               TestHelperPO.elementToBeClickable(orchDeployPage.deployConfiguration()).then(function(){
                   TestHelperPO.isElementPresent(orchDeployPage.deployTable());
                    callback();
               });
           });
        })
    });


    this.Then(/^the deploy table should contain "([^"]*)"$/, function (arg1,callback) {
        TestHelperPO.isElementPresent(orchDeployPage.deployTable());
        
        orchDeployPage.deployTable().getText().then(function(text){
            console.log("text is " + text);
            expect(text).to.have.string(arg1);
            
            console.log("my date is " + orchDeployPage.todayDate());
            expect(text).to.have.string(orchDeployPage.todayDate());
            callback();
        });

    });


    this.When(/^the deploy table is selected$/, function (callback) {
        TestHelperPO.isElementPresent(orchDeployPage.deployTable());
        orchDeployPage.deployTable().click();

        callback();
    });
    


    this.When(/^recurrent is selected$/, function (callback) {

        TestHelperPO.isElementPresent(orchDeployPage.recurrentRadio());
        orchDeployPage.recurrentRadio().click().then(function(){
            TestHelperPO.isElementPresent(orchDeployPage.repeatEveryText());
            TestHelperPO.isElementPresent(orchDeployPage.labelOffset());
            TestHelperPO.isElementPresent(orchDeployPage.labelSampleDuration());
            TestHelperPO.isElementPresent(orchDeployPage.labelSampleInterval());
            
            callback();
        });
        
    });


    this.Then(/^the deploy table should contain Scheduled$/, function (callback) {
        //TestHelperPO.isElementPresent(orchDeployPage.deployTable.get(0));

        orchDeployPage.deployConfiguration().click().then(function(){

            browser.sleep(5000);
            orchDeployPage.deployTable().getText().then(function(text){
                console.log("text is " + text);
                expect(text).to.have.string('Scheduled');

                console.log("my date is " + orchDeployPage.todayDate());
                callback();
            })
        })

    });


     
   /* this.When(/^the orchestration tab is clicked$/, function (callback) {

        //orchDeployPage.orchestrationTab().click()
        TestHelperPO.elementToBeClickable(orchDeployPage.orchestrationTab()).then(function(){
            expect(createOrchestrationPage.analyticBox()).to.exist;
            callback();
        });

    });*/


    
    
    this.Then(/^the Toast Message is verified$/, function (callback) {

        expect(orchDeployPage.alertBox()).to.exist;

        orchDeployPage.alertBox().getText().then(function(text){
            console.log("text is " + text);

           // expect(text).to.have.string('Heads Up!');


            orchDeployPage.toastMessage().getText().then(function(text) {
                console.log("toast is " + text);

                callback();
            });
        });

    });



    this.Then(/^the Dirty State message is verified in Modal page$/, function (callback) {

        expect(orchIOMapPage.saveButtonDisabled()).to.exist;
        expect(orchIOMapPage.closeButton()).to.exist;

        TestHelperPO.elementToBeClickable(orchIOMapPage.closeButton());


        expect(orchDeployPage.dirtyWarningButton()).to.exist;
        expect(orchDeployPage.dirtyWarningText()).to.exist;

        orchDeployPage.dirtyWarningText().getText().then(function(text) {
            console.log("text is " + text);

            expect(text).to.have.string('Latest orchestration updates have not been applied to existing deployments.');


            expect(orchStepsPage.closeButtonRightCorner()).to.exist
            
            callback();
        });

    });



    this.Then(/^the Dirty State message is verified in Main page$/, function (callback) {

        expect(orchDeployPage.dirtyWarningButton()).to.exist;
        expect(orchDeployPage.dirtyWarningText()).to.exist;

        orchDeployPage.dirtyWarningText().getText().then(function(text) {
            console.log("text is " + text);

            expect(text).to.have.string('Latest orchestration updates have not been applied to existing deployments.');
            

            callback();
        });

    });

    this.When(/^the user waits for popup to disappear$/, function (callback) {
        browser.sleep(10000).then(function(){
            callback();
        })
    });



};
(function () {
    'use strict';

    var WhatifPage = function () {

        return {
            clickHistoricalTextBox: function(){
                return element(by.css("#context-form > div > div > div:nth-child(1) > div.flex.flex--wrap.style-scope.context-settings-forecast > div:nth-child(2) > px-dropdown > div > div")).click();
            },
            clickHistoricalUnitsDropDown: function(historicalUnits){
                return element.all(by.css('div#prefix[draggable="true"]'));
            },
            getDragList: function() {
                return element.all(by.css('div#prefix[draggable="true"]'));
            }
        }


    };

    module.exports = new WhatifPage();
}())


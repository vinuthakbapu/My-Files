/**
 * Class encapsulating all functions in asset selection page
 */
(function () {
  'use strict';

    const currentPage = 'cafAssetSelectionPage';
    var TIMEOUT = 5000;

  var cafAssetSelectionPage = function () {
    var randVal = Date.now();

    return {
      visibilityOf: function (elementID) {
        var EC = protractor.ExpectedConditions;
        return browser.wait(EC.visibilityOf(elementID), 10000)
      },

      presenceOf: function (elem) {
        var until = protractor.ExpectedConditions;
        return browser.wait(until.presenceOf(elem), 50000, 'Element taking too long to appear in the DOM');
      },

      elementToBeClickable: function (elementID) {
        var EC = protractor.ExpectedConditions;
        return browser.wait(EC.elementToBeClickable(elementID), 50000)
      },

      /* browser.wait(function() {
       // return a boolean here. Wait for spinner to be gone.
       return !browser.isElementPresent(by.css('[ng-show="assetApplicabilitySpinner"]'));
       }, 20000)*/

      activeBreadcrumb: function() {
        return element(by.css('apm-db-breadcrumb-active'));
      },

      assetSelectionBreadcrumb: function() {
        return element(by.id('apm-dp-breadcrumb-item-0'));
      },

      addDeployment: function () {
        return element(by.css('i[title="Create Deployment"]'));
      },

      deploymentName: function () {
        return element(by.id('deploymentNameInput'));
      },

      dontSaveButton: function() {
        return element(by.id('apm-dp-confirm-no-save'));
      },

      newDeploymentSubmit: function () {
        return element(by.id("apm-dp-confirm-save"));
      },

      closeDeployment: function () {
        return element(by.id('apm-dp-config-close-button'));
      },

      existingDeploymentByName: function (name) {
        return element.all(by.css('.deployName')).filter(function (elem, index) {
          return elem.getText().then(function (text) {
            return text.indexOf(name) !== -1;
          });
        }).first();
      },

      getDeployment: function (url) {
        browser.driver.get("https://stuf-rc.run.asv-pr.ice.predix.io/sample14/analytics/#/analyticUi/analyticEntries/6fe4bc3a-b420-443e-bfe1-f2d7e5191857/details/deployList");
      },

      deployment: function () {
        console.log('Clicking Deployment');
        return element(by.css('td.name'));
      },

        assetFiltersHeader: function () {
            // return element(by.css('.asset-header-padding>span.title'));
            return element(by.css('.apm-dp-breadcrumb .apm-dp-breadcrumb-active'));
        },

        mouseOverAssetTitle: function () {
        return browser.actions().mouseMove(element.all(by.css('.deploy-center-items')).get(0)).perform();
        },

      getAssetFilter: function () {
        return element(by.id('asset-filter'));
      },

      clickNextButton: function () {
        return TestHelperPO.elementToBeClickable(element(by.id('apm-dp-breadcrumb-next-button')));
      },

      getPrevButton: function () {
        return TestHelperPO.elementToBeClickable(element(by.id('apm-dp-breadcrumb-prev-button')));
      },

      getDeployButton: function () {
        return element(by.id('apm-dp-config-deploy-button'));
      },

      getCloseButton: function () {
        return element(by.cssContainingText('.deployment-second-header .deploy-right .btn', 'Close'));
      },
    
      getNavigationTabs: function () {
        return element(by.css('.apm-dp-breadcrumb'));
      },

      assetFilterValue: function (value) {
        value = value || 'GE90';
        value = 'option[label="' + value + '"';
        return element.all(by.css(value)).get(0);
      },

      getSearchButton: function () {
        return element.all(by.id('asset-filter-search')).get(0);
      },

      getSelectedMax20assets: function() {
        return element(by.css('.reminder.color-orange'));
      },

      getDeploymentTitle: function () {
        return element.all(by.css('.deploy-center-items label')).get(0);
      },

      getDeployStatusLabel: function () {
        return element.all(by.css('.deployment-second-header .deploy-left .deploy-items')).get(0);
      },

      getDeployDateLabel: function () {
        return element.all(by.css('.deployment-second-header .deploy-left .deploy-items-time')).get(0);
      },

      getAnalyticStatusHeader: function() {
        return element.all(by.css('.apm-top-header-contents')).get(0);
      },

      getAnalyticHeader: function () {
        return element.all(by.css('.apm-top-header')).get(0);
      },

      getEditIcon: function () {
        return element.all(by.css('.fa.fa-pencil')).get(0);
      },

      getDeploymentNameInputField: function () {
        return element.all(by.css('.deploy-center-items.edit-text-box-dir input')).get(0);
      },

      deleteDeploymentIcon: function () {
        return element(by.css('.fa.fa-trash.edit-pencil'));
      },

      deleteActionConfirm: function () {
        return element(by.css('[ng-click=\'submit()\']'));
      },

      getDeplpoymentNameInput: function () {
        return element(by.id('deploymentNameInput'));
      },

        deploymentPopupInput: function () {
            return element(by.id('DeploymentNameInputBox'));
        },

      getAssetFilterLabelElem: function () {
        return element(by.css('.apm-dp-asset .title'));
      },

      getAssetTableRows: function () {
        return element.all(by.css('table tbody tr'));
      },

      getFirstAssetTableRow: function () {
          return element(by.css('table tbody tr td[tabindex="2"]'));
      },

        getCheckedCheckboxesFromAssetTable: function () {
            return element.all(by.css('.table.table-bordered.table-body input[type="checkbox"]:checked'));
        },

      getSelectedNumber: function () {
        return element(by.css('.result-box .title'));
      },

      getSelectedNumberAfterSearch: function () {
        return element(by.css('span[ng-bind="mode.entities.length"]'));
      },

      getTotalNumber: function () {
        return element(by.css('span[ng-bind="assetFromFiltersCount"]'));
      },

      getAssetTableFilterInputField: function () {
        return element(by.css('input.search-input'));
      },

      getAssetTableFilterClearIcon: function () {
        return element(by.css('i.fa.fa-times'));
      },

      getTableTitle: function() {
        return element(by.css('div.result-box span.title')).getText();
      },

      getAssetFilterAttributeSearchBox: function () {
        return element(by.css('input.bootstrap-typeahead-input-main'));
      },

      getAttributeNameTermCloseIcon: function () {
        return element(by.css('span.close-button'));
      },

      getCheckboxsFromAssetTable: function () {
        return element.all(by.css('table tbody tr td input'));
      },

      clickFirstAsset: function() {
        return TestHelperPO.elementToBeClickable(element(by.xpath('//*[@class="table table-bordered table-body"]/tbody/tr[1]/td[1]/input')));
      },

      clickSecondAsset: function() {
        return TestHelperPO.elementToBeClickable(element(by.xpath('//*[@class="table table-bordered table-body"]/tbody/tr[2]/td[1]/input')));
      },

      clickThirdAsset: function() {
        return TestHelperPO.elementToBeClickable(element(by.xpath('//*[@class="table table-bordered table-body"]/tbody/tr[3]/td[1]/input')));
      },

      getSelectAllCheckbox: function () {
        return element(by.css('input.react-bs-select-all'));
      },

      assetSelectionFilterSearch: function () {
        return element(by.css('.apm-search-box input'));
      },

      getLabeledLink: function () {
        return element(by.css('button.btn.btn-primary.react-bs-table-show-sel-only-btn.show-sel-only-btn'));
      },

      deleteAnalyticButton: function(){
        return element(by.css('button.btn.btn--tertiary.delete-button'));
      },

      ioMappingContainer() {
        return element(by.css('.apm-dp-ioMappingContainer'));
      },

      resetButton() {
        return element(by.css('#asset-filter-save.apm-btn.style-scope'));
      },

      saveButton() {
        return element(by.css('#asset-filter-save.apm-btn.apm-btn-blue'));
      },

      nextButton() {
        return element(by.id('apm-dp-breadcrumb-next-button'));
      },
        
      assetFilterOptions() {
        return element.all(by.css('#asset-filter > option'));
      },
        
      getAssetTemplate() {
        return element(by.id('asset-templates'));
      },
        
      assetTemplateOptions() {
        return element.all(by.css('#asset-templates > option'));
      },
        
      selectedTemplate() {
        return element(by.id('asset-templates')).element(by.css('option:checked')).getText();
      },
      selectedFilter() {
        return element(by.id('asset-filter')).element(by.css('option:checked')).getText();
      },
      filterTooltip() {
        return element(by.id('asset-filter-tooltip'));
      },
      templateTooltip() {
        return element(by.id('template-tooltip'));
      },
      searchTooltip() {
          return element(by.id('search-tooltip'));
      },
      tableTooltip() {
          return element(by.id('table-tooltip'));
      },
      getAssetFilterOption(name) {
        return element(by.cssContainingText('#asset-filter > option', name));
      },
      getAssetTemplateOption(name) {
          return element(by.cssContainingText('#asset-templates > option', name));
      },
      tableNoResults() {
        return element(by.css('.react-bs-table-no-data'));
      },
      errorMessageText() {
        return element(by.cssContainingText('px-alert-message', 'Error'));
      }
    };
  };

  module.exports = new cafAssetSelectionPage();

}());



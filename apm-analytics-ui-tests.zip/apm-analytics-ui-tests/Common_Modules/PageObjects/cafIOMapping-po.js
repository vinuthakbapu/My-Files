/**
 * Created by 212319611 on 5/10/17.
 */

(function () {
  'use strict';


  const cafIOMappingPage = function () {

    return {
      visibilityOf: function (elementID) {
        var EC = protractor.ExpectedConditions;
        return browser.wait(EC.visibilityOf(elementID), 10000)
      },

      elementToBeClickable: function (elementID) {
        var EC = protractor.ExpectedConditions;
        return browser.wait(EC.elementToBeClickable(elementID), 5000)
      },

      deployment: function () {
        return element(by.css('.linkRadio>span'));
      },

      ioMappingContainer: function () {
        return element(by.css('.apm-dp-ioPageContainer'));
      },

      ioMappingHeaderButton: function () {
        return element(by.css('.apm-dp-breadcrumb-active'));
      },

        analyticDataPointsTextbox: function () {
            return element(by.id('apm-dp-iomap-dataPoints-0'));
        },

        mapForAllAssetsRadioButton: function () {
            return element(by.id('apm-dp-iomap-mapByInput'));
        },

        mapForAssetRadioButton: function () {
            return element(by.id('apm-dp-iomap-mapByAsset'));
        },

      ioMappingSelectionDropDown: function() {
        return element(by.id('mapBy-dropdown'));
      },

      ioMappingForAssets: function() {
        return element(by.id('apm-dp-iomap-mapByAsset'));
      },

      ioMappingInputDefinitionHeader: function(){
        return element.all(by.css('.title-header')).get(2);
      },

        inputToolTip: function(){
            return element(by.css('.apm-dp-input-hover-tooltip'));
        },

        mouseOverToolTip: function(){
            return browser.actions().mouseMove(element(by.css('.apm-dp-input-hover-tooltip'))).perform();
        },

      ioMappingSelectedAssetsHeader: function(){
        return element(by.id('selected-asset-header'));
      },

      ioMappingTagIcon: function() {
        return element(by.css('[ng-click=\'mapInput(item)\']'));
      },
      
      ioMappingViewTags: function() {
        return element(by.css('a #apm-dp-iomap-tagslist-dropdown'));
      },

      secondChildTagsDropdown: function() { // currently it is option to view tags, TODO: add IDs
        return element(by.css('.wrapper .content:nth-child(2)'));
      },
      
      filterSearchTagIcon: function() { 
        return element(by.css('#initiateSearch)'));
      },

      ioMappingAttributeIcon: function () {
        return element(by.css('.fa.fa-at'));
      },

      ioMappingTimeSeriesIcon: function () {
        return element(by.css('span>.fa.fa-tags'));
      },

      ioMappingCustomAttributeIcon: function () {
        return element(by.css('.fa.fa-at'));
      },
      ioMappingHierarchyIcon: function(){
        return element(by.css('.fa.fa-sitemap'));
      },

      ioMappingSearchInput: function () {
        return element(by.id('assetTag-search'));
      },

      ioMappingTagSearchItem: function() {
        return element(by.xpath('//*[@id="tabs-views"]/ul/li'));
      },

      mapfoundCommonTagByClick: function() {
        return element(by.css('.assetTagBox .fa-plus'));
      },

      ioMappingAttributeList: function () {
        return element(by.css('.apm-ax-accordion-list.active'));
      },

      ioMappingTagName: function () {
        return element(by.css('.tag-name'));
      },

      ioMappingDetails: function () {
        return element(by.css('.analytic-details'));
      },

      ioMappingDataType: function () {
        return element(by.xpath('//*[@id="ioMappingTags"]/li[1]/div/div/div/div[2]/span[1]'));
      },

      ioMappingAssetMappingTarget: function() {
        return element(by.id('map-input-row-0'));
      },

      ioMappingPlusIcon: function () {
        return element(by.css('.fa.fa-plus'));
      },

      ioMappingTagUnit: function() {
        return element(by.xpath('//*[@id="ioMappingTags"]/li[26]/div/div/div/div[2]/span[3]'));
      },

      ioMappingTagList: function () {
        return element(by.css('.assetTagList'));
      },

      ioMappingTagListSpinner: function () {
        return element(by.css('.listSpinnerContainer.ng-scope'));
      },

      ioMappingRequiredInputs: function () {
        return element(by.xpath('//*[@class="mapped-required-ratio"]/span[3]'));
      },

      ioMappingRequiredInputsPercent: function () {
        return element(by.xpath('//*[@class="mapped-required-ratio"]/span[2]'));
      },

      ioMappingTotalInputs: function () {
        return element(by.xpath('//*[@class="mapped-ratio"]/span[3]'));
      },

      ioMappingTotalInputsPercent: function () {
        return element(by.xpath('//*[@class="mapped-ratio"]/span[2]'));
      },

        ioMappingInputDefinitionColumnNames: function (el) {
          return element.all(by.css('#input > thead > tr > th'));
      },

      ioMappingInputDefinitionColumnValues: function () {
        return element.all(by.css('#apm-dp-input-row-0 > td'));
      },

      ioMappingFirstInput: function () {
        return element(by.css('#apm-dp-input-row-0'));
      },

      ioMappingInput: function (inputNo) {
        return element(by.css('#apm-dp-input-row-'+inputNo));
      },

      ioMappingTagUOM: function () {
        return element(by.xpath('//*[@class="ioMappingTable"]/tbody/tr/td[4]'));
      },

      ioMappingConstantsHeader: function () {
        return element.all(by.css('.apm-orch-subsection-header')).get(0);
      },

      ioMappingConstantsColumnNames: function () {
        return element.all(by.css('#constant_table > thead > tr > th'));
      },

      ioMappingConstantsValues: function () {
        return element.all(by.css('.constant>td'));
      },

      ioMappingOutputDefinitionColumnNames: function () {
        return element.all(by.css('#output_table > thead > tr > th'));
      },

      ioMappingOutputDefinitionColumnValues: function () {
        return element.all(by.css('.output:nth-child(1)>td'));
      },

      ioMappingOutputDefinitionTagsHeader: function () {
        return element.all(by.css('.apm-orch-subsection-header')).get(1);
      },

      ioMappingOutputDefinitionAlertsHeader: function () {
        return element.all(by.css('.apm-orch-subsection-header')).get(2);
      },

      ioMappingOutputDefinitionAlertsColumnNames: function () {
        return element.all(by.css('#alert_table > thead > tr > th'));
      },

      ioMappingOutputDefinitionAlertsColumnValues: function () {
        return element.all(by.xpath('//*[@id="map-output-alerts-row-0"]/td'));
      },

        mappedTag: function() {
            return element(by.css('#apm-dp-input-row-0 > td:nth-child(5) > .mapping-cell > span'));
            //return element(by.id('apm-dp-input-row-0'));
        },

        outputMappedTag: function() {
            return element(by.css('#output_table tr:nth-child(1) > td:nth-child(5) > span > span'));
        },

        clearInputMapIcon: function() {
            return element(by.id('clear-input-map-btn'));
        },

        clearOutputMapIcon: function() {
            return element(by.css('.clear-map-icon'));
        },

      ioMappingAssetTag: function () {
        // return element(by.xpath('//*[@id="apm-dp-input-row-0"]/td[5]/span'));
        return element(by.css('#apm-dp-input-row-0 td:nth-child(5) > span'));
      },

        outputDefinitionRow: function() {
            return element(by.css('#output_table tr:nth-child(1) > td.truncate-cell-item'));
        },

        outputDefinitionAssetTag: function () {
          return element(by.css('#output_table tr:nth-child(1) > td:nth-child(5) > span > span'));
      },

      ioMappingTree: function () {
        return element(by.css('.tree-view-branch.style-scope.px-tree-view-node'));
      },

      ioMappingAssetRadioButton: function () {
        return element(by.id('apm-dp-asset-io-map-0'));
      },

        ioMappingMappedTagDelete: function () {
            return element(by.id('clear-input-map-btn'));
        },

      ioMappingExpandCaret: function () {
        return element.all(by.id('toggleicon')).get(1);
      },

        expandTagsNode: function () {
            return element.all(by.id('toggleicon')).get(1);
        },

        assetHierarchySearch: function () {
          return element(by.css('#apm-dp-asset-hierarchy-search input'));
        },

        assetHierarchySearchIcon: function () {
            return element(by.css('.fa-search'));
        },

        assetHierarchySearchResults: function () {
              return element(by.css('#text > span'));
        },


      constantValue: function () {
        return element(by.xpath('//*[@class="constant"]/td[4]/div'));
      },

      /*
       let child = element(by.xpath('//*[contains(@id,"supporting")]'));
       return child.element(by.xpath('ancestor::table')); potential solution
       */


      editConstantValueIcon: function () {
        return element(by.css('.fa.fa-pencil'));
      },

      constantValueInput: function () {
        return element(by.css('input.constantValue'));
      },

        editConstantValueInput: function () {
            return element(by.css('input.constantValue'));
        },

      constantValueAfterSave: function () {
        let el = element.all(by.css('.constant.selected td')).get(3);
        return el.element(by.css('div'));
      },

      constantvalue : function(){
        return element(by.css('#apm-dp-constant-0 td.data-value'));
      },


      ioMappingSelectedAssetsColumnNames: function () {
        return element.all(by.xpath('//*[@id="apm-dp-selected-asset-column-names"]/th'));
      },

      ioMappingSelectedAssetsValues: function () {
        return element.all(by.xpath('//*[@id="selected-asset-column-values-0"]/td'));
      },

        ioMappingSelectedAssetTagSource: function() {
            //return element(by.css('.label.style-scope.px-tree-view-leaf'));
            return element(by.css('.tree-view-level-2'));
        },

      ioMappingSelectedAssetTagTarget: function() {
        return element(by.xpath('//*[@id="apm-dp-input-row-0"]/td[5]'));
      },

      draggableAssetTag: function() {
        //return element(by.css('.label.style-scope.px-tree-view-leaf'));
          return element(by.css('.tree-view-level-2'));
      },

        outputDefinitionTarget: function() {
            return element(by.css('.output:nth-child(1)'));
        },

      ioMappingSelectedAssetTreeTags: function () {
        return element.all(by.id('text'));
      },

      ioMappingSelectedAssetTreeTagList: function () {
        return element.all(by.css('px-tree-view-leaf')).get(0);
      },
      ioMappingSelectedAssetSearchBoxAssetTag: function () {
        return element(by.xpath('//*[@id="apm-dp-asset-hierarchy-search"]/input'));
      },
      ioMappingSelectedAssetSearchBoxAssetTagAction: function () {
        return element(by.xpath('//*[@id="apm-dp-asset-hierarchy-search"]/a/i'));
      },
      ioMappingSelectedAssetsMappedByTag: function () {
        return element(by.css('#apm-dp-input-row-0 > td:nth-child(5) > span > span'));
      },

      analyticDataPointsInput: function () {
        return element(by.id('apm-dp-iomap-dataPoints-0'));
      },

      dataflowRadioButton: function() {
        return element(by.css('.apm-dp-iomap-input-datapoint'));
      },

      saveButton: function() {
        return element(by.id('apm-dp-iomap-saveEdit'));
      },

        resetButton: function() {
            return element(by.id('apm-dp-iomap-cancelEdit'));
        },

        nextButton: function(){
            return element(by.id('apm-dp-breadcrumb-next-button'));
        },

        prevButton: function(){
            return element(by.id('apm-dp-breadcrumb-prev-button'));
        },

        tagIcon: function() {
            return element(by.css('.fa.fa-tags'));
        },

        addTagsLink: function() {
            return element(by.linkText('Add tags...'));
        },

        suggestedTagsLink: function() {
            return element(by.linkText('Get Suggested Tags'));
        },

        suggestedTagsColumn: function() {
          return element(by.css('#input thead tr th input'))
        },

        saveSelected: function() {
          return element(by.css('#apm-dp-automap-apply'));
        },

      firstOutputDef: function() {
        return element.all(by.css('.output')).get(0);
      },

      secondOutputDef: function() {
        return element.all(by.css('.output')).get(1);
      },

      dataPointsError: function() {
        return element(by.css('.invalidEntryAlertTextShow'));
      },

      iterationDropdown: function() {
        return element(by.css('.fa.fa-chevron-down'));
      },

      ioMapItems: function() {
        return element.all(by.css('.content .item'));
      },

      iterationBox: function() {
        return element(by.css('.iterationInputBox'));
      },

      iterationDataPoints: function() {
        return element(by.css('.apm-dp-dataPointsStepInputBox'));
      },

      ioMapsText:function(){
        return element(by.css('.multipleIterationSpan'))
      },

      iterationLeftArrow: function() {
        return element(by.css('.fa.fa-angle-left'));
      },

      iterationRightArrow: function() {
        return element(by.css('.fa.fa-angle-right'));
      },

      dataPointsStepLevelInputBox: function() {
        return element(by.css('.apm-dp-dataPointsStepInputBox'));
      },

      descriptionMapping: function(){
        return element(by.css('.description-mapping'))
      },
      assetSelectionLabels: function() {
        return element(by.id('asset-selection-labels'));
      },
      getTemplateLabel: function(text) {
        return element(by.cssContainingText('template-name-label', text));
      },
      getAssetFilterLabel: function(text) {
        return element(by.cssContainingText('asset-filter-label', text));
      },
      getPositionTag: function() {
        return element(by.css('#container .tree-view-level-1 .px-tree-view-branch-0 #label #toggle'));
      },
      getPositionSubTemplates: function() {
          return element(by.css('#label .tree-view-level-3 a #text'));
      },
      getTagsList: function() {
        return element(by.xpath('//*[@id="container"]/px-tree-view-node/ul/li[1]/px-tree-view-leaf'));
      },
        getSubTemplatesList: function() {
            return element(by.xpath('//*[@id="container"]/px-tree-view-node/ul/li/px-tree-view-branch/[@id="label"]/template'));
        },
      getTreeView: function() {
        return element(by.css('.px-tree-view'));
      },
      getTagSearchField: function() {
        return element(by.css('#apm-dp-asset-hierarchy-search input'));
      },
      getSearchIcon: function() {
        return element(by.css('#apm-dp-asset-hierarchy-search a i'));
      },
      inputSearchTagToDrag: function() {
        return element(by.css('span.label.style-scope.px-tree-view-leaf'));
      },
      inputDefinitionMapped: function() {
        return element(by.css('#apm-dp-input-row-0 > td:nth-child(5) > span > span'));
      },
      getDraggableTag: function() {
        return element.all(by.css('div#label.tree-view-label.style-scope.px-tree-view-leaf.tree-view-level-3')).first();

      },
      selectAddCommonTagsOption: function () {
        return element(by.css('div.apm-dp-dropdown > div > div > a:nth-child(1)'));
      },

        getRootPositionTag: function() {
            return element(by.css('#container px-tree-view-node ul li px-tree-view-branch #label a#text'));
        },
        getDraggableCommonTag: function() {
            return element.all(by.css('div#label.tree-view-label.style-scope.px-tree-view-leaf.tree-view-level-2')).first();

        },
        getRootPositionAttributes: function() {
            return element(by.xpath('//*[@id="container"][1]/px-tree-view-node/ul/li[2]/px-tree-view-branch'));
        },

        getAttributeList: function() {
            return element(by.css('#container px-tree-view-node ul li[2] px-tree-view-branch #container px-tree-view-node ul li px-tree-view-leaf #label'));
        },
        getDraggableAttribute: function() {
            return element.all(by.css('#label.tree-view-level-2.px-tree-view-leaf'));

        },
        constantDefinitionMapped: function() {
            return element(by.css('#apm-dp-constant-0 > td.data-value > div.draggedAttribute'));
        },
        getByClassIcon: function() {
            return element(by.css('.fa-at'));
        },
        constantDefinitionMappedToTag: function() {
            return element(by.css('#apm-dp-constant-0 > td.data-value > div.draggedAttribute'));
        },
        getBySubTemplateIcon: function() {
            return element(by.css('.fa-sitemap'));
        },
        clearSearchTag: function() {
          return element(by.css('#apm-dp-asset-hierarchy-search > a > i.fa-close'))
        },
        constantDefinitionMappedToTagFromSubTemplateIcon: function() {
            return element(by.css('#apm-dp-constant-0 > td.data-value > div.draggedAttribute'));
        },
        getDraggableCommonTagBySubTemplate: function() {
            return element.all(by.css('div#label.tree-view-label.style-scope.px-tree-view-leaf.tree-view-level-3')).first();

        },
        outputDefinitionMappedToTag: function() {
            return element(by.css('#apm-dp-output-1> td:nth-child(5) > span > span'));
        },
        versionNumberIOMapping: function(){
            return element(by.css('.apm-dp-iomap-inputDescription'));
        },
        addTagWithPlusSign : function () {
            return element(by.css('.assetTagBox .fa.fa-plus')).click();
        },
        selectFirstInputRow : function () {
            return element(by.css('#apm-dp-input-row-0')).click();
        },
        ioMappingDropdown : function () {
            return element.all(by.css('.apm-ax-artifact-list .apm-ax-artifact-version')).getText();
        },
        ioMappingMapForAllAssets  : function () {
            return element(by.id('#apm-dp-iomap-mapByInput'))
        }
    }
  };
  module.exports = new cafIOMappingPage();
})();

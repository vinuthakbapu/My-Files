/********************************************************************************
 * Copyright (c) 2015-2016 GE Digital. All rights reserved.                     *
 *                                                                              *
 * The copyright to the computer software herein is the property of GE Digital. *
 * The software may be used and/or copied only with the written permission of   *
 * GE Digital or in accordance with the terms and conditions stipulated in the  *
 * agreement/contract under which the software has been supplied.               *
 ********************************************************************************/


/**
 * Class encapsulating all functions in main landing page
 */
(function () {
    'use strict';


    var TIMEOUT = 5000;


    var orchStepsPage = function () {

        var currentPage = 'orchTenantPage';
        var createdName;
        var randOrch = Date.now();
        var getAnalyticName;
        var analyticSearchName="AutomationExp1";
        var analyticSearchName2="Exp";

        return {

            viewOrchName:function(){
                return element(by.css('.header-name'))
            },
            

            orchNameDataFlow: function(){
                return element(by.css('.second-header-item'));
            },

            Applicability: function(){
                return element.all(by.css('.description-text-padding')).get(1);
            },
                
            noAnalyticText: function(){
                return element(by.css('.no-analytic'));
            },

            closeButton: function()
            {
                return element(by.id('close-editview-btn'));
            },

            
            //RIGHT COL ANALYTCS
           
            analyticRightPlus: function(){
                return element.all(by.id('addAnalytic'))
            },

            analyticRightInfoBox: function(){
                return element.all(by.css('analytic-info-box'))
            },

            analyticRightName: function(){
                return element.all(by.css('.analytic-name'))
            },

            analyticEditor:function(){
                return element.all(by.css('.analytic-box'));
            },

            analyticEditorName: function(){
                return element.all(by.css('.analytic-name-text'));
            },

            analyticSearch:function(){
                return element(by.id('analytic-search'));
            },

            stepsClearedSearch: function(){
                return element(by.id('clearedSearch'));
            },
            
            analyticEnterName:function(arg1){
                this.analyticSearch().sendKeys(arg1);
            },

            analyticEnterSampleName:function(){
                this.analyticSearch().sendKeys(analyticSearchName2);
            },

            //DRAG AND DROP
            analyticToDrag:function(){
                //return element.all(by.css('div.list-analytic-box > div > div'));
                return element.all(by.css('div.list-analytic-box > div '));
            },
            
            editorToDrop: function(){
                return element(by.id('editor'));
            },
            
            
            //FIRST ANALYTIC
            /*firstAnalyticPlus: function(){
                return element.all(by.id('addAnalytic')).get(0);
            },
            
            firstAnalyticName: function(){
                return element.all(by.css('.analytic-name')).get(0);
            },*/



            getFirstAnalyticName: function(){
                this.analyticRightName().get(0).getText().then(function(name){
                    return name;
                });
            },

            firstAnalyticEditor: function(){
                return element.all(by.css('#editor .analytic-box'));
            },

            firstAnalyticEditorName: function(){
                return element.all(by.css('#editor .analytic-box text')).get(0);
            },


            //SECOND ANALYTIC
            secondAnalyticPlus: function(){
                return element.all(by.id('addAnalytic')).get(1);
            },

            secondAnalyticName: function(){
                return element.all(by.css('.analytic-name')).get(1);
            },

            getSecondAnalyticName: function(){
                getAnalyticName= this.firstAnalyticName().getText();
                return getAnalyticName;
            },

            secondAnalyticEditorName: function(){
                return element.all(by.css('#editor .analytic-box text')).get(1);
            },


//THIRD ANALYTIC
            thirdAnalyticPlus: function(){
                return element.all(by.id('addAnalytic')).get(2);
            },

            thirdAnalyticName: function(){
                return element.all(by.css('.analytic-name')).get(2);
            },

            getThirdAnalyticName: function(){
                getAnalyticName= this.firstAnalyticName().getText();
                return getAnalyticName;
            },

            thirdAnalyticEditorName: function(){
                return element.all(by.css('#editor .analytic-box text')).get(2);
            },


            //Insert Confirmation POPUP

            insertPopupConfirm: function(){
                return element(by.css('.ReactModal__Content h2'));
            },

            insertSubmit:function(){
                return element(by.id('submitModalBtn'));
            },

            insertClose:function(){
                return element(by.id('closeModalBtn'));
            },


            //Delete Confirm popup

            hoverOver:function(){
                return element.all(by.css('.analytic-hover-icon'));
            },
            

            closeIcon:function(){
                return element.all(by.css('.analytic-close-icon'));
            },
        
            externalLink:function(){
                return element.all(by.css('.fa-external-link'));
            },
            
            deletePopupConfirm: function(){
                return element(by.css('.ReactModal__Content h2'));
            },

            deleteRemove:function(){
                return element(by.id('submitModalBtn'));
            },

            deleteClose:function(){
                return element(by.id('closeModalBtn'));
            },

            deleteIcon: function() {
                return element(by.css('.fa.fa-trash'));
            },

            //Close Button Right Corner
            closeButtonRightCorner:function(){
                return element(by.id('close-editview-btn'));
            },


            analyticToolTip:function(){
                return element(by.css('.analytic-tooltip span'));
            },

            analyticListVersion:function(){
                return element.all(by.css('.analytic-details span'));
            },

            incompleteMappingTextModalOrch:  function()
            {
                return element.all(by.css('.incomplete-mapped-indicator'));
            },

            orchRadioButton: function() {
                return element(by.css('input#Orchestration'));
            },


        }
    };

    module.exports = new orchStepsPage();

}());
/**
 * Created by 212350438 on 7/9/15.
 */

(function () {

    'use strict';


    var AnalysisPAPage = function () {
        var currentPage = "parallelAxisPage";
        return {

            selectChartType: function (chartType) {
                console.log("ChartType: "+chartType)
                aemPath[currentPage]['chartDropdownOption'].locatorValue=chartType;
                console.log("Here: "+aemPath[currentPage]['chartDropdownOption'].locatorValue);
                return TestHelper.elementToBeClickable(currentPage,"chartDropdownOption");
            },

            selectChartTypeFor2ndChart: function (chartType) {
                console.log("ChartType: "+chartType)
                aemPath[currentPage]['chartDropdownOptionFor2ndChart'].locatorValue=chartType;
                console.log("Here: "+aemPath[currentPage]['chartDropdownOptionFor2ndChart'].locatorValue);
                return TestHelper.elementToBeClickable(currentPage,"chartDropdownOptionFor2ndChart");
            },

            checkHintMessage: function () {
                return TestHelper.getText(currentPage,"hintMessage");
            },

            getPAChartArea: function(){
                return TestHelperPO.isElementVisible(element(by.css('.chart-target.chart-target-overlay.style-scope.chart-parx'))).then(function(){
                    return element(by.css('.chart-target.chart-target-overlay.style-scope.chart-parx'));  // for Chart Area
                })
            },
        };
    }
    module.exports = new AnalysisPAPage();
}())


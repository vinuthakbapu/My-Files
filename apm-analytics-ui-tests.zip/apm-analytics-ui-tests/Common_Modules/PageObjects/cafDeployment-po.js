/**
 * Class encapsulating all functions in main landing page
 */
(function () {
    'use strict';

    var TIMEOUT = 5000;

    var deploymentPage = function () {

        var randVal = Date.now();

        return {

            visibilityOf: function (elementID) {
                var EC = protractor.ExpectedConditions;
                return browser.wait(EC.visibilityOf(elementID), 10000)
            },

            elementToBeClickable: function (elementID) {
                var EC = protractor.ExpectedConditions;
                return browser.wait(EC.elementToBeClickable(elementID), 5000)
            },

            clickDeploymentConfigTab: function () {
                return element(by.css("a[href$='/caf/#/deployment']")).click();
            },

            gotoConfigPage: function () {
                return browser.getCurrentUrl().then(function (url) {
                    url = url + "/configs/123";
                    return browser.get(url);
                });
            },

            getSearchButton: function () {
                return element.all(by.id('asset-filter-search')).get(0);
            },

            getPrevButton: function () {
                return element(by.cssContainingText('.apm-btn.apm-dp-breadcrumb-nav-button', 'Prev'));
            },

            deploymentPrevButton: function(){
                return element(by.id('apm-dp-breadcrumb-prev-button'));
            },

            getAssetFilterDropdown: function () {
                return element(by.id('asset-filter'));
            },

            addDeployment: function () {
                return element(by.css('i[title="Create Deployment"]'));
            },

            editDeployment: function () {
                return element(by.id('apm-dp-deployment-edit'));
            },

            addAnalyticDeployment: function () {
                return element(by.css('i[title="Add Deployment"]'));
            },

            deploymentName: function () {
                return element(by.id('DeploymentNameInputBox'));
            },

            deploymentNameInCatalogList: function () {
                return element(by.css('#apm-dp-deployment-list-item0 > .apm-dp-link-box > .apm-dp-deployment-data-box-first > .apm-dp-deployment-item-name'));
            },

            deploymentDateInCatalogList: function () {
                return element(by.css('#apm-dp-deployment-list-item0 > .apm-dp-link-box > .apm-dp-deployment-data-box-second > .apm-dp-deployment-item-date'));
            },

            analyticNameInCatalogList: function () {
                return element(by.css('#apm-dp-deployment-list-item0 > .apm-dp-link-box > .apm-dp-deployment-data-box-first > .apm-dp-deployment-item-template'));
            },

            deploymentStatusInCatalogList: function () {
                return element(by.css('#apm-dp-deployment-list-item0 > .apm-dp-link-box > .apm-dp-deployment-data-box-second > .apm-dp-deployment-item-status'));
            },

            deploymentNameInDeploymentDetailsPage: function () {
                return element(by.css('.header-name.apm-dp-header-name'));
            },

            analyticNameInDeploymentDetailsPage: function () {
                return element(by.css('.apm-dp-subheader'));
            },
            isDeploymentsLinkAvailable: function() {
                return element(by.css("a[href$='/#/deployment']")).isDisplayed();
            },
            isDeploymentsLinkNotAvailable: function() {
                return element(by.css("a[href$='/#/deployment']")).isPresent();
            },

            editIconInDeploymentDetailsPage: function () {
                return element(by.id('apm-dp-deployment-edit'));
            },

            deleteIconInDeploymentDetailsPage: function () {
                return element(by.id('apm-dp-deployment-delete'));
            },

            scheduleAndDataRequestHeader: function () {
                return element(by.cssContainingText('.title-header', 'Schedule and Data Request'));
            },

            scheduleAndDataRequestData: function () {
                return element.all(by.css('.apm-dp-review-not-configured-string')).get(0);
            },

            savedDateInDeploymentDetailsPage: function () {
                return element(by.css('.apm-dp-update-info.update-last-saved'));
            },

            assetsHeader: function () {
                return element(by.cssContainingText('.title-header', 'Assets'));
            },

            assetsData: function () {
                return element.all(by.css('.apm-dp-review-not-configured-string')).get(1);
            },

            mapByInput: function () {
                return element(by.id('apm-dp-iomap-mapByInput'));
            },

            mapByAsset: function () {
                return element(by.id('apm-dp-iomap-mapByAsset'));
            },

            requiredInputsMappedPercentage: function () {
                return element.all(by.css('.mappedRequiredRatio')).get(1);
            },

            requiredInputsMappedCount: function () {
                return element(by.css('.mapped-required-ratio > span:nth-child(3)'))
            },

            inputsMappedPercentage: function () {
                return element.all(by.css('.mappedRatio')).get(1);
            },

            inputsMappedCount: function () {
                return element(by.css('.mapped-ratio > span:nth-child(3)'));
            },

            exclamationIcon: function () {
                return element(by.css('.fa.fa-exclamation-circle.inputs-not-mapped'));
            },

            getHelpText: function () {
                return element(by.css('.fa.fa-exclamation-circle.inputs-not-mapped')).getAttribute("title");
            },

            dataFlowRow: function () {
                return element(by.id('data_table'));
            },

            inputDefinitionRow: function () {
                return element(by.id('apm-dp-input-row-0'));
            },

            constantRow: function () {
                return element(by.id('apm-dp-constant-0'));
            },

            outputDefinitionRow: function () {
                return element(by.id('apm-dp-output-0'));
            },

            deploymentsHeader: function () {
                return element(by.linkText('Deployments'));
            },

            addDeploymentIcon: function () {
                return element(by.css('.fa-plus'));
            },

            deploymentDetailsPage: function () {
                return element(by.css('.apm-dp-detail-panel'));
            },


            templateName: function () {
                return element(by.id('modalTypeahead'));
            },

            analyticName: function () {
                return element(by.id('search'));
            },

            searchResults: function () {
                return element(by.id('searchResults'));
            },

            clickTypeaheadResult: function (el) {
                return TestHelperPO.elementToBeClickable(el.element(by.xpath('li[1]')));
            },

            analyticFirstResult: function (el) {
                return element(by.css('#searchResults > li:nth-child(1)'));
            },

            newDeploymentSubmit: function () {
                return element(by.css('.apm-dp-submitButton'));
            },

            closeDeployment: function () {
                return element(by.id('apm-dp-config-close-button'));
            },

            deploymentList: function () {
                return element(by.css('.apm-dp-list-container'));
            },

            existingDeploymentName: function () {
                return element(by.css('.apm-dp-header-name'));
            },

            deploymentStatus: function () {
                return element(by.css('.apm-dp-deployment-item-status'));
            },

            cafDeleteDeployment: function () {
                return element(by.id('apm-dp-deployment-delete'));
            },

            cafForceDeleteDeployment: function () {
                return element(by.css('input[type="checkbox"]'));
            },

            deploymentSearchInput: function () {
                return element(by.css('.apm-search-input'));
            },

            isCAFDeleteDeploymentClickable: function () {
                return TestHelperPO.elementToBeClickable(element(by.id('apm-dp-deployment-delete')));
            },

            deploymentDeleteConfirm: function () {
                return element(by.id('submitModalBtn'));
            },

            iscreatedepbuttonNotDisplayed: function () {
                return element(by.css('.fa-plus')).isPresent();
            },

            cafDeleteDeploymentIcon: function(){

                return element(by.css('#apm-ax-delete-deployment-row-0 i.fa.fa-trash'));
            },

            deploymentDeleteConfirmInDeploymentsTab: function(){
                return element(by.id('apm-af-submitModalBtn'));
            },

            clickAnalyticTemplate: function () {
                return element(by.linkText('Analytics Templates')).click();
            },

            clickAnalyticDeployment: function () {
                let deploymentTab = element(by.cssContainingText('.ReactTabs__TabList.template-tab-list li','Deployments'));
                return deploymentTab.click();
            },

            clickAnalyticCatalogTab: function () {
                return element(by.css("a[href$='/#/analytics']")).click();
            },

            clickSearchBox: function(){
                console.log("clicking search box 1....");
                return TestHelperPO.elementToBeClickable(element(by.css('.apm-search-input')));
            },

            firstDeploymentResult: function () {
                return TestHelperPO.elementToBeClickable(element(by.css('.apm-dp-link-box')));
            },

            deploymentStatusDetailsPage: function () {
                return element(by.css('.apm-dp-status'));
            }
        };


    };


        module.exports = new deploymentPage();


}());

/* created by 212340705 on Jan 6th 2016 */
(function(){
    'use strict';
    
    var currentpage = 'DashboardAppPages';
    var customCardPage = function(){
        return {
            getCustomCardThumbnail: function () {
//               return TestHelper.isElementPresent(currentpage, 'customCardThumbnail');
                return element.all(by.css('section.add-card-template div.card-thumb-img')).get(0);
            },
            getCustomcardPreviewBtn: function () {
                return element.all(by.id('preview-btn')).get(0);
//                return TestHelper.isElementPresent(currentpage, 'customCardPreviewBtn');
            },
            getCustomcardAddBtn: function () {
                // return element.all(by.id('add-btn')).get(0);
                return TestHelper.isElementPresent(currentpage, 'customCardAddBtn');
            },
            clickCustomcardAddBtn: function () {
                // return element.all(by.id('add-btn')).get(0);
                return TestHelper.elementToBeClickable(currentpage, 'customCardAddBtn');
            },
            clickAddCardButtonInCardLibrary: function (cardname) {
                //return TestHelperPO.elementToBeClickable(element(by.cssContainingText('#cardContainer h4 span +div button#add-btn',cardname)));
                // return element(by.xpath('//span[text()="'+ cardname + '"]/following-sibling::div/button[@id="add-btn"]')).click();
                var Btnele = element(by.xpath('//span[text()="'+ cardname + '"]/following-sibling::div/button[@id="add-btn"]'));

                return TestHelperPO.elementToBeClickable(Btnele);
            },
            clickPreviewButtonInCardLibrary: function (cardname) {
                //return TestHelperPO.elementToBeClickable(element(by.cssContainingText('#cardContainer h4 span +div button#add-btn',cardname)));
                // return element(by.xpath('//span[text()="'+ cardname + '"]/following-sibling::div/button[@id="preview-btn"]')).click();
                var Btnele = element(by.xpath('//span[text()="'+ cardname + '"]/following-sibling::div/button[@id="preview-btn"]'));

                return TestHelperPO.elementToBeClickable(Btnele);
            },
            clickAddCardPreviewButtonInCardLibrary: function (cardname) {
                //return TestHelperPO.elementToBeClickable(element(by.cssContainingText('#cardContainer h4 span +div button#add-btn',cardname)));
                // return element(by.xpath('//span[text()="'+ cardname + '"]/following-sibling::div/button[@id="preview-btn"]')).click();
                var btnEle = element(by.xpath('//span[text()="'+ cardname + '"]/following-sibling::div/button[@id="preview-btn"]'));
                return TestHelperPO.elementToBeClickable(btnEle);

            },
            clickThumbnailImageInAddCardLibrary: function (cardname) {
                //return TestHelperPO.elementToBeClickable(element(by.cssContainingText('#cardContainer h4 span +div button#add-btn',cardname)));
                // return element(by.xpath('//span[text()="'+ cardname +'"]/parent::h4/following-sibling::a/div[contains(@class, "card-thumb-img")]')).click();
                var btnEle = element(by.xpath('//span[text()="'+ cardname +'"]/parent::h4/following-sibling::a/div[contains(@class, "card-thumb-img")]'));
                return TestHelperPO.elementToBeClickable(btnEle);
            },
            ChkAddCardButtonInCardLibrary: function (cardname) {
                //return TestHelperPO.elementToBeClickable(element(by.cssContainingText('#cardContainer h4 span +div button#add-btn',cardname)));
                // return element(by.xpath('//span[text()="'+ cardname + '"]/following-sibling::div/button[@id="add-btn"]')).isPresent();
                var Btnele = element(by.xpath('//span[text()="'+ cardname + '"]/following-sibling::div/button[@id="add-btn"]'));

                return TestHelperPO.isElementVisible(Btnele);

            },
            getOverviewcardAddBtn: function () {
                // return element.all(by.id('add-btn')).get(0);
                return TestHelper.isElementPresent(currentpage, 'overviewCardAddBtn');
            },
            clickOverviewcardAddBtn: function () {
                // return element.all(by.id('add-btn')).get(0);
                return TestHelper.elementToBeClickable(currentpage, 'overviewCardAddBtn');
            },
            getCustomcardSaveBtn: function () {
                // return element.all(by.css('div.saveBtn >button.custom-card')).get(1);
                return TestHelper.isElementPresent(currentpage, 'customCardSaveBtn');
            },
            clickCustomcardSaveBtn: function () {
                // return element.all(by.css('div.saveBtn >button.custom-card')).get(1);
                return TestHelper.elementToBeClickable(currentpage, 'customCardSaveBtn');
            },
            
            addCustomCard: function () {
                return protractor.promise.all([
                    addcardpage.getCardActionMenuBtn().click(),
                    addcardpage.getAddNewCardLink().click(),
                    this.getCustomcardAddBtn.click(),
                    browser.sleep(15000)
                ], 2000).then(function () {
                    addcardpage.getDoneButton().click();
                    browser.sleep(2000);
                })
            },
            addCustomCardfromPreview: function () {
                var self = this;

                return protractor.promise.all([
                    addcardpage.getCardActionMenuBtn().click(),
                    addcardpage.getAddNewCardLink().click(),
                    this.getCustomcardPreviewBtn.click(),
                    browser.sleep(25000),
                    addcardpage.getPreviewAddButton().click(),
                    browser.sleep(5000),
                    addcardpage.getDoneButton().click(),
                    browser.sleep(5000)
                ], 15000).then(function () {
                    console.log('clicked on done button after adding a card from preview screen');
                })
            },
            createDashboardWithCustomCard: function (VuName) {
                var self = this;
                console.log('inside createDashboardWithCustomCard');
                return createviewpage.chkViewSelectorDropdown().then(function (present) {
                    if(present){
                        console.log('deckselector present');
                        createviewpage.clickViewSelectorDropdown().then(function () {
                            dem.findElement(currentpage, 'dropdown').getAttribute('hidden').then(function(present2){
                                if(present2){
                                    console.log('deck selector dropdown is hidden so click on the dropdown once again');
                                    createviewpage.clickViewSelectorDropdown().then(function () {
                                        TestHelper.scrollIntoView(currentpage,'AddDashboardLink').then(function() {
                                            createviewpage.clickAddDashboardLink().then(function () {
                                                createviewpage.getViewnameInputfield().sendKeys(VuName);
                                                self.clickCustomcardAddBtn().then(function(){
                                                    createviewpage.clickSaveViewButton().then(function () {
                                                        createviewpage.clickDoneButton().then(function () {browser.sleep(3000)});
                                                    })
                                                })
                                            });
                                        });
                                    });
                                }else {
                                    TestHelper.scrollIntoView(currentpage, 'AddDashboardLink').then(function () {
                                        createviewpage.clickAddDashboardLink().then(function () {
                                            createviewpage.getViewnameInputfield().sendKeys(VuName);
                                            self.clickCustomcardAddBtn().then(function(){
                                                createviewpage.clickSaveViewButton().then(function () {
                                                    createviewpage.clickDoneButton().then(function () {browser.sleep(3000)});
                                                })
                                            })
                                        });
                                    });
                                }

                            });

                        })
                    } else {
                        console.log('empty dashboard container');
                        createviewpage.clickEmptyDashboardButton().then(function () {
                            createviewpage.getViewnameInputfield().sendKeys(VuName);
                            self.clickCustomcardAddBtn().then(function(){
                                createviewpage.clickSaveViewButton().then(function () {
                                    createviewpage.clickDoneButton().then(function () {browser.sleep(3000)});
                                })
                            })
                        });
                    }
                })
            },
            getAllAddTilePlusSign: function(){
                    return element.all(by.css('div#container custom-card i.fa-plus'));
                // return TestHelper.findElement(currentpage, 'customCardPlusBtn');
            },
            getAddTilePlusSignCount: function(){
                return element.all(by.css('div#container custom-card i.fa-plus')).count();
                // return TestHelper.findElement(currentpage, 'customCardPlusBtn');
            },
            getVerticalTilePlusSign: function(){
                return element.all(by.css('div#container custom-card i.fa-plus')).get(0);
                // return TestHelper.isElementPresent(currentpage, 'customCardVerticalPlusBtn');
            },
            getHorTilePlusSign: function(num){
                return element.all(by.css('div#container custom-card i.fa-plus')).get(Number(num)-1);
                // return TestHelper.isElementPresent(currentpage, 'customCardVerticalPlusBtn');
            },
            getTile1InRow1: function(){
                return element(by.css('div#container custom-card div#r1 div#d1'));
                // return TestHelper.findElement(currentpage, 'customCardTile1InRow1');
            },
            getTile2InRow1: function(){
                //return element(by.css('div#container custom-card div#r1 div#d2'));
                return element(by.css('div#container div#mainDiv'));
                // return TestHelper.isElementPresent(currentpage, 'customCardTile2InRow1');
            },
            getTile3InRow1: function(){
                return element(by.css('div#container custom-card div#r1 div#d3'));
                // return TestHelper.isElementPresent(currentpage, 'customCardTile3InRow1');
            },
            getAllTileCountInEditMode: function(){
                return element.all(by.css('div#container custom-card div.custom-card.layout__block')).count();
                // return TestHelper.isElementPresent(currentpage, 'customCardTileCountInEditMode');

            },
            getAllTileCountInSaveMode: function(){
                return element.all(by.css('div#container custom-card div.custom-card.layout__block')).count();
                // return TestHelper.isElementPresent(currentpage, 'customCardPlusBtn');
            },
            getWidgetLibraryPageHeader: function(){
                return TestHelperPO.isElementPresent(element(by.cssContainingText('section.add-widget >div.add-widget','Widget Library')));
            },
            getCancelBtnWidgetLibrary: function(){
                return TestHelperPO.isElementPresent(element(by.cssContainingText('button.add-widget','Cancel')));
            },
            getBackBtnWidgetLibrary: function(){
                return TestHelperPO.isElementPresent(element(by.cssContainingText('section.add-widget #back-btn','Back')));
            },
            clickBackBtnWidgetLibrary: function(){
                return TestHelperPO.elementToBeClickable(element(by.cssContainingText('section.add-widget #back-btn','Back')));
            },
            getWidgetContainerWidgetLibrary: function(){
                // return element(by.css('section.add-widget div#widgetLibraryContainer'));
                return TestHelper.isElementPresent(currentpage, 'WidgetContainerWidgetLibrary');
            },
            getGenericGraphWidgetTtl: function(){
                // return element(by.css('a[title="Generic Graph Widget"]'));
                return TestHelper.isElementPresent(currentpage, 'customCardPlusBtn');
            },
            getAddButtonWidgetLib: function(){
                //return element.all(by.css('button#add-btn'));
                return element.all(by.css('div.add-widget button#add-btn'));
                // return TestHelper.isElementPresent(currentpage, 'addButtonWidgetLib');
            },
            clickAddButtonWidgetLib: function(widget){
                //return element.all(by.css('button#add-btn'));
                // return element.all(by.css('div.add-widget button#add-btn'));
                // dem2[currentpage]['addButtonWidgetLib'].value.index=num;
                return TestHelperPO.elementToBeClickable(element(by.css("#" + widget + " button#add-btn")));
            },
            clickAddBtnInWidgetLib: function(widget){
                console.log("clickAddWidgetLib",widget);
                //#widgetLibraryContainer [title='Asset Overview'] +div #add-btn
                return TestHelperPO.elementToBeClickable(element(by.css("#widgetLibraryContainer [title='"+widget+"'] +div #add-btn")));
                //return TestHelperPO.elementToBeClickable(element(by.xpath("//span[@title='"+widget+"']/following-sibling::div/button")));
            },
            getWidgetInWidgetLib: function(widget){
                dem2[currentpage]["WidgetTitleInWidgetLibrary"].locatorValue = widget;
                return TestHelper.isElementPresent(currentpage, 'WidgetTitleInWidgetLibrary');
                // console.log("title: " + widget);
                // return TestHelperPO.isElementVisible(element(by.css("#widgetLibraryContainer [title='"+ widget +"']")));
            },

            getWidgetImageInWidgetLib: function(image){
                // return TestHelperPO.isElementVisible(element(by.css("#apm-hmi-v1-0 img[src='widget-library-img/v1/widgets/apm-hmi/image?v=1.0']")));
                return TestHelperPO.isElementVisible(element(by.css("#apm-hmi-v1-0 img[src='" + image + "']")));
            },
            GetThumbTitleWidgetLib: function(){
                return element.all(by.css('h4 >span.add-widget'));
                // return TestHelper.isElementPresent(currentpage, 'thumbTitleWidgetLib');
            },
            GetDescriptionWidgetLib: function(){
                return element.all(by.css('div#widgetDescription'));
                // return TestHelper.isElementPresent(currentpage, 'descriptionWidgetLib');
            },
            GetThumbImageWidgetLib:function(){
                return element.all(by.css('#widgetLibraryContainer div.card-thumb-img'));
                // return TestHelper.isElementPresent(currentpage, 'thumbImageWidgetLib');
            },
            getWidgetOnCard:function(widgetTitle){
                return TestHelperPO.isElementPresent(element(by.cssContainingText("div#container .widget-container h3", widgetTitle)));
            },

            getWidgetTitleOnCard:function(widgetTitle) {
                return TestHelperPO.isElementPresent(element(by.cssContainingText("h3.opm-header-title.style-scope.ged-opm-forecast-v1-0", widgetTitle)));
            },

            getHMIstatusIcon:function(){
                return TestHelper.isElementVisible(currentpage, 'HMIStatusIcon')
            },
            getHMICanvas:function(){
                return TestHelper.isElementVisible(currentpage, 'HMICanvas')
            },
            getKPIWidgetOnCard:function(widgetTitle){
                return TestHelperPO.isElementPresent(element.all(by.cssContainingText(".display-header .apm-widget-frame-kpi-v2-0", widgetTitle)).get(0));
            },
            getCurrentWidgetOnCard:function(widgetTitle){
                return TestHelperPO.isElementPresent(element(by.cssContainingText(".title-header span[title='" + widgetTitle + "']", widgetTitle)));

            },
            getwidget:function(num){
                // return element(by.css('div.display-header'));
                //return TestHelper.isElementPresent(currentpage, 'widgetOnCard');
                dem2[currentpage]['widget'].value.index=num;
                return dem.findElement(currentpage, 'widget')
            }
        }
    };
    module.exports = new customCardPage();
}())
/**
 * Class encapsulating all functions in main landing page
 */
(function () {
  'use strict';


  var TIMEOUT = 5000;


  var cafSchedulePage = function () {

    var currentPage = 'AnalyticsDeployment';

    var createdName;
    var randVal = Date.now();

    return {

      visibilityOf: function (elementID) {
        var EC = protractor.ExpectedConditions;
        return browser.wait(EC.visibilityOf(elementID), 10000)
      },

      elementToBeClickable: function (elementID) {
        var EC = protractor.ExpectedConditions;
        return browser.wait(EC.elementToBeClickable(elementID), 5000)
      },
      
      breadcrumbScheduleTab: function() {
        return element(by.css('a[tabIndex="2"]'));
      },

      scheduleStreaming: function(){
            return element(by.css('input[value="DeployForStreamingData"]'));
        },
      scheduleRecurrent: function(){
        return element(by.css('input[value="DeployBySchedule"]'));
      },

      timespanFrom: function(){
        return element(by.id('fromFields'));
      },

      timespanTo: function(){
        return element(by.id('toFields'));
      },

      interpolatedOption: function() {
        return element(by.css('input[value="Interpolated"]'));
      },
      
      samplingIntervalRunOnce: function(){
        return element(by.css('#runonce_intervals'));
      },
      
      samplingIntervalRecurrent: function(){
        return element(by.css('input[name="intervals"]'));
      },

      samplingIntervalUnits: function(){
        return element(by.css('.input-inline.samplingInterval .apm-dropdown.input-inline'));
        // uncomment when # added to qa
        // return element(by.css('#apm-dp-dropdown-sampling-interval-unit'));
      },

        repeatEveryValue: function() {
            return element(by.css('.apm-dp-recurrent-repeats-every-box .apm-text-input-field.apm-dp-text-input'));
        },

        scheduleDefaultTextBoxes: function(){
        return element.all(by.css('.input-inline.apm-dp-offset input'));
      },

      repeatEveryDropDown: function(){
        return element(by.css('.apm-dp-recurrent-repeats-every-box .apm-dropdown.input-inline'));
      },

      offSet: function(){
        return element(by.css('.input-inline.apm-dp-offset .apm-text-input-field.apm-dp-text-input'));
      },

      offSetDropDown: function(){
        return element(by.css('.input-inline.apm-dp-offset .apm-dropdown.input-inline'));
      },


      sampleDurationValue: function(){
        return element(by.css('.input-inline .apm-text-input-field.apm-dp-text-input'));
      },

      sampleDurationDropDown: function(){
        return element(by.css('select.apm-dropdown.input-inline'));
      },

      minutesValue: function() {
        return element(by.css('option[value="MINUTES"]'));
      },

        secondsValue: function() {
            return element(by.css('option[value="SECONDS"]'));
        },

      sampleIntervalValue: function(){
        return element(by.css('.input-inline.samplingInterval .apm-text-input-field.apm-dp-text-input'));
      },

      sampleIntervalDropDown: function(){
        return element(by.css('.input-inline.samplingInterval .apm-dropdown.input-inline'));
      },

      deploymentNameHeader: function() {
        return element(by.id('apm-dp-config-last-saved-name'));
      },

      titleHeader: function() {
        return element(by.css('.title-header'));
      },

      saveButton: function() {
        return element(by.id('apm-dp-schedule-save'));
      },

      scheduleBreadcrumb: function() {
        return element(by.css('#apm-dp-breadcrumb-item-2 a'));
      },

      powerFabricScheduleOptions: function(){
         return element.all(by.css('.apm-dp-recurrent-repeats-every-box .apm-dp-recurrent-text.apm-dp-data-request'))

        },

        retryUponFailureLbl: function(){
            return element(by.css('.apm-dp-recurrent-repeats-every-box .right-label-text'))

        },

        powerFabrictooltipBtns: function(){
            return element.all(by.css('.fa.fa-question-circle.apm-dp-hover-tooltip'))
        },

        powerFabrictooltipContents: function(){
            return element.all(by.css('.apm-dp-style'))
        },
        powerFabricDropdowns: function(){
            return element.all(by.css('.apm-dropdown.input-inline'))
        },
        retryUponFailureDiv: function(){
          return element(by.css('.toggle-button-container'))
      },
        selectfromDropdown: function (val) {
            return element(by.cssContainingText('option', val)).click();
        },
        deploymentDate: function () {
            return element(by.cssContainingText('.radio-inline','Deployment Date'))
        },
        RawDataFormat: function () {
            return element(by.cssContainingText('.radio-inline','Raw'))
        },

        specificDate: function () {
            return element(by.cssContainingText('.radio-inline','Specific Date'))
        },
        interpolated: function () {
            return element(by.cssContainingText('.radio-inline','Interpolated'))
        },

        dataRequestSchedule: function () {
            return element.all(by.css('.apm-dp-streaming-text'))
        },

        selectRun: function () {
            return element.all(by.css('.apm-dp-select-run')).get(1);
        },

        startDatelbl: function () {
            return element(by.css('.apm-dp-offset.apm-dp-recurrent-text.apm-dp-data-request.apm-dp-top-padding')).get(1);
        },

        datePicker: function () {
            return element(by.css('.apm-dp-picker'));
        },

        interpolatedOptions: function () {
            return element.all(by.css('.input-inline .apm-dp-runonce-header'));
        },
        
        retryUponFailureBtn: function () {
            return element(by.css('.react-toggle.react-toggle--checked.blue-color'))
        },

        scheduleDateCalendar: function () {
            return element (by.css('.react-datepicker__input-container input'))
        }

    };
  };
  module.exports = new cafSchedulePage();

}());



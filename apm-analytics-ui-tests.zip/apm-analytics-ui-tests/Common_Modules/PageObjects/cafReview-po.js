(function () {
  'use strict';


  var cafReviewPage = function () {

    return {

      visibilityOf: function (elementID) {
        var EC = protractor.ExpectedConditions;
        return browser.wait(EC.visibilityOf(elementID), 10000)
      },

      elementToBeClickable: function (elementID) {
        var EC = protractor.ExpectedConditions;
        return browser.wait(EC.elementToBeClickable(elementID), 5000)
      },

      cafReviewStep: function(){
        return element.all(by.repeater('step in flow')).get(3);
      },

      deployConfirmTab: function(){
        return element(by.css('.apm-dp-review-container'));
      },

      editSchedule: function(){
        return element(by.id('goEditSchedule'));
      },

      deployByScheduleConfirm: function(){
        return element(by.css('.apm-dp-schedule-asset-data'));
      },

      deployByScheduleConfirmValue1: function(){
        return element(by.xpath("//div[@class='scheduling-summary-container']/div/div[2]/span[1]"));
      },

      deployByScheduleConfirmValue2: function(){
        return element(by.xpath("//div[@class='scheduling-summary-container']/div/div[2]/span[2]"));
      },

      deployOnDemandConfirmValue: function(){
        return element(by.xpath("//div[@class='scheduling-summary-container']/div/div[2]/span[1]"));
      },

//assets section
      assetDetailsSection: function(){
        return element.all(by.css('.title-header')).get(1);
      },

      assetsTable: function(){
        return element(by.css('.apm-dp-review-data-tittle'));
      },

      assetsTableRows: function(){
        return element.all(by.repeater('asset in paginatedAssets'));
      },

      showAssetsToggle: function() {
        return element(by.css('.apm-dp-edge-table-toggle'));
      },    
      
      reviewConfigButton: function() {
        return element(by.css('#apm-dp-breadcrumb-item-3'));
      },
      
      iconEdgeTableInvalid: function() {
        return element(by.css('.edge-table-invalid'));
      },

      isAssetsMappedEdgeValid: function() {
        return element(by.css('.apm-dp-edge-validation'));
      },

      assetsMappedCorrectly: function() {
        return element(by.css('.apm-dp-edge-validation div'));
      },

      edgeValidationTable: function() {
        return element(by.id('apm-dp-edge-asset-table'));
      },

      getValidationTableRows: function () {
          return element.all(by.css('table.edgeAssetTable tbody tr'));
      },
//inputs section

      inputsEditButton: function(){
        return element(by.id('goEditMapping'));
      },

      inputsTable: function(){
        return element.all(by.css('.ioMappingTable')).get(0);
      },

      inputsTableRows: function(){
        return element.all(by.repeater('input in paginatedInputs'));
      },
//constants section

      constantsEditButton: function(){
        return element(by.xpath('//*[@id="deploy-container"]/div[4]/div/div/div[3]/div/button'));
      },

      constantsTable: function(){
        return element.all(by.css('.ioMappingTable')).get(1);
      },

      constantsTableRows: function(){
        return element.all(by.repeater('constant in paginatedConstants'));
      },
//outputs section

      outputsEditButton: function(){
        return element(by.xpath('//*[@id="deploy-container"]/div[4]/div/div/div[5]/div/button'));
      },

      outputsTable: function(){
        return element.all(by.css('.ioMappingTable')).get(2);
      },

      outputsTableRows: function(){
        return element.all(by.repeater('output in paginatedOutputs'));
      },

      previousStepButton: function(){
        return element(by.id('apm-dp-breadcrumb-prev-button'));
      },

      nextStepButton: function(){
          return element(by.id('apm-dp-breadcrumb-next-button'));
      }


    };
  };
  module.exports = new cafReviewPage();

}());



/**
 * Created by 502664451 on 2/15/17.
 */

(function () {

    'use strict';


    var TagTreePage;
    TagTreePage = function () {
        var currentPage = "tagTreePage";
        return {
            getContextBrowser1: function () {
                return TestHelperPO.isElementPresent(element( by.css( 'div.px-context-browser')));
            },


        };
    };
    module.exports = new TagTreePage();
}())


/**
 * Class encapsulating all functions in main landing page
 */
(function () {
  'use strict';

  var TIMEOUT = 5000;

  var cafCreateAnalyticsPage = function () {

    var currentPage = 'analyticsTenantPage';
    var createdName;
    var randVal = Date.now();

    return {

      visibilityOf: function (elementID) {
        var EC = protractor.ExpectedConditions;
        return browser.wait(EC.visibilityOf(elementID), TIMEOUT * 2)
      },

      elementToBeClickable: function (elementID) {
        var EC = protractor.ExpectedConditions;
        return browser.wait(EC.elementToBeClickable(elementID), TIMEOUT)
      },

      verifyCreateAnalyticsTab: function () {
        return element(by.css(".pxh-navigation__item [title*='Analytics'][href*='/caf']")).getText();
      },

      clickAnalyticsLink: function () {
        console.log("inside clickAnalyticsLink function")
          return element(by.linkText('Analytics')).click();
      },

      clickAnalyticsTemplatesLink: function () {
        console.log("inside clickAnalyticsLink function")
        return element(by.linkText('Analytics Templates')).click();
      },
      
      clickAnalyticTab: function () {
        return element(by.css(".pxh-navigation__item [title*='Analytics'][href*='/caf']")).click();
      },

      clickOrchestrationLink: function () {
        console.log("inside clickOrchestration sub tab function")
        return element(by.linkText('Orchestrations')).click();
      },

      clickAnalyticTemplatesTab: function () {
        return element(by.linkText('Analytics Templates')).click();
      },

      clickDeploymentsTab: function () {
        return element(by.linkText('Deployments')).click();
      },

        clickConfigurationTab: function () {
            return element(by.linkText('Configuration')).click();
        },

        isConfigurationLinkAvailable: function() {
            return element(by.linkText('Configuration')).isDisplayed();
        },
        isConfigurationLinkNotAvailable: function() {
            return element(by.linkText('Configuration')).isPresent();
        },

      clickDashboardTab: function () {
        return element(by.css("a[href$='/dashboards/#']")).click();
      },

      clickMakeCurrentButton: function () {
        return element(by.id('apm-ax-btn-artifact-select-btn')).click();
      },


        clickFirstDeploymentRow: function () {
            return element(by.className('linkRadio')).click();
        },

        getSpecificRowCount: function(){
            return element.all(by.xpath('//*[@id="alert_table"]//tr[@id="apm-dp-constant-0"]')).count();
        },

        isFirstAlertTemplateDisabled : function() {
            return element(by.css('.react-toggle.blue-color-1')).isDisplayed();
        },

        isSecondAlertTemplateDisabled : function() {
            return element(by.css('.react-toggle.blue-color-1')).isDisplayed();
        },

        isFirstAlertTemplateEnabled : function() {
            return element(by.css('.react-toggle--checked')).isDisplayed();
        },

        isSecondAlertTemplateEnabled : function() {
            return element(by.css('.react-toggle--checked')).isDisplayed();
        },

        changeFirstAlertTemplateStatus : function() {
            return TestHelperPO.elementToBeClickable(element.all((by.css('.toggle-button-container'))).get(0))
        },

        changeSecondAlertTemplateStatus : function() {
            return TestHelperPO.elementToBeClickable(element.all((by.css('.toggle-button-container'))).get(1))
        },

        clickForNextIteration: function () {
            return element(by.id('apm-dp-mult-next-iteration')).click();
        },

        clickInputDataPoint: function () {
            return element(by.id('apm-dp-iomap-depStep-1')).click();
        },

        clickAnalyticCatalogTab: function () {
        return element(by.css("a[href$='/#/analytics']")).click();
      },
        clickAnalyticsMainLink: function() {
            return element(by.css('.fa-rocket')).click();
        },

      clickAssetFilterTab: function () {
        return element(by.css("a[href$='/#/assetFilters']")).click();
      },

      clickOrchestrations: function () {
        return element(by.css("a[href$='/#/orchestration']")).click();
      },

      clickDeployments: function () {
        return element(by.css("a[href$='/#/deployment']")).click();
      },

      getDashboardPage: function () {
        return element(by.cssContainingText('div', 'Dashboard page for running deployments ...'));
      },

      getAnalyticTemplatesPage: function () {
        return element(by.cssContainingText('div', 'Analytics Templates'));
      },

      getLandingPage: function () {
        return element(by.cssContainingText('div', 'Select a Deployment'));
      },

      createAnalyticIcon: function () {
        return element(by.css('.fa-plus'));
      },

      analyticsList: function(){
        return element(by.css('.list-container'));
      },

      versionPopUp: function(){
        return element(by.css('.apm-ax-artifact-list'));
      },

      allVersionsList: function(){
        return element.all(by.css('.apm-ax-artifact-list-item'));
      },

      deleteConfirmationPopup: function(){
        return element(by.css('.modal-btn-container'));
      },

      AnalyticName: function () {
        return element(by.id('analytic_name'));
      },

      AnalyticVersionInput: function () {
        return element(by.id('analytic-artifact-version'));
      },

      MakeCurrentButtondisabled: function () {
        return element(by.id('apm-ax-btn-artifact-select-btn')).isPresent();
      },

      AnalyticOwner: function () {
        return element(by.id('analytic_owner'));
      },

      createAnalyticType: function () {
        return element(by.id('supported-lang-dropdown'));
      },

        analyticName: function () {
            return element(by.id('list-search-box'));
        },

        analyticResult: function(el) {
            return element(by.className('orchestration-data-box-first'));
        },
        deployementResult: function(el) {
            return element(by.className('apm-dp-deployment-data-box-first'));
        },
        orchestrationResult: function(el) {
            return element(by.className('orchestration-data-box-first'));
        },
        assetfiltersResult: function(el) {
            return element(by.className('orchestration-data-box-first'));
        },

        isEditIconNotDisplayed: function() {
            return  element(by.id('apm-ax-editAnalyticBtn')).isPresent();
        },
        isDeploymentEditIconDisplayed: function() {
            return  element(by.css('.fa.fa-pencil')).isDisplayed();
        },
        isDeploymentDeleteButtonDisplayed: function() {
            return  element(by.css('.fa.fa-trash')).isDisplayed();
        },
        isAnalyticsLinkAvailable: function() {
            return element(by.css("a[href$='/#/analytics']")).isDisplayed();
        },

        isAnalyticsLinkNotAvailable: function() {
            return element(by.css("a[href$='/#/analytics']")).isPresent();
        },

        isDeploymentEditIconNotDisplayed: function() {
            return  element(by.css('.fa.fa-pencil')).isPresent();
        },
        isDeploymentDeleteButtonNotDisplayed: function() {
            return  element(by.css('.fa.fa-trash')).isPresent();
        },
        isDeleteButtonNotDisplayed: function() {
            return  element(by.css('.fa.fa-trash')).isPresent();
        },

        createAnalyticPrimaryCategory: function () {
        return element(by.id('cat1'));
      },

      createAnalyticSecondaryCategory: function () {
        return element(by.id('cat2'));
      },

      createAnalyticSubmit: function () {
        return element(by.id("analytic-form-submit-btn"));
      },

      getRunTimeTypeDropdownOptions: function () {
        return cem.findElement("CafCreateAnalyticPage", "runTimeTypeOptions");
      },

      getRunTimeTypeDropdownDefaultValue: function (value) {
        return element(by.cssContainingText('#runtime-type-dropdown', value));
      },

      clickRunTimeTypeDropdown: function () {
        return element(by.id('runtime-type-dropdown')).click();
      },

      clickDataFrameTypeDropdown: function () {
        return element(by.id('input-type-dropdown')).click();
      },

      selectRuntimeType: function (dropDownOption) {
        cemPath["CafCreateAnalyticPage"]['runTimeTypeOption'].locatorValue = dropDownOption;
        TestHelper.elementToBeClickable("CafCreateAnalyticPage", "runTimeTypeOption");
        return TestHelper.elementToBeClickable("CafCreateAnalyticPage", "runTimeType");
      },

      selectDataFrameType: function (dropDownOption) {
        cemPath["CafCreateAnalyticPage"]['dataFrameTypeOption'].locatorValue = dropDownOption;
        TestHelper.elementToBeClickable("CafCreateAnalyticPage", "dataFrameTypeOption");
        return TestHelper.elementToBeClickable("CafCreateAnalyticPage", "dataFrameType");
      },

      unselectRuntimeType: function () {
        TestHelper.elementToBeClickable("CafCreateAnalyticPage", "runTimeTypeEmptyValueOption");
        return TestHelper.elementToBeClickable("CafCreateAnalyticPage", "runTimeType");
      },

      getCSSValueRunTimeType: function () {
        return TestHelper.getCssValue("CafCreateAnalyticPage", "runTimeType", "border");
      },

      enterName: function (name) {
        console.log("entering name" + name);
        createdName = name;
        return TestHelper.sendKeys("CafCreateAnalyticPage", "name", name);
      },

      isNameVisible: function () {
        return TestHelper.isElementPresent("CafCreateAnalyticPage", "name");
      },

      getNameDefaultText: function () {
        return TestHelper.getAttribute("CafCreateAnalyticPage", "name", "placeholder");
      },

      isOwnerVisible: function () {
        return TestHelper.isElementPresent("CafCreateAnalyticPage", "owner");
      },

      getOwnerDefaultText: function () {
        return TestHelper.getAttribute("CafCreateAnalyticPage", "owner", "placeholder");
      },

      enterOwner: function (owner) {
        return TestHelper.sendKeys("CafCreateAnalyticPage", "owner", owner);
      },

      getAnalyticTypeDropdownOptions: function () {
        return cem.findElement("CafCreateAnalyticPage", "analyticTypeOptions");
      },

      getAnalyticTypeDropdownDefaultValue: function () {
        return TestHelper.getText("CafCreateAnalyticPage", "analyticTypeDefaultSelectedValue");
      },

      getCSSValueAnalyticType: function () {
        return TestHelper.getCssValue("CafCreateAnalyticPage", "analyticType", "border");
      },

      isEditIconDisplayed: function() {
        return  element(by.id('apm-ax-editAnalyticBtn')).isDisplayed();
      },

      isDeleteButtonDisplayed: function() {
        return  element(by.css('.fa.fa-trash')).isDisplayed();
      },

      enterAnalyticVersion: function (value) {
        element(by.id('analytic-artifact-version')).clear();
        return element(by.id('analytic-artifact-version')).sendKeys(value);
      },

      clickAnalyticTypeDropdown: function () {
        return TestHelper.elementToBeClickable("CafCreateAnalyticPage", "analyticType");
      },

      selectAnalyticType: function (dropDownOption) {
        cemPath["CafCreateAnalyticPage"]['analyticTypeOption'].locatorValue = dropDownOption;
        return TestHelper.elementToBeClickable("CafCreateAnalyticPage", "analyticTypeOption");
      },

      unselectAnalyticType: function () {
        TestHelper.elementToBeClickable("CafCreateAnalyticPage", "analyticTypeEmptyValueOption");
        return TestHelper.elementToBeClickable("CafCreateAnalyticPage", "analyticType");
      },

      getTypeVersionDropdownDefaultValue: function () {
        return TestHelper.getText("CafCreateAnalyticPage", "typeVersionDefaultSelectedValue");
      },

      clickTypeVersionDropdown: function () {
        return TestHelper.elementToBeClickable("CafCreateAnalyticPage", "typeVersion");
      },

      selectTypeVersion: function (dropDownOption) {
        cemPath["CafCreateAnalyticPage"]['typeVersionOption'].locatorValue = dropDownOption;
        return TestHelper.elementToBeClickable("CafCreateAnalyticPage", "typeVersionOption");
      },

      clickPrimaryCategoryDropdown: function () {
        return TestHelper.elementToBeClickable("CafCreateAnalyticPage", "PrimaryCategory");
      },

      getPrimaryCategoryDropdownDefaultValue: function () {
        return TestHelper.getText("CafCreateAnalyticPage", "primaryCategoryDefaultSelectedValue");
      },

      selectPrimaryCategory: function (dropDownOption) {
        cemPath["CafCreateAnalyticPage"]['primaryCategoryOption'].locatorValue = dropDownOption;
        return TestHelper.elementToBeClickable("CafCreateAnalyticPage", "primaryCategoryOption");
      },

      clickUploadIcon: function () {
        return TestHelper.elementToBeClickable("CafCreateAnalyticPage", "UploadIcon");
      },

      ingestionIcon: function () {
        return element(by.css("#create_analytic_by_ingestion"));
      },

      selectJarFile: function (filePath) {
        console.log("the file path: " + filePath);
        element(by.css("#fileUpload_btn")).sendKeys(filePath);
      },

      selectZipFile: function (filePath) {
        console.log("the file path: " + filePath);
        element(by.id('analytic-ingestion-input')).sendKeys(filePath);
      },

      isSubmitEnabled: function () {
        var ele = cem.findElement("CafCreateAnalyticPage", "submitButton");
        return ele.isEnabled();
      },

      clickSubmit: function () {
        return TestHelper.elementToBeClickable("CafCreateAnalyticPage", "submitButton");
      },

      waitForSpinnerToDisappear: function () {
        var EC = protractor.ExpectedConditions;
        var ele = cem.findElement("CreateAnalyticPage", "spinner");
        return browser.wait(EC.invisibilityOf(ele), 10000);
      },

      waitForDeleteIcon: function() {
        var ele = element(by.css('apm-ax-deleteAnalyticBtn'));
        return browser.wait(TestHelper.elementToBeClickable(ele), 10000);
      },

      clickDeleteButtonInModal: function() {
        return element(by.id('apm-ax-deleteModalBtn')).click()
      },

      clickYesForDeleteDeployment: function() {
        return element(by.id('submitModalBtn')).click()
      },

      clickDeleteIconOfDeployments: function() {
        return TestHelper.elementToBeClickable(element(by.css('tr.apm-deployments-row td.action i.fa.fa-trash')));
      },

      isTemplatePageBlank: function() {
        return element(by.css('.noIocContainer')).isDisplayed();
      },

      clickCancelButton: function() {
        return element(by.id('analytic-form-cancel-btn')).click();
      },

      clickVersionLink: function() {
        return element(by.id('apm-ax-version-text')).click();
      },

      currentAnalyticVersion: function() {
        return element(by.css('#apm-ax-version-text span')).getText();
      },

      getCreatedAnalytic: function () {
        return TestHelper.getText('analyticListBox', "firstAnalyticName");
      },

      getAnalyticRuntime: function () {
        return element(by.xpath('//*[@class="header-author"]/span[1]')).getText();
      },

      isVersionDropdownVisible: function () {
        return TestHelper.isElementPresent("CafCreateAnalyticPage", "typeVersion");
      },

      getTypeVersionDropdownOptions: function () {
        return cem.findElement("CafCreateAnalyticPage", "typeVersionOptions");
      },

      isAnalyticFileUploadVisible: function () {
        return TestHelper.isElementPresent("CafCreateAnalyticPage", "analyticFileUpload");
      },

      isUploadIconVisible: function () {
        return TestHelper.isElementPresent("CafCreateAnalyticPage", "UploadIcon");
      },

      getAnalyticFileUploadFieldDefaultText: function () {
        return TestHelper.getAttribute("CafCreateAnalyticPage", "analyticFileUpload", "placeholder");
      },

      isPrimaryCategoryVisible: function () {
        return TestHelper.isElementPresent("CafCreateAnalyticPage", "PrimaryCategory");
      },

      getPrimarycategoryDropdownOptions: function () {
        return cem.findElement("CafCreateAnalyticPage", "primaryCategoryOptions");
      },

      isSecondaryCategoryEnabled: function () {
        var ele = cem.findElement("CafCreateAnalyticPage", "secondaryCategory");
        return ele.isEnabled();
      },

      getCSSValuePrimaryCategory: function () {
        return TestHelper.getCssValue("CafCreateAnalyticPage", "PrimaryCategory", "border");
      },

      unselectPrimaryCategory: function () {
        TestHelper.elementToBeClickable("CafCreateAnalyticPage", "primaryCategoryEmptyValueOption");
        return TestHelper.elementToBeClickable("CafCreateAnalyticPage", "PrimaryCategory");
      },

      clickSecondaryCategoryDropdown: function () {
        return TestHelper.elementToBeClickable("CafCreateAnalyticPage", "secondaryCategory");
      },

        getSecondaryCategoryDropdownDefaultValue: function () {
            return TestHelper.getText("CafCreateAnalyticPage", "secondaryCategoryDefaultSelectedValue");
        },

      clickSecondaryCategoryDropdownOption: function() {
        return element(by.cssContainingText('[name="cat2"] option', 'Forecasting')).click()
      },

      isSubmitButtonEnabled: function() {
        return element(by.css('#analytic-form-submit-btn')).isEnabled();
      },

      clickEditIcon: function() {
        return element(by.id('apm-ax-editAnalyticBtn')).click();
      },

      clickDeleteButton: function() {
        return element(by.id('apm-ax-deleteAnalyticBtn')).click();
      },

      clickSubmitButtonInEditAnalyticPage: function() {
        return element(by.css('.btn--primary')).click()
      },

      isAnalyticTemplatePageDisplayed: function() {
        return  element(by.css('.apm-ax-template-box')).isDisplayed();
      },

      isRunTimeTypeDropdownEnabled: function() {
        return element(by.css('select[name="runtime-type-dropdown"]')).isEnabled();
      },

      getRunTimeTypeDropdownSelectedValue: function() {
        return TestHelperPO.getAttribute(element(by.css('select[name="runtime-type-dropdown"]')), "value");
      },

      getRunTimeTypeDropdownSelectedLabel: function(runtimeTypeValue) {
        return TestHelperPO.getAttribute(element(by.css(`select[name="runtime-type-dropdown"] option[value=${runtimeTypeValue}]`)), "label");
      },

      isNameEnabled: function() {
        return element(by.css('#analytic_name')).isEnabled();
      },

      getName: function() {
        return TestHelperPO.getAttribute(element(by.id('analytic_name')), "value");
      },

      getStoredName: function() {
        console.log(createdName);
        return createdName;
      },

      getOwner: function() {
        return TestHelperPO.getAttribute(element(by.id('analytic_owner')), "value");
      },

      isAnalyticTypeDropdownEnabled: function() {
        return element(by.css('select[name="supported-lang-dropdown"]')).isEnabled();
      },

      getAnalyticTypeDropdownSelectedValue: function() {
        return TestHelperPO.getAttribute(element(by.css('select[name="supported-lang-dropdown"]')), "value");
      },

      getAnalyticTypeDropdownSelectedLabel: function(typeValue) {
        return TestHelperPO.getAttribute(element(by.css(`select[name="supported-lang-dropdown"] option[value=${typeValue}]`)), "label");
      },

      isVersionTypeDropdownEnabled: function() {
        return element(by.css('select[name="lang-version-dropdown"]')).isEnabled();
      },

      getVersionTypeDropdownSelectedValue: function() {
        return TestHelperPO.getAttribute(element(by.css('select[name="lang-version-dropdown"]')), "value");
      },

      getVersionTypeDropdownSelectedLabel: function(versionType) {
        return TestHelperPO.getAttribute(element(by.css(`select[name="lang-version-dropdown"] option[value=${versionType}]`)), "label");
      },

      getPrimaryCategoryDropdownSelectedValue: function() {
        return TestHelperPO.getAttribute(element(by.css('select[name="cat1"]')), "value");
      },

      getPrimaryCategoryDropdownSelectedLabel: function(category) {
        return TestHelperPO.getAttribute(element(by.css(`select[name="cat1"] option[value=${category}]`)), "label");
      },

      isAnalyticVersionUpdateEnabled: function(){
        return  element(by.name('analytic-artifact-version-description')).isEnabled();
      },

      isAnalyticVersionEnabled: function(){
        return  element(by.id('analytic-artifact-version')).isEnabled();
      },

      getAnalyticVersion: function(){
        return TestHelperPO.getAttribute(element(by.id('analytic-artifact-version')), "value");
      },

      getSecondaryCategoryDropdownSelectedValue: function() {
        return TestHelperPO.getAttribute(element(by.css('select[name="cat2"]')), "value");
      },

      getSecondaryCategoryDropdownSelectedLabel: function() {
        return TestHelperPO.getAttribute(element(by.css(`select[name="cat2"] option[value=${category}]`)), "label");
      },

      getSecondarycategoryDropdownOptions: function () {
        return cem.findElement("CafCreateAnalyticPage", "secondaryCategoryOptions");
      },

      selectSecondaryCategory: function (dropDownOption) {
        cemPath["CafCreateAnalyticPage"]['secondaryCategoryOption'].locatorValue = dropDownOption;
        return TestHelper.elementToBeClickable("CafCreateAnalyticPage", "secondaryCategoryOption");
      },

      unselectSecondaryCategory: function () {
        TestHelper.elementToBeClickable("CafCreateAnalyticPage", "secondaryCategoryEmptyValueOption");
        return TestHelper.elementToBeClickable("CafCreateAnalyticPage", "secondaryCategory");
      },

      getCSSValueSecondaryCategory: function () {
        return TestHelper.getCssValue("CafCreateAnalyticPage", "secondaryCategory", "border");
      },

      clickSearchBox: function(){
        console.log("clicking search box 1");
        return element(by.id('list-search-box')).click();
      },

      clearSearchBox: function(){
        return TestHelperPO.elementToBeClickable(element(by.css('.apm-search-button')));
      },

      getSearchResultsCount: function(){
        return element.all(by.xpath('//div[contains(@class, "orchestration-item-name")]')).count();
      },

      enterSearchText: function(analyticName){
          return TestHelperPO.sendKeys(element(by.id('list-search-box')), analyticName);
      },

      getAnalyticName: function(){
        return element(by.css('.orchestration-item-name')).getText();
      },

      getAnalyticOwner: function(){
        return element(by.css('.orchestration-item-author')).getText();
      },

      getAnalyticDate: function(){
        return element(by.css('.orchestration-item-date')).getText();
      },

      getAnalyticPublishStatus: function(){
        return element(by.css('.orchestration-item-status')).getText();
      },

      clickFirstSearchResult: function(){
        return element(by.id('apm-ax-analytic-list-item0')).click();
      },

      clickDeploymentsTabOnAnalyticPage: function(){
        return TestHelper.elementToBeClickable(element(by.cssContainingText('div.ReactTabs ul li', 'Deployments')));
      },

      clickFirstOrchSearchResult: function(){
        return element(by.css('.orchestration-box')).click();
      },

      getAnalyticNameInTemplate: function(){
        return element(by.css('.apm-ax-detail-panel .header-name')).getText();
      },

      getAnalyticVersionInTemplate: function(){
        return element(by.css('.apm-ax-detail-panel .ax-header-blue')).getText();
      },

      getAnalyticOwnerInTemplate: function(){
        return element(by.css('.apm-ax-detail-panel .header-author')).getText();
      },

      getAnalyticPrimaryCategoryInTemplate: function(){
        return element.all(by.css('.apm-ax-detail-panel .header-category')).get(0).getText();
      },

      getSavedDateInTemplate: function(){
        return element(by.css('.apm-ax-detail-panel .update-last-saved')).getText();
      },

      clickUploadFileIcon: function() {
        return element(by.css('i[title="Upload"]')).click();
      },

      getUploadModal: function() {
        return element(by.id('file-input-box')).getText()
      },

      uploadFile: function() {
        let path = require('path');
        let fileToUpload = './../TestData/tempAnalyticRequired.csv';
        let absolutePath = path.resolve(__dirname, fileToUpload);
        $('input[type="file"]').sendKeys(absolutePath);
        return element(by.id('fileUpload_file')).getAttribute('value');
      },

      clickSubmitUpload: function() {
        return element(by.xpath('//div[contains(@class, "modal-bottom-group")]//button[contains(@class, "btn--primary")]')).click();
      },

      getDescriptionInputBox: function() {
        return element(by.id('file-description')).getAttribute('class');
      },

      addValidDescription: function() {
        return element(by.id('file-description')).sendKeys('this is a valid description');
      },

      getAssetFilterstext: function() {
        return element(by.css('h1.pxh-view-header__title')).getText();
      },

      getOrchestrationtext: function() {
        return element(by.css('a.pxh-view-header__title-link')).getText();
      },

      getDeploymenttext: function() {
        return element(by.css('a.pxh-view-header__title-link')).getText();
      },

       getUploadSpinner: function() {
        return element(by.xpath('//div[contains(@class, "pxh-spinner pxh-spinner--small")]')).getAttribute('class');
      },

      clickAnalytic: function() {
        return element(by.css('.orchestration-item-name')).click();
      },

      isInputTableExist : function() {
        return element(by.css('#input definition-subsection-headers .apm-ax-subsection-row')).isPresent();
      },

      isConstantTableExist : function() {
        return element(by.css('#constants-subsection-headers .apm-ax-subsection-row')).isPresent();
      },

      isOutputDefTableExist : function() {
        return element(by.css('#output definition-subsection-headers .apm-ax-subsection-row')).isPresent();
      },

      isOutputEventTableExist : function() {
        return element(by.css('#output event-subsection-headers .apm-ax-subsection-row')).isPresent();
      },

      headerName: function() {
        return element(by.xpath('//div[@class="header-name"]/span')).getText();
      },

      firstAnalytic: function () {
        return element(by.css('.orchestration-data-box-first')).click();
      }
    };
  };

  module.exports = new cafCreateAnalyticsPage();

}());



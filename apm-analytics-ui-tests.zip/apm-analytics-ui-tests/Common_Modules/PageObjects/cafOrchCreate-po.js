/**
 * Class encapsulating all functions in main landing page
 */
(function () {
    'use strict';


    var TIMEOUT = 5000;
    let path = browser.params.appHubpath;



    var createOrchestrationPage = function () {

        var currentPage = 'orchTenantPage';

        var createdName;
        var randOrch = Date.now();
        var assetValue = 'GE90';
        var sharedTimeStamp;
        var analyticEntry;
        var analyticName;
        var soarAnalyticName;
        var airAnalyticName;
        var Pxorchestration;
        var PxorchestrationName;
        var PxorchestrationwithAnalytic;


        return {

            getSharedTimeStamp : function (){
                if(!sharedTimeStamp){
                    sharedTimeStamp = Math.floor(Date.now() / 1000);
                }
                return sharedTimeStamp;
            },

            createAnalyticWithTemplate : function(callback) {
                analyticName = 'predixAnalytic' + this.getSharedTimeStamp();

                var formData = {
                    file: fs.createReadStream('Common_Modules/TestData/thresholdAnalytic-java.jar'),
                    analytic: '{"@type": "analyticEntryPx", "name": "' + analyticName + '", "author": "Test", "analyticVersion": "1.0.0", "analyticLanguageVersion": "1.8", "analyticLanguage": "Java", "primaryCategory": "Monitoring", "secondaryCategory": "Monitoring", "analyticDefine": {"@type":"analyticDefinePx", "inputs": [{"name":"temp_today","unitGroup":"","unit":"Fahrenheit","dataType":"Double","isRequired": true,"description":"Todays temperature. Map with any temperature tag" }], "constants": [{"name": "threshold", "unit": "FAHRENHEIT", "description": "threshold", "value": "30", "dataType": "double"} ], "outputs": [{"name": "mean", "unit": "none", "description": "mean", "dataType": "double"}, {"name": "deviation", "unit": "FAHRENHEIT", "description": "deviation from Mean", "dataType": "double"} ] } }'
                };
                browser.sleep(2000).then(function () {
                    restUtil.makeRequest("caf/api/caf-mgmt-svc/v1/analyticEntries", 'POST', formData, 'multipart/form-data').then(function (resp) {
                        analyticEntry = JSON.parse(resp.body);
                        console.log("Px Name is " + analyticEntry.name)
                        callback();
                });
            });
            },

            createSoarAnalyticWithTemplate : function(callback) {
                soarAnalyticName = 'soarAnalytic' + this.getSharedTimeStamp();
                var formData = {
                    file: fs.createReadStream('Common_Modules/TestData/thresholdAnalytic-java.jar'),
                    analytic: '{"@type": "analyticEntryCaf", "name": "' + soarAnalyticName + '", "author": "Test", "runtimeName": "SOAR", "analyticVersion": "1.0.0", "analyticLanguageVersion": "1.8", "analyticLanguage": "Java", "primaryCategory": "Monitoring", "secondaryCategory": "Monitoring", "analyticDefine": {"@type":"analyticDefinePx", "inputs": [{"name":"temp_today","unitGroup":"","unit":"Fahrenheit","dataType":"Double","isRequired": true,"description":"Todays temperature. Map with any temperature tag" }], "constants": [{"name": "threshold", "unit": "FAHRENHEIT", "description": "threshold", "value": "30", "dataType": "double"} ], "outputs": [{"name": "mean", "unit": "none", "description": "mean", "dataType": "double"}, {"name": "deviation", "unit": "FAHRENHEIT", "description": "deviation from Mean", "dataType": "double"} ] } }'
                };
                browser.sleep(2000).then(function () {
                    restUtil.makeRequest("caf" + path + "/api/caf-mgmt-svc/v1/analyticEntries", 'POST', formData, 'multipart/form-data').then(function (resp) {
                      console.log(resp.body);
                      analyticEntry = JSON.parse(resp.body);
                        console.log("Soar Name is " + analyticEntry.name)
                        callback();
                    });
                });
            },

            createAirAnalyticWithTemplate : function(callback) {
              airAnalyticName = 'AirAnalytic' + this.getSharedTimeStamp();
              var formData = {
                  file: fs.createReadStream('Common_Modules/TestData/thresholdAnalytic-java.jar'),
                  analytic: '{"@type": "analyticEntryCaf", "name": "' + airAnalyticName + '", "author": "Test", "runtimeName": "AIR", "analyticVersion": "1.0.0", "analyticLanguageVersion": "1.8", "analyticLanguage": "Java", "primaryCategory": "Monitoring", "secondaryCategory": "Monitoring", "analyticDefine": {"@type":"analyticDefine", "inputs": [{"name":"temp_today","unitGroup":"","unit":"Fahrenheit","dataType":"Double","isRequired": true,"description":"Todays temperature. Map with any temperature tag" }], "constants": [{"name": "threshold", "unit": "FAHRENHEIT", "description": "threshold", "value": "30", "dataType": "double", "dataSourceType":"ANY"} ], "outputs": [{"name": "mean", "unit": "none", "description": "mean", "dataType": "double"}, {"name": "deviation", "unit": "FAHRENHEIT", "description": "deviation from Mean", "dataType": "double"} ] } }'
              };
              browser.sleep(2000).then(function () {
                  restUtil.makeRequest("caf" + path + "/api/caf-mgmt-svc/v1/analyticEntries", 'POST', formData, 'multipart/form-data').then(function (resp) {
                    console.log(resp.body);
                    analyticEntry = JSON.parse(resp.body);
                      console.log("Air Name is " + analyticEntry.name)
                      callback();
                  });
              });
          },

        createOrchestrationPx: function(callback) {
                PxorchestrationName = 'orchestrationUI-'+ this.getSharedTimeStamp();
                var data = '{"@type": "orchestrationPx","name": "' + PxorchestrationName + '","author": "Automation", "description": "UI automation","runtimeName": "Predix"}';
                restUtil.makeRequest("caf/api/caf-mgmt-svc/v1/orchestrations", 'POST', data, 'application/json').then(function (resp) {
                    console.log(resp.body);
                    Pxorchestration = (resp.body);
                    callback();
                });
            },


        updateOrchestrationwithAnalyticPx: function(callback) {
            console.log("data");
            var uri = "caf/api/caf-mgmt-svc/v1" + Pxorchestration.uri;
            // let data = '{"@type":"orchestrationPx", "uri":"'+ orchestration.uri +'", "name":"'+ orchestration.name + '","author":"automation",'
            //     + '"orchestrationType":"ORCHESTRATION_NORMAL","orchestrationSteps":[{"analyticName":"'+ analyticEntry.name +'", '
            //     + '"analyticUri":"'+ analyticEntry.uri +'","analyticAuthor":"Test","analyticVersion":"1.0.0"}],'
            //     + '"runtimeName":"Predix"}';
            var data = '{"@type": "orchestrationPx", "uri": "' + Pxorchestration.uri + '", "name": "' + Pxorchestration.name + '", "createdOn": "' + Pxorchestration.createdOn + '", "updatedOn": "' + Pxorchestration.updatedOn+ '", "createdBy": "analytics-smokeuser", "updatedBy": "analytics-smokeuser", "author": "Automation", "orchestrationType": "ORCHESTRATION_NORMAL", "orchestrationSteps": [{"analyticName": "' + analyticEntry.name + '", "analyticUri": "' + analyticEntry.uri + '", "analyticAuthor": "Test", "analyticVersion": "1.0.0"}], "runtimeName": "Predix"}';
            restUtil.makeRequest(uri, 'PUT', data, 'application/json').then(function (resp) {
                Pxorchestration = (resp.body);
                callback();
            });
        },


        createOrchestrationPxwithAnalytic: function(callback) {
            PxorchestrationwithAnalytic = 'orchestrationUI-'+ this.getSharedTimeStamp();
            var data = '{"@type": "orchestrationPx","name": "' + PxorchestrationName + '","author": "Automation", "description": "UI automation", "createdBy": "analytics-smokeuser","updatedBy": "analytics-smokeuser","orchestrationSteps": [{"analyticName": analyticEntry.name,"analyticUri": analyticEntry.uri,"analyticAuthor": "Test","analyticVersion": "1.0.0"],"runtimeName": "Predix"}';
            restUtil.makeRequest("caf/api/caf-mgmt-svc/v1/orchestrations", 'POST', data, 'application/json').then(function (resp) {
                console.log(resp.body);
                Pxorchestration = (resp.body);
                callback();
            });
        },



            getAnalyticName : function (){
                if(typeof analyticName === 'undefined') {
                    analyticName = cafCreateAnalyticPage.getStoredName();
                    return analyticName;
                }
                return analyticName;
            },

            getSoarAnalyticName : function (){
                return soarAnalyticName;
            },

            getAirAnalyticName : function (){
              return airAnalyticName;
          },

            getPxOrchestrationName : function (){
                return PxorchestrationName;
            },

            getPxOrchestrationNamewithAnalytic : function (){
                return PxorchestrationwithAnalytic;
            },

            isOrchestrationLinkAvailable: function() {
                return element(by.css("a[href$='/#/orchestration']")).isDisplayed();
            },

            isOrchestrationLinkNotAvailable: function() {
                return element(by.css("a[href$='/#/orchestration']")).isPresent();
            },

            verifyOrchestrationTab : function (){
                return element(by.css('[title="Orchestration catalog"]'));
                //return TestHelper.isElementPresent('landingPage','Orchestration catalog');
            },

            clickOrchTab: function() {
                return element(by.css('[title="Orchestrations"]')).click();

            },

            OrchTitle : function () {
                return element(by.css('.pxh-view-header__title-link'));
            },

            createOrchButton: function(){
                return element(by.id('createOrchestrationBtn'));
            },

            visibilityOf : function(elementID){
                var EC = protractor.ExpectedConditions;
                return browser.wait(EC.visibilityOf(elementID),10000)
            },

            elementToBeClickable: function(elementID){
                var EC = protractor.ExpectedConditions;
                return browser.wait(EC.elementToBeClickable(elementID), 5000)
            },

            NewOrchLabel : function () {
                return element(by.css('.create-form-container h2'));
            },

            nameField : function () {
                return element(by.id('input-name'));
            },

            ownerField : function () {
                return element(by.id('input-author'));
            },

            descriptionField : function () {
                return element(by.id('input-description'));
            },

            runtimeTypeField : function () {
                return element(by.id('runtime-type-dropdown'));
            },

            dataFrameTypeField : function () {
                return element(by.id('input-type-dropdown'));
            },

            assetGroupField : function () {
                return element(by.id('filter-dropdown'));
            },

            createRandomOrchName: function(){
                this.nameField().sendKeys('OrchName-'+randOrch);
                    return  createdName='OrchName-'+randOrch;
            },

            getName: function(){
                return  createdName='OrchName-'+randOrch;
            },

            createOwner: function(){
                this.ownerField().clear().sendKeys('Automation');
            },

            createDescription: function(){
                this.descriptionField().sendKeys('Orch created by Automation');
            },

            selectAssetGroup:function(){
                return element(by.cssContainingText('option', assetValue)).click();
            },

            assetApplicability:function(){
                return element(by.css('.assetCriteriaContainer .title-header'));
            },

            submitButton:function(){
                return element(by.id('submit-space create-btn-submit'));
            },

            analyticBox: function(){
                return element(by.css('.analytic-box'));
            },


            ///View orch Story

            viewOrchName:function(){
                return element(by.css('.header-name'))
            },

            searchOrchField: function(){
                return element(by.css('input[placeholder="Search"][type="text"]'));
            },

            searchAnalyticField: function(){
                return element(by.css('input[id="analytic-search"][type="text"]'));
            },

            analyticSearchCount: function(){
                return element.all(by.css('.list-analytic-box')).count();
            },

            searchCount: function(){
                return element.all(by.css('.orchestration-box')).count();
            },

            firstOrchName: function()
            {
                return element.all(by.css('.orchestration-box')).get(0);
            },

            soarAnalyticSearch: function()
            {
                return element.all(by.css('.list-analytic-box')).get(0);
            },

            getCreatedOrchName: function()
            {
                return this.viewOrchName().getText()
            },

            getDeployedStatusLabel: function()
            {
                return element(by.css('.header-status'));
            },

            plusIcon : function()
            {
                return element(by.id('goAddAnalytic'));
            },

            editIcon : function()
            {
                return element(by.id('goEditOrchestration'));
            },

            trashIcon : function()
            {
                return element(by.css('.fa-trash'));
            },

            deployLabelMain: function(){
                return element(by.css(".header-status"));
            },


            deleteModalText: function()
            {
                return element(by.css('h2'));
            },

            submitModalBtn :  function()
            {
                return element(by.id('submitModalBtn'));
            },

            closeModalBtn :  function()
            {
                return element(by.id('closeModalBtn'));
            },

            emptyOrchScreen:  function()
            {
                return element(by.css('.noIocContainer'));
            },

            addedAnalyticMainOrch:  function()
            {
                return element.all(by.css('.analytic-box'));
            },

            incompleteMappingTextMainOrch:  function()
            {
                return element.all(by.css('.incomplete-mapping-indicator'));
            },

            deployment : function (){
                //return element(by.css('li[aria-selected="false"][aria-disabled="false"]'));
                return element(by.css('.ReactTabs__Tab:nth-child(2)'));
            },

            isDeploymentTabDisplayed : function (){
                return element(by.css('.ReactTabs__Tab:nth-child(2)')).isPresent();
            },


            orchestrationTab : function (){
                //return element(by.css('li[aria-selected="false"][aria-disabled="false"]'));
                return element(by.css('.ReactTabs__Tab:nth-child(1)'));
            },

            createDeployButton : function (){
                return element(by.id("goCreateDeployment"));
            },

            newDeploymentPopup : function(){
                return element(by.css(".apm-dp-createDeploymentBoxNoTemplate"));
            },

            newDeploymentPopupCancel : function(){
                return element(by.css(".apm-dp-cancelButton"));
            },

            newDeploymentPopupNameField : function(){
                return element(by.id("DeploymentNameInputBox"));
            },

            isTemplateHeaderCreateOrchestrationIconDisplayed: function() {
                return TestHelperPO.isElementPresent(element.all(by.css('.fa-plus')).get(0));
            },
            isTemplateHeaderDeleteOrchestrationIconDisplayed: function() {
                return TestHelperPO.isElementPresent(element.all(by.css('.fa-trash')).get(0));
            },
            isOrchestrationTabAddOrchestrationIconDisplayed: function() {
                return TestHelperPO.isElementPresent(element.all(by.css('.btn.btn--tertiary.btn--icon')).get(0));
            },
            isDeploymentTabAddDeploymentIconDisplayed: function() {
                return TestHelperPO.isElementPresent(element.all(by.css('.fa-plus')).get(0));
            },
            isTemplateHeaderCreateOrchestrationIconNotDisplayed: function() {
                return element(by.css('.fa.fa-plus.btn-spec-new')).isPresent()
            },
            isTemplateHeaderDeleteOrchestrationIconNotDisplayed: function() {
                return element(by.css('fa-trash')).isPresent()
            },

            isTemplateHeaderaddOrchestrationIconNotDisplayed: function() {
                return element(by.css('.fa-pencil')).isPresent()
            },
            isDeploymentTabAddDeploymentIconNotDisplayed: function() {
                return element(by.css('.fa-plus')).isPresent()
            },

            newDeploymentPopupSubmit : function(){
                return element(by.css(".apm-dp-submitButton"));
            },

            createRandomDeploymentName: function(){
                this.newDeploymentPopupNameField().sendKeys('deployUI-'+randOrch);

                return  createdName='deployUI-'+randOrch;
            },

            assetSelectionPage : function(){
                return element(by.css(".apm-dp-breadcrumb"));
            },


        };
    };

    module.exports = new createOrchestrationPage();

}());



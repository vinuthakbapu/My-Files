/**
 * Created by 212350438 on 7/9/15.
 */

(function () {

    'use strict';


    var AnalysisTSPage = function () {
        var currentTSPage = "timeSeriesPage";

        return {

// <analisis>.<Date Range- From Field- Iron icon > ***********************************
            getIronIcon_FromDateField_TS: function(){
                return element.all(by.css('#icon')).get(2);
            },
// <analisis>.<Date Range- To Field- Iron icon > ***********************************
            getIronIcon_ToDateField_TS: function(){
                return element.all(by.css('#icon')).get(5);
            },

// Hint text for Timeseris chart*********************************
            getTS_HintMessage: function () {
                TestHelper.setElementManager(aem);
                return TestHelper.getText(currentTSPage,"timeserisChartWebHintMessage");

            },
            
        };
    }

    module.exports = new AnalysisTSPage();
}())


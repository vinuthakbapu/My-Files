/**
 * Class encapsulating all functions in Analytic Applicability main landing page
 */
(function () {
    'use strict';
    const CONDITION_OPERATOR = {
        '=': {
            operator: '=',
            operatorLabel: 'is equal to',
            name: 'OPERATOR_EQUALS'
        },
        '!=': {
            operator: '!=',
            operatorLabel: 'is not equal to',
            name: 'OPERATOR_IS_NOT_EQUALS'
        },
        'in': {
            operator: 'in',
            operatorLabel: 'ini',
            name: 'OPERATOR_IN'
        },
        'like': {
            operator: 'like',
            operatorLabel: 'like',
            name: 'OPERATOR_LIKE'
        }
    };

    //page
    const applicabilityPage =  'analyticApplicabilityPage';

    //elements
    const nameTextbox = 'applicabilityName';
    const descriptionTextbox = 'applicabilityDescription';
    const addNewFilter = 'createNewFilterButton';
    const hierarchySelect = 'hierarchySelect';
    const filterSaveButton = 'filterSaveButton';
    const attributeSelectClass = 'attributeSelect';
    const conditionSelectClass = 'conditionSelect';
    const valueInputClass = 'ruleValue';
    const previewButton = 'previewButton';
    const previewTable = 'previewTable';
    const previewExportAll ='previewExportAllButton';

    const ElementManager = require('proui-utils').ElementManager;
    const applicabilityEm = new ElementManager('../../../Test_Modules/Analytics/caf-analyticApplicability-element-repo.json');


    const analyticApplicabilityPage = function () {

        const getElementValue = function (elementRepoFieldName) {
            return applicabilityEm.findElement(applicabilityPage, elementRepoFieldName).getAttribute('value');
        };

        const clickOnElement = function (elementRepoFieldName) {
            return TestHelperPO.elementToBeClickable(applicabilityEm.findElement(applicabilityPage, elementRepoFieldName));
        };

        const populateInputField = function (elementRepoFieldName, value) {
            return applicabilityEm.findElement(applicabilityPage, elementRepoFieldName).clear().sendKeys(`${protractor.Key.chord(protractor.Key.CONTROL, 'a')}${value}`);
        };

        const selectOption = function (elementRepoFieldName, optionText) {
            return  applicabilityEm.findElement(applicabilityPage, elementRepoFieldName).click().then(() => {
                applicabilityEm.findElement(applicabilityPage, elementRepoFieldName).element(by.cssContainingText('option',optionText)).click();
            });
        };

        const selectRuleOption = function (selectClass, optionText, ruleLevel) {
            return element.all(by.css('table[id="'+ ruleLevel + '_ruleList"]>tbody>tr')).last().element(by.className(selectClass)).click().then(() => {
                return element.all(by.css('table[id="'+ ruleLevel +'_ruleList"]>tbody>tr')).last().element(by.className(selectClass)).element(by.xpath(`option[normalize-space()="${optionText}"]`)).click();
            });
        };

        const selectCustomRuleOption = function (selectClass, optionText, ruleLevel) {
            return element.all(by.css('table[id="'+ ruleLevel + '_CustomFilterList"]>tbody>tr')).last().element(by.className(selectClass)).click().then(() => {
                return element.all(by.css('table[id="'+ ruleLevel +'_CustomFilterList"]>tbody>tr')).last().element(by.className(selectClass)).element(by.xpath(`option[normalize-space()="${optionText}"]`)).click();
            });
        };

        const getAssetLevelRules = function (ruleLevel) {
            return element(by.id(ruleLevel+ '_ruleList')).all(by.css('tbody>tr')).map(row => {
                const attributeUri = row.element(by.className('attributeSelect')).getAttribute('value');
                const attributeName = row.element(by.className('attributeSelect')).element(by.css('option:checked')).getText();
                const condition = row.element(by.className('conditionSelect')).getAttribute('value');
                const inputValue = row.element(by.className('ruleValue')).getAttribute('value');
                return Promise.all([attributeUri, attributeName, condition, inputValue]).then(values => {
                    const splitValue = values[3].split(',');
                    const conditionValue = splitValue.length > 1 ? '' : splitValue[0];
                    const conditionValues = splitValue.length > 1 ? splitValue : [];
                    const derivedCondition = conditionValues.length > 0 && values[2] === '=' ? 'in' : values[2];
                    return {entityFilterFieldName: values[1],
                        entityFilterFieldUri: values[0],
                        operator: CONDITION_OPERATOR[derivedCondition],
                        value: conditionValue,
                        values: conditionValues}
                })
            });
        };

        const getCustomLevelRules = function (ruleLevel) {
            return element(by.id(ruleLevel+ '_CustomFilterList')).all(by.css('tbody>tr')).map(row => {
                const attributeUri = row.element(by.className('attributeSelect')).getAttribute('value');
                const attributeName = row.element(by.className('attributeSelect')).element(by.css('option:checked')).getText();
                const condition = row.element(by.className('conditionSelect')).getAttribute('value');
                const inputValue = row.element(by.className('ruleValue')).getAttribute('value');
                return Promise.all([attributeUri, attributeName, condition, inputValue]).then(values => {
                    const splitValue = values[3].split(',');
                    const conditionValue = splitValue.length > 1 ? '' : splitValue[0];
                    const conditionValues = splitValue.length > 1 ? splitValue : [];
                    const derivedCondition = conditionValues.length > 0 && values[2] === '=' ? 'in' : values[2];
                    return {entityFilterFieldName: values[1],
                        entityFilterFieldUri: values[0],
                        operator: CONDITION_OPERATOR[derivedCondition],
                        value: conditionValue,
                        values: conditionValues}
                })
            });
        };

        const alertClear = function () {
            //hack to avoid implicit wait penalty when waiting for element not present
            return element(by.tagName('fieldset')).all(by.xpath('./*')).count().then(count => {
               return count === 4;
            });
        }

        return {

            isFilterPresent: function (filterName) {
                return element(by.id(`filterList_${filterName}`)).isPresent();
            },

            selectFilter: function(filterName) {
                return element(by.id(`filterList_${filterName}`)).click();
            },

            initiateNewFiler: function() {
                return clickOnElement(addNewFilter).then(() => {
                    const until = protractor.ExpectedConditions;
                    const nameField = applicabilityEm.findElement(applicabilityPage, nameTextbox);
                    browser.wait(until.presenceOf(nameField), 5000, 'details page did not load');
                })
            },

            populateBasicMetadata: function(name,description,hierarchyLevel) {
                return populateInputField(nameTextbox, name).then(() => {
                    return populateInputField(descriptionTextbox, description).then(() => {
                        return selectOption(hierarchySelect, hierarchyLevel);
                    })
                })
            },

            addCondition: function(name,condition,value, ruleLevel) {
                return element(by.id(ruleLevel+'_addRule')).click().then(() => {
                    const valuePromise = element.all(by.css('table[id="'+ruleLevel+'_ruleList"]>tbody>tr')).last().element(by.className(valueInputClass)).sendKeys(value);
                    const attributeSelect = selectRuleOption(attributeSelectClass, name, ruleLevel);
                    const conditionPromise = selectRuleOption(conditionSelectClass, condition, ruleLevel);
                    return Promise.all([attributeSelect,conditionPromise,valuePromise]).then(() => {});
                });
            },

            addCustomCondition: function(name,condition,value, ruleLevel) {
                return element(by.id(ruleLevel+'_addRule')).click().then(() => {
                    const valuePromise = element.all(by.css('table[id="'+ruleLevel+'_CustomFilterList"]>tbody>tr')).last().element(by.className(valueInputClass)).sendKeys(value);
                    const attributeSelect = selectCustomRuleOption(attributeSelectClass, name, ruleLevel);
                    const conditionPromise = selectCustomRuleOption(conditionSelectClass, condition, ruleLevel);
                    return Promise.all([attributeSelect,conditionPromise,valuePromise]).then(() => {});
                });
            },

            saveFilter: function() {
                return clickOnElement(filterSaveButton).then(() => {
                    const until = protractor.ExpectedConditions;
                    browser.wait(until.presenceOf(element(by.className('loading'))), 5000, 'loading never occured').then(() => {
                        const alert = element(by.id("message"));
                        browser.wait(until.presenceOf(alert), 8000, 'timeout waiting for success message to appear').then(() => {
                            browser.wait(alertClear, 8000, 'timeout waiting for success message to disappear');
                        })
                    });
                });
            },

            getCurrentDisplayedFilter: function(ruleLevel) {
                const name = getElementValue(nameTextbox);
                const description = getElementValue(descriptionTextbox);
                const hierarchyLevel =  getElementValue(hierarchySelect);
                let filterConditions = null;
				if (ruleLevel != null)
					filterConditions = getAssetLevelRules(ruleLevel);

				return Promise.all([name,description, hierarchyLevel,filterConditions]).then((values) => {
                   return {name: values[0],
                       description: values[1],
                       entityFilterResponseType: values[2],
                       entityFilterConditions: values[3]}
                });
            },

            getCurrentCustomDisplayedFilter: function(ruleLevel) {
                const name = getElementValue(nameTextbox);
                const description = getElementValue(descriptionTextbox);
                const hierarchyLevel =  getElementValue(hierarchySelect);
                let filterConditions = null;
                if (ruleLevel != null)
                    filterConditions = getCustomLevelRules(ruleLevel);

                return Promise.all([name,description, hierarchyLevel,filterConditions]).then((values) => {
                    return {name: values[0],
                        description: values[1],
                        entityFilterResponseType: values[2],
                        entityFilterConditions: values[3]}
                });
            },

            deleteRule: function (targetName,targetOperator,targetValue, ruleLevel) {
                return element(by.id(ruleLevel+'_ruleList')).all(by.css('tbody>tr')).map(row => {
                    const attributeName = row.element(by.className('attributeSelect')).element(by.css('option:checked')).getText();
                    const condition = row.element(by.className('conditionSelect')).element(by.css('option:checked')).getText();
                    const inputValue = row.element(by.className('ruleValue')).getAttribute('value');
                    return Promise.all([attributeName, condition, inputValue]).then(values => {
                        if(values[0] === targetName && values[1].trim() === targetOperator && values[2] === targetValue) {
                            return row.element(by.className('deleteRule')).click();
                        }
                    })
                });
            },

            openPreviewModal: function() {
                return clickOnElement(previewButton).then(() => {
                    const until = protractor.ExpectedConditions;
                    browser.wait(until.presenceOf(element(by.className('loading'))), 5000, 'loading never occured');
                });
            },

            isPreviewModalOpen: function () {
                return applicabilityEm.findElement(applicabilityPage, previewTable).isPresent();
            },

            previewResultsExportAsCSV : function () {
                return clickOnElement(previewExportAll);
            },

            verifyAnalyticApplicabilityTab: function () {
                return element(by.css("a[href$='/#/analyticApplicability']")).click();
            },

            deleteCurrentFilter: function() {
                return element(by.xpath("//*[@id='root']/div/div[2]/form/fieldset/section[1]/button[3]")).click();
            },

            cancelPreviewWindow: function() {
                return element(by.id("apm-af-preview-cancel-btn")).click();
            },
            
            DeleteFilter: function(){
                return element(by.id("apm-af-delete-btn"));
            },

            CancelFilterButton: function() {
                return element(by.id("apm-af-reset-btn"));
            },
            
            SaveChangesButton: function() {
                return element(by.id("apm-af-submit-btn"));
            },
            

        };
    };

    module.exports = new analyticApplicabilityPage();
}());


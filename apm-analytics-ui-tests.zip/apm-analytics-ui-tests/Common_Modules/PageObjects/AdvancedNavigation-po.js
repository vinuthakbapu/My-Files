
(function(){
    'use strict';

    var currentpage = 'DashboardAppPages';
    var AdvancedNavPage = function(){
        return {
            chkAdvNavTitle: function (){
                return TestHelper.isElementPresent(currentpage, 'AdvNavTitle');
            },
            chkAdvNavPlusSign: function (){
                return TestHelper.isElementPresent(currentpage, 'AdvNavPlusSign');
            },
            clickAdvNavPlusSign: function (){
                return TestHelper.elementToBeClickable(currentpage, 'AdvNavPlusSign');
            },
            ChkAdvNavToggle: function (num){
                dem2[currentpage]['AdvNavToggleButton'].value.index=Number(num);
                return dem.findElement(currentpage, 'AdvNavToggleButton').isSelected();
            },
            ClickAdvNavToggle: function (num){
                dem2[currentpage]['AdvNavToggleButton'].value.index=Number(num);
                return TestHelper.elementToBeClickable(currentpage, 'AdvNavToggleButton');
            },
            chkNavAllCount: function() {
                return element.all(by.css('new-edit-widget li.input-container.clearfix.advance-navigation'));
            },
            chkNavDropDown: function() {
                return TestHelper.isElementPresent(currentpage, 'NavDropDown');
            },
            chkToggleButton: function() {
                return TestHelper.isElementPresent(currentpage, 'NavToggleButton');
            },
            checkToggleButtonOld: function(arg1) {
                dem2[currentpage]['NavToggleButtonStatus'].value.index = arg1 - 1;
                return TestHelper.getCssValue(currentpage,'NavToggleButtonStatus','background-color');
            },
            checkToggleButton: function(arg1) {
                dem2[currentpage]['NavToggleButtonStatus'].value.index = Number(arg1 - 1);
                return dem.findElement(currentpage, 'NavToggleButtonStatus').isSelected();
            },
            chkAll_x_icon: function() {
                return dem.findElement(currentpage, 'NavToggleButtonStatusAll').count();
            },
            clickOnDestinationDropDown: function(num) {
                dem2[currentpage]['NavDropDownWithIndex'].value.index = num;
                return TestHelper.elementToBeClickable(currentpage, 'NavDropDownWithIndex');
            },
            clickOnDestinationDropDownByName: function (nameOfAsset) {
                var currentIndex = dem2[currentpage]['NavDropDownWithIndex'].value.index;
                currentIndex = currentIndex + 2;
                dem2[currentpage]['NavDropDownWithIndex'].value.index = currentIndex;
                return dem.findElement(currentpage, 'NavDropDownWithIndex').sendKeys(nameOfAsset);
            },
            clickOnDestinationDropDownByIndexAndName: function(indexOfDropDown, nameOfAsset) {
                dem2[currentpage]['NavDropDownWithIndex'].value.index = indexOfDropDown - 1;
                return TestHelper.sendKeys(currentpage, 'NavDropDownWithIndex', nameOfAsset);
            },
            clickOnDestinationDropDownByNameNoIndex: function(nameOfAsset) {
                dem2[currentpage]['NavDropDownItemByName'].locatorValue = nameOfAsset;
                return dem.findElement(currentpage, 'NavDropDownItemByName');
            },
            chkItemNameUnderDestination: function(textString) {
                var localIndex = 0;
                if (textString === 'Alerts') {
                    localIndex = 1;
                } else if (textString === 'Analysis') {
                    localIndex = 2;
                } else if (textString === 'Asset') {
                    localIndex = 3;
                } else if (textString === 'Cases') {
                    localIndex = 4;
                } else if (textString === 'Dashboard') {
                    localIndex = 5;
                } else {
                    localIndex = 100;
                }
                dem2[currentpage]["NavDropDownItemByIndex"].value.index = localIndex;
                return TestHelper.getText(currentpage, 'NavDropDownItemByIndex');
            },
            selectItemUnderDashboardDropDownList: function(nameOfItem) {
                dem2[currentpage]["NavDropDownItemByName"].locatorValue = nameOfItem;
                return TestHelper.elementToBeClickable(currentpage, 'NavDropDownItemByName');
            },
            getContextLinkUnderNavigation: function() {
                return TestHelper.getText(currentpage, 'Nav_SetContext_Link');
            },
            chkDoneButtonThatHasBeenGreyedOut: function() {
                return TestHelper.isElementPresent(currentpage, 'NavDoneButtonGreyedOut');
            },
            clickOnSetContextLink: function(arg1) {
                return TestHelper.elementToBeClickable(currentpage, 'Nav_SetContext_Link');
            },
            clickOnSetContextLinkWithIndex: function(arg1, index) {
                dem2[currentpage]["Nav_SetContext_Link"].value.index = index;
                return TestHelper.elementToBeClickable(currentpage, 'Nav_SetContext_Link');
            },
            checkNewlyCreatedAndLinkedDashboadAssetItem: function() {
                return TestHelper.getText(currentpage, 'NewDashboardAssetItem');
            },
            checkNewlyCreatedAndLinkedDashboadAssetItemArray: function(index) {
                dem2[currentpage]["NewDashboardAssetItemArray"].value.index = index;
                return TestHelper.getText(currentpage, 'NewDashboardAssetItemArray');
            },
            checkThe_X_iconNextToAsset: function() {
                return TestHelper.isElementPresent(currentpage, 'x_iconNextToAsset');
            },
            checkThe_X_iconNextToAssetNotPresent: function(index) {
                dem2[currentpage]["x_iconNextToAssetNotPresent"].value.index = index;
                return TestHelper.isElementVisible(currentpage, 'x_iconNextToAssetNotPresent');
            },
            checkThe_X_iconNextToDashboardDropDownNotPresent: function(index) {
                dem2[currentpage]["x_iconNextToDashBoardDropDownNotPresent"].value.index = index;
                return TestHelper.isElementVisible(currentpage, 'x_iconNextToDashBoardDropDownNotPresent');
            },
            checkDashboardSelectorDropDown: function() {
                return TestHelper.isElementPresent(currentpage, 'subLevelDashboardSelectorDropDown');
            },
            selectDashboardSelectorDropDown: function() {
                return TestHelper.elementToBeClickable(currentpage, 'subLevelDashboardSelectorDeckSelector');
            },
            clickSelectedOption2: function(selectedOption) {
                dem2[currentpage]["SelectedOption2"].locatorValue = selectedOption;
                return TestHelper.elementToBeClickable(currentpage, 'SelectedOption2');
            },
            checkArrowIcon: function() {
                return TestHelper.isElementPresent(currentpage, 'arrowIcon');
            },
            checkNavigationKebabMenuInWidget: function() {
                return TestHelper.isElementVisible(currentpage, 'NavKebabMenu');
            },
            clickWithTimeout: function (element, timeout) {
                return browser.wait(function () {
                    return element.click().then(function () {
                            return true;
                        },
                        function () {
                            browser.sleep(1000);
                            console.log("idle for 1 more second..");
                            return false;
                        });
                }, timeout);
            },
            clickArrowIcon: function() {
                this.arrowIconLocalVar = element(by.css(dem2[currentpage]["arrowIcon"].locatorValue));
                return this.clickWithTimeout(this.arrowIconLocalVar, 5000);
            },
            clickArrowIconWidgets: function() {
                this.arrowIconLocalVar = element(by.css(dem2[currentpage]["arrowIconWidgets"].locatorValue));
                return this.clickWithTimeout(this.arrowIconLocalVar, 5000);
            },
            checkEditCardOptionMenu: function() {
                return TestHelper.isElementVisible(currentpage, 'editCardOptionMenu');
            },
            checkKebabMenuInWidget: function() {
                return TestHelper.isElementPresent(currentpage, 'NavKebabMenu');
            },
            clickKebabMenuInWidget:  function() {
                return TestHelper.elementToBeClickable(currentpage, 'NavKebabMenu');
            },
            checkKebabMenuInCurrentWidget: function() {
                return TestHelper.isElementPresent(currentpage, 'WidgetNavKebabMenu');
            },
            clickKebabMenuInCurrentWidget:  function() {
                return TestHelper.elementToBeClickable(currentpage, 'WidgetNavKebabMenu');
            },
            checkCountOfNavKebabMenuInWidget: function() {
                return element.all(by.css('#advanceNavigation .dropdown-menu.kebab-menu:not([hidden]) li'));
            },
            checkItemInNavigationKebabDropDownMenu: function(assetName) {
                dem2[currentpage]["ItemInKebabMenuInWidget"].locatorValue = assetName;
                return TestHelper.isElementPresent(currentpage, 'ItemInKebabMenuInWidget');
            },
            selectItemInNavigationKebabDropDownMenu: function(assetName) {
                dem2[currentpage]["ItemInKebabMenuInWidget"].locatorValue = assetName;
                return TestHelper.elementToBeClickable(currentpage, 'ItemInKebabMenuInWidget');
            },
            checkMicroAppNameToBePresent: function(agr1) {
                dem2[currentpage]["microAppName"].locatorValue = agr1;
                return TestHelper.getText(currentpage, 'microAppName');
            },
            checkAlertMicroAppNameToBePresent: function(agr1) {
                dem2[currentpage]["microAppNameForAlertApp"].locatorValue = agr1;
                return TestHelper.getText(currentpage, 'microAppNameForAlertApp');
            },
            checkDashboardMicroAppNameToBePresent: function(arg1) {
                dem2[currentpage]["microAppNameForDashboardApp"].locatorValue = arg1;
                return TestHelper.getText(currentpage, 'microAppNameForDashboardApp');
            },
            checkDashboardMicroAppNameInListToBePresent: function() {
                return dem.findElement(currentpage, 'microAppNameFromListForDashboardApp').getAttribute('title');
            },
            checkDashboardKebabMenuIfExists: function() {
                return TestHelper.isElementVisible(currentpage, 'dashBoardDropDownMenu');
            },
            checkAsteriskForAllNavigationAsset: function(arg1) {
                dem2[currentpage]["asteriskElementNextToNavigationAsset"].value.index = arg1;
                return TestHelper.isElementPresent(currentpage, 'asteriskElementNextToNavigationAsset');
            },
            checkAsteriskNotAvailableForNavigationAsset: function(arg1) {
                dem2[currentpage]["asteriskElementNextToNavigationAsset"].value.index = arg1;
                return TestHelper.isElementPresent(currentpage, 'asteriskElementNextToNavigationAsset');
            },
            getCountOfAssetsUnderNavigation: function() {
                var customCSSValue = dem2[currentpage]["asteriskElementNextToNavigationAsset"].value.locatorValue;
                return element.all(by.css(customCSSValue)).count();
            },
            toggleOffNavigationOption: function(arg1) {
                dem2[currentpage]["NavToggleButtonStatusToClickOn"].value.index = arg1 - 1;
                return TestHelper.elementToBeClickable(currentpage, 'NavToggleButtonStatusToClickOn');
            },
            clickOnXButtonToDeleteAsset: function(arg1) {
                dem2[currentpage]["XiconsUsedToDeleteAssetUnderNavigation"].value.index = arg1 - 1;
                return TestHelper.elementToBeClickable(currentpage, 'XiconsUsedToDeleteAssetUnderNavigation');
            },
            chkViewTest: function(viewname) {
                var counter  = 0;
                console.log('inside chkView');
                dem2[currentpage]["View"].locatorValue = viewname;
                return TestHelper.isElementVisible(currentpage, 'View');
            },
            checkMicroAppContainerToBePresent: function(agr1) {
                return TestHelper.isElementVisible(currentpage, 'microAppContainer');
            }
        }
    };
    module.exports = new AdvancedNavPage();
}())
(function () {
    'use strict';

    var cafConfigurationPage = function () {
        var current = {

        };
        return {

            isConfigurationAssetAddIconDisplayed: function(){
                return  element(by.xpath('//*[@id="Asset_addNew_button"]/i')).isDisplayed();
            },

            isConfigurationSegmentAddIconDisplayed: function(){
                return  element(by.xpath('//*[@id="Segment_addNew_button"]/i')).isDisplayed();
            },

            isConfigurationSiteAddIconDisplayed: function(){
                return  element(by.xpath('//*[@id="Site_addNew_button"]/i')).isDisplayed();
            },

            isConfigurationEnterpriseAddIconDisplayed: function(){
                return  element(by.xpath('//*[@id="Enterprise_addNew_button"]/i')).isDisplayed();
            },

            configurationHeader: function () {
                return element(by.cssContainingText('.pxh-view-header__title-link', 'Configuration'));
            },

            isConfigurationAssetAddIconNotDisplayed: function(){
                return  element(by.xpath('//*[@id="Asset_addNew_button"]/i')).isPresent();
            },

            isConfigurationSegmentAddIconNotDisplayed: function(){
                return  element(by.xpath('//*[@id="Segment_addNew_button"]/i')).isPresent();
            },

            isConfigurationSiteAddIconNotDisplayed: function(){
                return  element(by.xpath('//*[@id="Site_addNew_button"]/i')).isPresent();
            },

            isConfigurationEnterpriseAddIconNotDisplayed: function(){
                return  element(by.xpath('//*[@id="Enterprise_addNew_button"]/i')).isPresent();
            },

        };
    };

    module.exports = new cafConfigurationPage();

}());
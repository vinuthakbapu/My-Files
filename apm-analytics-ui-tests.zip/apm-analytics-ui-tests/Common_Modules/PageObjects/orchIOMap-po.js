/********************************************************************************
 * Copyright (c) 2015-2016 GE Digital. All rights reserved.                     *
 *                                                                              *
 * The copyright to the computer software herein is the property of GE Digital. *
 * The software may be used and/or copied only with the written permission of   *
 * GE Digital or in accordance with the terms and conditions stipulated in the  *
 * agreement/contract under which the software has been supplied.               *
 ********************************************************************************/


/**
 * Class encapsulating all functions in main landing page
 */
(function () {
    'use strict';


    var TIMEOUT = 5000;


    var orchIOMapPage = function () {

        var currentPage = 'orchTenantPage';
        var createdName;
        var randOrch = Date.now();
        var assetTagName="AV_TAG_2";
        var assetTagNameOutput= "AV_TAG_10";

        return {

            stepName: function(){
                return element(by.css('.analyticName'));
            },
            
            IOApplicabilityText: function(){
                return element(by.css('.io_description div'));
            },  

            IOMapHeader: function(){
                return element(by.css('.multipleIterationsHeaderContainer .title-header'));
            },

            inputDefinitionText: function(){
                return element(by.css('.inputDefHeaderContainer .title-header'));
            },

            percentRequired: function(){
                return element(by.css('.mappedRequiredRatio'));
                //  return element(by.css('.mapped-required-ratio'));
            },

            percentInputMapped: function(){
                return element(by.css('.mappedRatio'));
                //return element(by.css('.mapped-ratio'));
            },

            assetTagSearch : function(){
                return element(by.id('assetTag-search'));
            },
            
            assetTagSearchText: function(){
                this.assetTagSearch().sendKeys(assetTagName);
            },

            assetTagBox: function(){
                return element.all(by.css('div.assetTagBox'));
            },

            assetTagBoxPlus: function(){
                return element.all(by.css('.fa-plus'));
            },

            inputTag:function(){
                return element.all(by.css('.input'));
            },

            constantValue: function(){
                return element.all(by.css('input.constantValue'));
            },

            outputValue: function(){
                //return element.all(by.css('.output td.required'));
                return element.all(by.css('.output td'));
            },

            assetTagSearchTextOutput: function(){
                this.assetTagSearch().clear().sendKeys(assetTagNameOutput);
            },

            cancelButton: function(){
                return element(by.css('.btn--default'))
            },

            saveButton: function(){
                return element(by.css('.btn--primary'))
            },

            saveButtonDisabled: function(){
                return element(by.css('.btn--primary[disabled=""]'))
            },

            closeButton: function(){
                return element(by.css('.btn--default'))
            },

            deleteTag: function(){
                return element(by.css('.fa-times'))
            },


            //IO MAPS:

            ioMapsText:function(){
                return element(by.css('.iterationIterator span'))
            },
            
            ioMapDropDown: function(){
                return element(by.css('.fa-chevron-down'))
            },

            ioMapItems: function(){
                return element.all(by.css('.item'))
            },

            removeDisabled: function(){
                return element(by.css('a.disabled'))
            },

            iterationBox: function(){
                return element(by.css('.iterationInputBox'))
            },

            iterationLeftArrow: function(){
                return element(by.css('.preIteration'))
            },

            iterationRightArrow: function(){
                return element(by.css('.nextIteration'))
            },

            iterationLeftArrowClick: function(){
                return element(by.css('.fa-angle-left'))
            },

            iterationRightArrowClick: function(){
                return element(by.css('.fa-angle-right'))
            },



            //Iteration Indicator:


            iterationIndicator: function(){
                return element(by.css('.iterationIndicator'))
            },

            descriptionMapping: function(){
                return element(by.css('.description-mapping'))
            },

            dataPointsStepLevelInputBox: function(){
                return element(by.css('.dataPointsStepInputBox'))
            },

            dataPointsIterationLevelInputBox: function(){
                return element(by.css('.dataPointsIterationInputBox'))
            },

            dataPointsPortLevelInputBox: function(){
                return element(by.css('.rowDataPointsInputField'))
            },

        }
    };

    module.exports = new orchIOMapPage();

}());
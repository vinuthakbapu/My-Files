/**
 * Class encapsulating all functions in main landing page
 */
(function () {
    'use strict';

    var TIMEOUT = 5000;

    var assetFilterPage = function () {

        //var currentPage = 'analyticsTenantPage';

        var createdName;
        var createdFamilyName;
        var createdPosition;
        var randVal = Date.now();
        var randEngineFamily = Math.floor((Math.random() * 10) + 1);
        var randEnginePosition =  Math.floor((Math.random() * 4) + 1);

        return {
            visibilityOf : function(elementID){
                var EC = protractor.ExpectedConditions;
                return browser.wait(EC.visibilityOf(elementID),10000) 
            },

            presenceOf: function (elem) {
                var until = protractor.ExpectedConditions;
                return browser.wait(until.presenceOf(elem), 50000, 'Element taking too long to appear in the DOM');
            },

            elementToBeClickable: function(elementID){
                var EC = protractor.ExpectedConditions;
                return browser.wait(EC.elementToBeClickable(elementID), 50000)
            },

            isAssetFiltersLinkDisplayed: function() {
                var el = element(by.linkText('Asset Filters'));
                /* var until = protractor.ExpectedConditions;
                return browser.wait(until.presenceOf(el), 50000, 'Element taking too long to appear in the DOM')
                .then(function() {
                    return el.isDisplayed();
                }); */

                return  element(by.linkText('Asset Filters')).isDisplayed();


            },

            clickAssetFiltersLink: function() {
                return TestHelperPO.elementToBeClickable(element(by.linkText('Asset Filters')));
            },

            isAssetFiltersHeaderDisplayed: function() {
                return  element(by.cssContainingText('.pxh-view-header__title-link', 'Asset Filters')).isDisplayed();
            },

            isfilterNameTextboxDisplayed: function() {
                return  element(by.id('applicability-name')).isDisplayed();
            },

            isAssetTypeLabelDisplayed: function() {
                var until = protractor.ExpectedConditions;
                return browser.wait(until.presenceOf(element(by.css('.apm-af-attribute-name'))), 50000, 'Element taking too long to appear in the DOM')
                .then(function() {
                    return true;
                });
            },

            // isAsteriskDisplayedForAssetType: function() {
            //     return element(by.css('.filterset-item-column1>span:nth-child(2)')).getText();
            // },

            getAssetTypeText: function() {
                return element(by.css('.apm-af-attribute-name')).getText();
            },

            // getAssetTypeOperatorText: function() {
            //     return  element.all(by.css('.filterset-item-column2')).get(0).getText();
            // },

            isAssetTypeTextboxDisplayed: function() {
                return  element.all(by.css('.apm-text-input-field')).get(0).isDisplayed();
            },

            isAssetTypeTextboxEnabled: function() {
                return  element(by.css('.apm-text-input-field')).isEnabled();
            },

            isSubmitButtonEnabled: function() {
                return  element(by.id('apm-af-submit-btn')).isEnabled();
            },

            getAttributeSelectedText: function() {
                return element(by.css('ul.px-dropdown--list > li.px-dropdown-content')).getText();
            },

            getAttributeToWork: function() {
                return element(by.css('ul.px-dropdown--list > li.px-dropdown-content', 'Asset Type Id')).isSelected();
            },

            getFilterNameDefaultText: function() {
                return  element(by.id('filter-name')).getText();
            },

            clickAddAttributeDropdown: function() {
                return TestHelperPO.elementToBeClickable(element(by.id('attribute-dropdown')))
            },

            clickAssetNameOptionInAddAttributeDropdown: function() {
                return TestHelperPO.elementToBeClickable(element.all((by.css('ul.px-dropdown--list > li.px-dropdown-content'))).get(5))
            },

            clickAssetTypeOptionInAddAttributeDropdown: function() {
                return TestHelperPO.elementToBeClickable(element.all((by.css('ul.px-dropdown--list > li.px-dropdown-content'))).get(7))
            },

            isAssetFiltersLinkAvailable: function() {
                return  element(by.linkText('Asset Filters')).isDisplayed();
            },

            isAssetFiltersLinkNotAvailable: function() {
                return  element(by.linkText('Asset Filters')).isPresent();
            },
            clickAssetHierarchyDropdown: function() {
                return TestHelperPO.elementToBeClickable(element.all((by.id('apm-aa-asset-hier-dropdown'))))
            },

            isAssetHierarchyDropdownEnabled: function(){
                return  element(by.id('apm-aa-asset-hier-dropdown')).element(by.css('select')).isEnabled();
            },

            clickEnterpriseHierarchy: function() {
                return TestHelperPO.elementToBeClickable(element.all((by.css('option[value="Enterprise"]'))))
            },

            clickAssetHierarchy: function() {
                return TestHelperPO.elementToBeClickable(element.all((by.css('option[value="Asset"]'))))
            },

            isAssetNamefieldDisplayed: function() {
                return  element(by.id('apm-af-attribute-name', 'Site Name')).isDisplayed();
            },

            isAssetHierNameDisplayed: function() {
                return element(by.id('apm-af-asset-hier-dropdown', 'Enterprise')).isDisplayed();
            },

            isAssetNamefieldDeleted: function() {
                return TestHelperPO.isElementNotPresent(element(by.cssContainingText('apm-af-attribute-name', 'Asset Name')));
            },

            isCancelButtonEnabled: function() {
                return  element(by.id('apm-af-reset-btn')).isEnabled();
            },

            isSearchBarDisplayedInFilterContainerListBlock: function() {
                return  element(by.css('.apm-search-input')).isDisplayed();
            },

            getNewFilterSetText: function() {
                return  element(by.css('.apm-af-new-filter-set')).getText();
            },

            isAddIconDisplayed: function() {
                return  element(by.css('.apm-aa-new-filter-plus-icon')).isDisplayed();
            },

            clickResetButton: function() {
                return TestHelperPO.elementToBeClickable(element(by.id('apm-af-reset-btn')));
            },

            enterFilterName: function(filterName) {
                return TestHelperPO.elementToBeClickable(element(by.id('filter-name'))).then(function(){
                    return element(by.id('filter-name')).sendKeys(filterName);
                });
            },

            // updateFilterName: function(filterName){
            //     return TestHelperPO.elementToBeClickable(element(by.css('.define-input-label'))).then(function(){
            //         return TestHelperPO.sendKeys(element(by.css('.edit-filter-name')), filterName)
            //     });
            // },

            enterAssetType: function() {
                return TestHelperPO.elementToBeClickable(element(by.id('apm-af-attribute-value'))).then(function(){
                    return element(by.id('apm-af-attribute-value')).sendKeys("GE90");
                });
            },

            clickSaveButton: function() {
                return  TestHelperPO.elementToBeClickable(element(by.id('apm-af-submit-btn')));
            },

            isAssetFilterPresent: function(filterId) {
                return  TestHelperPO.isElementPresent(element(by.id(filterId)))
            },

            clickAssetFilter: function(filterName) {
              return element(by.id('filterList_' + filterName)).click();
            },

            clickNewAssetFilter: function() {
                return element(by.css('.apm-aa-new-filter-plus-icon')).click();
            },

            isCreatedFilterPresent: function(filterName) {
                return  TestHelperPO.isElementPresent(element(by.cssContainingText('.apm-af-list-item',filterName)))
            },

            clickSearchIcon: function() {
                return  TestHelperPO.elementToBeClickable(element(by.css('.apm-search-button')));
            },

            waitForSpinnerToComplete: function(){
                return !browser.isElementPresent(by.css('[ng-show="assetApplicabilitySpinner"]'));
            },

            waitSpinner: function(){
                return element(by.css('[ng-show="assetApplicabilitySpinner"]'));
            },

            clickAssetFilterSubNav: function() {
                return element (by.linkText('Asset Filters')).click();
            },

            enterFilterNameLabel: function(){
                return element(by.id('filter-name'));
            },

            enterFilterNameInput: function(){
                return element(by.id('filter-name'));
            },

            filtername:function(){
                return element(by.id('filter-name')).click();
            },

            newFilterSetButton: function(){
                return element(by.css('.new-filter-set'));
            },
            resetButton:function(){
                return element(by.id('apm-af-reset-btn'))
            },
            saveButton: function(){
                return element(by.id('apm-af-submit-btn'))
            },
            addAttribute:function(){
                return element(by.css('span.asset-attribute-dd'))
            },
            getattributeList: function(){
                return element.all(by.css('px-dropdown#attribute-dropdown ul.px-dropdown--list > li.px-dropdown-content'));
            },
            getAssetHierList: function(){
                return element(by.id('apm-af-asset-hier-dropdown'));
            },
            displayedAttribute: function(){
                return element.all(by.repeater('filterOption in selectableFilters'));
            },

            displayedAttributeCount: function(){
                return element.all(by.repeater('filterOption in selectableFilters')).count();
            },

            displayedAttributeValueList: function(){
                return element.all(by.css('div.apm-af-details-fields'));
            },

            engineFamilyTextField: function(){
                return element.all(by.css('.apm-af-details-fields')).get(0);
            },

            engineFamilyName : function(){
                return ('text'+ randEngineFamily);
            },

            enginePositionValue : function(){
                return (randEnginePosition);
            },

            displayedSecondAttribute : function(){
                return element.all(by.css('.apm-af-details-fields > input')).get(1);
            },

            displayedAttributes : function(){
                return element.all(by.css('.apm-af-details-fields> input'));
            },

            assetCriteriaName: function(){
                this.enterFilterNameInput().sendKeys('asset'+ randVal);
            },

            getAssetCriteriaName: function(){
                return element(by.css('label.define-input-label')).getText();
            },

            assetFilterSearchBar: function(){

                return element(by.css('.apm-af-list-search-bar'));
            },

            assetFilterSearchButton: function(){

                return element(by.css('.apm-search-button'));
            },

            assetFilterSearchField: function(filterName){
                return element(by.css('.apm-af-list-search-bar > input')).click().sendKeys(filterName);
            },

            enterSearchFilter: function(filterName) {
                return element(by.css('.apm-af-list-search-bar')).click().clear().then(function(){
                    return element(by.css('.apm-search-input')).sendKeys(filterName);
                });
            },

            getassetFilterSearchResultCount: function(){
                return element.all(by.css('.apm-af-list-item')).count();
            },

            clickFirstSearchResult: function(){
                // return element.all(by.css('.apm-af-list-item')).get(0).click();
                return element.all(by.css('.orchestration-item-name')).click();

            },

            getFilterNameText: function(){
                return element(by.id('applicability-name')).getAttribute('value');
            },

            isDeleteIconDisplayed: function() {
                return  element(by.id('apm-af-delete-btn')).isDisplayed();
            },

            getAssetTypeValue: function(){
                return element(by.css('.text-input.filter-input')).getText();
            },

            getAssetNameColumnHeader: function(){
                return (element(by.cssContainingText('.apm-af-details-fields', 'Site Name'))).getText();
            },

            getAssetDescriptionColumnHeader: function(){
                return (element(by.css('.apm-af-details-fields.apm-text-input-field'))).getText();
            },

            isSearchBarDisplayed: function() {
                return  element(by.css('.apm-af-list-search-bar')).isDisplayed();
            },

            clickDeleteIcon: function(){
                return element(by.id('apm-af-delete-btn')).click();
            },

            clickDeleteButton: function(){
                return element(by.id('apm-af-submitModalBtn')).click();
            },

            isDeleteButtonEnabled: function(){
                return  element(by.id('apm-af-delete-btn')).isEnabled();
            },
            isAssetFiltersAddIconDisplayed: function(){
                return TestHelperPO.isElementPresent(element.all(by.css('.fa-plus')).get(0));
            },
            isresetButtonEnabled: function() {
                return  element(by.id('apm-af-reset-btn')).isDisplayed();
            },
            isdeleteButtonEnabled: function(){
                return  element(by.id('apm-af-delete-btn')).isDisplayed();
            },
            isSaveChangesButtonEnabled: function(){
                return element(by.id('apm-af-submit-btn')).isDisplayed()
            },
            isAssetHierarchDropdownEnabled: function(){
                return  element(by.xpath('//*[@id="apm-aa-asset-hier-dropdown"]/select/option[1]')).isPresent();
            },
            isAssetnameDropdownEnabled: function(){
                return  element(by.xpath('//*[@id="ASSET_0"]/td[1]/select')).isPresent();
            },
            isNameTextFieldEnabled: function(){
                return  element(by.xpath('//*[@id="applicability-name"]')).isPresent();
            },
            isDescriptionTextFieldEnabled: function(){
                return  element(by.xpath('//*[@id="applicability-description"]')).isPresent();
            },
            isRuleButtonEnabled: function(){
                return  element(by.css('.fa-plus')).isPresent();
            },
            isDeleteRuleEnabled: function(){
                return  element(by.css('.fa-close.deleteRule')).isPresent();
            },
            isAssetFiltersAddIconNotDisplayed: function () {
                return element(by.css('.fa-plus')).isPresent();
            },
            isresetButtonNotEnabled: function() {
                return  element(by.id('apm-af-reset-btn')).isPresent();
            },
            isdeleteButtonNotDisplayed: function(){
                return  element(by.id('apm-af-delete-btn')).isPresent();
            },
            isSaveChangesButtonNotDisplayed: function(){
                return element(by.id('apm-af-submit-btn')).isPresent()
            },
            isAssetHierarchDropdownNotDisplayed: function(){
                return  element(by.xpath('//*[@id="apm-aa-asset-hier-dropdown"]/select/option[1]')).isPresent();
            },
            isAssetnameDropdownNotDisplayed: function(){
                return  element(by.xpath('//*[@id="ASSET_0"]/td[1]/select')).isPresent();
            },
            isNameTextFieldNotDisplayed: function(){
                return  element(by.xpath('//*[@id="applicability-name"]')).isPresent();
            },
            isDescriptionTextFieldNotDisplayed: function(){
                return  element(by.xpath('//*[@id="applicability-description"]')).isPresent();
            },
            isRuleButtonNotDisplayed: function(){
                return  element(by.css('.fa-plus')).isPresent();
            },
            isDeleteRuleButtonNotDisplayed: function(){
                return  element(by.css('.fa-close.deleteRule')).isPresent();
            },

            areSearchResultsElementNotDisplayed: function(){
                return TestHelperPO.isElementNotPresent(element(by.css('.apm-af-list-item')));
            },

            editFilterName: function(){
                return element(by.id('filter-name'));
            },

            getFilterSetFirstRow: function(){
                return element(by.css('.filterset-item-column1'));
            },

            editEngineFamilyValue: function(){
                return element(by.css('[ng-model="filterOption.value"]'));
            },

            deleteAnalyticIcon: function(){
                return element(by.id('delete-btn')).click();
            },

            deleteAnalyticButton: function(){
                return element(by.css('button.btn.btn--primary')).click();
            },

            clickNewFilterSet: function(){
                return TestHelperPO.elementToBeClickable(element(by.css('.new-filter-set')));
            },
        };
    };

    module.exports = new assetFilterPage();
}());



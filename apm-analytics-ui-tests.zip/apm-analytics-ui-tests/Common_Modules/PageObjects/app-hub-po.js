(function () {

    //pages
    var loginPage = 'loginPage';
    var dashboardAppPages = 'DashboardAppPages';

    //controls
    var usernameTextbox = 'username';
    var passwordTextbox = 'password';
    var loginAvatar = 'LoginAvtar';

    //misc
    var loginPageClass = 'predix-uaa';

    var AppHubPage = function () {

         return {

             login: function(baseUrl, username, password) {
                 browser.driver.get(baseUrl).then(function() {
                     //check if already logged in from other tests
                     element(By.tagName('body')).getAttribute('class').then(function(classValue) {
                         if(classValue.includes(loginPageClass)) {
                             cem.findElement(loginPage, usernameTextbox).sendKeys(username);
                             cem.findElement(loginPage, passwordTextbox).sendKeys(password);
                             cem.findElement(loginPage, passwordTextbox).sendKeys(protractor.Key.ENTER);
                         }
                     });
                 });
                 //check for presence of login avatar to verify login successful
                 return TestHelper.isElementPresent(dashboardAppPages, loginAvatar);
             },

             navigateToSubmodule: function(moduleName, subModuleName) {
                 return TestHelperPO.elementToBeClickable(element(By.linkText(moduleName))).then(function () {
                     TestHelperPO.elementToBeClickable(element(By.linkText(subModuleName)));
                 });
             }

         }

    };

    module.exports = new AppHubPage();

}());
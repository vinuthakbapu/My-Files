
(function(){
    'use strict';
    var currentpage = 'DashboardAppPages';

    var dashboardSummaryPage = function(){
        var self = this;
        return {
            chkDashboardSummaryToggle: function () {
                return TestHelper.isElementVisible(currentpage, 'DashSumCrdToggle');
            },
            chkDashboardSummaryToggleChk: function () {
                //if(TestHelper.isElementPresent(currentpage, 'DashSumCrdToggle')){
                    return dem.findElement(currentpage, 'DashSumCrdToggle').isSelected();
                //}

                //return TestHelper.findElement(currentpage, 'dashboardSummaryToggle');
                //return dem.findElement(currentpage, 'dashboardSummaryToggle').checked();
                //return element.all(by.css('#dashboard-summary')).get(0).isSelected();
            },
            clickDashboardSummaryToggle: function () {
                return TestHelper.elementToBeClickable(currentpage, 'DashSumCrdTglLabel');
            },
            chkDashboardSummaryLabel: function () {
                return TestHelper.isElementVisible(currentpage, 'DashSumCrdTglLabel');
            },
            getDashboardSummaryLabelTxt: function () {
                return TestHelper.getText(currentpage, 'DashSumCrdTglLabel');
            },
            chkDashboardSummaryCard: function () {
                // return TestHelper.isElementPresent(currentpage, 'dashboardSummaryCard');
                return TestHelper.isElementVisible(currentpage, 'dashboardSummaryCard');
            },
            chkConfigureDashboardSummaryButton: function () {
                    return TestHelper.isElementPresent(currentpage, 'configureDashboardSummaryButton');
            },
            clickConfigureDashboardSummaryButton: function () {
                return TestHelper.elementToBeClickable(currentpage, 'configureDashboardSummaryButton');
            },
            chkConfigureDashboardLink: function () {
                return TestHelper.isElementPresent(currentpage,'configureDashboardLink');
            },
            clickConfigureDashboardLink: function () {
                return TestHelper.elementToBeClickable(currentpage,'configureDashboardLink');
            },
            IsEnabledConfigureDashboardLink: function () {
                return dem.findElement(currentpage,'configureDashboardLink').isEnabled();
            },
            chkConfigureDashboardDisabled: function() {
                return TestHelper.isElementPresent(currentpage,'configureDashboardDisabled');
            },
            chkNumberofTilesInSummaryCard: function() {
                return dem.findElement(currentpage, 'SumryWidgetTiles').count();
                //return TestHelper.getCount(currentpage, 'SumryWidgetTiles')
            },
            chkAddWidgetButtonsInSummaryCard: function() {
                return dem.findElement(currentpage, 'SumryAddWidgetButtons').count();
                //return TestHelper.getCount(currentpage, 'SumryAddWidgetButtons');
            },
            getWidgetsCountInSummaryCard: function() {
                return dem.findElement(currentpage, 'SumryWidgetHoldersWithWidgets').count();
                //return TestHelper.getCount(currentpage, 'SumryAddWidgetButtons');
            },
            clickSumyAddWidgetBtn:function(num){
                dem2[currentpage]["SumryAddWidgetBtn"].value.index=num;
                return TestHelper.elementToBeClickable(currentpage,"SumryAddWidgetBtn");
            },
            chkSumryCardSaveButton: function() {
            return TestHelper.isElementPresent(currentpage,'SumryCrdSaveButton');
            },
            getSumryCardInnerTile:function(num){
                dem2[currentpage]["SumryCardInnerTile"].value.index=num;
                return dem.findElement(currentpage,"SumryCardInnerTile");
            },
            clickSumryDltWidgetIcon:function(num){
                dem2[currentpage]["SumryDltWidgetIcon"].value.index=num;
                return TestHelper.elementToBeClickable(currentpage,"SumryDltWidgetIcon");
            },
            getSumryDltWidgetIconCount: function() {
                return dem.findElement(currentpage, 'SumryDltWidgetIcons').count();
            },
            clickSumryEditWidgetIcon:function(num){
                dem2[currentpage]["SumryEditWidgetIcon"].value.index=num;
                return TestHelper.elementToBeClickable(currentpage,"SumryEditWidgetIcon");
            },
            getSumryEditWidgetIconCount: function() {
                return dem.findElement(currentpage, 'SumryEditWidgetIcons').count();
            },
            getSumryFooterMsgCount: function() {
                return dem.findElement(currentpage, 'SumryCardFooterMessages').count();
            },
            getSumryCardFooterText:function(num){
                dem2[currentpage]["SumryCardFooterMsg"].value.index=num;
                return TestHelper.getText(currentpage,"SumryCardFooterMsg");
            },
            clickSumryCardSaveButton: function() {
                return TestHelper.elementToBeClickable(currentpage,'SumryCrdSaveButton');
            },
            chkSumryCardCancelButton: function() {
                return TestHelper.isElementVisible(currentpage,'SumryCrdCancelButton');
            },
            clickSumryCardCancelButton: function() {
                return TestHelper.elementToBeClickable(currentpage,'SumryCrdCancelButton');
            },
            clickSumryCardAddTilePlusSign: function() {
                return TestHelper.elementToBeClickable(currentpage,'SumryPlusSignAddTile');
            },
            ChkSumryCardAddTilePlusSign: function() {
                return TestHelper.isElementVisible(currentpage,'SumryPlusSignAddTile');
            },
            ChkSumryCardAddTilePlusSignHidden: function() {
                return TestHelper.isElementVisible(currentpage,'SumryPlusSignAddTileHidden');
            },
            getSummaryCardLandingSection: function() {
                return dem.findElement(currentpage,'SumryCardLandingSection');
            },
            ChkSumryCardInEditMode: function() {
                return TestHelper.isElementVisible(currentpage,'SumryCardInEditMode');
            }

        }
    };
    module.exports = new dashboardSummaryPage();

}());

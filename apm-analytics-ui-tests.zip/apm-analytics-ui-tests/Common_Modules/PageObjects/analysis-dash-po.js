/**
 * Created by 212350438 on 7/9/15.
 */

(function () {

    'use strict';

    //   var dataTablePage = require('../common/add-asset-po');


    var path = require( 'path' );
    var contextname;


    var AnalysisPage = function () {

        return {
            get: function () {
                return browser.get( pageUrl );
            },

            getContextBrowser: function () {
               return TestHelperPO.isElementPresent(element( by.css( 'div.px-context-browser')));
            },

            getGraphElement: function(){
                return element(by.css('#layer1 > g path'));
            },



            // Updated for Q1
            getContextBrowser_dropdown: function () {
                return element( by.css('#selectContext > div.flex__item--middle.style-scope.px-context-browser > h1 > iron-icon'));

            },



            // clickAsset: function (txt) {
            //     return TestHelperPO.elementToBeClickable(element(by.cssContainingText( 'span.px-context-browser', txt)));
            // },

                clickAsset: function (txt) {
                    return TestHelperPO.elementToBeClickable(element(by.cssContainingText( 'span.flex__item.item-label.style-scope.px-context-browser', txt)));
                },

            clickAssetCheckbox: function (txt) {
                const ele = element(by.css( 'input[name="'+ txt +'"]'));
                return TestHelperPO.elementToBeClickable(ele);
            },
            getCompareAssetTooltip: function () {
                return  TestHelperPO.getText(element.all(by.css( 'span.style-scope.px-tooltipr' )).get(10));
            },

            getCompareAssetButton: function () {
                return  TestHelperPO.elementToBeClickable(element(By.xpath("//button[contains(text(),'Compare')]")));
            },

            getOpenAssetButton: function () {
                return  TestHelperPO.elementToBeClickable(element.all( by.css( 'li.selected button.opener' )).last());
            },

            getMake_Label: function(){
                return TestHelperPO.getText(element(by.css('#make > div.asset-spine-label.style-scope.asset-spine')));  // label
            },

            // <analisis>.<Make on Asset Spine> ***********************************
            getMakeValue: function(){
                return TestHelperPO.getText(element(by.css('#make > div.asset-spine-value.style-scope.asset-spine')));  // value
            },

            // <analisis>.<Make on Asset Spine> ***********************************
            getAssetType_Label: function(){
                return TestHelperPO.getText(element(by.css('#assetType > div.asset-spine-label.style-scope.asset-spine')));  // label
            },


            // <analisis>.<Make on Asset Spine> ***********************************
            getAssetTypeValue: function(){
                return TestHelperPO.getText(element(by.css('#assetType > div.asset-spine-value.style-scope.asset-spine')));  // value
            },

            // <analisis>.<Applied to on save template view > ***********************************
            getAppliedToLabel_saveTemp: function(){
                return TestHelperPO.getText(element(by.css('#appliedTo > span.asset-spine-label.style-scope.asset-spine')));  // label
            },

            // <analisis>.<Analysis Type on adhoc view > ***********************************
            getAnalysisTypeLabel_adhoc: function(){
                return TestHelperPO.getText(element(by.css('#analysisType > div.asset-spine-label.style-scope.asset-spine')));  // label
            },

            // <analisis>.<Analysis Type on template view > ***********************************
            getAnalysisTypeValue_template: function(){
                return TestHelperPO.getText(element.all(by.css('div.context-spine-value.style-scope.context-spine')).get(2));  // value
            },

            // <analisis>.<Analysis Type on adhoc view > ***********************************
            getAnalysisTypeValue_adhoc: function(){
               // return TestHelperPO.getText(element(by.css('#analysisType > div.asset-spine-value.style-scope.asset-spine')));  // value
                return TestHelperPO.getText(element.all(by.css('div#analysisType > div.asset-spine-value.style-scope.asset-spine')).get(1));  // value
            },

            // <analisis>.<Applied to on save template view > ***********************************
            getAppliedToValue_saveTemp: function(){
                return TestHelperPO.getText(element(by.css('#appliedTo > span.asset-spine-value.style-scope.asset-spine')));  // value
            },

            // <analisis>.<PublishedTo on save template view > ***********************************
            getPublishedToLabel_saveTemp: function(){
                return TestHelperPO.getText(element(by.css('#publishedTo > span.asset-spine-label.style-scope.asset-spine')));  // label
            },

            // <analisis>.<PublishedTo on save template view > ***********************************
            getPublishedToValue_saveTemp: function(){
                return TestHelperPO.getText(element(by.css('#publishedTo > span.asset-spine-value.style-scope.asset-spine')));  // value
            },


            // <analisis>.<Applied to on adhoc view > ***********************************
            getAppliedToLabel_adhoc: function(){
                return TestHelperPO.getText(element(by.css('#analysis-spine > div > section.multi-chart-template-container.style-scope.asset-spine > ul > li:nth-child(5) > div > div.asset-spine-label.style-scope.asset-spine')));  // label
            },

            // <analisis>.<Applied to on adhoc view > ***********************************
            getAppliedToValue_adhoc: function(){
                return TestHelperPO.getText(element(by.id('appliedValue')));  // value
            },

            // <analisis>.<PublishedTo on adhoc view > ***********************************
            getPublishedToLabel_adhoc: function(){
                return TestHelperPO.getText(element(by.css('#analysis-spine > div > section.multi-chart-template-container.style-scope.asset-spine > ul > li:nth-child(6) > div > div.asset-spine-label.style-scope.asset-spine')));  // label
            },

            // <analisis>.<PublishedTo on adhoc view > ***********************************
            getPublishedToValue_adhoc: function(){
                return TestHelperPO.getText(element(by.css('#analysis-spine > div > section.multi-chart-template-container.style-scope.asset-spine > ul > li:nth-child(6) > div > div.asset-spine-value.style-scope.asset-spine')));  // value
            },


            getTagToolbox: function () {

                return element( by.css( 'tag-toolbox#tag-toolbox' ) );
            },

            getViewMenu: function() {

                return TestHelperPO.elementToBeClickable(element(by.css("[id^='layout-icon-bar'] > #kabob-menu * .tag-menu-kabob")));
            },

            getDeckSelectorArrow: function() {

                return TestHelperPO.elementToBeClickable(element(by.css("#header-deck-selector #tag-menu-kabob")));
            },


            //Published To
            getPublishedToArrow: function() {

                return TestHelperPO.elementToBeClickable(element(by.css("#header-container #publishedTo #button [title='Public Templates']")));
            },

            getPublicTemplateOption: function() {

                return TestHelperPO.elementToBeClickable(element(by.css("#header-container #publishedTo #selector div[title='Public Templates']")));
            },

            getPublicTemplateOptionText: function() {

                return TestHelperPO.getText(element(by.css("#header-container #publishedTo #selector div[title='Public Templates'] span")));
            },
//OKC-CODE
            getPrivateTemplateOption: function() {

                return TestHelperPO.elementToBeClickable(element(by.css("#publishedTo * #list > li:nth-child(3)")));
            },

            getPrivateTemplateOptionText: function() {

                return TestHelperPO.getText(element(by.css("#publishedTo * px-dropdown-text > #textWrap")));
            },


            getDeckSelectorPublicTempOption: function() {

                return TestHelperPO.elementToBeClickable(element(by.css("#layout-view-selector * ul > li:nth-child(2)")));
            },
//OKC-CODE
            getDeckSelectorPrivateTempOption: function() {

                return TestHelperPO.elementToBeClickable(element(by.css("#layout-view-selector * ul > li:nth-child(3)")));
            },

            // Save as evidence kebab icon

            getSaveEvidenceKebabIcn: function() {

                return element(by.css('view-menu-new#view-menu-new-evidence div'));
            },

            // Save as evidence menu option

            getSaveEvidenceOptn: function() {

                return element(by.cssContainingText('view-menu-new#view-menu-new-evidence li span', 'Save as Evidence'));
            },


            //save as evidence template

            getSaveAsTemplate: function() {


                return element.all(by.css('save-view-template div.save-view-template-container')).get(1);

            },

            getEviNameInput: function() {

                return element.all(by.css('div.view-name input#viewNameInput')).get(1);

            },
            getTagtToolBoxKebabIcon: function() {

                return element(by.css('tag-toolbox view-menu-new div i'));

            },

            // alert details evidence name
            getAlertEvidenceName: function(name) {

                return element(by.cssContainingText('span.analysis-evidence-name', name));
            },

            // search menu option in tag toolbox

            getTagToolSearchOpt: function(arg) {

               return element(by.cssContainingText('view-options-menu-new li', arg));
            },


            getViewMeuOption: function(txt) {

                return TestHelperPO.isElementPresent(element(by.cssContainingText('#kabob-menu * div.pae-dropdown-container.style-scope.pae-dropdown * li * span',txt)));
            },

            getViewMeuOption_forDeleteTemplate: function() {
                return TestHelperPO.isElementPresent(element(by.css('#view-menu-new view-options-menu-new ul:nth-child(3) li > span:nth-child(2)')));
                // return TestHelperPO.isElementPresent(element(by.css('#submenucontainer > div:nth-child(1) > ul:nth-child(3) > li > span:nth-child(2)')));

            },
            getSavedAnalysisTemplateName_inView: function(){
                return TestHelperPO.getText(element(by.css('#selectedDeckvalue')));  // Save template name in view
            },

            getDelete_AnalysisTemplate_option: function(txt){
                return TestHelperPO.isElementPresent(element(by.cssContainingText('#kabob-menu * div.pae-dropdown-container.style-scope.pae-dropdown * li * span',txt)));
            },

            getDelete_AnalysisTemplate_confirmBTN: function(){
                return TestHelperPO.elementToBeClickable(element.all(by.id('btnModalPositive')).get(1));  // delete confirm button

            },

            getCancel_onDeleteTemplate_confirmBTN: function(){
                return TestHelperPO.elementToBeClickable(element(by.id('Cancel')));  // cencel confirm button
            },

            getViewMeuOptionClick: function(txt) {
                return TestHelperPO.elementToBeClickable(element(by.cssContainingText('#kabob-menu * div.pae-dropdown-container.style-scope.pae-dropdown * li * span',txt)));
            },

            getEBQViewMeuOptionClick: function(txt) {
                return TestHelperPO.elementToBeClickable(element(by.cssContainingText('#kabob-menu > div.menu-parent-container.style-scope.pae-dropdown * li * span',txt)));
            },

            getViewMeuOptionVisibility: function(txt) {
                return TestHelperPO.isElementVisible(element(by.cssContainingText('#kabob-menu * div.pae-dropdown-container.style-scope.pae-dropdown * li * span',txt)));
            },

            getSaveViewTemplateCnt: function() {

                return TestHelperPO.isElementPresent(element.all(by.css('div.save-view-header-container.style-scope.save-view-header')).get(0));
            },

            getAssetContextSaveView: function(){

                return element(by.css('span.save-view-template.ng-binding'));
            },

            getConfirmationModal: function(){

                return element(by.css('section.px-modal'));
            },

            getModalOkButton: function(){
                return element(by.css('button#OK'));
            },

            getModalCancelButton:function() {
                return element(by.css('button#Cancel'));
            },

            getViewNameInput: function(){
                return TestHelperPO.isElementPresent(element.all(by.id('viewNameInput')).get(0));
            },

            getViewMenuTagAlias: function(){
                return TestHelperPO.elementToBeClickable(element.all(by.css('div.tag-list-controls-container div.button-container #tag-menu-kabob')).get(1));
            },

            getTagAliasMenuItem: function(){

                return element(by.css('tag-toolbox#tag-toolbox div#submenucontainer li'));
            },

            getPlottedTagInfoIndicator: function(){

                return element(by.css('div.plotted-tag-info-indicator'));
            },

            getTagInfoBackButton: function(){
                return element(by.css('span.tag-header-back'));
            },

            getPlottedTaginfoScreen: function(){

                return element(by.css('plotted-tag-info#plotted-tag-info'));
            },

            getSaveViewBtnElements: function(){

                return element(by.css('div.save-view-actions button'))
            },

//            getSearchInput: function () {
//
//                return element( by.css( 'input#tagSearch' ) )
//            },

            getSearchIcon: function () {

                return element( by.css( 'span.tag-toolbox i.fa-search' ) );
            },

            getTagFilter: function () {


                return element( by.css( 'li.tag-filter-open' ) );
            },
            getSearchInputDeleteIcon: function () {

                return element( by.css( 'div.tag-list-controls-container span.x-icon' ) )
            },

            getSearchInputFilterIcon: function () {

                return element( by.css( 'div.tag-list-controls-container span.search-icon' ) )
            },

            getTagResultsArea: function () {

                return TestHelperPO.isElementPresent(element(by.css( '.tags.style-scope.tag-panel' )));
            },

            getSpinner: function () {

                return element( by.css( 'div.px-spinner' ) );
            },

            getPlottedTagsHeader: function () {

                return element( by.css( 'plotted-tag-list.tag-toolbox div.tag-list-controls-container' ) );
            },

            getPlottedTag: function () {

                return element( by.css( 'plotted-tag-list.tag-toolbox  h4' ) );
            },

            getPlottedTagSearchResult: function () {

                return element( by.css( 'ul.display-tag-list li' ) );
            },

            getDeleteIcon: function () {
                return TestHelperPO.elementToBeClickable(element(by.css('div.tag-toolbox span.x-icon i.fa-times-circle')));
            },

            getMuteButtonOn: function () {

                return element( by.css( 'span.mute-button-on' ) );
            },

            getMuteButtonOff: function () {

                return element( by.css( 'span.mute-button-off' ) );
            },

            getFromDateField: function () {

                return element( by.css( 'div#fromFields' ) );
            },

            getToDateField: function () {

                return element( by.css( 'div#toFields' ) );
            },

            getSubmitBtn: function () {

                return element( by.css( 'button.px-range-fields' ) );
            },

            getDisplayMsgElement: function () {

                return element.all( by.css( 'div.displayMsg' ) ).get( 1 );
            },

            getLoggedProfileImage: function () {

                return element( by.css( 'img.logout-menu-avatar' ) );
            },

            getLoggedUserName: function () {
                return element( by.css( 'span.username-wrap' ) );
            },

            getGearIcon: function () {
                return element( by.css( 'i.fa-gear' ) );
            },

            getLogoutMenu: function () {

                return element( by.css( 'i.logout-menu-angle-up' ) );
            },

            getHighchartsElement: function () {

                return element( by.css( 'rect.highcharts-background' ) );
            },

            getContextBrowserToggle: function () {

                return element( by.css( 'span.px-context-browser' ) );
            },

            getPlottedChartTracker: function () {

                return element( by.css( 'path.highcharts-tracker' ) )
            },

            getCardEditDropdown: function () {

                return element( by.css( 'i.editDropDown' ) )
            },

            getUserName: function () {

               return TestHelperPO.isElementPresent(element( by.name( 'username' )));
            },


            getEditProfile: function(){
                return element(by.cssContainingText('button' , 'Edit'));
            },
            getSelectAssetName: function(assetName){
                //  return element.all(by.model('userProfile.edit.preference') ).get(1) ;
                element(by.css('select') ).click() ;
                return element(by.cssContainingText('option', assetName)) ;
            },

            getSaveProfileButton: function(){
                return element(by.cssContainingText('button', 'Save')) ;
            },

            getAssetName:function(){

                return element(by.css('p.displayPreferenceForAssetName')) ;
            },

//left navigation
            getLeftTab: function (textName) {

                return element( by.cssContainingText( '#navitemlist li a span', textName ) );
            },
//should change to element
            getAllLeftTab: function () {
                 TestHelperPO.isElementPresent(element.all( by.css( '#navitemlist a span' )).get(0)).then(function(){
                    return element.all( by.css( '#navitemlist a span' )).get(0);
                })
            },

            //
            //getAllLeftTab: function(){
            //
            //    return by.css('#navitemlist a span') ;
            //},


            getAllToolTipNav: function () {

                return by.css( 'ul.nav-login li a' );
            },
//            getTagSearchViewMnuIcon: function() {
//
//                return element.all(by.css('div.tag-list-controls-container div.button-container.view-menu-new')).get(0);
//            },

            getAnalysisHeader: function () {

                return by.css( 'header#selectContext' );
            },
            getSearch: function () {
                return TestHelperPO.elementToBeClickable(element(by.css('#header-toggle-side-panel')));
                },
            getSearch2: function () {
                return TestHelperPO.elementToBeClickable(element.all(by.css( 'i.fa.fa-search.style-scope.tag-toolbox' )).get(0));
            },
            // getAnalysisTab: function () {
            //     return TestHelperPO.isElementPresent(element(by.linkText('Analysis')));
            // },

           //For Q1 dev env - temporary
            getAnalysisTab: function () {
                return TestHelperPO.isElementPresent(element(by.linkText('Analysis2')));
            },

            // OKC-CODE  For ESP Analysis
            getAnalysis: function () {
                return TestHelperPO.isElementPresent(element(by.linkText('Analysis')));
            },

            getDashboardTab: function () {
                return TestHelperPO.isElementPresent(element(by.linkText('Dashboard')));
            },
            //edit dashboard widgets

            getWidgetHover: function (widget_number) {
                var widgetClassName = 'div.widget-' + widget_number;
                console.log('inside hover ' + widget_number);
                return element( by.css( widgetClassName ) );
            },

            getWidgetPencilIcon: function (widget_number) {
                var widgetClassName = 'div.widget-' + widget_number + ' i.fa.fa-pencil';
                return element( by.css( widgetClassName ) );
            },

            getWidgetTitle: function (widget_number) {
                var cssWidgetTitle = 'div.widget-' + widget_number + ' .display-header';
                return element( by.css( cssWidgetTitle ) );
            },

//edit widget title
            getEditWidgetTitle: function () {
                return element.all( by.css( 'input.text-input' ) ).get( 1 );
            },
            getSaveWidgetButton: function () {
                return element(by.cssContainingText( 'button.btn--primary.edit-widget-header', 'Save'));
            },
            getCancelWidgetButton: function () {
                return element( by.css( '#btn-back-to-dashboard' ) );
            },
            getContextColumnBrowser: function () {
                return TestHelperPO.isElementPresent(element( by.css( 'div#columnBrowser' )));
            },
            getCancelWidgetModalButton: function(){
                return element(by.css('#Cancel')) ;
            },
            getOkWidgetModalButton: function(){
                return element(by.css('#OK')) ;
            },

            getEditWidgetConfirmationModal: function(){

                return element(by.css('#Cancel'));
                //         return element(by.css('div.modal__buttons'));


                //    return element(by.css('#edit-widget-confirm-title'));
            },
            getEditWidgetConfirmationModalOk: function(){

                return element(by.css('#OK'));
            },
            getEditWidgetConfirmationModalCancel: function(){

                return element(by.css('#Cancel'));

            },

            getOutputWidgetEditName1: function(){

                return element.all(by.css('input.text-input.configure-output-capacity-widget') ).get(1);
            },
            getOutputWidgetEditName2: function(){

                return element.all(by.css('input.text-input.configure-output-capacity-widget') ).get(4);
            },
            getOutputWidgetEditUnit: function(){

                return element.all(by.css('input.text-input.configure-output-capacity-widget') ).get(2);
            },

            getOutputWidgetNameUnits1: function () {
                return element.all(by.css('div.output-display') ).get(0);
            },
            getOutputWidgetNameUnits2: function () {
                return element.all(by.css('div.output-display') ).get(1);
            },
            getPerformanceWidgetEditUnit: function () {
                return element.all(by.css('input.text-input.configure-performance-widget') ).get(1);
            },
            getPerformanceWidgetUnit: function () {
                return element(by.css('div.capacity-display.performance-widget') );
            },
            getNumberWidgetEditName1: function () {
                return element.all(by.css('input.text-input.configure-number-widget') ).get(1);
            },
            getNumberWidgetEditName2: function () {
                return element.all(by.css('input.text-input.configure-number-widget') ).get(3);
            },
            getNumberWidgetEditUnit1: function () {
                return element.all(by.css('input.text-input.configure-number-widget') ).get(2);
            },
            getNumberWidgetEditUnit2: function () {
                return element.all(by.css('input.text-input.configure-number-widget') ).get(4);
            },
            getNumberWidgetName1: function () {
                return element.all(by.css('div.number-widget.epsilon') ).get(0);
            },
            getNumberWidgetName2: function () {
                return element.all(by.css('div.number-widget.epsilon') ).get(2);
            },
            getNumberWidgetUnit1: function () {
                return element.all(by.css('div.number-widget.epsilon') ).get(1);
            },
            getNumberWidgetUnit2: function () {
                return element.all(by.css('div.number-widget.epsilon') ).get(3);
            },

			/*
***********************************************Properties by Monira Sultana******************************************************
*/
// <analysis>.<Asset or Tag search input box>
            getSearchInput: function () {
                return TestHelperPO.isElementPresent(element(by.css('input#tagSearch.style-scope.tag-toolbox'))).then(function(){
                    return element( by.css('input#tagSearch.style-scope.tag-toolbox' ) )
                })
            },

// <analisis>.<Tag Search In> dropdown icon**********************************************************
            getTagSearchViewMnuIcon: function() {
				return element(by.css('div.tag-list-controls-container div.button-container.view-menu-new'));
            },

// <analisis>.<Search in> selection from dropdown list*****************************
//             getTagSearchViewMnuIcon_SearchIn: function() {
//                 return element.all(by.css('div.tag-list-controls-container div.button-container.view-menu-new')).get(0);
//             },

            // Updated for Q1
            getTagSearchViewMnuIcon_SearchIn: function() {
                return element.all(by.css('#header-toggle-side-panel')).get(0);
            },


// <analisis>.<Tags> or <Tags+Child> or <Assets> selection from dropdown list***************************
            getTagAssetSearchDropDown_selectMenuItems: function(text) {
				return element(by.cssContainingText('view-options-menu-new li.view-options-menu-new', text));
            },


// <analisis>.<TagSearch Input field Placeholder> ******************************************************
            getTagSearchInputPlaceholder: function() {
                return element( by.css( 'input#tagSearch' )).getAttribute('placeholder');
            },

// <analisis>.<Tag Expression option from dropdown> ******************************************************
			 getViewMenuTagExpression: function(){
                return element.all(by.css('div.tag-list-controls-container div.button-container')).get(1);
            },
			getViewOptionsMenuNew_selectItems: function(text){
				return TestHelperPO.isElementPresent(element(by.cssContainingText('view-options-menu-new li.view-options-menu-new', text)));
            },

// <analisis>.<Tag Expression popup window> *************************************************
			 getTagExpressionWindow: function(){
                return TestHelperPO.isElementPresent(element(by.id('expressionTag')));
            },

// <analisis>.<Validate Expression btn> *****************************************************
			 getValidateTagExpressionBtn: function(){
                return TestHelperPO.isElementPresent(element(by.id('validateExpressionBtn'))).then(function(){
                    return element(by.id('validateExpressionBtn'));
                })
            },

// <analisis>.<Create Expression btn> ******************************************************
			 getCreateTagExpressionBtn: function(){
                 browser.sleep(6000);
                return TestHelperPO.isElementPresent(element(by.id('Create'))).then(function(){
                    return element(by.id('Create'));
                })
            },

// <analisis>.<Cancel Expression btn> ******************************************************
			 getCancelTagExpressionBtn: function(){
                return TestHelperPO.isElementPresent(element(by.css('div#expressionTag button#Cancel'))).then(function(){
                    return element(by.css('div#expressionTag button#Cancel'));
                })
            },

// <analisis>.<Tag Expression popup window> ******************************************************
            getTagExpressionPopup: function () {
                // return element(by.css('#expressionTag > div')); // non microapp
                // ('#expressionTag').getElementsByTagName('div')[1]
                return TestHelperPO.isElementPresent(element.all(by.css('#expressionTag div')).get(1)).then(function () {
                    return element.all(by.css('#expressionTag div')).get(1); // target refactored
                })
            },


// <analisis>.<All Cancel btn> ******************************************************
			 getCancel_for_TagExpression_Btn: function(){
                return element.all(by.id('Cancel')).get(3);
            },

// <analisis>.<Tag Expression - Result Preview Message> *************************************
			 getTagExpressionResultPreviewMessage: function(){
                return TestHelperPO.getText(element(by.id('resultPreview')));
			 },

// <analisis>.<Tag Expression - Result Preview ERROR BLOCK> *************************************
			 getTagExpressionErrorMessage: function(){
                return TestHelperPO.getText(element(by.id('error-block')));
			 },

// <analisis>.<Tag Expression Name- Input Field> *********************************************
			 getTagExpressionNameInput: function(){
                return TestHelperPO.isElementPresent(element(by.id('exprName'))).then(function(){
                    return element(by.id('exprName'));
                })
			 },

// <analisis>.<Tag Expression- Input Field> **************************************************
			 getTagExpressionInput: function(){
                return TestHelperPO.isElementPresent(element(by.id('expression'))).then(function(){
                    return element(by.id('expression'));
                })
			 },

// <analisis>.<saveTemplateErrorMessage selector for all error> **********************************************************************************************
			 getsaveTemplateAlert_selector: function(){
				 // return element(by.css('div.message.style-scope.px-alert-message > p > span:nth-child(2)'));
				 return element (by.id('alert'));  // target the location to all alerts for save template

			 },


// <analisis>.<saveTemplateErrorMessage for Tag Expression existes on the view> **********************************************************************************************
			 getsaveTemplateErrorMessageForTagExp: function(){

				// return element.all( by.css( 'div.message.style-scope.px-alert-message > p > span:nth-child(2)')).get(8); //Before refactor

                return element.all(by.css('div.message.style-scope.px-alert-message >p > span:nth-child(2)')); // target refactroed


			 },


// <analisis>.<Tag Expression Header- Field LABEL> *************************************************
			 getTagExpressionHeader_LABEL: function() {
                 return TestHelperPO.getText(element(by.id('expressionTag-title')));
             },
// <analisis>.<Tag Expression Name- Field LABEL> *************************************************
			 getTagExpressionNameField_LABEL: function(){
                return TestHelperPO.getText(element(by.css('#expressionTag > section > p:nth-child(2) > b')));
			 },
// <analisis>.<Tag Expression- Field LABEL> *************************************************
			getTagExpressionField_LABEL: function(){
			return TestHelperPO.getText(element(by.css('#expressionTag > section > p:nth-child(4) > b')));
			},

// <analisis>.<Tag Expression RESULT PREVIEW- Field LABEL> *************************************************
			getTagExpressionResultPreview_LABEL: function(){
			return TestHelperPO.getText(element(by.css('#expressionTag > section > p:nth-child(6) > b')));
			},

// <analisis>.<Date Range- From Field > ***********************************
            getFromField_DateRange: function(){
                return TestHelperPO.elementToBeClickable(element(by.id('fromFields')));

                //return TestHelperPO.elementToBeClickable(element.all(by.css('#dtEntry')).get(0));
                // return TestHelperPO.elementToBeClickable(element.all(by.css('#fromDate > div > label > input')).get(0));
            },
// <analisis>.<Date Range- From Field > ***********************************
            getToField_DateRange: function(){
                return TestHelperPO.elementToBeClickable(element(by.id('toFields')));

              //   return TestHelperPO.elementToBeClickable(element.all(by.css('#dtEntry')).get(6));
                // return TestHelperPO.elementToBeClickable(element.all(by.css('#toDate > div > label > input')).get(0));
            },

// <analisis>.<Date Range- Apply button > ***********************************
            getApplyBTN_DateRange: function(){
                return TestHelperPO.elementToBeClickable(element(by.css('#submitButton')));
            },

// <analisis>.<saveTemplateErrorMessage for unauthorized user existes on the view> **********************************************************************************************
            getsaveTemplateErrorMessageForViewOnlyAuth: function(){

                // return element.all(by.css('div.message.style-scope.px-alert-message >p > span:nth-child(2)')); // target refactroed

                return element.all(by.css('#message > span:nth-child(2)')); // target refactroed

            },

// <analisis>.<View Save Template dropdown > ***********************************
            getViewTemplateDropdownArrow: function(){
            //    return TestHelperPO.isElementPresent(element(by.css('#my-deck-selector > div > i')));
                return TestHelperPO.isElementPresent(element(by.css('#header-deck-selector > div > iron-icon'))); //Q1 refactor
            },
// <analisis>.<View Save Template dropdown > ***********************************
            getViewTemplateDropdownOption: function(){
                return TestHelperPO.isElementPresent(element(by.css('#dropdown')));
            },

            getViewTemplateDropdown: function(){
                return element(by.css('#dropdown'));
            },
// <analisis>.<New Save Template- view template dropdown menu > ***********************************
            getViewTemplateDropdownMenu_lastOption: function(){
                return element(by.css('#dropdown > li.deck-editor.style-scope.px-deck-selector > div'));
            },

// <analisis>.<Analysis Line Charts Resize on Left Menu Collapse/Expand > ***********************************

            // Target for left menu on the top of the screen
            getLeftMenu: function(){
                return TestHelperPO.elementToBeClickable(element(by.css('.pxh-drawer-toggle__link')));
            },

            // Target for chart area
            getChartArea: function(){
                return TestHelperPO.isElementVisible(element(by.id('chartSVG'))).then(function(){
                    return element(by.id('chartSVG'));  // for Chart Area
                })
            },

            // Target for high chart area
            getHighChartGrid: function(){
                return TestHelperPO.isElementPresent(element(by.id('px-chart-container'))).then(function() {
                    return element(by.id('px-chart-container'));  // High Chart Grid
                });
            },

            //checkForPlottedData: function(){
            //    return TestHelperPO.isElementPresent(element(by.css('.spinner.style-scope.px-spinner'))).then(function() {
            //       return  element(by.css('.spinner.style-scope.px-spinner')).getInnerHtml().then(function(result){
            //        if(result.toEqual("")){
            //            console.log("EMPTY NO CHILD");
            //            return false;
            //        }
            //            else{
            //            console.log("NOT EMPTY. HAS CHILD");
            //            return true;
            //        }
            //        });
            //    });
            //},
            checkForPlottedData: function(){
                return TestHelperPO.isElementPresent(element.all(by.css('.spinner.style-scope.px-spinner')).get(4)).then(function() {
                    return  element.all(by.css('.spinner.style-scope.px-spinner')).get(4)
                });
            },


            getLeftNav: function(){
                return TestHelperPO.isElementVisible(element(by.css('body > aside > nav')));  // Left Navigation
            },

            getDefaultDateRangePicker: function(){
                //  return element(by.id('analysis-rangepicker'));
                // return TestHelperPO.isElementPresent(element(by.css('#analysis-rangepicker'))).then(function(){

                // return TestHelperPO.isElementPresent(element(by.id('ts-data-widget')));

               // return TestHelperPO.isElementPresent(element(by.id('ts-data-widget'))).then(function(){
                    return element(by.id('ts-data-widget'));
               // })

            },



            // Multi-asset label
            getMultiAssetLabel: function(){
                return TestHelperPO.isElementPresent(element(by.css('#analysisdeckspinner'))).then(function(){
                    browser.sleep(6000)
                    return TestHelperPO.isElementVisible( element(by.css('#plotted-assets-list > li > div > div.tag-name-container.style-scope.plotted-asset-list > h4'))).then(function(){
                    return TestHelperPO.elementToBeClickable( element(by.css('#plotted-assets-list > li > div > div.tag-name-container.style-scope.plotted-asset-list > h4'))).then(function(){
                            return element(by.css('#plotted-assets-list > li > div > div.tag-name-container.style-scope.plotted-asset-list > h4'));
                        })
                    })
                })
            },


        //Multi Charts get the template name

            getSavedMultiChartTemplateName: function(template_name){
                 TestHelperPO.getText(element(by.css('#my-deck-selector > div > span'))).then(function(txt) {
                     template_name = txt;
                     // return  TestHelperPO.elementToBeClickable(element(by.css('#my-deck-selector > div > span'))).then(function() {
                     //    console.log(txt);
                    }) // Save MultiChart template name in view


            },

// <analysis>.<new adhoc>.<Loss Confirmation>****************************
            getContinueBTN_LossTempChange_visibility: function(){
                // return TestHelperPO.isElementVisible(element(by.css('#ADHOC-analysis-modal> #ADHOC-analysis-modal > section> div > div.flex.style-scope.px-modal> #Continue'))); // Continue button visibility
                browser.sleep(6000); // Updated for Q1 code
                return TestHelperPO.isElementPresent(element.all(by.css('#btnModalPositive')).get(3)); // Continue button visibility
            },

            getContinueBTN_LossTempChange_WhenVisible: function(){
                // element(by.css('#ADHOC-analysis-modal > #Continue'))
                browser.sleep(10000);

                // return TestHelperPO.isElementPresent(element(by.css('button#Continue.btn.btn--primary.style-scope.px-modal'))).then(function() {
                // return  element(by.css('#button#Continue.btn.btn--primary.style-scope.px-modal'));
                return  element(by.css('#ADHOC-analysis-modal > section > div > div'));
            },

            // <analysis>.<new adhoc>.<Loss Confirmation><Continue>Q1 code****************************
            getContinueBTN_LossTempChange: function(){
                return TestHelperPO.isElementPresent(element(by.css('#adhoc-analysis-modal>  section> div > div.flex.style-scope.px-modal> button#btnModalPositive.btn.btn--primary.style-scope.px-modal'))).then(function() {
                    return  element(by.css('#adhoc-analysis-modal>  section> div > div.flex.style-scope.px-modal> button#btnModalPositive.btn.btn--primary.style-scope.px-modal'));
                });
            },

            // <analysis>.<new adhoc>.<Loss Confirmation><Cancel>****************************
            getCancelBTN_LossTempChange: function(){
                return TestHelperPO.isElementPresent(element(by.css('#ADHOC-analysis-modal > #Continue'))).then(function() {
                    return  element(by.css('#ADHOC-analysis-modal > #Cancel'))
                });
            },

            // <analysis>.<new adhoc>.<Loss Confirmation><Cancel>****************************
            getTitle_LossTempChange: function(){
                browser.sleep(8000);

                return TestHelperPO.isElementPresent(element(by.css('#ADHOC-analysis-modal > #Continue'))).then(function() {
                    return  element(by.css('#ADHOC-analysis-modal > #ADHOC-analysis-modal-title'))
                });
            },

            getTagSearchToolbox: function(){
                return TestHelperPO.isElementPresent(element(by.css('#tag-toolbox > div > div > div.tag-list-controls-container.style-scope.tag-toolbox > span > i'))).then(function(){
                    return element(by.css('#tag-toolbox > div > div > div.tag-list-controls-container.style-scope.tag-toolbox > span > i'));
                })  // delete option
            },


            getDeleteChartBtn: function(){
                return TestHelperPO.isElementPresent(element(by.id('deleteButton'))).then(function(){
                    return element(by.id('deleteButton'));
                })
            },


            /*
             *****************************************************End of Monira Sultana Properties*******************************************************
             */

            /*
             *****************************************************Devadas's Properties*******************************************************
             */

            getClassTemplateDropdown: function() {
                return TestHelperPO.isElementPresent(element(by.css('#dropDown'))).then(function(){
                                    console.log('Drop down found to be present');
                                    browser.sleep(6000);
                                    return TestHelperPO.isElementVisible( element(by.css('#dropDown #dropcell'))).then(function(){
                                            // return TestHelperPO.elementToBeClickable( element(by.css('#analysis-data-res'))).then(function() {
                                                console.log('Drop cell found to be present');
                                           return element(by.css('#dropDown #dropcell'));
                                            // });
                                            });
                               });
            },

            getDeleteTemplateModal: function(){
                return TestHelperPO.isElementPresent(element(by.class('modal__buttons flex flex--right style-scope px-modal')));
            },

            /*
             *****************************************************End of Devadas's Properties*******************************************************
             */

            /*
             *****************************************************Rao Properties*******************************************************
             */
            getResolutionDropDown: function() {
                return TestHelperPO.isElementPresent(element(by.css('#preferences-selector > div > pae-dropdown > div > div.pae-dropdown-container.pae-dropdown-container-left.style-scope.pae-dropdown > ul.pae-dropdown-menu-list.list-ui.list-ui--tiny.style-scope.pae-dropdown > li'))).then(function(){
                    browser.sleep(6000);
                    return TestHelperPO.isElementVisible( element(by.css('#preferences-selector > div > pae-dropdown > div > div.pae-dropdown-container.pae-dropdown-container-left.style-scope.pae-dropdown > ul.pae-dropdown-menu-list.list-ui.list-ui--tiny.style-scope.pae-dropdown > li'))).then(function(){
                        // return TestHelperPO.elementToBeClickable( element(by.css('#analysis-data-res'))).then(function() {
                            // return element(by.css('#data-resolution-selector'));
                            return element(by.css('#preferences-selector > div > pae-dropdown > div > div.pae-dropdown-container.pae-dropdown-container-left.style-scope.pae-dropdown > ul.pae-dropdown-menu-list.list-ui.list-ui--tiny.style-scope.pae-dropdown > li'));  // Q1 refactor
                        // });
                    });
                });
            },

            getSpineDropDown: function() {
                return TestHelperPO.isElementPresent(element(by.css('#dropDown'))).then(function(){
                    browser.sleep(6000);
                    return TestHelperPO.isElementVisible( element(by.css('#dropDown'))).then(function(){
                        // return TestHelperPO.elementToBeClickable( element(by.css('#analysis-data-res'))).then(function() {
                        return element(by.css('#dropDown'))
                            ;
                        // });
                    });
                });
            },

            /*
             *****************************************************End of Rao Properties*******************************************************
             */
            // Monira Properties*********************************************************************************************
            getUpdateTemplateDropdownOptionClick: function() {
                return TestHelperPO.elementToBeClickable(element(by.css('#submenucontainer > div:nth-child(1) > ul:nth-child(2) > li > span:nth-child(2)')));
            },


            clickAViDAsset_fromContext: function (txt) {
                return TestHelperPO.elementToBeClickable(element.all(by.cssContainingText( 'span.px-context-browser', txt)).get(0));
            },

            getViewMeuOptionPresent: function(txt) {
                return TestHelperPO.isElementPresent(element(by.cssContainingText('#view-menu-new div#menu ul li',txt)));
            },

            getLossTempChange_module: function(){
                // return TestHelperPO.isElementVisible(element(by.css('#ADHOC-analysis-modal> #ADHOC-analysis-modal > section> div > div.flex.style-scope.px-modal> #Continue'))); // Continue button visibility
                browser.sleep(6000); // Updated for Q1 code
                return TestHelperPO.isElementPresent(element(by.css('#adhoc-analysis-modal > section'))); // Continue button visibility
            },

            getInstanceTemplateDropdown: function() {
                return TestHelperPO.isElementPresent(element(by.css.all('#dropDown'))).then(function(){
                    console.log('Drop down found to be present');
                    browser.sleep(6000);
                    return TestHelperPO.isElementVisible( element(by.css('#dropDown #dropcell'))).then(function(){
                        // return TestHelperPO.elementToBeClickable( element(by.css('#analysis-data-res'))).then(function() {
                        console.log('Drop cell found to be present');
                        return element(by.css('#dropDown #dropcell'));
                        // });
                    });
                });
            },

            getTemplatePreferencesDropdown: function() {
                return TestHelperPO.elementToBeClickable(element(by.css("[id^='preferences-selector'] * #tag-menu-kabob")));
            },

            areTimezoneComponentsPresent: function() {
                return TestHelperPO.isElementPresent(element(by.css("[id^='preferences-selector'] * #tag-menu-kabob")))
                && TestHelperPO.isElementPresent(element.all(by.css('#dtEntry')).get(0))
                && TestHelperPO.isElementPresent(element.all(by.css('#dtEntry')).get(6));
            },

            isPreferenceMenuOptionPresent: function(preferenceOption) {
                return TestHelperPO.isElementPresent(element(by.cssContainingText("[id^='preferences-selector'] * span", preferenceOption)));
            },

            getPreferenceMenuOption: function(preferenceOption) {
                var menuOption = element(by.cssContainingText("[id^='preferences-selector'] * span", preferenceOption))
                .element(by.xpath('..'))
                .element(by.xpath('..'));

                return TestHelperPO.elementToBeClickable(menuOption);
            },

            getDateRangeTime: function(selector) {
                var rangeNode = element(by.css('#' + selector));
                var hour =  rangeNode.all(by.css("[id^='time'] * #dtEntry")).get(0).getAttribute('value');
                var minute = rangeNode.all(by.css("[id^='time'] * #dtEntry")).get(1).getAttribute('value');
                var seconds = rangeNode.all(by.css("[id^='time'] * #dtEntry")).get(2).getAttribute('value');
                var meridiem = rangeNode.all(by.css("[id^='time'] * #dtEntry")).get(3).getAttribute('value')
                var timezone = rangeNode.element(by.css("[id^='time'] * #timeZoneText")).getText();
                return protractor.promise.all([hour, minute, seconds, meridiem,timezone]);
            },

            getDateRangeDate: function(selector) {
                var rangeNode = element(by.css('#' + selector));
                var month =  rangeNode.all(by.css("[id^='date'] * #dtEntry")).get(0).getAttribute('value');
                var day = rangeNode.all(by.css("[id^='date'] * #dtEntry")).get(1).getAttribute('value');
                var year = rangeNode.all(by.css("[id^='date'] * #dtEntry")).get(2).getAttribute('value');
                return protractor.promise.all([month, day, year]);
            },

            getLeftNavTab: function (linkText) {
                return TestHelperPO.isElementPresent(element(by.linkText(linkText)));
            },

            getLabel_switchModel: function(){
                return TestHelperPO.getText(element(by.css('#axis-measurement-options-modal > section > div.half-column.label-column.style-scope.chart-header')));  // Label
            },

            getVisibility_switchModel: function(){
                browser.sleep(3000);
                return TestHelperPO.isElementPresent(element(by.css('#axis-measurement-options-modal'))).then(function () {
                    return element(by.css('#axis-measurement-options-modal')); // target refactored
                })
            },
        }


    };

    module.exports = new AnalysisPage();

}())


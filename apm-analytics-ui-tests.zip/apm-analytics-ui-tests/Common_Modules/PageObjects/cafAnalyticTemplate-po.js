(function () {
    'use strict';


    var cafAnalyticTemplatePage = function () {
        var current = {
            
        };
        return {

            visibilityOf: function (elementID) {
                var EC = protractor.ExpectedConditions;
                return browser.wait(EC.visibilityOf(elementID), 30000)
            },

            checkDescriptiontitle: function () {
                return element.all(by.css('div.apm-ax-subsection-header')).get(1).getText();
            },

            // getDescriptionDefaultText: function () {
            //     return element.all(by.css('span.placeholder-data')).get(0).getText();
            // },

            getDescriptionDefaultText: function () {
                return element(by.cssContainingText('tr.apm-ax-subsection-row','Select to add a description')).getText();
            },

            checkSupportingFilestitle: function() {
                return  element(by.cssContainingText('div.apm-ax-subsection-header', "SUPPORTING")).getText();
            },

            getSupportingFiles: function() {
               return element.all(by.xpath('//*[contains(text(), "SUPPORTING")]/../table/tbody/tr'));
            },

            supportingFilesReadOnlyLabel: function() {
                return element(by.css('.is-read-only'));
            },

            getInputDefinitions: function() {
                return element.all(by.xpath('//*[contains(text(), "INPUT DEFINITION")]/../table/tbody/tr'));
            },

            inputDefinitionsReadOnlyLabel: function() {
                return element(by.xpath('//*[contains(text(), "INPUT DEFINITION")]/../table/tbody/tr/td/div/label'));
            },

            getConstants: function() {
                return element.all(by.xpath('//*[contains(text(), "CONSTANTS")]/../table/tbody/tr'));
            },

            constantsReadOnlyLabel: function() {
                return element(by.xpath('//*[contains(text(), "CONSTANTS")]/../table/tbody/tr/td/div/label'));
            },

            getOutputDefinitions: function() {
                return element.all(by.xpath('//*[contains(text(), "OUTPUT DEFINITION")]/../table/tbody/tr'));
            },

            outputDefinitionsReadOnlyLabel: function() {
                return element(by.xpath('//*[contains(text(), "OUTPUT DEFINITION")]/../table/tbody/tr/td/div/label'));
            },

            checkInputDefinitiontitle: function() {
                return  element(by.cssContainingText('div.apm-ax-subsection-header', "INPUT")).getText();
            },

            checkConstanttitle: function() {
                return  element(by.cssContainingText('div.apm-ax-subsection-header', "CONSTANTS")).getText();
            },

            checkOutputDefinitiontitle: function() {
                return  element(by.cssContainingText('div.apm-ax-subsection-header', "OUTPUT DEFINITION")).getText();
            },

            checkOutputEventsTitle: function() {
                return  element(by.cssContainingText('div.apm-ax-subsection-header', "OUTPUT EVENTS")).getText();
            },

            getSupportingFilesDefaultText: function(){
                return element.all(by.css('span.placeholder-data')).get(1).getText();
            },

            isSupportingFilesUploadIconDisplayed: function(){
                return  element(by.css('.fa.fa-upload.define-table-icon')).isDisplayed();
            },

            getInputDefinitionDefaultText: function(el){
                //return el.element(by.css('span.placeholder-data')).getText();
                return el.element(by.xpath('tbody/tr/td/span')).getText();
            },

            isInputDefinitionAddIconDisplayed: function(){
                return TestHelperPO.isElementPresent(element.all(by.id('apm-ax-add-inputs')).get(0));
            },

            isInputDefinitionUploadIconDisplayed: function(){
                return TestHelperPO.isElementPresent(element(by.id('apm-ax-csv-upload-inputs')));
            },

            isConstantsAddIconDisplayed: function(){
                return TestHelperPO.isElementPresent(element(by.id('apm-ax-add-constants')));
            },

            isConstantsUploadIconDisplayed: function(){
                return TestHelperPO.isElementPresent(element(by.id('apm-ax-csv-upload-constants')));;
            },

            getConstantsDefaultText: function(el){
                return el.element(by.xpath('tbody/tr/td/span')).getText();
            },

            isOutputDefinitionAddIconDisplayed: function(){
                return TestHelperPO.isElementPresent(element(by.id('apm-ax-add-outputs')));
            },

            isOutputDefinitionUploadIconDisplayed: function(){
                return TestHelperPO.isElementPresent(element(by.id('apm-ax-csv-upload-outputs')));
            },

            getOutputDefinitionDefaultText: function(el){
                //return el.element(by.css('span.placeholder-data')).getText();
                return el.element(by.xpath('tbody/tr/td/span')).getText();
            },

            isOutputEventsAddIconDisplayed: function(){
                return TestHelperPO.isElementPresent(element(by.id('apm-ax-add-outputEvents')));
            },

            getOutputEventsDefaultText: function(el){
                return el.element(by.xpath('tbody/tr/td/span')).getText();
            },

            analyticMouseOverEditIcon: function() {
                return element(by.id('apm-ax-editAnalyticBtn'));
            },

            analyticEditIcon: function() {
                return element(by.id('apm-ax-editAnalyticBtn')).element(by.xpath('i'));
            },

            enterDescriptionClick: function() {
                return element(by.xpath('//*[@id="react-tabs-1"]/div/div[1]/table/tbody/tr/td[1]/div/label/span[2]')).click();
            },

            descriptionSection: function() {
                                // find DESCRIPTION section
                return element.all(by.css('div.apm-ax-subsection')).filter(function(elem) {
                                        return elem.isElementPresent(by.cssContainingText('div.apm-ax-subsection-header', "DESCRIPTION"));
                                    }).first();
            },

            editDescriptionIcon: function(section) {
                return section.element(by.xpath('table/tbody/tr/td[1]/div/label/span[2]'));
            },
            getDescription: function(){
                return TestHelperPO.getText(element(by.xpath('//*[@id="react-tabs-1"]/div/div[1]/table/tbody/tr/td[1]/div/label/span[1]')));
            },

            enterTemplateDescription: function(section, name) {
                return section.element(by.xpath('table/tbody/tr/td[1]/div/input')).sendKeys(name);
            },

            clickInputDefinitionAddIcon: function(){
                return TestHelperPO.elementToBeClickable(element(by.id('apm-ax-add-inputs'))).then(function(){
                    return browser.sleep(1000);
                });
            },

            getNameInput: function (el) {
                let getInputElementPath= el.element(by.xpath('tbody/tr/td[1]/div/label/span[2]'));
                return getInputElementPath;
            },

            EnterName: function (el,name) {
                let getInputDefName = el.element(by.xpath('tbody/tr/td[1]/div/input')).sendKeys(name);
                return getInputDefName;
            },

            getDescriptionInput: function (el) {
                let getDescriptionPath = el.element(by.xpath('tbody/tr/td[last()-1]/div/label/span[2]'));
                return getDescriptionPath;
            },

            enterDescription: function (el, description) {
                // given table for section, enter text in input field
                return el.element(by.xpath('tbody/tr/td[last()-1]/div/input')).sendKeys(description);
            },

          getOutputEventDescriptionInput: function (el) {
            let getDescriptionPath = el.element(by.xpath('tbody/tr/td[2]/div/label/span[2]'));
            return getDescriptionPath;
          },

          EnterOutputEventDescription: function (el, description) {
            let getDescription = el.element(by.xpath('tbody/tr/td[2]/div/input')).sendKeys(description);
            return getDescription;
          },

            getValueInput: function (el) {
                let getValuePath = el.element(by.xpath('tbody/tr/td[2]/div/label/span[2]'));
                return getValuePath;
            },

            enterValue: function (el, value) {
                let getValue = el.element(by.xpath('tbody/tr/td[2]/div/input')).sendKeys(value);
                return getValue;
            },

            getInputUnits: function(el) {
                return  el.element(by.xpath('tbody/tr/td[2]/label/span'));

            },

            EnterInputDefinitionUnits: function (el,name) {
                let getInDefUnits = el.element(by.xpath('tbody/tr/td[2]/div/input'));
                return getInDefUnits.sendKeys(name).then(function() {
                    el.element(by.xpath('tbody/tr/td[2]//li[@class="unit selected"]')).click();
                });
            },

            mouseOverSupportingFileRecord: function(){
                let deleteBtn = element(by.xpath('//*[contains(text(), "SUPPORTING")]/../table/tbody/tr' +
                                        '/td[@class="action-icons-wrapper"]'));
                return browser.actions().mouseMove(deleteBtn).perform();
            },

            clickSupportingFileDeleteIcon: function(){
                return TestHelperPO.elementToBeClickable(element(by.xpath('//*[contains(text(), "SUPPORTING")]/../table' +
                                        '/tbody/tr/td[@class="action-icons-wrapper"]/span[2]/i')));
            },

            isSupportingFileRecordDeleted: function(){
                return TestHelperPO.isElementNotPresent(element(by.css('.action-icons-wrapper')));
            },

            clickUploadInputIcon:function() {
                return element.all(by.id('apm-ax-csv-upload-inputs')).get(0).click();
            },

          clickUploadConstantIcon:function() {
                console.log("Entered clickUploadConstantIcon function");
              return element.all(by.id('apm-ax-csv-upload-constants')).get(0).click()
            //return element.all(by.css('i.fa.fa-upload.define-table-icon')).get(2).click()
          },

          clickUploadOutputDefIcon: function() {
              return element.all(by.id('apm-ax-csv-upload-outputs')).get(0).click();
          },

            submitUpload: function(){
                return element(by.css('.btn.submit-btn'));
            },

            getSupportingfilesTable : function(){
                let child = element(by.xpath('//*[contains(@id,"supporting")]'));
                return child.element(by.xpath('ancestor::table'));
            },

            clickSubmitUpload : function() {
                return element(by.buttonText('Submit')).click();
            },

            analyticTemplate: function(){
                return element(by.id('react-tabs-0'));
            },
            getDataFormatColumnText : function(){
                let tableColumn = element(by.css('.table-container.contains-data table tbody tr td:nth-child(5)'));
                return tableColumn;
            },
           
            uploadCSVFile : function(file) {
                var filepath = './../TestData/' + file;
                var path = require('path');
                var absolutePath = path.resolve(__dirname, filepath);
                console.log("absolute path",absolutePath)
                var input = element(by.id('fileUpload_btn'));
                return input.sendKeys(absolutePath);
            },

            elementToBeClickable: function(elementID){
                var EC = protractor.ExpectedConditions;
                return browser.wait(EC.elementToBeClickable(elementID), 5000)
            },

            clickInputDefinitionDataTypeDropdown: function(){
                return TestHelperPO.elementToBeClickable(element(by.xpath('//*[@id="react-tabs-1"]/div/div[3]/table/tbody/tr/td[3]/select"]')));
            },

            selectDropdownbyIndex : function (element, optionNum ) {
                if (optionNum){
                    var options = element.all(by.tagName('option'))
                        .then(function(options){
                            options[optionNum].click();
                        });
                }
            },

            clickInputDefinitionDataTypeDropdownOption: function(option) {
                return selectDropdownbyNum (element,option);
            },

            getDropdownElement: function (el){
               let dropDown = el.element(by.xpath('tbody/tr/td[3]/select'));
               return dropDown;
            },

            getInputDefinitionTable : function(){
                let child = element(by.xpath('//*[contains(@id,"input")]'));
                return child.element(by.xpath('ancestor::table'));
            },

            getInputDefinitionTableHeaders : function(table){
                return table.all(by.css('th.table-header')).map(function(column) {
                    return column.getText();
                    });
                },

            getInputDefinitionDescription: function(){
                return TestHelperPO.getText(element(by.css('#inputsTable [index-id="description"] label')));
            },

            getInputDefinitionDescriptionEditIcon: function(el){
                let inputDefinitionDescriptionEditIconPath = el.element(by.xpath('tbody/tr/td[5]/div/label/span[2]/i'));
                return inputDefinitionDescriptionEditIconPath;
                //return inputDefinitionDescriptionElement.click();
            },

            EnterInputDefinitionDescription: function(el,name){
                let inputDefDescription = el.element(by.xpath('tbody/tr/td[5]/div/input'));
                return inputDefDescription.sendKeys(name);
            },

            clickInputDefinitionRequiredCheckbox: function(){
                return element(by.id('apm-ax-isRequired-inputs-0')).click();
            },

            clickConstantRequiredCheckbox: function(){
                return element(by.id('apm-ax-isRequired-constants-0')).click();
            },

            getInputDefinitionDataTypeDropdownSelectedOption: function() {
                return TestHelperPO.getText(element(by.css('#inputsTable select[index-id="dataType"]')).$('option:checked'));
            },

            isInputDefinitionRequiredCheckboxChecked: function(){
                return element(by.css('#inputsTable [type="checkbox"]')).isSelected();
            },

            mouseOverRecord: function(el){
                let mouseOverInput = el.element(by.xpath('tbody/tr/td[@class="action-icons-wrapper"]'));
                return browser.actions().mouseMove(mouseOverInput).perform();
            },

            clickRecordDeleteIcon: function(el){
                return TestHelperPO.elementToBeClickable(el.element(by.xpath('tbody/tr/td[@class="action-icons-wrapper"]' + '/span/i')));
            },

            clickConstantsAddIcon: function(){
                return TestHelperPO.elementToBeClickable(element(by.id('apm-ax-add-constants'))).then(function(){
                    return browser.sleep(1000);
                });
            },

            getConstantsTable : function(){
                let child = element(by.xpath('//*[contains(@id,"constants")]'));
                return child.element(by.xpath('ancestor::table'));
            },

            getConstantsElement: function (el) {
                let getConstantsPath= el.element(by.xpath('tbody/tr/td[1]/div/label/span[1]'));
                return getConstantsPath;
            },

            EnterConstantsName: function (el,name) {
                let getConstantName = el.element(by.xpath('tbody/tr/td[1]/div/input')).sendKeys(name);
                return getConstantName;
            },

            getConstantsValue: function(el) {
                return  el.element(by.xpath('tbody/tr/td[2]/div/label/span'));

            },

            isTemplateHeaderCreateAnalyticIconDisplayed: function(){
                return TestHelperPO.isElementPresent(element.all(by.css('.fa-plus')).get(0));
            },
            iscreateorcbuttonNotDisplayed: function() {
                return element(by.css('.fa-plus')).isPresent()
            },

            isSupportingFilesUploadIconNotDisplayed: function(){
                return  element(by.css('.fa.fa-upload.define-table-icon')).isPresent();
            },

            isInputDefinitionAddIconNotDisplayed: function(){
                return  element(by.id('apm-ax-add-inputs')).isPresent();
            },
            isInputDefinitionUploadIconNotDisplayed: function(){
                return  element(by.id('apm-ax-csv-upload-inputs')).isPresent();
            },
            isConstantsAddIconNotDisplayed: function(){
                return  element(by.id('apm-ax-add-constants')).isPresent();
            },

            isConstantsUploadIconNotDisplayed: function(){
                return  element(by.id('apm-ax-csv-upload-constants')).isPresent();
            },
            isOutputDefinitionAddIconNotDisplayed: function(){
                return  element(by.id('apm-ax-add-outputs')).isPresent();
            },
            isOutputDefinitionUploadIconNotDisplayed: function(){
                return  element(by.id('apm-ax-csv-upload-outputs')).isPresent();
            },
            isOutputEventsAddIconNotDisplayed: function(){
                return  element(by.id('apm-ax-add-outputEvents')).isPresent();
            },

            EnterConstantsValue: function (el,name) {
                let getConstantUnits = el.element(by.xpath('tbody/tr/td[2]/div/input'));
                getConstantUnits.sendKeys(name);
            },

            getConstantsUnits: function(el) {
                return  el.element(by.xpath('tbody/tr/td[3]/label/span'));
            },

            EnterConstantsUnits: function (el,name) {
                let getConstantUnits = el.element(by.xpath('tbody/tr/td[3]/div/input'));
                return getConstantUnits.sendKeys(name).then(function() {
                    el.element(by.xpath('tbody/tr/td[3]//li[@class="unit selected"]')).click();
                    });
            },

            getDropdownElementConstant: function (el){
                let dropDown = el.element(by.xpath('tbody/tr/td[4]/select'));
                return dropDown;
            },

            clickConstantsDescriptionEditIcon: function(el){
                let constantDescriptionElement = el.element(by.xpath('tbody/tr/td[5]/div/label/span[1]'));
                return constantDescriptionElement.click();
            },

            EnterConstantsDescription: function(el,name){
                let constantDescription = el.element(by.xpath('tbody/tr/td[5]/div/input'));
                return constantDescription.sendKeys(name);
            },

            clickOutputDefinitionAddIcon: function(){
                return TestHelperPO.elementToBeClickable(element(by.id('apm-ax-add-outputs'))).then(function(){
                    return browser.sleep(1000);
                });
            },

            getOutputDefinitionTable : function(){
                let child = element(by.xpath('//*[contains(@id,"output")]'));
                return child.element(by.xpath('ancestor::table'));
            },

            getOutputDefinitionElement: function (el) {
                let getOutputDefinitionPath= el.element(by.xpath('tbody/tr/td[1]/div/label/span[1]'));
                return getOutputDefinitionPath;
            },

            EnterOutputDefinitionName: function (el,name) {
                let getOutputDefinitionName = el.element(by.xpath('tbody/tr/td[1]/div/input')).sendKeys(name);
                return getOutputDefinitionName;
            },

            getOutputDefinitionUnits: function(el) {
                return  el.element(by.xpath('tbody/tr/td[2]/label/span'));
            },

            EnterOutputDefinitionUnits: function (el,name) {
                let getOutputDefinitionUnits = el.element(by.xpath('tbody/tr/td[2]/div/input'));
                return getOutputDefinitionUnits.sendKeys(name).then(function() {
                    el.element(by.xpath('tbody/tr/td[2]//li[@class="unit selected"]')).click();
                    });
            },

            getDropdownElementOutputDefinition: function (el){
                let dropDown = el.element(by.xpath('tbody/tr/td[3]/select'));
                return dropDown;
            },

            clickOutputDefinitionDescriptionEditIcon: function(el){
                let OutputDefinitionDescriptionElement = el.element(by.xpath('tbody/tr/td[5]/div/label'));
                return OutputDefinitionDescriptionElement.click();
            },

            EnterOutputDefinitionDescription: function(el,name){
                let OutputDefinitionDescription = el.element(by.xpath('tbody/tr/td[5]/div/input'));
                return OutputDefinitionDescription.sendKeys(name);
            },

            clickOutputEventsAddIcon: function(){
                return TestHelperPO.elementToBeClickable(element(by.id('apm-ax-add-outputEvents'))).then(function(){
                    return browser.sleep(1000);
                });
            },

            getOutputEventsTable : function(){
                let child = element(by.xpath('//*[contains(@id,"events")]'));
                return child.element(by.xpath('ancestor::table'));
            },

            getOutputEventsElement: function (el) {
                let getOutputDefinitionPath= el.element(by.xpath('tbody/tr/td[1]/label/span'));
                return getOutputDefinitionPath;
            },

            EnterOutputEventsName: function (el,name) {
                let getOutputDefinitionName = el.element(by.xpath('tbody/tr/td[1]/div/input')).sendKeys(name).then(function() {
                    el.element(by.xpath('tbody/tr/td[1]//li[@class="unit selected"]')).click();
                    });
                return getOutputDefinitionName;
            },

            clickOutputEventsDescriptionEditIcon: function(el){
                let OutputDefinitionDescriptionElement = el.element(by.xpath('tbody/tr/td[2]/div/label'));
                return OutputDefinitionDescriptionElement.click();
            },

            EnterOutputEventsDescription: function(el,name){
                let OutputDefinitionDescription = el.element(by.xpath('tbody/tr/td[2]/div/input'));
                return OutputDefinitionDescription.sendKeys(name);
            },

            isOutputEventAddIconNotDisplayed: function(){
                return TestHelperPO.isElementNotPresent(element(by.id('apm-ax-add-outputEvents')));

            },

            mouseOverOutputEventsRecord: function(el){
                let mouseOverInput = el.element(by.xpath('tbody/tr/td[3]'));
                return browser.actions().mouseMove(mouseOverInput).perform();
            },

            clickOutputEventsDeleteIcon: function(el){
                return TestHelperPO.elementToBeClickable(el.element(by.xpath('tbody/tr/td[3]/span/i')));
            },

            clickSaveButton: function() {
                let saveele =  element(by.css('.confirmation-buttons'));
                //return saveele.element(by.css('.apm-btn apm-btn-blue')).click();
                return saveele.element(by.buttonText('Save')).click();
            },

            clickSaveButtonInModal: function() {
                let saveeleconf =  element(by.css('.modal-bottom-group'));
                return element(by.buttonText('Submit')).click();
            },

            clickSubmitButtonInModal: function() {
                let saveeleconf =  element(by.css('.modal-bottom-group'));
                return element(by.buttonText('Submit')).click();
            },

            searchResults: function() {
              return element(by.css('.suggestions-list.suggestions-list-outputEvents'));
            },

            clickTypeaheadResult: function(el) {
              return TestHelperPO.elementToBeClickable(el.element(by.xpath('ul/li[1]')));
            },

            clickSupportingFileDownloadIcon: function() {
                return TestHelperPO.elementToBeClickable(element(by.css('.fa-download')));
            },

            clickIngestButton: function() {
              // return TestHelperPO.elementToBeClickable(element(by.css('i.fa.fa-upload')));
              return TestHelperPO.elementToBeClickable(element(by.id('create_analytic_by_ingestion')));
            },

            SupportingFileRow: function() {
                return element.all(by.css('.apm-ax-text-input-box')).get(2);
            },
            selectMakeCurrent: function() {
                return element(by.css('#apm-ax-btn-artifact-select-btn')).click();
            },
            templateVersionsDropdown: function() {
                return element(by.css('#versions-dropdown'));
            },


            isOutputEventsRowsExist: function(){
                return element(by.xpath('//*[@id="react-tabs-1"]/div/div[7]/table/tbody/tr[2]')).isPresent();
            },

            getUploadModal: function() {
                return element(by.xpath('//div[@class="apm-ax-csv-upload-modal"]'));
                },

            clickDownloadTemplateButtonInModal: function () {
                let modal = element(by.xpath('//div[@class="apm-ax-csv-upload-modal"]'));
                return modal.element(by.css('button.download-btn')).click();
                },

            clickCancelButtonInModal: function () {
                let modal = element(by.xpath('//div[@class="apm-ax-csv-upload-modal"]'));
                return modal.element(by.css('button.cancel-btn')).click();
                },


            deploymentRowVersion: function () {
                return element.all(by.css('.apm-deployments-row .updates')).get(1)
            }

        };
    };

    module.exports = new cafAnalyticTemplatePage();

}());
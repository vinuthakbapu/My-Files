/********************************************************************************
 * Copyright (c) 2015-2016 GE Digital. All rights reserved.                     *
 *                                                                              *
 * The copyright to the computer software herein is the property of GE Digital. *
 * The software may be used and/or copied only with the written permission of   *
 * GE Digital or in accordance with the terms and conditions stipulated in the  *
 * agreement/contract under which the software has been supplied.               *
 ********************************************************************************/

/**
 * Class encapsulating all functions in main landing page
 */
(function () {
    'use strict';


    var TIMEOUT = 5000;


    var orchDeployPage = function () {


        var months = new Array(12);
        months[0] = "Jan";
        months[1] = "Feb";
        months[2] = "Mar";
        months[3] = "Apr";
        months[4] = "May";
        months[5] = "Jun";
        months[6] = "Jul";
        months[7] = "Aug";
        months[8] = "Sept";
        months[9] = "Oct";
        months[10] = "Nov";
        months[11] = "Dec";

        
        var today = new Date();

        var dd = (today.getDate() < 10 ? '0' : '') + today.getDate();
        var mm = today.getMonth();
        //var dd = today.getDate();
        //var mm = today.getMonth()+1; //January is 0!
        var yyyy = today.getFullYear();

        today= months[mm] + " " + dd + ", " + yyyy;
        
        return {
            
            todayDate:function(){
                return today;
            },


            firstOrch : function (){
                return element.all(by.css('.orchestration-item-name'));
            },

            

            deployConfiguration : function (){
                return element(by.css('li[aria-selected="false"][aria-disabled="false"]'));
                //return element(by.xpath("/html/body/section/section/section/div/div/div[3]/div/div[2]/ul/li[1]"));
            },

            
            /*orchestrationTab : function (){
                return element(by.xpath("/html/body/section/section/section/div/div/div[3]/div/div[2]/ul/li[0]"));
                //return element(by.linkText("Deployment Configuration"));
            },*/


           /* createDeployButton : function (){
            return element(by.id("btnCreateDeploy"));
            },*/

            deployHeaders: function(){
                return element.all(by.css(".colHeader"));
            },

            emptyText: function(){
            return element(by.css(".instructions"));
            },

            onlyOnceRadio: function(){
                return element(by.id("onlyOnceRadio"));
            },

            recurrentRadio: function(){
                return element(by.id("recurrentRadio"));
            },

            fromFields: function(){
               // return element(by.id("fromFields"));
                return element(by.css("#fromDate .text-input--bare"));
            },

            toFields: function(){
                //return element(by.id("toFields"));
                return element(by.css("#toDate .text-input--bare"));
            },



            fromFieldsInputDate: function(){
                //#fromDate .text-input--bare
                 return element(by.css("#fromFields #fromDate input"));

            },

            fromFieldsInputTime: function(){
                return element(by.css("#fromFields #fromTime input"));
            },

            toFieldsInputDate: function(){
                return element(by.css("#toFields #toDate input"));
            },

            toFieldsInputTime: function(){
                return element(by.css("#toFields #toTime input"));
            },

            icon:function(){
                return element(by.css("#fromDate #icon"));
            },

            deployBtn: function(){
                return element(by.id("io-publish-btn"));
            },

            closeBtn: function(){
                return element(by.id("io-close-btn"));
            },

           //Recurrent:

            repeatEveryText: function(){
                return element(by.css("input[name='repeatData.timeValue']"));
            },

            repeatEveryDropdown: function(){
                return element(by.css("select[name='repeatData.timeUnit']"));
            },


            labelOffset: function(){
                return element(by.css("label[for='startOffset.timeValue']"));
            },
            offsetInput: function(){
                return element(by.css("input[name='startOffset.timeValue']"));
            },
            offsetDD: function(){
                return element(by.css("select[name='startOffset.timeUnit']"));
            },


            labelSampleDuration: function(){
                return element(by.css("label[for='sampleDuration.timeValue']"));
            },
            sampleDurationInput: function(){
                return element(by.css("input[name='samplingDuration.timeValue']"));
            },
            sampleDurationDD: function(){
                return element(by.css("select[name='samplingDuration.timeUnit']"));
            },



            labelSampleInterval: function(){
                return element(by.css("label[for='samplingInterval.timeValue']"));
            },
            sampleIntervalInput: function(){
                return element(by.css("input[name='samplingInterval.timeValue']"));
            },
            sampleIntervalDD: function(){
                return element(by.css("select[name='samplingInterval.timeUnit']"));
            },




            //Calendar box:

            dateRangeBox: function(){
                return element(by.id("dateRangePicker"));
            },

            fromTimeText: function(){
                return element(by.css("#fromTime #timeInput"));
            },

            toTimeText: function(){
                return element(by.css("#toTime #timeInput"));
            },

            applyButton: function(){
                return element(by.id("submitButton"));
            },

            deploySpinner:function(){
                return element(by.css(".phx-spinner"));
            },

            alertBox: function(){
                return element(by.css(".alert-box"));
            },


            //Deploy Table

            deployTable: function(){
                return element(by.css(".body"));
            },






            // TOAST Message

            dirtyAlertBox: function() {
                return element(by.id("alert"));
            },

            toastMessage: function(){
                return element(by.id("message"));
            },

            dirtyWarningButton: function(){
                return element(by.css(".dirty-warning.btn"));
            },

            dirtyWarningText: function(){
                return element(by.css("span.dirty-message"));
            },


            


        };
    };

    module.exports = new orchDeployPage();

}());



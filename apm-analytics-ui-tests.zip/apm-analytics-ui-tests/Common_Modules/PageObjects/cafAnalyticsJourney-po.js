/**
 * Class encapsulating all functions the analytics journey page
 */
(function () {
    'use strict';


    const cafAnalyticsJourneyPage = function () {

        var months = new Array(12);
        months[0] = "Jan";
        months[1] = "Feb";
        months[2] = "Mar";
        months[3] = "Apr";
        months[4] = "May";
        months[5] = "Jun";
        months[6] = "Jul";
        months[7] = "Aug";
        months[8] = "Sept";
        months[9] = "Oct";
        months[10] = "Nov";
        months[11] = "Dec";

        var monthsInNumbers = new Array(12);
        monthsInNumbers[0] = "01";
        monthsInNumbers[1] = "02";
        monthsInNumbers[2] = "03";
        monthsInNumbers[3] = "04";
        monthsInNumbers[4] = "05";
        monthsInNumbers[5] = "06";
        monthsInNumbers[6] = "07";
        monthsInNumbers[7] = "08";
        monthsInNumbers[8] = "09";
        monthsInNumbers[9] = "10";
        monthsInNumbers[10] = "11";
        monthsInNumbers[11] = "12";


        var today = new Date();

        var dd = (today.getDate() < 10 ? '0' : '') + today.getDate();
        var mm = today.getMonth();
        var year = today.getFullYear();
        //var dd = today.getDate();
        //var mm = today.getMonth()+1; //January is 0!

        today = months[mm] + " " + dd;

        var todayFormat = monthsInNumbers[mm] + "/" + dd + "/" + year;

        var OneMonthBack = new Date();
        mm = OneMonthBack.getMonth() - 1; //January is 0!
        OneMonthBack = monthsInNumbers[mm] + "/" + dd + "/" + year;
        //03/04/2018

        var oneYearBack = monthsInNumbers[mm] + "/" + dd + "/" + '2017';
        return {

            assetFilter: function () {
                return element(by.xpath('//*[@id="filter-dropdown"]'));
            },

            assetFilterValue: function () {
                return element(by.cssContainingText('option', 'GE90'));
            },

            assetSearch: function () {
                return element(by.id('btnSearchAttributes'));
            },

            assetsDisplayed: function () {
                return element(by.css('[table-data="assetFromFilters"]')).isPresent();
            },

            assetGoNext: function () {
                return element(by.id('nextStepBtn'));
            },

            addTagsToInputDefinition: function () {
                return element(by.css('div.one-line-box > div.apm-dp-dropdown .wrapper'));
            },

            selectAddTagsOption: function () {
                return element(by.css('div.apm-dp-dropdown > div > div > a:nth-child(2)'));
            },

            selectInputDefinitionFirstRow: function () {
                return element(by.css('#apm-dp-input-row-0'));
            },

            selectInputDefinitionSecondRow: function () {
                return element(by.css('#apm-dp-input-row-1'));
            },


            selectFirstTagSearchResult: function () {
                return element(by.css('div.assetTagList > div:nth-child(1) > i'));
            },

            verifyIOMappingPage: function () {
                return TestHelperPO.isElementPresent(element(by.css('.apm-dp-ioMappingContainer')));
            },

            mapPerAllAssetInput: function () {
                return element(by.id('apm-dp-iomap-mapByAsset'));
            },


            assetTagSearchInput: function () {
                return element(by.id('assetTag-search'));
            },

            customattributeSearchInput: function () {
                return element(by.id('assetAttribute-search'));
            },

            assetTagSearchItem: function () {
                return element(by.xpath('//*[@id="tabs-views"]/ul/li'));
            },

            assetTagSearchItemPromise: function () {
                //return element(by.xpath('//*[@id="tabs-views"]/ul/li'));
                var deferred = protractor.promise.defer();
                protractor.promise.controlFlow().execute(function () {
                    deferred.fulfill(element(by.xpath('//*[@id="tabs-views"]/ul/li')))
                });
                return deferred
            },

            inputTagName: function () {
                return element.all(by.css('.assetTagBox .tag-name')).get(0);
            },

            assetRowToDrop: function () {
                return element(by.css('table#input tbody tr:nth-child(1)'));
            },

            inputDefinitionTarget: function () {
                // return element(by.xpath('//*[@id="asset-applicability"]/div/div[2]/div[4]/div/div/div[1]/table[1]/tbody/tr[2]'));
                return element(by.css('[table-data="inputs"] table tr:nth-child(2)'));
            },

            inputDefinitionTargetPromise: function () {
                // return element(by.xpath('//*[@id="asset-applicability"]/div/div[2]/div[4]/div/div/div[1]/table[1]/tbody/tr[2]'));
                //return element(by.css('[table-data="inputs"] table tr:nth-child(2)'));
                var deferred = protractor.promise.defer();
                protractor.promise.controlFlow().execute(function () {
                    deferred.fulfill(element(by.css('[table-data="inputs"] table tr:nth-child(2)')))
                });
                return deferred
            },

            inputTagIconClickToAdd: function () {
                return element(by.css('.fa-tags#apm-dp-iomap-tagslist-dropdown'))
            },

            inputDefinitionMapped: function () {
                return element(by.css('.ioMappingTable #apm-dp-input-row-0 .mapping-cell'));
            },

            inputDefinition: function(inputNo) {
                return element(by.css('.ioMappingTable #apm-dp-input-row-'+inputNo+'>td:nth-of-type(5) span'));
            },

            firstOutputDefinitionMapped: function () {
                return element.all(by.css('.ioMappingTable tr.output .mapping-cell')).get(0);
            },

            secondOutputDefinitionMapped: function () {
                return element.all(by.css('.ioMappingTable tr.output .mapping-cell')).get(3);
            },

            assetIOMappingGoNext: function () {
                return element(by.id('nextStepBtn'));
            },

            verifySchedulePage: function () {
                return element(by.xpath('//*[@id="deploymentSchedule"]/p/span[1]'));
            },

            scheduleFromCalendarIcon: function () {
                return element(by.css('#fromFields #icon'));
            },

            scheduleCalendarStartDay: function () {
                return element(by.css('.calendar-cell.is-start'));
            },

            scheduleCalendarStartDayInputBox: function () {
                return element(by.css('#fromDate input'));
            },

            scheduleCalendarEndDayInputBox: function () {
                return element(by.css('#toDate input'));
            },

            scheduleCalendarEndDay: function () {
                return element(by.css('.calendar-cell.is-end'));
            },

            scheduleCalendarStartTime: function () {
                return element(by.xpath('//*[@id="fromTime"]/div/input'));
            },

            scheduleCalendarEndTime: function () {
                return element(by.xpath('//*[@id="toTime"]/div/input'));
            },

            scheduleCalendarSelectionApply: function () {
                return element(by.id('submitButton'));
            },

            schedulePageGoNext: function () {
                return element(by.id('nextStepBtn'));
            },

            addPriority: function () {
                return element(by.css('.apm-dp-order-input'));
            },

            priorityMessage: function () {
                return element(by.css('.apm-invalid-field-msg.is-visible'));
            },

            schedulePage: function () {
                return element(by.css('.apm-dp-runonce-container'));
            },

            verifyReviewPage: function () {
                return element(by.css('.apm-dp-review-container')).isPresent();
            },

            closesAnalyticDeployment: function () {
                return TestHelperPO.elementToBeClickable(element(by.id('apm-dp-config-close-button')));
            },
            clickSmartSignalMaintanceLink: function () {
                return TestHelperPO.elementToBeClickable(element(by.xpath('//*[@id="apm-dp-redirectBtn"]')));
            },
            getSmartSignalMaintnanceLink: function () {
                // return element(by.xpath('//*[@id="apm-dp-redirectBtn"]'));
                return element(by.css('#apm-dp-redirectBtn'));
            },
            getSmartSignalMaintnanceLinkUrl: function () {
                // return element(by.xpath('//*[@id="apm-dp-redirectBtn"]'));
                // var element =  element(by.css('#apm-dp-redirectBtn'));
                var element = browser.driver.findElement(By.css('#apm-dp-redirectBtn'));
                return element.getAttribute('href');
            },


            deleteAnalyticBtn: function () {
                return element(by.css('[ng-click=\'deleteAnalyticModal()\']')).click();
            },

            deleteAnalyticBtnConfirm: function () {
                return element(by.id('apm-ax-deleteModalBtn')).click();
            },

            deployAnalyticDeployment: function () {
                return element(by.id('apm-dp-config-deploy-button'));
            },

            alertMessage: function () {
                return element(by.css('px-alert-message'));
            },

            DeploymentRecord: function () {
                return element(by.css('.apm-dp-detail-panel'));
            },

            alertLinks: function () {
                return element(by.linkText("Alerts")).click();
            },

            unclaimedAlerts: function () {
                return element(by.linkText("Unclaimed")).click();
            },

            verifyAlertsPage: function () {
                return element(by.xpath('//*[@id="container"]/div/div[1]'));
            },

            inputDefRow: function () {
                return element(by.css('tr#apm-dp-input-row-0'));
            },

            addTagsOption: function () {
                return element(by.cssContainingText('.item', 'Add tags...'));
            },

            firstTagResult: function () {
                return element.all(by.css('.assetTagBox .fa.fa-plus')).get(0);
            },

            xTagResult: function (x) {
                console.log("index " + x);
                return element.all(by.css('.assetTagBox .fa.fa-plus')).get(x);
            },

            secondTagIcon: function () {
                return element(by.css('.apm-ax-list-selector-icons .fa.fa-tags'));
            },

            assetTagSearchClear: function () {
                return element(by.id('clearedSearch'));
            },

            deploymentStatus: function () {
                return element(by.css('.selected-item-in-list .apm-dp-deployment-item-status'));
            },

            runOnceFileIcon: function () {
                return element(by.css('.apm-dp-detail-infoheader-download.header-icons button'));
            },

            newDownloadsTab: function () {
                let url = 'chrome://downloads';
                return browser.executeScript("return window.open(arguments[0], '_blank')", url);
            },

            latestAlertTitle: function () {
                return element(by.css(".unpadded-column .alarm-list-group-item .alarm-list-name-block h4"));// .alarm-list-group-item.ng-scope#:0"));// .alarm-list-name-block h4"));
            },

            latestAlertDate: function () {
                return element(by.css(".unpadded-column .alarm-list-group-item .alarm-list-time-block h4"));
            },

            latestAlertDetailDate: function () {
                return element(by.css(".alert-received-time"));
            },

            clickAlertTemplatesTab: function () {
                return element(by.linkText('Alert Templates'));
            },

            clickPlusIconInAlertTemplates: function () {
                return element(by.css('.add-profile-icon.fa.fa-plus'));
            },

            AlertTemplateNameField: function (name) {
                return element(by.id('profileNameField'));
            },

            clickSaveButttonInAlertTemplates: function () {
                return element(by.id('profile-save'));
            },

            alertTemplateCreationSuccessMessage: function () {
                return element(by.css('.alert.alert-fixed-top.ng-isolate-scope.alert-success'));
            },

            failureExclamationIcon: function () {
                return element(by.css('.fa.fa-exclamation-circle.warning-sub-icon.failed-dep')).isPresent();
            },

            getAnalyticAutomationAlerts: function (alertTemplateName) {
                return element.all(by.css('h4[title="' + alertTemplateName + '"]'));
            },

            todayDate: function () {
                return today;
            },

            todayDateFormat: function () {
                return todayFormat;
            },

            OneMonthBackDate: function () {
                return OneMonthBack;
            },

            OneYearBackDate: function () {
                return oneYearBack;
            },
            
            getTemplateTableSearchBar: function () {
                return element(by.css('#list-search-box'));
            },
        }
    };
    module.exports = new cafAnalyticsJourneyPage();
})();

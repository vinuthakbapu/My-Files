
(function () {
    'use strict';

    var TIMEOUT = 5000;

    const ElementManager = require('proui-utils').ElementManager;
    const pem = new ElementManager('../../../Test_Modules/Analytics/caf-preferences-element-repo.json');

    var preferencesPage = function () {

        return {

            addAttribute: function(attributeType, attributeName) {
                return pem.findElement('preferencesPage',`${attributeType}AddNewLink`).click().then(function() {
                    pem.findElement('preferencesPage',`${attributeType}AddNewTextbox`).clear().sendKeys(`${attributeName}${protractor.Key.ENTER}`).then(() =>{
                        const until = protractor.ExpectedConditions;
                        browser.wait(until.presenceOf(element(by.className('loading'))), 5000, 'loading never occured');
                    });
                })
            },

            editDefaultAttribute: function(attributeType, attributeName, appendEditValue) {
                let editedValue = attributeName + '_' + appendEditValue;
                return element(by.id(`${attributeType}_${attributeName}`)).click().then(() => {
                    element(by.id(`${attributeType}_${attributeName}`)).clear().sendKeys(`${protractor.Key.chord(protractor.Key.CONTROL, 'a')}${editedValue}${protractor.Key.ENTER}`).then(() =>{
                        const until = protractor.ExpectedConditions;
                        browser.wait(until.presenceOf(element(by.className('loading'))), 5000, 'loading never occured');
                    });
                })
            },

            isAttributePresent: function(attributeType, attributeName) {
                return element(by.id(`${attributeType}_${attributeName}`)).isPresent();

            },

            newAttributeButton: function(attributeType) {
                return element(by.id(`${attributeType}`));

            },
            
            verifyPreferencesTab: function () {
                return element(by.css("a[href$='/#/assetFiltersConfig']")).click();
            },

            deleteTestAttribute: function(attributeType, attributeName, appendEditValue) {
                let attributeValue = attributeType + '_' + attributeName ;
                if (appendEditValue != null){
                    attributeValue = attributeValue + '_' + appendEditValue ;
                }
                return element(by.id(attributeValue)).click().then(() => {
                    return element(by.id(attributeValue + '_' + 'delete')).click();
                })
            },

            addSameAttribute: function(attributeType, attributeName) {
                return pem.findElement('preferencesPage',`${attributeType}AddNewLink`).click().then(function() {
                    pem.findElement('preferencesPage',`${attributeType}AddNewTextbox`).sendKeys(`${attributeName}${protractor.Key.ENTER}`)

                })
            },

            errorMessage:function() {
                return element(by.css('div.apm-attr-invalidAlertShow')).getText();
            },

            errorPopUp : function() {
                return element(by.id("alert")).getText();
            }
        };
    };

    module.exports = new preferencesPage();
}());


# ProUI

## Installation Instructions
           
1) 	Should have Github account

2) 	Send your SSO to '@Research Automation Team' to provide an access to the repo

3) 	Open new terminal and clone repo from GitHub to the local system
```
git clone git@github.build.ge.com:APM/apm-analytics-ui-tests.git
```

4)	 Open IDE (WebStorm) and select File-> Open and navigate to cloned Project

5) Run the commands below to install all the required dependencies:
```
	npm install -g grunt --proxy=http://proxy-src.research.ge.com:8080
	npm config set strict-ssl false   
	npm install --only=dev --proxy=http://proxy-src.research.ge.com:8080
```

6) Cd in your project directory.

7)	In order to run the default test built with this framework run:
```
	grunt
```

8)	Run your test without suite name:
```
	grunt noSuite --conf= <path of conf file>
```
 
9)	Run your test with a specific suite:
```
	grunt test --conf= <path of conf file> --suite= <name of suite>
``` 
 or to use specific tenant we can use the below command to specifiy the url and the related credentials
 ```
	grunt --suite= <name of suite> --baseUrl=<url> --mgrusername=<username credential> --mgrpassword=<password credentials>
``` 

## Key Things to Note:
Cucumber is no longer included by default as of version 3.0. You can integrate Cucumber with Protractor with the custom framework option. 


Change framework from “cucumber” to “custom” and add the new framework path


Documentation: https://devcloud.swcoe.ge.com/devspace/display/KKQTL/ProUI

### Also note
There are a few configuration variables that must change in order to use the microapp running on localhost, rather than the deployed version.

Firstly, uncomment line 55 to set `noProx: 'localhost'`

Then, comment out lines 211-213 containing the following:

```
      baseUrl: 'https://stuf-rc.run.asv-pr.ice.predix.io/analyticsqe3',
      mgrusername: 'analyticsqe3-smokeuser',
      mgrpassword: 'Pa55w0rd',
```

Finally, uncomment the next three lines containing the following:

```
      baseUrl: 'http://localhost:3000',
      "mgrusername": "analytics-admin",
      "mgrpassword": "analyt1cs",
```

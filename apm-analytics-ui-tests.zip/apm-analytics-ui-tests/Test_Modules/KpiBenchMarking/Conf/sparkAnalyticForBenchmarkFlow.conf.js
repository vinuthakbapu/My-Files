exports.config = {

    // ---- While testing locally
    sauceUser: null,
    sauceKey: null,
    sauceSeleniumAddress: null,

    directConnect: false,
    firefoxPath: null,

    // ---------------------------------------------------------------------------
    // ----- What tests to run ---------------------------------------------------
    // ---------------------------------------------------------------------------

    // Spec patterns are relative to the location of this config.
    specs: [],

    // Patterns to exclude.
    exclude: [],

    // Organize spec files into suites. To run specific suite, --suite=<name of suite>
    suites: {
        // login: ['../Features/apmLogin.feature'],

        CafSparkBenchMarkingAnalyticFlow: ['../Features/CafSparkKPIBenchmarkingAnalyticFlow.feature']



    },

    // Hooks running in the background
    plugins: [{
        path: '../../../node_modules/proui-utils/Compressed_Utils/GeneralHook.js',

    }],

    capabilities: {

        browserName: 'chrome',
        proxy: {
            // proxyType: 'manual',
            // httpProxy: 'sjc1intproxy01.crd.ge.com:8080',
            // sslProxy: 'sjc1intproxy01.crd.ge.com:8080',
            // proxyType: 'manual',
            // httpProxy: 'proxy-src.research.ge.com:8080',
            // sslProxy: 'proxy-src.research.ge.com:8080',
            proxyType: 'manual',
            httpProxy: 'grc-americas-sanra-pitc-wkcz.proxy.corporate.gtm.ge.com:80',
            sslProxy: 'grc-americas-sanra-pitc-wkcz.proxy.corporate.gtm.ge.com:80',

},
        count: 1,
        shardTestFiles: false,
        maxInstances: 1,
        'chromeOptions': {
            args: ['--no-sandbox', '--test-type=browser'],
            // Set download path and avoid prompting for download even though
            // this is already the default on Chrome but for completeness
            prefs: {
                'download': {
                    'prompt_for_download': false,
                    'directory_upgrade': true,
                    'default_directory': 'C:/Jenkins/sharedspace/public/test/e2e-reboot/steps/'
                }
            }
        }
    },


    //Browser options
    //multiCapabilities: [
    //	// {
    //	// browserName: 'internet explorer',
    //	// platform: 'ANY',
    //	// version: '11'
    //	// },
    //
    //	// {
    //	// browserName: 'firefox',
    //	// },
    //
    //	{
    //		browserName: 'chrome',
    //		count: 1,
    //		shardTestFiles: false,
    //		maxInstances: 1,
    //		'chromeOptions': {
    //			args: ['--no-sandbox', '--test-type=browser'],
    //			// Set download path and avoid prompting for download even though
    //			// this is already the default on Chrome but for completeness
    //			prefs: {
    //				'download': {
    //					'prompt_for_download': false,
    //					'directory_upgrade': true,
    //					'default_directory': 'C:/Jenkins/sharedspace/public/test/e2e-reboot/steps/'
    //				}
    //			}
    //		}
    //	}
    //
    //],

    params: {
        //env: 'dev'
    },

    maxSessions: -1,

    allScriptsTimeout: 250000,

    // How long to wait for a page to load.
    getPageTimeout: 650000,

    // Before launching the application
    beforeLaunch: function () {
    },

    // Application is launched but before it starts executing
    onPrepare: function () {
        browser.ignoreSynchronization = true;
        // Create reports folder if it does not exist
        var folderName = (new Date()).toString().split(' ').splice(1, 4).join(' ');
        var mkdirp = require('mkdirp');
        var reportsPath = "./Reports/";

        mkdirp(reportsPath, function (err) {
            if (err) {
                console.error(err);
            }
        });

        browser.manage().deleteAllCookies();
        browser.manage().timeouts().pageLoadTimeout(50000);
        browser.manage().timeouts().implicitlyWait(50000);
        browser.driver.manage().window().setSize(1280, 1440);
        //browser.driver.manage().window().maximize();
        //browser.driver.manage().window().setSize(1280, 1440);

        chai = require('chai');
        expect = chai.expect;
        path = require('path');
        Cucumber = require('cucumber');
        fs = require('fs');

        chaiAsPromised = require('chai-as-promised');
        chai.use(chaiAsPromised);

        // Initializing page object variables
        loginPage = require('../../../Common_Modules/PageObjects/apm-login-po.js');
        createOrchestrationPage = require('../../../Common_Modules/PageObjects/cafOrchCreate-po.js');
        viewOrchestrationPage = require('../../../Common_Modules/PageObjects/viewOrch-po.js');
        orchIOMapPage = require('../../../Common_Modules/PageObjects/orchIOMap-po.js');
        orchStepsPage = require('../../../Common_Modules/PageObjects/cafOrchSteps-po.js');
        orchDeployPage = require('../../../Common_Modules/PageObjects/orchDeploy-po.js');


        //caf section
        cafCreateAnalyticPage = require('../../../Common_Modules/PageObjects/cafCreateAnalytic-po.js');
        cafDeploymentPage = require('../../../Common_Modules/PageObjects/cafDeployment-po.js');
        cafAnalyticTemplatePage = require('../../../Common_Modules/PageObjects/cafAnalyticTemplate-po.js');
        cafanalyticTemplatePage = require('../../../Common_Modules/PageObjects/cafAnalyticTemplate-po.js');
        cafAssetFilters = require('../../../Common_Modules/PageObjects/cafAssetFilters-po.js');
        cafAssetSelectionPage = require('../../../Common_Modules/PageObjects/cafAssetSelection-po.js');
        cafSchedulePage = require('../../../Common_Modules/PageObjects/cafSchedule-po');
        cafIOMappingPage = require('../../../Common_Modules/PageObjects/cafIOMapping-po');
        cafAnalyticsJourneyPage = require('../../../Common_Modules/PageObjects/cafAnalyticsJourney-po');
        cafReviewPage = require('../../../Common_Modules/PageObjects/cafReview-po');
        benchmarkPage = require('../PageObjects/kpiBenchmark-po.js');
        // Initializing necessary utils from proui-utils module



        TestHelper = require('proui-utils').TestHelper;
        TestHelperPO = require('proui-utils').TestHelperPO;
        ElementManager = require('proui-utils').ElementManager;
        Logger = require('proui-utils').Logger;
        cem = new ElementManager('../../../Common_Modules/common-element-repo.json');
        cemPath = require('../../../Common_Modules/common-element-repo.json');
        TestHelper.setElementManager(cem);
        RestHelper = require('proui-utils').RestHelper;
        commonTestData = require('../../../Common_Modules/TestData/common-test-data.json').data;
        bem = new ElementManager('../../../Test_Modules/KpiBenchMarking/benchmark-element-repo.json');
        bemPath = require("../benchmark-element-repo.json");

        TestHelper.setWaitTime(60000);

        navPage= require('../../../Common_Modules/PageObjects/nav-po.js');
        analysisPage = require('../../../Common_Modules/PageObjects/analysis-dash-po.js');
        analysisTS = require('../../../Common_Modules/PageObjects/analysis-TS-po.js');
        analysisPA = require('../../../Common_Modules/PageObjects/analysis-PA-po.js');
        //aem = new ElementManager('../../Test_Modules/Analysis/analysis-element-repo.json');
        aemPath = require('../../Analysis/analysis-element-repo.json');


        // Initializing page object variables
        AdvancedNavPage = require('../../../Common_Modules/PageObjects/AdvancedNavigation-po.js');
        createviewpage = require('../../../Common_Modules/PageObjects/add-new-dashboard-po.js');
        addcardpage = require('../../../Common_Modules/PageObjects/addCard-po.js');
        editWidgetPage = require('../../../Common_Modules/PageObjects/editWidget-po.js');
        customcardpage = require('../../../Common_Modules/PageObjects/CustomCard-po.js');
        favoritesPage = require('../../../Common_Modules/PageObjects/favorite-po.js');
        dashboardSummaryPage = require('../../../Common_Modules/PageObjects/dashboard-summary-po.js');
        dem = new ElementManager('../../../Common_Modules/dashboard-element-repo.json');
        dem2 = require('../../../Common_Modules/dashboard-element-repo.json');


        //defining global variables
        var analyticName = "";
        var deploymentName="";

        //libaries
        async = require('async');
    },

    // A callback function called once tests are finished
    onComplete: function () {
    },
    // A callback function called once tests are cleaning up
    onCleanUp: function (exitCode) {
    },
    // A callback function after tests are launched
    afterLaunch: function () {
    },

    // Browser parameters for feature files.
    params: {
        login: {
             baseUrl: 'https://apmrc.int-app.aws-usw02-pr.predix.io/oorcg',
             mgrusername: 'opmrc',
             mgrpassword: 'Pa55w0rd',
        },
    },

    resultJsonOutputFile: null,

    // If true, protractor will restart the browser between each test.
    // CAUTION: This will cause your tests to slow down drastically.
    restartBrowserBetweenTests: false,

    // Custom framework in this case cucumber
    framework: 'custom',
    frameworkPath: require.resolve('protractor-cucumber-framework'),
    cucumberOpts: {
        // tags:['@beena','~@donotrunplease'],
        // define your step definitions in this file
        require: [
            //'../step_definitions/*',
            //'../../node_modules/proui-utils/Compressed_Utils/Reporter.js',
            '../../../node_modules/proui-utils/Compressed_Utils/Reporter.js',
            '../step_definitions/* ',

            '../../../node_modules/proui-utils/Compressed_Utils/Reporter.js',
            '../../../Common_Modules/step_definitions/* '

        ],


    },
};
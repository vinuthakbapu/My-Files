module.exports = function () {


    this.Then(/^I click on template dropdown and create a new benchmarking analysis$/, function (callback) {
        aem = new ElementManager('../../../Test_Modules/KpiBenchMarking/benchmark-element-repo.json');
        TestHelper.setElementManager(aem);
        TestHelper.elementToBeClickable("kpiBenchMarkPage", "templateDropdownArrow").then(function () {
            console.log("click on dropdown")
            browser.sleep(5000).then(function () {
                TestHelperPO.elementToBeClickable(element(by.cssContainingText('span.style-scope.pae-dropdown', 'New Benchmark Analysis'))).then(function () {
                    console.log("came here...");
                    //browser.pause
                    browser.sleep(2000).then(function () {
                        callback();
                    })
                });
            });
        });

        var elementList = element(by.css('#header-deck-selector px-icon.tag-menu-kabob:nth-of-type(1) iron-icon'));
        elementList.click();
    });

    this.When(/^User drags and drops the KPI model for "([^"]*)" onto chart$/, function (assetName, callback) {
            var EC = protractor.ExpectedConditions;
            browser.wait(EC.elementToBeClickable(benchmarkPage.getKpiToBeDraged(assetName))).then(function () {
                TestHelperPO.dragAndDrop(benchmarkPage.getKpiToBeDraged(assetName), benchmarkPage.getDroppingPoint())
                        .then(function () {
                            browser.sleep(10000);
                            callback();
                        });
                    browser.sleep(2000);
                });


    });

    this.Then(/^I should see KPI graph data points$/, function (callback) {
        browser.sleep(20000).then(function () {
            console.log('Verify data points are present');
            analysisPage.getGraphElement().getAttribute('d').then(function (chartElement) {
                console.log("graph points:" + JSON.stringify(chartElement));
                var datapointsPresent = chartElement.split(',').length > 5;
                expect(datapointsPresent).to.equal(true);
                callback();
            });
        });
    });

    this.When(/^cafUser search "([^"]*)" asset$/, function (assetName, callback) {
        benchmarkPage.reSelectAsset(assetName).then(function () {
            callback();
        })
    });

    this.Then(/^Benchmark header "([^"]*)" is displayed$/, function (expectedHeader, callback) {
        benchmarkPage.getBenchMarkHeader().getText().then(function (actualHeaderVal) {
            expect(expectedHeader).to.equal(actualHeaderVal);
            callback();
        });
    });

    this.Then(/^Kpi browser tree should start at the right level$/, function (callback) {
        benchmarkPage.getContextBrowserLevel().getText().then(function (contextBrowser) {
            benchmarkPage.getKpiRootLevel().getText().then(function (kpiRootLevel) {
                expect(true).to.equals(kpiRootLevel.indexOf(contextBrowser) !== -1);
                callback();
            });

        });
    });

    this.Then(/^The KPI name should be displayed on the chart$/, function (callback) {
        benchmarkPage.getContextBrowserLevel().getText().then(function (contextBrowser) {
            benchmarkPage.getKpiChartName().getText().then(function (kpiChartName) {
                expect(analyticName).to.equals(kpiChartName)
                callback();
            });
        });
    })

    this.When(/^user enters the deployment name$/, function (callback) {
        deploymentName = 'deploy' + TestHelperPO.getRandomString();
        element(by.id('DeploymentNameInputBox')).sendKeys(deploymentName).then(function () {
            browser.sleep(2000);
            callback();
        });
    });

    this.Then(/^Wait for analytic to deploy$/, function (callback) {
        cafCreateAnalyticPage.enterSearchText(deploymentName).then(function () {
            cafDeploymentPage.deploymentStatus().getText().then(function (value) {
                if (value != 'Run Once') {
                    browser.sleep(100000).then(function () {
                        element(by.linkText('Analytics Templates')).click().then(function () {
                            cafCreateAnalyticPage.clickDeploymentsTab().then(function () {
                                cafCreateAnalyticPage.clickSearchBox().then(function () {
                                    cafCreateAnalyticPage.enterSearchText(deploymentName).then(function () {
                                        cafDeploymentPage.deploymentStatus().getText().then(function (status) {
                                            expect('Run Once').to.equals(status);
                                            callback();
                                        });
                                    });
                                });
                            });
                        })
                    })
                } else {
                    callback();
                }
            });
        })
    });

    this.Then(/^The other KPIs should be disabled$/, function (callback) {
        benchmarkPage.getDisabledKPIs().then(function (disabledKPIs) {
            browser.sleep(3000).then(function () {
                expect(true).to.equals(disabledKPIs.length > 0)
                callback();
            })
        });
    });

    this.When(/^Expand plotted section$/, function (callback) {
        benchmarkPage.getPlottedTagExpand().click();
        callback();

    });

    this.When(/^Delete the plotted Tag$/, function (callback) {
        browser.actions().mouseMove(benchmarkPage.getPlottedKPI()).perform().then(function () {
            benchmarkPage.getDeleteTag().click();
        });
        browser.sleep(30000).then(function () {
            callback();
        });
    });

    this.Then(/^The other KPIs should be enabled$/, function (callback) {

        benchmarkPage.getDisabledKPIs().then(function (disabledKPIs) {
            browser.sleep(3000).then(function () {
                expect(true).to.equals(disabledKPIs.length == 0)
                callback();
            })
        });

    });

    this.Then(/^The Plotted tag section header should be displayed$/, function (callback) {

        benchmarkPage.getPlottedTagHeader().getText().then(function (plottedTagHeader) {
            expect('New Benchmark Analysis').to.equals(plottedTagHeader)
            callback();

        });

    });

    this.Then(/^The KPI name in  plotted section should match$/, function (callback) {

        benchmarkPage.getPlottedKPI().getText().then(function (kpiName) {
            var expectedKPIName = analyticName
            expect(expectedKPIName.toUpperCase()).to.equals(kpiName);
            callback();

        });

    });

    this.Then(/^The asset name "([^"]*)" in plotted section should match$/, function (assetName, callback) {
        browser.sleep(50000).then(function () {
            benchmarkPage.getPlottedAsstName().getText().then(function (actualAssetName) {
                expect(assetName).to.equal(actualAssetName);
                callback();
            });

        });

    });

    this.Then(/^KPI is selected to observe the details$/, function (callback) {
        benchmarkPage.getKPIToBeSelected().click().then(function () {
            callback();
        });
    });

    this.Then(/^Deployment name should be displayed in KPI details$/, function (callback) {
        benchmarkPage.getDetailDeployName().getText().then(function (deployName) {
            expect(deploymentName).to.equal(deployName);
            callback();
        });
    });

    this.Then(/^Asset header should be displayed in KPI details$/, function (callback) {
        benchmarkPage.getDetailAssetHead().getText().then(function (assetHead) {
            expect("Asset").to.equal(assetHead);
            callback();
        });
    });

    this.Then(/^Asset name field should be displayed in KPI details$/, function (callback) {
        benchmarkPage.getDetailAssetName().getText().then(function (assetField) {
            expect("Asset Name").to.equal(assetField);
            callback();
        });
    });

    this.Then(/^Asset name "([^"]*)" should match in KPI details$/, function (actualAssetName, callback) {
        benchmarkPage.getDetailAssetNameVal().getText().then(function (assetName) {
            expect(actualAssetName).to.equal(assetName);
            callback();
        });
    });

    this.Then(/^Input header should be displayed in KPI details$/, function (callback) {
        benchmarkPage.getDetailInputHeader().getText().then(function (inputHeader) {
            expect("Inputs").to.equal(inputHeader);
            callback();
        });
    });

    this.Then(/^ Input name field should be displayed in KPI details$/, function (actualAssetName, callback) {
        benchmarkPage.getDetailInputName().getText().then(function (inputName) {
            expect("Input Name").to.equal(inputName);
            callback();
        });
    });

    this.Then(/^Input name field should be displayed in KPI details$/, function (callback) {
        benchmarkPage.getDetailInputName().getText().then(function (inputName) {
            expect("Input Name").to.equal(inputName);
            callback();
        });
    });

    this.Then(/^Input name "([^"]*)" should match in KPI details$/, function (actualInputNameVal, callback) {
        benchmarkPage.getDetailInputNameVal().getText().then(function (inputName) {
            expect(actualInputNameVal).to.equal(inputName);
            callback();
        });
    });

    this.Then(/^Input unit field should be displayed in KPI details$/, function (callback) {
        benchmarkPage.getDetailInputUnit().getText().then(function (inputUnit) {
            expect("Input Unit").to.equal(inputUnit);
            callback();
        });
    });

    this.Then(/^Input unit "([^"]*)" should match in KPI details$/, function (actualInputUnitVal, callback) {
        benchmarkPage.getDetailInputUnitVal().getText().then(function (inputUnit) {
            expect(actualInputUnitVal).to.equal(inputUnit);
            callback();
        });
    });

    this.Then(/^Input tag should be displayed in KPI details$/, function (callback) {
        benchmarkPage.getDetailInputTag().getText().then(function (inputTag) {
            expect("Mapped Tag").to.equal(inputTag);
            callback();
        });
    });

    this.Then(/^Input tag "([^"]*)" should match in KPI details$/, function (actualInputTagVal, callback) {
        benchmarkPage.getDetailInputTagVal().getText().then(function (inputTag) {
            expect(actualInputTagVal).to.equal(inputTag);
            callback();
        });
    });

    this.Then(/^Output header should be displayed in KPI details$/, function (callback) {
        benchmarkPage.getDetailOutputTag().getText().then(function (outputTag) {
            expect("Output").to.equal(outputTag);
            callback();
        });
    });

    this.Then(/^Output tag should be displayed in KPI details$/, function (callback) {
        benchmarkPage.getDetailOutputTagVal().isDisplayed().then(function (isDisplayed) {
            expect(true).to.equal(isDisplayed)
            callback();
        });

    });

}

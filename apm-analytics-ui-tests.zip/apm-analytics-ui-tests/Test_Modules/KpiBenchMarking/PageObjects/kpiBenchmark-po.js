/**
 * Created by 212350438 on 7/9/15.
 */

(function () {

    'use strict';
    var path = require('path');
    var currentpage = 'kpiBenchMarkPage';

    var benchmarkPage = function () {

        return {

            reSelectAsset: function (assetName) {

                return browser.sleep(10000).then(function () {
                    return TestHelperPO.elementToBeClickable(element(by.css('thead tr:nth-of-type(1) input:nth-of-type(1)')))
                }).then(function () {
                    var asset = assetName;
                    return TestHelperPO.sendKeys(element(by.css('.search-input')), assetName + protractor.Key.ENTER);
                }).then(function () {
                    return browser.sleep(5000).then(function () {
                        return TestHelperPO.elementToBeClickable(element(by.css('tbody tr:nth-of-type(1) input')));
                    });
                });

            },

            getBenchMarkHeader: function () {
                return bem.findElement(currentpage, 'benchmarkHeader');
            },

            getContextBrowserLevel: function () {
                return bem.findElement(currentpage, 'contextBrowser');
            },

            getKpiRootLevel: function () {
                return bem.findElement(currentpage, 'kpiRootLevel');
            },

            getKpiChartName: function () {
                return bem.findElement(currentpage, 'kpiChartName');
            },

            getDisabledKPIs: function () {

                return bem.findElement(currentpage, 'disabledKPIs');
            },

            getPlottedTagHeader: function () {

                return bem.findElement(currentpage, 'plottedTagHeader');
            },

            getDeleteTag: function () {

                return bem.findElement(currentpage, 'deleteTag');
            },

            getPlottedTagExpand: function () {

                return bem.findElement(currentpage, 'plottedTagExpand');
            },

            getPlottedKPI: function () {

                return bem.findElement(currentpage, 'plottedKPI');
            },

            getPlottedAsstName: function () {

                return bem.findElement(currentpage, 'plottedAssetName');
            },

            getKPIToBeSelected: function () {
                return bem.findElement(currentpage, 'kpiPlotted');
            },

            getDetailDeployName: function () {

                return bem.findElement(currentpage, 'detailDeployName');
            },

            getDetailAssetHead: function () {

                return bem.findElement(currentpage, 'detailAssetHead');
            },

            getDetailAssetName: function () {

                return bem.findElement(currentpage, 'detailAssetName');
            },

            getDetailAssetNameVal: function () {

                return bem.findElement(currentpage, 'detailAssetNameVal');
            },

            getDetailInputHeader: function () {

                return bem.findElement(currentpage, 'detailInputHeader');
            },

            getDetailInputName: function () {

                return bem.findElement(currentpage, 'detailInputName');
            },

            getDetailInputUnit: function () {

                return bem.findElement(currentpage, 'detailInputUnit');
            },

            getDetailInputTag: function () {

                return bem.findElement(currentpage, 'detailInputTag');
            },

            getDetailInputNameVal: function () {

                return bem.findElement(currentpage, 'detailInputNameVal');
            },

            getDetailInputUnitVal: function () {

                return bem.findElement(currentpage, 'detailInputUnitVal');
            },

            getDetailInputTagVal: function () {

                return bem.findElement(currentpage, 'detailInputTagVal');
            },

            getDetailOutputTag: function () {

                return bem.findElement(currentpage, 'detailOutputTag');
            },

            getDetailOutputTagVal: function () {

                return bem.findElement(currentpage, 'detailOutputTagVal');
            },

            getKpiToBeDraged: function (assetName) {
                var kpiLocatorHolder = "//div[a[text()='" + analyticName + "']][@id='label']/following-sibling::div/descendant::div/a/span[text()='" + assetName + "']/ancestor::div[@id='label']"
                bemPath["kpiBenchMarkPage"]["kpiPlotted"].locatorValue = kpiLocatorHolder;
                console.log("kpiLocatorHolderS---->" + kpiLocatorHolder)
                //var dragList = element.all(by.xpath(kpiLocatorHolder));
                //console.log("lenghtnb++-->"+dragList.length)
                //return dragList.first();

                return bem.findElement(currentpage,"kpiPlotted");

            },

            getDroppingPoint: function () {
                return $('.chart-target.chart-target-overlay.style-scope.chart-target.chart-target-overlay.style-scope.chart-kpi');

            }
        }
    };

    module.exports = new benchmarkPage();

}())


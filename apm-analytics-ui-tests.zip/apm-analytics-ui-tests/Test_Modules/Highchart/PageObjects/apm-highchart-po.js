/**
 * Copyright (c) 2013 - 2015 GE Global Research. All rights reserved.
 * The copyright to the computer software herein is the property of
 * GE Global Research. The software may be used and/or copied only
 * with the written permission of GE Global Research or in accordance
 * with the terms and conditions stipulated in the agreement/contract
 * under which the software has been supplied.
 */

(function () {
    'use strict';

    var chart = require('proui-utils').HighChart;
    var section;
    var currentPage = "dashboardPage"

    var HighchartPage = function () {

        return {

            navigateToChart: function () {
                return TestHelper.isElementPresent("highChartsHomepage", 'contextNameList').then(function () {
                    return TestHelper.elementToBeClickable(currentPage, 'e2eEdisonEnterpriseDiv').then(function () {
                        return TestHelper.elementToBeClickable(currentPage, 'azPrescottSiteDiv').then(function () {
                            return TestHelper.isElementPresent(currentPage, 'azPrescottSiteDivCheck').then(function () {
                                return TestHelper.elementToBeClickable(currentPage, 'azPrescottSiteButton').then(function () {
                                    return TestHelper.isElementPresent(currentPage, 'dropDownDashboardCheck').then(function () {
                                        return TestHelper.elementToBeClickable(currentPage, 'dropDownDashboard').then(function () {
                                            return TestHelper.elementToBeClickable(currentPage, 'newDashboardNavigation').then(function () {
                                                //return TestHelper.elementToBeClickable(currentPage, 'graphNewTab').then(function () {
                                                //    browser.getAllWindowHandles().then(function (handles) {
                                                //        var secondWindowHandle = handles[1];
                                                //        browser.switchTo().window(secondWindowHandle).then(function () { //the focus moves on new tab
                                                //            browser.sleep(3000);
                                                //            console.log("Made it to the second window")
                                                //        });
                                                    //});
                                                //});
                                            });
                                        });
                                    });
                                });
                            });
                        });
                    });
                });
            },

            checkChartPage: function () {
                console.log("checking chart element");
                return TestHelper.isElementPresent(currentPage, 'chartHeader')
            },

            setChart: function () {
                console.log("Before")
                section = cem.findElement(currentPage, 'graphWidgetContainer');
                console.log("After getting section")
                chart.setChartElements(section);
            },

            isChartVisibile: function () {
                return chart.isChartDisplayed();
            },

            getXAxisLabels: function () {
                return chart.getXaxisLabels();
            },

            getYAxisLabels: function () {
                return chart. getYaxisLabels();
            },

            getYaxisText: function () {
                return chart.getYaxisText();
            },

            getLegends: function () {
                return chart.getLegendsFromSVG();
            },

            getData: function () {
                return chart.getData();
            }
        }

    };

    module.exports = new HighchartPage();

}());
/**
 * Copyright (c) 2013 - 2015 GE Global Research. All rights reserved.
 * The copyright to the computer software herein is the property of
 * GE Global Research. The software may be used and/or copied only
 * with the written permission of GE Global Research or in accordance
 * with the terms and conditions stipulated in the agreement/contract
 * under which the software has been supplied.
 */

(function () {
    'use strict';

    var em = new ElementManager('../../../Test_Modules/DragAndDrop/drag-and-drop-element-repo.json');
	var dragNDrop = require('./drag.js');

    var DragAndDropPage = function () {

        return {

			getSectionA: function () {
				return em.findElement('basics', 'sectionA');
			},

			isSectionAVisible: function () {
				return this.getTryImage().isPresent();
			},

			getSectionB: function () {
				return em.findElement('basics', 'sectionB');
			},

			dragAndDrop: function () {
				var deferred = protractor.promise.defer();
				var elem = this.getSectionA();
				var target = this.getSectionB();
				browser.actions().
					mouseDown(elem).
					mouseMove(target).
					mouseUp().
					perform().then(function () {
					deferred.fulfill();
				})

				return deferred.promise;
			},

			getSectionACount: function () {
				var ele = em.findElement('basics', 'countA');
				return ele.getText();
			}
        }

    };

    module.exports = new DragAndDropPage();

}());
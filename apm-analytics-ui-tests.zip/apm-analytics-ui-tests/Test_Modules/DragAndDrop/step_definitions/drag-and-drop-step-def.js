/**
 * Main step definition. Add all glue code here in this class
 */

var myStepDefinitionsWrapper = function () {
	this.setDefaultTimeout(60 * 1000);
	var em = new ElementManager('../../../Test_Modules/DragAndDrop/drag-and-drop-element-repo.json');
	var ddPage = require('../PageObjects/drag-and-drop-po.js');

	geSSOLogin = function () {
		// pass through GE SSO page
		cem.findElement('geSSOPage', 'username').sendKeys(commonTestData.sso);
		cem.findElement('geSSOPage', 'password').sendKeys(commonTestData.password);
		cem.findElement( 'geSSOPage', 'password').sendKeys(protractor.Key.ENTER)
	}

	//'use strict';
	this.Given(/^I navigate (.*)$/, function (env, callback) {
		browser.driver.get(env).then(function () {
			browser.ignoreSynchronization = true;
		 	geSSOLogin();
			browser.sleep(10000);

			TestHelper.setElementManager(em);
			TestHelper.isElementPresent('basics', 'sectionA').then(function () {
				callback();
			});

		});
	});

	this.When(/^I drag and drop section A on section B$/, function (callback) {
		ddPage.dragAndDrop().then(function () {
			callback();
		})
	});

	this.Then(/^It should swap$/, function (callback) {
		// Setting the Highchart to retrieve information from it
		//browser.sleep(25000);
		ddPage.getSectionACount().then(function (text) {
			console.log('count............... '+text);
			TestHelper.assertEqual(text, 'moves: 1', callback);
			callback();
		})
	});
};
module.exports = myStepDefinitionsWrapper;

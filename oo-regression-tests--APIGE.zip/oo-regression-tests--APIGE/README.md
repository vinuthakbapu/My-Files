#To run against CF3 run following command:


mvn test -DenvType=dev_cf3 -Dlocal=true -DignoreTestProperty="false" -Dtest=com.ge.automation.OO.OOHealthCheckCF3Tests#testE2E_ApmTSInput_ApmTSOutput_Java -DsuiteXmlFile=HealthCheckCF3TestSuite -o $runArguments -s menlo_settings.xml



To Run against Colo CF1 run following command:

mvn test -DenvType=qa_stuf4 -Dlocal=true -DignoreTestProperty="false" -Dtest=com.ge.automation.OO.OOHealthCheckAndromedaTests#testE2E_StreamInput_StreamOutput_Java -DsuiteXmlFile=HealthCheckAndromedaTestSuite -o $runArguments -s menlo_settings.xml







# oo-system-e2e

## Before run test, please make sure JAVA_HOME is pointing to jdk1.8. 
You can use your .bash_profile for setting JAVA_HOME

`export JAVA_HOME=/Library/Java/JavaVirtualMachines/jdk1.8.0_121.jdk/Contents/Home`

- To setup in Eclipse, you need to import this repo into Eclipse from File->Import menu. 

Make sure that you have Java Build Path properly setup. You can run a test in Eclipse by right click project->Run as->Run configuration and add following in the goal:

`clean install test -DenvType=dev_stuf4 -Dlocal=true -DignoreTestProperty="false" -Dtest=com.ge.automation.OO.OOAnalyticE2ETest#testEnd2EndScenariosAnalyticService_positive`

-Dtest provides ClassName#TestMethodName format. -DenvType will fetch specified configuration.properties file(in this case dev_stuf4.configuration.properties)

After this setup, run this project as Maven Build. If you face a jar is missing error, copy mvnsettings.xml file in .m2 folder in home directory. Rename it as settings.xml. From Eclipse->Preference->Maven->User settings, specify path to settings.xml in Local Repository.

To run testing in Eclipse. By default, test runner will look for testcases.json under current folder recursively. You may need to configure eclipse test run by adding following in goals.

` -Dtestcases.root.dir=./src/main/resources -Dtestfile.name.pattern=wse2e.json `

By default, the environment is set to dev. However, it is configurable by setting value to system property envType to change environment. For example, in test.properties,
` tenant_mgm_base_url=http://oo-tenancy-${sys:envType}.grc-apps.svc.ice.ge.com/services/v1 `

If you don’t set any value to envType, it will be ` tenant_mgm_base_url=http://oo-tenancy-dev.grc-apps.svc.ice.ge.com/services/v1 ` during runtime. If you add ` -DenvType=qa `, it will become ` tenant_mgm_base_url=http://oo-tenancy-qa.grc-apps.svc.ice.ge.com/services/v1 `.

Here are some vm arguments that you will probably need to run tests:
* Env pen-test:
`-Dtestcases.root.dir=./src/main/resources -Dtestfile.name.pattern=ws-e2e*.json -DenvType=pen-test -DtestPropertyFile=test.properties,env-pen-test.properties `

* Env acceptance:
` -Dtestcases.root.dir=./src/main/resources -Dtestfile.name.pattern=ws-e2e*.json -DenvType=acceptance -DtestPropertyFile=test.properties,env-acceptance.properties `

* Env QA:
` -Dtestcases.root.dir=./src/main/resources -Dtestfile.name.pattern=ws-e2e*.json -DenvType=qa -DtestPropertyFile=test.properties,env-qa.properties `

### To run tests on colo, the vm arguments will be slightly different.
* Pre-prod
` -Dtestcases.root.dir=./src/main/resources -Dtestfile.name.pattern=ws-e2e*.json -DenvType=preprod-oo-api -DtestPropertyFile=test.properties,env-colo.properties `

* Prod, use -Dtest to run different test suits
`-Dtestcases.root.dir=./src/main/resources`
`-Dtestfile.name.pattern=ws-e2e*.json`

## How to build and run from local
* To build a package for CI, run command `mvn clean package -Dlocal=false`
* To run tests from local, you can run maven command: `mvn clean test -Dlocal=true …`.

Please refer to the sections above for the rest of parameters.


## How to debug in Eclipse in local
Set the breakpoint. Change the eclipse maven build goal in debug configuration to the following

`clean install -Dmaven.surefire.debug test -DenvType=dev_stuf4 -Dlocal=true -DignoreTestProperty="false" -Dtest=com.ge.automation.OO.ClassName#TestName`

Under debug configuration, change remote java application(port=5005). Hit debug(it will hit breakpoint).


To run health check against Andromeda environment following is the command:

 mvn test -DenvType=dev_stuf5 -Dlocal=true -DignoreTestProperty="false" -Dtest=com.ge.automation.OO.OOHealthCheckAndromedaTests#testE2E_ApmTSInput_ApmTSOutput_Python -DsuiteXmlFile=HealthCheckAndromedaTestSuite

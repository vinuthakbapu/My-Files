
export JAVA_HOME=${JAVA_HOME_OPENJDK8}
export PATH=${JAVA_HOME}/bin:${PATH}

 
mvn clean test -DenvType=qa_cf1 -Dlocal=true -DignoreTestProperty="false" -Dsuite=HealthCheckCF1AlertsTestSuite -s menlo_settings.xml -DfilePath=local -Dhttps.proxyHost=sjc1intproxy02.crd.ge.com -Dhttps.proxyPort=8080 -Dhttp.nonProxyHosts=*.ge.com

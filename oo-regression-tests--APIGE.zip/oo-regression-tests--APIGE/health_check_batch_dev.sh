
export JAVA_HOME=${JAVA_HOME_OPENJDK8}
export PATH=${JAVA_HOME}/bin:${PATH}

#mvn clean test -DenvType=dev_stuf5 -Dlocal=true -DignoreTestProperty="false" -Dsuite=HealthCheckAndromedaTestSuite -s menlo_settings.xml

#mvn clean test -DenvType=dev_cf3 -Dlocal=true -DignoreTestProperty="false" -Dsuite=HealthCheckCF3TestSuite -s menlo_settings.xml

mvn clean test -DenvType=dev_cf1 -Dlocal=true -DignoreTestProperty="false" -Dsuite=HealthCheckCF1BatchTestSuite -s menlo_settings.xml -DfilePath=local -Dhttps.proxyHost=sjc1intproxy02.crd.ge.com -Dhttps.proxyPort=8080 -Dhttp.nonProxyHosts=*.ge.com

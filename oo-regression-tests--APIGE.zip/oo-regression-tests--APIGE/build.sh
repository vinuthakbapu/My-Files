mvn deploy -s menlo_settings.xml -DskipTests

#!/bin/bash

export E2E_HOME=.
cd $E2E_HOME

SMOKE_ONLY="ws-e2e*-smoke.json"
REGRESSION="ws-e2e*.json"

RUN_TEST_PATTERN=SMOKE_ONLY
if [[ -n "$1" ]]; then
  RUN_TEST_PATTERN=$1
fi

jcomm="java -jar -Dtestcases.root.dir=. -Dtestfile.name.pattern="${!RUN_TEST_PATTERN}" -DenvType=$TO_ENV "
jcomm1="java -jar -Dlocal=true -DenvType=$TO_ENV"



grepResults=`grep "$TO_ENV." runTime.properties`
for line in $grepResults; do
   newParam=`echo $line | sed -e "s/^$TO_ENV./-D/g"`
   jcomm="$jcomm$newParam "
#   echo $jcomm
done

grepResults=`grep "$TO_ENV." runTime.properties`
for line in $grepResults; do
   newParam=`echo $line | sed -e "s/^$TO_ENV./-D/g"`
   jcomm1="$jcomm$newParam "
#   echo $jcomm1
done

jcomm="$jcomm oo-e2e-test-latest.jar wstestsuites/e2e.xml"
jcomm1="$jcomm oo-e2e-test-latest.jar wstestsuites/ServicesTestSuite.xml"

eval $jcomm
eval $jcomm1
package com.ge.automation.OO.opmDataServiceTest;

import com.ge.microtester.common.utils.RestAssuredUtil;
import com.ge.microtester.rally.RallyInfo;
import com.jayway.restassured.response.Response;
import org.testng.annotations.Test;

import javax.servlet.http.HttpServletResponse;
import java.util.Collections;
import java.util.List;

import static com.ge.automation.OO.opmDataServiceTest.OpmDataServiceAssertion.*;
import static org.junit.Assert.assertFalse;

public class OpmDataServiceTest extends RestAssuredUtil {

    @Test(priority = 1, description = "testSummaryResponse")
    @RallyInfo(UserStory = OpmDataServiceProperties.USER_STORY)
    public void testSummaryResponse() throws Exception {
        Response clpmResponse = OpmDataServiceTestHelper.getClpmResponse("clpm_service_payload");
        String summaryResponse = clpmResponse.getBody().jsonPath().getString(OpmDataServiceProperties.SUMMARY_RESPONSE);
        assertForAssetFieldsInSummaryResponse(summaryResponse);
        assertForSummaryTags(clpmResponse.getBody().jsonPath().getString(OpmDataServiceProperties.SUMMARY_TAG_LIST));
    }

    @Test(priority = 1, description = "testAggregatedResponse")
    @RallyInfo(UserStory = OpmDataServiceProperties.USER_STORY)
    public void testAggregatedResponse() throws Exception {
        Response clpmResponse = OpmDataServiceTestHelper.getClpmResponse("clpm_service_payload");
        assertStatusCode(clpmResponse.getStatusCode(), HttpServletResponse.SC_OK);
        String aggregatedResponse = clpmResponse.getBody().jsonPath().getString(OpmDataServiceProperties.AGGREGATED_RESPONSE);
        assertForTagFieldsInAggregatedResponse(aggregatedResponse);
        assertForAggregatedTags(clpmResponse.getBody().jsonPath().getString(OpmDataServiceProperties.AGGREGATED_RESPONSE));
    }

    @Test(priority = 1, description = "testClpmResponseWithoutAggregateTags")
    @RallyInfo(UserStory = OpmDataServiceProperties.USER_STORY)
    public void testClpmResponseWithoutAggregateTags() throws Exception {
        Response clpmResponse = OpmDataServiceTestHelper.getClpmResponse("clpm_service_payload_without_aggregated_tags");
        assertStatusCode(clpmResponse.getStatusCode(), HttpServletResponse.SC_INTERNAL_SERVER_ERROR);
    }

    @Test(priority = 1, description = "testClpmResponseWithoutSummaryTags")
    @RallyInfo(UserStory = OpmDataServiceProperties.USER_STORY)
    public void testClpmResponseWithoutSummaryTags() throws Exception {
        Response clpmResponse = OpmDataServiceTestHelper.getClpmResponse("clpm_service_payload_without_summary_tags");
        assertStatusCode(clpmResponse.getStatusCode(), HttpServletResponse.SC_INTERNAL_SERVER_ERROR);
    }

    @Test(priority = 1, description = "testClpmResponseWithoutPvVariabilityTag")
    @RallyInfo(UserStory = OpmDataServiceProperties.USER_STORY)
    public void testClpmResponseWithoutPvVariabilityTag() throws Exception {
        Response clpmResponse = OpmDataServiceTestHelper.getClpmResponse("clpm_service_payload_without_pv_variability_tag");
        assertStatusCode(clpmResponse.getStatusCode(), HttpServletResponse.SC_OK);
        String response = clpmResponse.getBody().jsonPath().getString(OpmDataServiceProperties.SUMMARY_TAG_LIST);
        assertFalse(response.contains("PV Variability"));
        assertForAggregatedTags(response);
    }

    @Test(priority = 1, description = "testClpmResponseDateRangeMoreThan30Days")
    @RallyInfo(UserStory = OpmDataServiceProperties.USER_STORY)
    public void testClpmResponseDateRangeMoreThan30Days() throws Exception {
        Response clpmResponse = OpmDataServiceTestHelper.getClpmResponse("clpm_service_payload_date_range_more_than_30_days");
        assertStatusCode(clpmResponse.getStatusCode(), HttpServletResponse.SC_BAD_REQUEST);
    }

    @Test(priority = 1, description = "testClpmResponseDateRangeMoreThan30Days")
    @RallyInfo(UserStory = OpmDataServiceProperties.USER_STORY)
    public void testClpmResponseInvalidSegmentId() throws Exception {
        Response clpmResponse = OpmDataServiceTestHelper.getClpmResponse("clpm_service_payload_invalid_segment_id");
        assertStatusCode(clpmResponse.getStatusCode(), HttpServletResponse.SC_BAD_REQUEST);
    }

    @Test(priority = 1, description = "testClpmResponseVerifyIndividualDataPoints")
    @RallyInfo(UserStory = OpmDataServiceProperties.USER_STORY)
    public void testClpmResponseVerifyIndividualDataPoints() throws Exception {
        Response clpmResponse = OpmDataServiceTestHelper.getClpmResponse("clpm_service_payload_asset_linkage_to_segment");
        String dataPoints = clpmResponse.body().jsonPath().getString(OpmDataServiceProperties.AGGREGATED_TAG_LIST).replaceAll
                ("\\s+", "");
        List<Long> dataPointList = convertToLongArray(dataPoints.substring(1, dataPoints.length() - 1)
                .split(","));
        Collections.sort(dataPointList);
        assertForIndividualDataPoints(dataPointList);
    }

}
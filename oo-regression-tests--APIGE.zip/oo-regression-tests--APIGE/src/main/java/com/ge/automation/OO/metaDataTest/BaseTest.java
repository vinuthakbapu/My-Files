package com.ge.automation.OO.metaDataTest;

import com.ge.microtester.common.utils.RestAssuredUtil;
import com.jayway.restassured.response.Response;
import org.testng.annotations.AfterClass;
import org.testng.annotations.BeforeClass;

import java.io.IOException;
import java.net.URISyntaxException;

public class BaseTest extends RestAssuredUtil {

    protected String path;
    protected MetaDataTestUtil metaDataTestUtil ;
    protected MetaDataAssertion metaDataAssertion;

    @BeforeClass
    protected void setUp() {
        path = "src/main/resources/payloadsAndromeda";
        metaDataTestUtil= new MetaDataTestUtil();
        metaDataAssertion = new MetaDataAssertion();

    }


    @AfterClass()
    protected void tearDown() throws IOException, URISyntaxException {
        Response metaData;
        Response updateMetaData;
        metaData = metaDataTestUtil.getConfig("tenant",getTestProperty("meta_data_app"), getTestProperty("view_meta_data_feature"),200,"en_US");
        updateMetaData = metaDataTestUtil.updateMetaData(metaData, path + "/meta_data/update_meta_data_payload.json", "Every5minutes");
        metaDataAssertion.verifyUpdateMetaData(updateMetaData, path + "/meta_data/updated_meta_data.json",path + "/meta_data/updated_view_geo_config.json");
    }
}

package com.ge.automation.OO;

import com.ge.microtester.common.utils.RestAssuredUtil;
import com.ge.microtester.rally.RallyInfo;
import com.jayway.restassured.response.Response;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.boot.test.TestRestTemplate;
import org.springframework.web.client.RestTemplate;
import org.testng.Assert;
import org.testng.annotations.AfterClass;
import org.testng.annotations.AfterMethod;
import org.testng.annotations.AfterSuite;
import org.testng.annotations.AfterTest;
import org.testng.annotations.BeforeClass;
import org.testng.annotations.BeforeMethod;
import org.testng.annotations.BeforeSuite;
import org.testng.annotations.BeforeTest;
import org.testng.annotations.Test;

import java.io.IOException;
import java.net.URISyntaxException;
import java.time.Instant;
import java.time.LocalDateTime;
import java.time.ZoneId;
import java.time.temporal.ChronoUnit;
import java.util.LinkedHashMap;
import java.util.Map;
import java.util.Properties;

@RallyInfo(ProjectName ="APM Super Optimo")
public class OOHealthCheckCF1SchedulingTests extends RestAssuredUtil {
	private static final Logger log = LoggerFactory.getLogger("OOHealthCheckCF1Tests");
	static String jsonfileName;
	Properties configFile = new Properties();
	String truncateDateTime[];
	String tagName;
	String proxyHost;
	String proxyPort;
	Response responseBody;
	String kpiid;
	String kpiJobId;
	String dataSourceId;
	long kpi_id;
	long kpi_id1;
	String path = "src/main/resources/payloadsAndromeda";
	String apmTSforIngestionPath;
	boolean apmIngestionDynamicTag;
	String kpiTemplateJsonPath;
	String kpiTemplateAnalyticPath;
	String kpiJobJsonPath;
	String dataIngestionFilePath;
	String inputTag;
	String outputTag;
	String expectedValue;
	String expectedJobStatus;
	boolean createKpiJobWithTag;
	String apmTsUrl = "";
	int MAX_TRIALS = 60;
	public OOTestUtil ooTestutil = new OOTestUtil();
	RestTemplate restTemplate = new TestRestTemplate();
	// Generating Query Params
	Map<String, Object> values = new LinkedHashMap<>();

	@BeforeMethod
	public void beforeMethod() {
	}

	@AfterMethod
	public void afterMethod() {
	}

	@BeforeClass
	public void beforeClass() {

		/*
		 * System.getProperties().put("proxySet", "true");
		 * System.getProperties().put("http.proxyHost",
		 * "sjc1intproxy01.crd.ge.com");
		 * System.getProperties().put("http.proxyPort", "8080");
		 * System.getProperties().put("https.proxyHost",
		 * "sjc1intproxy01.crd.ge.com");
		 * System.getProperties().put("https.proxyPort", "8080");
		 */
		// getServiceResponse("alert_profile_base_url");
		setSysProperty("currentTimeStamp", "" + getCurrentTimestamp());// ${sys:currentTimeStamp}

	}// end of beforeClass

	@AfterClass
	public void afterClass() {
	}

	@BeforeTest
	public void beforeTest() {

	}// end of beforeTest

	/********************************************************************************************************************/
	@Test
	public void test_ApmTsIngestion_ApmTsRetrieval() {
		// post data to apm
		int valuePosted;
		try {
			valuePosted = ooTestutil.postRandomDataPointToAPMTimeSeries(path + "/data_files/data_ingestion_gen.json",
					"OO_Tag_Temperature_ID2");

			// get data from APM
			Thread.sleep(20000);
			ooTestutil.getDataFromApmTimeSeries("OO_Tag_Temperature_ID2", String.valueOf(valuePosted));
		} catch (IOException | URISyntaxException | InterruptedException e) {
			Assert.fail("test_ApmIngestion_ApmRetrieval failed with message " + e.getMessage());
		}
	}

	/********************************************************************************************************************/
	@Test
	public void test_ApmAssetRetrieval() {
		log.info("Asserting Assets Exists");
		// get Asset data from APM
		try {
			ooTestutil.getAPMAssets();
		} catch (InterruptedException e) {
			Assert.fail("test_ApmAssetRetrieval failed with message " + e.getMessage());
		}
	}

	/*********************************************************************************************************/
	@Test (dependsOnMethods={"test_ApmTsIngestion_ApmTsRetrieval","test_ApmAssetRetrieval"})
	@RallyInfo(UserStory ="US223441")
	public void testE2E_ApmTSInput_ApmTSOutput_Scheduling_Java() throws Exception {
		String analyticZipFile = "/kpi_analytics/simple_java_version2.zip";
		String analyticTemplate = "/kpi_templates/kpi_e2e_ooapmts_inputAndOutput.json";
		String kpiJobFile = "/kpi_jobs/kpi_e2e_healthCheck_inputAndOutput_job_with_scheduler.json";
		testE2E_ApmTSInput_ApmTSOutput_SchedulingWithLanguage("JAVA",analyticZipFile,analyticTemplate,kpiJobFile);
	}

	/*********************************************************************************************************/
	@Test (dependsOnMethods={"test_ApmTsIngestion_ApmTsRetrieval","test_ApmAssetRetrieval"})
	@RallyInfo(UserStory ="US223441")
	public void testE2E_ApmTSInput_ApmTSOutput_Scheduling_Python() throws Exception {
		String analyticZipFile = "/kpi_analytics/simple_python_version3.zip";
		String analyticTemplate = "/kpi_templates/kpi_e2e_ooapmts_inputAndOutput.json";
		String kpiJobFile = "/kpi_jobs/kpi_e2e_healthCheck_inputAndOutput_job_with_scheduler.json";
		testE2E_ApmTSInput_ApmTSOutput_SchedulingWithLanguage("PYTHON",analyticZipFile,analyticTemplate,kpiJobFile);
	}

	/*********************************************************************************************************/
	@Test (dependsOnMethods={"test_ApmTsIngestion_ApmTsRetrieval","test_ApmAssetRetrieval"})
	@RallyInfo(UserStory ="US223441")
	public void testE2E_Scheduling_newpayload() throws Exception {
		String analyticZipFile = "/kpi_analytics/spark-ex.zip";
		String analyticTemplate = "/kpi_templates/kpiTemplate_newpayload.json";
		String kpiJobFile = "/kpi_jobs/kpiJob_newpayload.json";
		testE2E_SchedulingWithLanguage("JAVA",analyticZipFile,analyticTemplate,kpiJobFile);
	}
	/*********************************************************************************************************/
	private void testE2E_ApmTSInput_ApmTSOutput_SchedulingWithLanguage(String language, String analyticZipFile,
			String analyticTemplate, String kpiJobFile) throws Exception {
		setSysProperty("language", language);
		// ingest test data into apm time series
		String inputTag = "OO_Tag_Temperature_ID22";
		String outputTag = "OO_Tag_Temperature_ID24";

		// create kpi template

		kpi_id = ooTestutil.createKpiTemplate(path + analyticTemplate,
				path + analyticZipFile);
		Thread.sleep(10000);

		// create kpi job

		kpiJobId = ooTestutil.createKpiJobWithSchedulerInfo(path + kpiJobFile, kpi_id, outputTag, inputTag, "");

		LocalDateTime startTime = LocalDateTime.now(ZoneId.of("UTC"));
		int valuePosted = ooTestutil.postRandomDataPointToAPMTimeSeriesWithTimestamp(
				path + "/data_files/data_ingestion_gen.json", inputTag, startTime.toString());

		// start kpi job
		String schedulerId = ooTestutil.startScheduledKpiJob(kpiJobId);

		// wait for the next schedule flow trigger
        long timeMs = Instant.now().toEpochMilli();
		timeMs = ooTestutil.getNextKPIJobScheduleRunMillis() - timeMs;
        log.info(String.format("*** Waiting %d ms for the next schedule flow trigger", timeMs));
        Thread.sleep(timeMs);

		if (schedulerId != null) {

			int i = 0;
			int wait = 10;
			int numTrials = 0;
			while(!"FINISHED".equalsIgnoreCase(ooTestutil.getStatusOfJob(kpiJobId))) {
				Thread.sleep(wait * 3000L);
				i += wait;
				log.info(String.format("After %d seconds since job start, waiting for the job to finish.", i));
				numTrials++;
				log.info("Number of trials till now:"+ numTrials);
				if(numTrials>MAX_TRIALS) {
					cleanUp(kpiJobId, kpi_id);
					fail("Trials have been exceeded to find FINISHED job status");
					break;
				}
			}
			System.out.println("Trying to delete the job");
			// delete kpi job
			ooTestutil.deleteKpiJob(kpiJobId);
			System.out.println("Waiting to delete the job");
			Thread.sleep(20000);

			String tsResponse = ooTestutil.getDataFromApmTimeSeriesWithTimeFilter(outputTag,
					startTime.minus(1, ChronoUnit.SECONDS).toString());

			log.info("Value posted was " + String.valueOf(valuePosted));
			isEqual("Calculated data of APM TS is not matching expected value", true,
					tsResponse.contains(String.valueOf(valuePosted * 10)));

			// DELETE KPI
			log.info("+++ DELETE KPI+++++++++++++++++++++++++++++++++++");
			String kpiDeleteUrl = getTestProperty("kpi_url") + "/" + kpi_id;
			log.info("+++ kpiDeleteUrl == " + kpiDeleteUrl);
			Response delete_response = deleteServiceResponse("kpi_url" + "/" + kpi_id, values,
					ooTestutil.kpiprovideHeaders());
			log.info("+++ delete_response.asString() == " + delete_response.asString());

			Response get_response = getServiceResponse("kpi_url" + "/" + kpi_id, ooTestutil.kpiprovideHeaders_2());
			isEqual("Delete KPI template failed", true, get_response.asString().contains("ObjectNotFound"));

			ooTestutil.printnewLine();
		} else {
			fail("Job not scheduled. Scheduler id is null");
		}
	}
	/********************************************************************************************************************/
	private void testE2E_SchedulingWithLanguage(String language, String analyticZipFile,
			String analyticTemplate, String kpiJobFile) throws Exception {
		
		setSysProperty("language", language);

		// create kpi template

		kpi_id = ooTestutil.createKpiTemplate(path + analyticTemplate,
				path + analyticZipFile);
		Thread.sleep(10000);

		// create kpi job

		kpiJobId = ooTestutil.createKpiJobWithSchedulerInfo(path + kpiJobFile, kpi_id, "", "", "");
		// start kpi job
		String schedulerId = ooTestutil.startScheduledKpiJob(kpiJobId);

		// wait for the next schedule flow trigger
		long timeMs = Instant.now().toEpochMilli();
		timeMs = ooTestutil.getNextKPIJobScheduleRunMillis() - timeMs;
		log.info(String.format("*** Waiting %d ms for the next schedule flow trigger", timeMs));
		Thread.sleep(timeMs);

		if (schedulerId != null) {

			int i = 0;
			int wait = 10;
			int numTrials = 0;
			String status = null;

			do {
				Thread.sleep(wait * 3000L);
				i += wait;
				log.info(String.format("After %d seconds since job start, waiting for the job to finish.", i));
				numTrials++;
				log.info("Number of trials till now:"+ numTrials);
				if(numTrials>MAX_TRIALS) {
					cleanUp(kpiJobId, kpi_id);
					fail("Trials have been exceeded to find FINISHED job status");
					break;
				}

				status = ooTestutil.getStatusOfJob(kpiJobId);

			} while(!"FINISHED".equalsIgnoreCase(status));


			//isTrue("FINISHED".equalsIgnoreCase(ooTestutil.getStatusOfJob(kpiJobId)));
			System.out.println("Trying to delete the job");
			// delete kpi job
			ooTestutil.deleteKpiJob(kpiJobId);
			System.out.println("Waiting to delete the job");
			Thread.sleep(20000);


			// DELETE KPI
			//log.info("+++ DELETE KPI+++++++++++++++++++++++++++++++++++");
			//String kpiDeleteUrl = getTestProperty("kpi_url") + "/" + kpi_id;
			//log.info("+++ kpiDeleteUrl == " + kpiDeleteUrl);
			//Response delete_response = deleteServiceResponse("kpi_url" + "/" + kpi_id, values,
			//ooTestutil.kpiprovideHeaders());
			//log.info("+++ delete_response.asString() == " + delete_response.asString());
			//
			//Response get_response = getServiceResponse("kpi_url" + "/" + kpi_id, ooTestutil.kpiprovideHeaders_2());
			//isEqual("Delete KPI template failed", true, get_response.asString().contains("ObjectNotFound"));

			ooTestutil.printnewLine();
		} else {
			fail("Job not scheduled. Scheduler id is null");
		}
	}
	/********************************************************************************************************************/
	public void cleanUp(String kpiJobID, long kpiID) throws Exception {
		System.out.println("cleaning up the job");
		// delete kpi job
		ooTestutil.deleteKpiJob(kpiJobID);
		System.out.println("Waiting to delete the job");
		Thread.sleep(20000);
		// DELETE KPI
		log.info("+++ DELETE KPI+++++++++++++++++++++++++++++++++++");
		String kpiDeleteUrl = getTestProperty("kpi_url") + "/" + kpiID;
		log.info("+++ kpiDeleteUrl == " + kpiDeleteUrl);
		Response delete_response = deleteServiceResponse("kpi_url" + "/" + kpiID, values,
				ooTestutil.kpiprovideHeaders());
		log.info("+++ delete_response.asString() == " + delete_response.asString());

		Response get_response = getServiceResponse("kpi_url" + "/" + kpiID, ooTestutil.kpiprovideHeaders_2());
		isEqual("Delete KPI template failed", true, get_response.asString().contains("ObjectNotFound"));

		ooTestutil.printnewLine();
	}

	/********************************************************************************************************************/
	@AfterTest
	public void afterTest() {
	}

	@BeforeSuite
	public void beforeSuite() {

	}

	@AfterSuite
	public void afterSuite() {
	}
}

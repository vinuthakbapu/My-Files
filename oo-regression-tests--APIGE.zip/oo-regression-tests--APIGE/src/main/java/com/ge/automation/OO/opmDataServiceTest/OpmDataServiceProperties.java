package com.ge.automation.OO.opmDataServiceTest;

public class OpmDataServiceProperties {
    static final String USER_STORY = "US260762";
    static final String TOTAL_PIDF_CHANGES = "Total PIDF Changes";
    static final String OVERALL_PERFORMANCE = "Overall Performance";
    static final String PERCENTAGE_GOOD_QUALITY = "Percentage Good Quality";
    static final String PV_ERROR_ABSOLUTE_AVERAGE = "PV Error Absolute Average";
    static final String PV_VARIABILITY = "PV Variability";
    static final String MOVEMENT_INDEX = "Movement Index";

    static final String PERCENTAGE_LIMITS_EXCEEDED = "Percentage Limits Exceeded";
    static final String PERCENTAGE_MANUAL = "Percentage Manual";
    static final String PERCENTAGE_CASCADE = "Percentage Cascade";
    static final String PERCENTAGE_SHUTDOWN = "Percentage Shutdown";
    static final String PERCENTAGE_AUTO = "Percentage Auto";

    static final String ASSET_NAME = "assetName";
    static final String DESCRIPTION = "description";
    static final String ASSET_URI = "assetURI";
    static final String TAG_LIST = "tagList";

    static final String TAG_NAME = "tagName";
    static final String DATA = "data";

    static final String STATUS_CODE_ERROR = "Status code not verified";
    static final String STATUS_LINE_ERROR = "Error Message Not Verified";

    static final String START_DATE = "startDate";
    static final String END_DATE = "endDate";

    static final String SEGMENT_URI = "segmentURI";
    static final String SUMMARY_ASSET_URI = "assetUri";
    static final String JSON_EXTENSION = ".json";
    static final String PAYLOAD_BASE_PATH = "src/main/resources/payloadsAndromeda/opm_data_service/";
    static final String CLPM_URL = "clpm_url";
    static final String SUMMARY_RESPONSE = "summaryResponse";
    static final String SUMMARY_TAG_LIST = "summaryResponse.tagList";
    static final String AGGREGATED_RESPONSE = "aggregatedResponse";
    static final String AGGREGATED_TAG_LIST = "aggregatedResponse.data.ts[0]";


    static final int NUMBER_OF_DAYS = 7;



}

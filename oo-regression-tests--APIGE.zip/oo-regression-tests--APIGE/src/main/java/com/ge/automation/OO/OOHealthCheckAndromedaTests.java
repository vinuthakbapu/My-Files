package com.ge.automation.OO;

import com.ge.microtester.common.utils.RestAssuredUtil;
import com.ge.microtester.rally.RallyInfo;
import com.jayway.restassured.response.Response;
import net.sf.json.JSONArray;
import net.sf.json.JSONObject;
import org.apache.http.HttpStatus;
import org.springframework.boot.test.TestRestTemplate;
import org.springframework.web.client.RestTemplate;
import org.testng.annotations.*;

import java.time.LocalDateTime;
import java.time.ZoneId;
import java.time.temporal.ChronoUnit;
import java.util.LinkedHashMap;
import java.util.Map;
import java.util.Properties;

import static org.junit.Assert.assertTrue;

@RallyInfo(ProjectName = "APM Super Optimo")
public class OOHealthCheckAndromedaTests extends RestAssuredUtil {

    static String jsonfileName;
    Properties configFile = new Properties();
    String truncateDateTime[];
    String tagName;
    String proxyHost;
    String proxyPort;
    Response responseBody;
    String kpiid;
    String kpiJobId;
    String dataSourceId;
    long kpi_id;
    long kpi_id1;
    String path = "src/main/resources/payloadsAndromeda";
    String apmTSforIngestionPath;
    boolean apmIngestionDynamicTag;
    String kpiTemplateJsonPath;
    String kpiTemplateAnalyticPath;
    String kpiJobJsonPath;
    String dataIngestionFilePath;
    String inputTag;
    String outputTag;
    String expectedValue;
    String expectedJobStatus;
    boolean createKpiJobWithTag;
    String apmTsUrl = "";

    public OOTestUtil ooTestutil = new OOTestUtil();
    RestTemplate restTemplate = new TestRestTemplate();
    // Generating Query Params
    Map<String, Object> values = new LinkedHashMap<String, Object>();

    @BeforeMethod
    public void beforeMethod() {
    }

    @AfterMethod
    public void afterMethod() {
    }

    @BeforeClass
    public void beforeClass() {

        System.getProperties().put("proxySet", "true");
        System.getProperties().put("http.proxyHost", "sjc1intproxy01.crd.ge.com");
        System.getProperties().put("http.proxyPort", "8080");
        System.getProperties().put("https.proxyHost", "sjc1intproxy01.crd.ge.com");
        System.getProperties().put("https.proxyPort", "8080");
        // getServiceResponse("alert_profile_base_url");
        setSysProperty("currentTimeStamp", "" + getCurrentTimestamp());// ${sys:currentTimeStamp}

    }// end of beforeClass

    @AfterClass
    public void afterClass() {
    }

    @BeforeTest
    public void beforeTest() {

    }// end of beforeTest

    /********************************************************************************************************************/
    // @Test(priority = 1, description = "test_ApmIngestion_ApmRetrieval")
    @RallyInfo(UserStory = "US127041")
    public void test_ApmTsIngestion_ApmTsRetrieval() throws Exception {

        // post data to apm
        int valuePosted = ooTestutil.postRandomDataPointToAPMTimeSeries(path + "/data_files/data_ingestion_gen.json",
                "OO_Tag_Pressure_ID2");
        // get data from APM
        Thread.sleep(20000);
        ooTestutil.getDataFromApmTimeSeries("OO_Tag_Pressure_ID2", String.valueOf(valuePosted));

        return;
    }

    /********************************************************************************************************************/
    @Test(priority = 2, description = "test_ApmAssetRetrieval")
    @RallyInfo(UserStory = "US127041")
    public void test_ApmAssetRetrieval() throws Exception {

        // get Asset data from APM
        ooTestutil.getAPMAssets();

        return;
    }

    /********************************************************************************************************************/
    //@Test(priority = 3, description = "testGetJobStatus")
    @RallyInfo(UserStory = "USXXXXX")
    public void testGetJobStatus() throws Exception {

        // ingest test data into apm time series
        String inputTag = "OO_Tag_Temperature_ID40";
        int valuePosted = ooTestutil.postRandomDataPointToAPMTimeSeries(path + "/data_files/data_ingestion_gen.json",
                inputTag);

        // create kpi template
        kpi_id = ooTestutil.createKpiTemplate(path + "/kpi_templates/kpi_e2e_ooapmts_inputAndOutput.json",
                path + "/kpi_analytics/simpleJavaKpiAnalytic.zip");
        Thread.sleep(10000);

        // create kpi job

        kpiJobId = ooTestutil.createKpiJobWithNoRandomBothInputAndOutputTag(
                path + "/kpi_jobs/kpi_e2e_ooapmts_inputAndOutput_1_job.json", kpi_id, "OO_Tag_Temperature_ID41",
                inputTag, "");

        // start kpi job
        String runtimeJobId = ooTestutil.startKpiJob(kpiJobId);
        Thread.sleep(20000);

        String status = ooTestutil.getStatusOfJob(kpiJobId);
        isEqual("Status is null", "200", status);

        // delete kpi job
        Thread.sleep(10000);
        ooTestutil.deleteKpiJob(kpiJobId);
        Thread.sleep(10000);
        // get status of the job
        ooTestutil.getStatusOfJob(kpiJobId);

        // DELETE KPI
        System.out.println("+++ DELETE KPI+++++++++++++++++++++++++++++++++++");
        String kpiDeleteUrl = getTestProperty("kpi_url") + "/" + kpi_id;
        System.out.println("+++ kpiDeleteUrl == " + kpiDeleteUrl);
        Response delete_response = deleteServiceResponse("kpi_url" + "/" + kpi_id, values,
                ooTestutil.kpiprovideHeaders());
        System.out.println("+++ delete_response.asString() == " + delete_response.asString());
        isEqual("Delete failed", true, delete_response.getStatusCode() == HttpStatus.SC_NO_CONTENT);

    }

    /********************************************************************************************************************/
    @Test(priority = 5, description = "testE2E_ApmTSInput_ApmTSOutput_Java")
    @RallyInfo(UserStory = "US127041")
    public void testE2E_ApmTSInput_ApmTSOutput_Java() throws Exception {

		/*
         * //zip analytic with new name //(String filePath, String zipFileName)
		 * String zipFileName =
		 * "simple_java_kpi"+ooTestutil.generateRandomNumberNonUUID()+".zip";
		 * System.out.println(
		 * "OOHealthCheckAndromedaTests.testE2E_ApmTSInput_ApmTSOutput_Java()\n"
		 * +zipFileName); ooTestutil.ZipFile(path +
		 * "/kpi_analytics/simple_java_kpi",zipFileName);
		 */

        // ingest test data into apm time series
        String inputTag = "OO_Tag_Temperature_ID14";
        String outputTag = "OO_Tag_Temperature_ID15";


        // create kpi template
        kpi_id = ooTestutil.createKpiTemplate(path + "/kpi_templates/kpi_e2e_ooapmts_inputAndOutput.json",
                path + "/kpi_analytics/simpleJavaKpiAnalytic_test9.zip");
        Thread.sleep(10000);

        // create kpi job

        kpiJobId = ooTestutil.createKpiJobWithNoRandomBothInputAndOutputTag(
                path + "/kpi_jobs/kpi_e2e_ooapmts_inputAndOutput_1_job.json", kpi_id, outputTag,
                inputTag, "");

        int valuePosted = ooTestutil.postRandomDataPointToAPMTimeSeries(path + "/data_files/data_ingestion_gen.json",
                inputTag);

        // start kpi job
        String runtimeJobId = ooTestutil.startKpiJob(kpiJobId);
        Thread.sleep(20000);
        ooTestutil.getDataFromApmTimeSeries(outputTag, String.valueOf(valuePosted * 10));

        // delete kpi job
        Thread.sleep(10000);
        ooTestutil.deleteKpiJob(kpiJobId);
        Thread.sleep(10000);
        // get status of the job
        ooTestutil.getStatusOfJob(kpiJobId);

        // DELETE KPI
        System.out.println("+++ DELETE KPI+++++++++++++++++++++++++++++++++++");
        String kpiDeleteUrl = getTestProperty("kpi_url") + "/" + kpi_id;
        System.out.println("+++ kpiDeleteUrl == " + kpiDeleteUrl);
        Response delete_response = deleteServiceResponse("kpi_url" + "/" + kpi_id, values,
                ooTestutil.kpiprovideHeaders());
        System.out.println("+++ delete_response.asString() == " + delete_response.asString());
        isEqual("Delete failed", true, delete_response.getStatusCode() == HttpStatus.SC_NO_CONTENT);

        ooTestutil.printnewLine();
    }

    /*********************************************************************************************************
     * Python Analytic - Read APM TS as input and write output to APM TS
     *
     *********************************************************************************************************/

    @Test(priority = 1, description = "testE2E_ApmTSInput_ApmTSOutput_Python")
    @RallyInfo(UserStory = "US127041")
    public void testE2E_ApmTSInput_ApmTSOutput_Python() throws Exception {

        // ingest test data into apm time series
        String sourcetag = "OO_Tag_Temperature_ID16";
        String targettag = "OO_Tag_Temperature_ID17";


        // create kpi template
        kpi_id = ooTestutil.createKpiTemplate(path + "/kpi_templates/kpi_e2e_ooapmts_inputAndOutput_python.json",
                path + "/kpi_analytics/simple_py_kpi_4.zip");
        Thread.sleep(10000);

        // create kpi job
        kpiJobId = ooTestutil.createKpiJobWithNoRandomBothInputAndOutputTag(
                path + "/kpi_jobs/kpi_e2e_ooapmts_inputAndOutput_job_python.json", kpi_id, targettag, sourcetag, "");
        Thread.sleep(10000);

        int valuePosted = ooTestutil.postRandomDataPointToAPMTimeSeries(path + "/data_files/data_ingestion_gen.json",
                sourcetag);
        Thread.sleep(10000);

        // start kpi job
        String runtimeJobId = ooTestutil.startKpiJob(kpiJobId);
        Thread.sleep(30000);


        ooTestutil.getDataFromApmTimeSeries(targettag, String.valueOf(valuePosted * 10));

        // delete kpi job
        Thread.sleep(10000);
        ooTestutil.deleteKpiJob(kpiJobId);
        Thread.sleep(10000);
        // get status of the job
        ooTestutil.getStatusOfJob(kpiJobId);

        // DELETE KPI
        System.out.println("+++ DELETE KPI+++++++++++++++++++++++++++++++++++");
        String kpiDeleteUrl = getTestProperty("kpi_url") + "/" + kpi_id;
        System.out.println("+++ kpiDeleteUrl == " + kpiDeleteUrl);
        Response delete_response = deleteServiceResponse("kpi_url" + "/" + kpi_id, values,
                ooTestutil.kpiprovideHeaders());
        System.out.println("+++ delete_response.asString() == " + delete_response.asString());
        isEqual("Delete failed", true, delete_response.getStatusCode() == HttpStatus.SC_NO_CONTENT);

        ooTestutil.printnewLine();

    }

    /********************************************************************************************************************/
    @Test(priority = 5, description = "testE2E_ApmTSInput_ApmTSOutput_translateDP_Java")
    @RallyInfo(UserStory = "US135343")
    public void testE2E_ApmTSInput_ApmTSOutput_translateDP_Java() throws Exception {

        // ingest test data into apm time series
        String inputTag = "OO_Tag_Temperature_ID18";
        String outputTag = "OO_Tag_Temperature_ID19";


        // create kpi template
        kpi_id = ooTestutil.createKpiTemplate(path + "/kpi_templates/kpi_e2e_ooapmts_inputAndOutput_1_java.json",
                path + "/kpi_analytics/simpleJavaKpiAnalytic_test10.zip");
        Thread.sleep(10000);

        // create kpi job

        kpiJobId = ooTestutil.createKpiJobWithNoRandomBothInputAndOutputTag(
                path + "/kpi_jobs/kpi_e2e_ooapmts_inputAndOutput_job_NoAsset_java.json", kpi_id, outputTag,
                inputTag, "");


        int valuePosted = ooTestutil.postRandomDataPointToAPMTimeSeries(path + "/data_files/data_ingestion_gen.json",
                inputTag);
        Thread.sleep(20000);

        // start kpi job
        String runtimeJobId = ooTestutil.startKpiJob(kpiJobId);
        Thread.sleep(30000);


        ooTestutil.getDataFromApmTimeSeries(outputTag, String.valueOf(valuePosted * 10));

        // delete kpi job
        Thread.sleep(10000);
        ooTestutil.deleteKpiJob(kpiJobId);
        Thread.sleep(10000);
        // get status of the job
        ooTestutil.getStatusOfJob(kpiJobId);

        // DELETE KPI
        System.out.println("+++ DELETE KPI+++++++++++++++++++++++++++++++++++");
        String kpiDeleteUrl = getTestProperty("kpi_url") + "/" + kpi_id;
        System.out.println("+++ kpiDeleteUrl == " + kpiDeleteUrl);
        Response delete_response = deleteServiceResponse("kpi_url" + "/" + kpi_id, values,
                ooTestutil.kpiprovideHeaders());
        System.out.println("+++ delete_response.asString() == " + delete_response.asString());
        isEqual("Delete failed", true, delete_response.getStatusCode() == HttpStatus.SC_NO_CONTENT);

        ooTestutil.printnewLine();

    }

    /*********************************************************************************************************
     * Python Analytic - Read APM TS as input and write output to APM TS
     *
     *********************************************************************************************************/

    @Test(priority = 1, description = "testE2E_ApmTSInput_ApmTSOutput_translateDP_Python")
    @RallyInfo(UserStory = "US135343")
    public void testE2E_ApmTSInput_ApmTSOutput_translateDP_Python() throws Exception {

        // ingest test data into apm time series
        String sourcetag = "OO_Tag_Temperature_ID35";
        String targettag = "OO_Tag_Temperature_ID36";

        // create kpi template
        kpi_id = ooTestutil.createKpiTemplate(path + "/kpi_templates/kpi_e2e_ooapmts_inputAndOutput_1_python.json",
                path + "/kpi_analytics/simple_py_kpi_test8.zip");
        Thread.sleep(10000);

        // create kpi job
        kpiJobId = ooTestutil.createKpiJobWithNoRandomBothInputAndOutputTag(
                path + "/kpi_jobs/kpi_e2e_ooapmts_inputAndOutput_job_NoAsset_python.json", kpi_id, targettag, sourcetag, "");
        Thread.sleep(10000);

        int valuePosted = ooTestutil.postRandomDataPointToAPMTimeSeries(path + "/data_files/data_ingestion_gen.json",
                sourcetag);

        Thread.sleep(30000);

        // start kpi job
        String runtimeJobId = ooTestutil.startKpiJob(kpiJobId);
        Thread.sleep(30000);


        ooTestutil.getDataFromApmTimeSeries(targettag, String.valueOf(valuePosted * 10));

        // delete kpi job
        Thread.sleep(10000);
        ooTestutil.deleteKpiJob(kpiJobId);
        Thread.sleep(10000);
        // get status of the job
        ooTestutil.getStatusOfJob(kpiJobId);

        // DELETE KPI
        System.out.println("+++ DELETE KPI+++++++++++++++++++++++++++++++++++");
        String kpiDeleteUrl = getTestProperty("kpi_url") + "/" + kpi_id;
        System.out.println("+++ kpiDeleteUrl == " + kpiDeleteUrl);
        Response delete_response = deleteServiceResponse("kpi_url" + "/" + kpi_id, values,
                ooTestutil.kpiprovideHeaders());
        System.out.println("+++ delete_response.asString() == " + delete_response.asString());
        isEqual("Delete failed", true, delete_response.getStatusCode() == HttpStatus.SC_NO_CONTENT);

        ooTestutil.printnewLine();

    }

    /*********************************************************************************************************/
    //@Test(priority = 1, description = "testE2E_ApmTSInput_ApmTSOutput_Scheduling_Java")
    @RallyInfo(UserStory = "USXXXX")
    public void testE2E_ApmTSInput_ApmTSOutput_Scheduling_Java() throws Exception {
        testE2E_ApmTSInput_ApmTSOutput_SchedulingWithLanguageVersion2("JAVA");
    }

    /*********************************************************************************************************/
    //@Test(priority = 1, description = "testE2E_ApmTSInput_ApmTSOutput_Scheduling_Python")
    @RallyInfo(UserStory = "USXXXX")
    public void testE2E_ApmTSInput_ApmTSOutput_Scheduling_Python() throws Exception {
        testE2E_ApmTSInput_ApmTSOutput_SchedulingWithLanguage("PYTHON");
    }

    /*********************************************************************************************************/
    private void testE2E_ApmTSInput_ApmTSOutput_SchedulingWithLanguage(String language) throws Exception {
        setSysProperty("language", language);
        // ingest test data into apm time series
        String inputTag = "OO_Tag_Temperature_ID22";
        String outputTag = "OO_Tag_Temperature_ID23";


        // create kpi template
        String analyticZipFile = "";
        if (language.equals("PYTHON")) {
            analyticZipFile = "/kpi_analytics/simplePyKpiSchedule_100.zip";
        } else if (language.equals("JAVA")) {
            analyticZipFile = "/kpi_analytics/simpleJavaKpiSchedule_100.zip";
        }

        kpi_id = ooTestutil.createKpiTemplate(path + "/kpi_templates/kpi_e2e_ooapmts_inputAndOutput.json",
                path + analyticZipFile);
        Thread.sleep(10000);

        // create kpi job

        String kpiJobFile = "";
        if (language.equals("PYTHON")) {
            kpiJobFile = "/kpi_jobs/kpi_e2e_ooapmts_inputAndOutput_job_with_scheduler.json";
        } else if (language.equals("JAVA")) {
            kpiJobFile = "/kpi_jobs/kpi_e2e_ooapmts_inputAndOutput_job_with_scheduler.json";
        }


        kpiJobId = ooTestutil.createKpiJobWithSchedulerInfo(path + kpiJobFile, kpi_id, outputTag, inputTag, "");

        // start kpi job
        String schedulerId = ooTestutil.startScheduledKpiJob(kpiJobId);

        if (schedulerId != null) {

			/* Thread.sleep(10000); JsonPath statusJson =
             ooTestutil.getStatusResponseOfJob(kpiJobId);
			 System.out.println("After 10 seconds");
			 isEqual("Job should not be running",
			 statusJson.getString("message").equals("JobNotRunning"), true);
			 
			 Thread.sleep(10000); statusJson =
			 ooTestutil.getStatusResponseOfJob(kpiJobId);
			 System.out.println("After 20 seconds");
			 isEqual("Job should not be running",
			 statusJson.getString("message").equals("JobNotRunning"), true);
			 
			 Thread.sleep(10000); statusJson =
			 ooTestutil.getStatusResponseOfJob(kpiJobId);
			 System.out.println("After 30 seconds");
			 isEqual("Job should not be running",
			 statusJson.getString("message").equals("JobNotRunning"), true);
			 
			 Thread.sleep(10000); statusJson =
			 ooTestutil.getStatusResponseOfJob(kpiJobId);
			 System.out.println("After 40 seconds");
			 isEqual("Job should not be running",
			 statusJson.getString("message").equals("JobNotRunning"), true);
			 
			 Thread.sleep(10000); statusJson =
			 ooTestutil.getStatusResponseOfJob(kpiJobId);
			 System.out.println("After 50 seconds");
			 isEqual("Job should not be running",
			 statusJson.getString("message").equals("JobNotRunning"), true);
			 
			 // get Status of the Job Thread.sleep(10000); statusJson =
			 ooTestutil.getStatusResponseOfJob(kpiJobId);
			 System.out.println("After 60 seconds");
			 isEqual("Job should not be running",
			 statusJson.getString("message").equals("JobNotRunning"), true);*/


            LocalDateTime startTime = LocalDateTime.now(ZoneId.of("UTC"));
            int valuePosted = ooTestutil.postRandomDataPointToAPMTimeSeriesWithTimestamp(path + "/data_files/data_ingestion_gen.json",
                    inputTag, startTime.plus(1, ChronoUnit.MINUTES).toString());

            Thread.sleep(80000);
            System.out.println("After 120 seconds");
            Thread.sleep(20000);
            String tsResponse = ooTestutil.getDataFromApmTimeSeriesWithTimeFilter(outputTag, startTime.toString());

            System.out.println("Value posted was " + String.valueOf(valuePosted));
            isEqual("Calculated data of APM TS is not matching expected value", true,
                    tsResponse.contains(String.valueOf(valuePosted * 10)));

            // delete kpi job
            ooTestutil.deleteKpiJob(kpiJobId);

			/*String status = ooTestutil.getStatusOfJob(kpiJobId);
            System.out.println("Status of scheduled job is " + status);
			if (status != null) {// && status.equalsIgnoreCase("FINISHED")) {
				String tsResponse = ooTestutil.getDataFromApmTimeSeriesWithTimeFilter(outputTag, startTime.toString());
				System.out.println("Value posted was " + String.valueOf(valuePosted));
				isEqual("Calculated data of APM TS is not matching expected value", true,
				tsResponse.contains(String.valueOf(valuePosted*10)));

				// delete kpi job
				ooTestutil.deleteKpiJob(kpiJobId);

			} else {
				fail("Job not Started Successfully.Status of the JOB is --->" + status);
			}*/

            // DELETE KPI
            System.out.println("+++ DELETE KPI+++++++++++++++++++++++++++++++++++");
            String kpiDeleteUrl = getTestProperty("kpi_url") + "/" + kpi_id;
            System.out.println("+++ kpiDeleteUrl == " + kpiDeleteUrl);
            Response delete_response = deleteServiceResponse("kpi_url" + "/" + kpi_id, values,
                    ooTestutil.kpiprovideHeaders());
            System.out.println("+++ delete_response.asString() == " + delete_response.asString());
            isEqual("Delete failed", true, delete_response.getStatusCode() == HttpStatus.SC_NO_CONTENT);

            ooTestutil.printnewLine();
        } else

        {
            fail("Job not scheduled. Scheduler id is null");
        }
    }

    /**
     * This is used to test scheduled job in colo dev
     * colo dev cannot schedule job, but we can get multi runtime job ids
     * so in the test we will check the runtime job id size larger than 1
     *******************************************************************************************************/
    private void testE2E_ApmTSInput_ApmTSOutput_SchedulingWithLanguageVersion2(String language) throws Exception {
        setSysProperty("language", language);
        // ingest test data into apm time series
        String inputTag = "OO_Tag_Temperature_ID22";
        String outputTag = "OO_Tag_Temperature_ID23";


        // create kpi template
        String analyticZipFile = "";
        if (language.equals("PYTHON")) {
            analyticZipFile = "/kpi_analytics/simplePyKpiSchedule_100.zip";
        } else if (language.equals("JAVA")) {
            analyticZipFile = "/kpi_analytics/simpleJavaKpiSchedule_ds100.zip";
        }

        kpi_id = ooTestutil.createKpiTemplate(path + "/kpi_templates/kpi_e2e_ooapmts_inputAndOutput.json",
                path + analyticZipFile);
        Thread.sleep(10000);

        // create kpi job

        String kpiJobFile = "";
        if (language.equals("PYTHON")) {
            kpiJobFile = "/kpi_jobs/kpi_e2e_ooapmts_inputAndOutput_job_with_scheduler.json";
        } else if (language.equals("JAVA")) {
            kpiJobFile = "/kpi_jobs/kpi_e2e_ooapmts_inputAndOutput_job_with_scheduler.json";
        }

        kpiJobId = ooTestutil.createKpiJobWithSchedulerInfoVersion2(path + kpiJobFile, kpi_id, outputTag, inputTag, "");

        // start kpi job
        String schedulerId = ooTestutil.startScheduledKpiJob(kpiJobId);

        if (schedulerId != null) {
            LocalDateTime startTime = LocalDateTime.now(ZoneId.of("UTC"));
            int valuePosted = ooTestutil.postRandomDataPointToAPMTimeSeriesWithTimestamp(path + "/data_files/data_ingestion_gen.json",
                    inputTag, startTime.plus(1, ChronoUnit.MINUTES).toString());

            Thread.sleep(80000);
            System.out.println("After 120 seconds");
            Thread.sleep(20000);

            //check job info, runtime_jobIds size should be larger than 1
            String kpijobDetailsString = ooTestutil.getKpiJob(kpiJobId);
            System.out.println("get jobdetauls is +++++++++++++++: " + kpijobDetailsString);
            JSONArray jsonArray = JSONArray.fromObject(kpijobDetailsString);
            JSONObject jsonObject = JSONObject.fromObject(jsonArray.get(0));
            JSONArray jsonArray1 = jsonObject.getJSONArray("runtime_jobIds");
            System.out.print("size is {}" + jsonArray1.size());
            assertTrue("runtime job ids size (" + jsonArray1.size() + ") should be greater than 1", jsonArray1.size() > 1);

            // delete kpi job, colo dev andromeda cannot delete scheduled job completely, so you need to manually delete job from DB
            ooTestutil.deleteKpiJob(kpiJobId);
            ooTestutil.printnewLine();
        } else

        {
            fail("Job not scheduled. Scheduler id is null");
        }
    }
    /********************************************************************************************************************
     * Test Case: Asset and StreamTS input data provider OOStream as output data
     * provider Test Steps: 1) Create Kpi Template. 2) Create Kpi Job with
     * kpireference id. 3) Start Job 4) Assert data that is written to Kafka
     * topic. /
     ********************************************************************************************************************/
    //@Test(priority = 1, description = "testE2E_AssetNStreamInputs_ApmTSOutput")
    @RallyInfo(UserStory = "US4776")
    public void testE2E_AssetNStreamInputs_ApmTSOutput() throws Exception {

        // create kpi template
        kpi_id = ooTestutil.createKpiTemplate(path + "/kpi_templates/kpiTemplate_7.json",
                path + "/kpi_analytics/simple_java_kpi_100.zip");
        Thread.sleep(10000);

        // create kpi job
        String inputTag = "OO_Tag_Temperature_ID24";
        String outputTag = "OO_Tag_Temperature_ID25";
        kpiJobId = ooTestutil.createKpiJobWithNoRandomBothInputAndOutputTag(path + "/kpi_jobs/kpiJob_7.json", kpi_id,
                outputTag, inputTag, "");
        Thread.sleep(10000);

        ooTestutil.startStreamingKpiJob(kpiJobId);
        Thread.sleep(40000);

        int valuePosted = ooTestutil
                .postDataPointToEventHubGenData(path + "/data_files/data_ingestion_gen_predixTs.json", inputTag);
        Thread.sleep(15000);
        ooTestutil.getDataFromApmTimeSeries(outputTag, String.valueOf(valuePosted * 10));
        Thread.sleep(15000);
        // stop kpi job
        ooTestutil.stopKpiJob(kpiJobId);
        // delete kpi job
        Thread.sleep(10000);
        ooTestutil.deleteKpiJob(kpiJobId);
        Thread.sleep(10000);
        // get status of the job
        ooTestutil.getStatusOfJob(kpiJobId);

        // DELETE KPI
        System.out.println("+++ DELETE KPI+++++++++++++++++++++++++++++++++++");
        String kpiDeleteUrl = getTestProperty("kpi_url") + "/" + kpi_id;
        System.out.println("+++ kpiDeleteUrl == " + kpiDeleteUrl);
        Response delete_response = deleteServiceResponse("kpi_url" + "/" + kpi_id, values,
                ooTestutil.kpiprovideHeaders());
        System.out.println("+++ delete_response.asString() == " + delete_response.asString());
        isEqual("Delete failed", true, delete_response.getStatusCode() == HttpStatus.SC_NO_CONTENT);

        ooTestutil.printnewLine();
    }

    /********************************************************************************************************************
     * Test Case: StreamTS input data provider OOStream as output data provider
     * Test Steps: 1) Create Kpi Template. 2) Create Kpi Job with kpireference
     * id. 3) Start Job 4) Assert data that is written to Kafka topic. /
     ********************************************************************************************************************/
    @Test(priority = 2, description = "testE2E_StreamInput_ApmTSOutput")
    @RallyInfo(UserStory = "DE10414")
    public void testE2E_StreamInput_ApmTSOutput() throws Exception {

        // create kpi template
        kpi_id = ooTestutil.createKpiTemplate(path + "/kpi_templates/kpiTemplate_stream_ts.json",
                path + "/kpi_analytics/simple_java_kpi_test2.zip");
        Thread.sleep(10000);

        // create kpi job
        String inputTag = "OO_Tag_Temperature_ID26";
        String outputTag = "OO_Tag_Temperature_ID27";
        kpiJobId = ooTestutil.createKpiJobWithNoRandomBothInputAndOutputTag(path + "/kpi_jobs/kpiJob_stream_ts.json", kpi_id,
                outputTag, inputTag, "");

        // start kpi job
        ooTestutil.startStreamingKpiJob(kpiJobId);
        Thread.sleep(40000);

        // post data to event hub
        int valuePosted = ooTestutil
                .postDataPointToEventHubGenData(path + "/data_files/data_ingestion_gen_predixTs.json", inputTag);
        Thread.sleep(15000);
        LocalDateTime startTime = LocalDateTime.now(ZoneId.of("UTC"));
        // get data from Apm time Series
        ooTestutil.getDataFromApmTimeSeries(outputTag, String.valueOf(valuePosted * 10));
//		ooTestutil.getDataFromApmTimeSeriesWithFilterAndValue(outputTag, startTime.toString(),String.valueOf(valuePosted * 10));
        Thread.sleep(20000);
        // stop kpi job
        ooTestutil.stopKpiJob(kpiJobId);
        // delete kpi job
        Thread.sleep(10000);
        ooTestutil.deleteKpiJob(kpiJobId);
        Thread.sleep(10000);
        // get status of the job
        ooTestutil.getStatusOfJob(kpiJobId);

        // DELETE KPI
        System.out.println("+++ DELETE KPI+++++++++++++++++++++++++++++++++++");
        String kpiDeleteUrl = getTestProperty("kpi_url") + "/" + kpi_id;
        System.out.println("+++ kpiDeleteUrl == " + kpiDeleteUrl);
        Response delete_response = deleteServiceResponse("kpi_url" + "/" + kpi_id, values,
                ooTestutil.kpiprovideHeaders());
        System.out.println("+++ delete_response.asString() == " + delete_response.asString());
        isEqual("Delete failed", true, delete_response.getStatusCode() == HttpStatus.SC_NO_CONTENT);

        ooTestutil.printnewLine();

    }

    /********************************************************************************************************************
     * Test Case: APM-TS input data provider OOStream as output data provider
     * Test Steps:1) Create Kpi Template.2) Create Kpi Job with kpireference
     * id.3) Start Job 4) Assert data that is written to Kafka topic.
     *
     ********************************************************************************************************************/
    @Test(priority = 2, description = "testE2E_ApmTSInput_StreamOutput")
    @RallyInfo(UserStory = "USXXXXX")
    public void testE2E_ApmTSInput_StreamOutput() throws Exception {

        // create kpi template
        kpi_id = ooTestutil.createKpiTemplate(path + "/kpi_templates/kpiTemplate_ts_stream.json",
                path + "/kpi_analytics/simple_1002.zip");
        Thread.sleep(10000);

        // create kpi job
        String inputTag = "OO_Tag_Temperature_ID28";
        String outputTag = "OO_OutputTag_testE2E_ApmTSInput_StreamOutput";

        kpiJobId = ooTestutil.createKpiJobWithNoRandomBothInputAndOutputTag(path + "/kpi_jobs/kpiJob_ts_stream.json", kpi_id,
                outputTag, inputTag, "");

        // start kpi job
        ooTestutil.startStreamingKpiJob(kpiJobId);
        Thread.sleep(40000);

        int valuePosted = ooTestutil.postRandomDataPointToAPMTimeSeries(path + "/data_files/data_ingestion_gen_ts_stream.json",
                inputTag);
        // get data from Apm time Series
        ooTestutil.getDataPointFromEventHub(outputTag, String.valueOf(valuePosted * 10));

        Thread.sleep(20000);
        // stop kpi job
        ooTestutil.stopKpiJob(kpiJobId);
        Thread.sleep(15000);
        // delete kpi job
        ooTestutil.deleteKpiJob(kpiJobId);
        Thread.sleep(15000);
        // get status of the job
        ooTestutil.getStatusOfJob(kpiJobId);

        // DELETE KPI
        System.out.println("+++ DELETE KPI+++++++++++++++++++++++++++++++++++");
        String kpiDeleteUrl = getTestProperty("kpi_url") + "/" + kpi_id;
        System.out.println("+++ kpiDeleteUrl == " + kpiDeleteUrl);
        Response delete_response = deleteServiceResponse("kpi_url" + "/" + kpi_id, values,
                ooTestutil.kpiprovideHeaders());
        System.out.println("+++ delete_response.asString() == " + delete_response.asString());
        isEqual("Delete failed", true, delete_response.getStatusCode() == HttpStatus.SC_NO_CONTENT);

    }

    /********************************************************************************************************************
     * Test Case: StreamTS input data provider OOStream as output data provider
     * Test Steps:1) Create Kpi Template.2) Create Kpi Job with kpireference
     * id.3) Start Job 4) Assert data that is written to Kafka topic.
     *
     ********************************************************************************************************************/
    @Test(priority = 2, description = "testE2E_StreamInput_StreamOutput")
    @RallyInfo(UserStory = "USXXXXX")
    public void testE2E_StreamInput_StreamOutput_Java() throws Exception {

        // create kpi template
        kpi_id = ooTestutil.createKpiTemplate(path + "/kpi_templates/kpiTemplate_2.json",
                path + "/kpi_analytics/simpleJavaKpiAnalytic_test11.zip");
        Thread.sleep(10000);

        // create kpi job
        String inputTag = "OO_InputTag_testE2E_StreamInput_StreamOutput_Java";
        String outputTag = "OO_OutputTag_testE2E_StreamInput_StreamOutput_Java";
        kpiJobId = ooTestutil.createKpiJobWithNoRandomBothInputAndOutputTag(path + "/kpi_jobs/kpiJob_5.json", kpi_id,
                outputTag, inputTag, "");

        // start kpi job
        ooTestutil.startStreamingKpiJob(kpiJobId);

        Thread.sleep(30000);

        // post data to event hub
        int valuePosted = ooTestutil.postDataPointToEventHubGenData(path + "/data_files/data_ingestion_gen_predixTs.json", inputTag);
        Thread.sleep(30000);

        // get data from Apm time Series
        ooTestutil.getDataPointFromEventHub(outputTag, String.valueOf(valuePosted * 10));

        Thread.sleep(40000);
        // stop kpi job
        ooTestutil.stopKpiJob(kpiJobId);
        Thread.sleep(15000);
        // delete kpi job
        ooTestutil.deleteKpiJob(kpiJobId);
        Thread.sleep(15000);
        // get status of the job
        ooTestutil.getStatusOfJob(kpiJobId);

        // DELETE KPI
        System.out.println("+++ DELETE KPI+++++++++++++++++++++++++++++++++++");
        String kpiDeleteUrl = getTestProperty("kpi_url") + "/" + kpi_id;
        System.out.println("+++ kpiDeleteUrl == " + kpiDeleteUrl);
        Response delete_response = deleteServiceResponse("kpi_url" + "/" + kpi_id, values,
                ooTestutil.kpiprovideHeaders());
        System.out.println("+++ delete_response.asString() == " + delete_response.asString());
        isEqual("Delete failed", true, delete_response.getStatusCode() == HttpStatus.SC_NO_CONTENT);

    }

    /********************************************************************************************************************
     * Test Case: StreamTS input data provider OOStream as output data provider
     * Test Steps:1) Create Kpi Template.2) Create Kpi Job with kpireference
     * id.3) Start Job 4) Assert data that is written to Kafka topic.
     *
     ********************************************************************************************************************/
    //@Test(priority = 2, description = "testE2E_StreamInput_StreamOutput_Python")
    @RallyInfo(UserStory = "USXXXXX")
    public void testE2E_StreamInput_StreamOutput_Python() throws Exception {

        // create kpi template
        kpi_id = ooTestutil.createKpiTemplate(path + "/kpi_templates/kpiTemplate_2.json",
                path + "/kpi_analytics/simple1006.zip");
        Thread.sleep(10000);

        // create kpi job
        String inputTag = "OO_InputTag_testE2E_StreamInput_StreamOutput_Python";
        String outputTag = "OO_OutputTag_testE2E_StreamInput_StreamOutput_Python";
        kpiJobId = ooTestutil.createKpiJobWithNoRandomBothInputAndOutputTag(path + "/kpi_jobs/kpiJob_6.json", kpi_id,
                outputTag, inputTag, "");

        // start kpi job
        ooTestutil.startStreamingKpiJob(kpiJobId);

        Thread.sleep(30000);

        // post data to event hub
        int valuePosted = ooTestutil.postDataPointToEventHubGenData(path + "/data_files/data_ingestion_gen_predixTs.json", inputTag);
        Thread.sleep(30000);

        // get data from Apm time Series
        ooTestutil.getDataPointFromEventHub(outputTag,  String.valueOf(valuePosted * 10));

        Thread.sleep(40000);
        // stop kpi job
        ooTestutil.stopKpiJob(kpiJobId);
        Thread.sleep(15000);
        // delete kpi job
        ooTestutil.deleteKpiJob(kpiJobId);
        Thread.sleep(15000);
        // get status of the job
        ooTestutil.getStatusOfJob(kpiJobId);

        // DELETE KPI
        System.out.println("+++ DELETE KPI+++++++++++++++++++++++++++++++++++");
        String kpiDeleteUrl = getTestProperty("kpi_url") + "/" + kpi_id;
        System.out.println("+++ kpiDeleteUrl == " + kpiDeleteUrl);
        Response delete_response = deleteServiceResponse("kpi_url" + "/" + kpi_id, values,
                ooTestutil.kpiprovideHeaders());
        System.out.println("+++ delete_response.asString() == " + delete_response.asString());
        isEqual("Delete failed", true, delete_response.getStatusCode() == HttpStatus.SC_NO_CONTENT);

    }

    /*********************************************************************************************************
     * Python Analytic - Forecasting Model and Streaming Job
     *
     *********************************************************************************************************/

    //@Test(priority = 1, description = "testE2E_ForeCastingModel_StreamingJob")
    @RallyInfo(UserStory = "USXXXXX")
    public void testE2E_ForeCastingModel_StreamingJob() throws Exception {

        // ingest test data into apm time series
        String sourcetag = "OO_Tag_Temperature_ID26";
        String targettag = "OO_Tag_Temperature_ID27";


        //***************************Forecasting Model***************************//

        // create kpi template
        kpi_id = ooTestutil.createKpiTemplate(path + "/kpi_templates/kpi_payload_ML.json",
                path + "/kpi_analytics/forecastMl_14.zip");
        Thread.sleep(10000);

        // create kpi job
        kpiJobId = ooTestutil.createKpiJobWithNoRandomBothInputAndOutputTag(
                path + "/kpi_jobs/job_payload_ML.json", kpi_id, targettag, sourcetag, "");
        Thread.sleep(10000);

        // Deploy Forecasting Model
        String runtimeJobId = ooTestutil.startKpiJob(kpiJobId);
        Thread.sleep(10000);

        // DELETE KPI
        System.out.println("+++ DELETE KPI+++++++++++++++++++++++++++++++++++");
        String kpiDeleteUrl = getTestProperty("kpi_url") + "/" + kpi_id;
        System.out.println("+++ kpiDeleteUrl == " + kpiDeleteUrl);
        Response delete_response = deleteServiceResponse("kpi_url" + "/" + kpi_id, values,
                ooTestutil.kpiprovideHeaders());
        System.out.println("+++ delete_response.asString() == " + delete_response.asString());
        isEqual("Delete failed", true, delete_response.getStatusCode() == HttpStatus.SC_NO_CONTENT);

        //***************************Start Streaming Job***************************//

        // create kpi template
        kpi_id = ooTestutil.createKpiTemplate(path + "/kpi_templates/kpi_payload_streaming.json",
                path + "/kpi_analytics/predict_14.zip");
        Thread.sleep(10000);

        // create kpi job
        kpiJobId = ooTestutil.createKpiJobWithNoRandomBothInputAndOutputTag(
                path + "/kpi_jobs/job_payload_streaming.json", kpi_id, targettag, sourcetag, "");
        Thread.sleep(10000);

        // start kpi job
        ooTestutil.startStreamingKpiJob(kpiJobId);

        Thread.sleep(30000);

        // post data to event hub
        int valuePosted = ooTestutil
                .postDataPointToEventHubGenData(path + "/data_files/data_ingestion_gen_forecast.json", sourcetag);
        Thread.sleep(40000);

        // get data from Apm time Series
        ooTestutil.getDataPointFromEventHub(targettag, String.valueOf(valuePosted * 10));
        Thread.sleep(30000);

        // delete kpi job
        Thread.sleep(10000);
        ooTestutil.deleteKpiJob(kpiJobId);
        Thread.sleep(10000);
        // get status of the job
        ooTestutil.getStatusOfJob(kpiJobId);

        // DELETE KPI
        System.out.println("+++ DELETE KPI+++++++++++++++++++++++++++++++++++");
        kpiDeleteUrl = getTestProperty("kpi_url") + "/" + kpi_id;
        System.out.println("+++ kpiDeleteUrl == " + kpiDeleteUrl);
        delete_response = deleteServiceResponse("kpi_url" + "/" + kpi_id, values,
                ooTestutil.kpiprovideHeaders());
        System.out.println("+++ delete_response.asString() == " + delete_response.asString());
        isEqual("Delete failed", true, delete_response.getStatusCode() == HttpStatus.SC_NO_CONTENT);

        ooTestutil.printnewLine();

    }

    /********************************************************************************************************************/


    @AfterTest
    public void afterTest() {
    }

    @BeforeSuite
    public void beforeSuite() {

    }

    @AfterSuite
    public void afterSuite() {
    }
}

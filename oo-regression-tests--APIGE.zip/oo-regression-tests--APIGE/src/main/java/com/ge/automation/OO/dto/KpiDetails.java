package com.ge.automation.OO.dto;

import java.util.LinkedHashSet;
import java.util.Map;
import java.util.Set;

import com.ge.oo.commons.datasources.DSSpecification;
import com.ge.oo.commons.types.global.Language;
import com.ge.oo.commons.types.kpi.DeploymentInfo;

/**
 * This class represents the DTO for KPI details in this PORT
 * @author 212546754
 * @version 1.0.0
 * @since 1.0.0
 */
public class KpiDetails {
    private long id;
    private String name;
    private String tenant;
    private long dateCreated;
    private String createdBy;
    private long dateLastUpdated;
    private String lastUpdatedBy;
    private int currentVersion;
    private DeploymentInfo deploymentInfo;
    private Map<String, String> category;
    private Language language;

    private Set<DSSpecification<String>> inputs = new LinkedHashSet<DSSpecification<String>>();
    private Set<DSSpecification<String>> outputs = new LinkedHashSet<DSSpecification<String>>();
    //private Set<DSSpecification<String>> category = new LinkedHashSet<DSSpecification<String>>();

    public long getId() {
        return id;
    }

    public void setId(long id) {
        this.id = id;
    }

    public long getDateCreated() {
        return dateCreated;
    }

    public void setDateCreated(long dateCreated) {
        this.dateCreated = dateCreated;
    }

    public String getCreatedBy() {
        return createdBy;
    }

    public void setCreatedBy(String createdBy) {
        this.createdBy = createdBy;
    }

    public long getDateLastUpdated() {
        return dateLastUpdated;
    }

    public void setDateLastUpdated(long dateLastUpdated) {
        this.dateLastUpdated = dateLastUpdated;
    }

    public String getLastUpdatedBy() {
        return lastUpdatedBy;
    }

    public void setLastUpdatedBy(String lastUpdatedBy) {
        this.lastUpdatedBy = lastUpdatedBy;
    }

    public int getCurrentVersion() {
        return currentVersion;
    }

    public void setCurrentVersion(int currentVersion) {
        this.currentVersion = currentVersion;
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public String getTenant() {
        return tenant;
    }

    public void setTenant(String tenant) {
        this.tenant = tenant;
    }

    public Set<DSSpecification<String>> getInputs() {
        return inputs;
    }

    public void setInputs(Set<DSSpecification<String>> inputs) {
        this.inputs = inputs;
    }

    public Map<String, String> getCategory() {
        return category;
    }

    public void setCategory(Map<String, String> category) {
        this.category = category;
    }

    public Set<DSSpecification<String>> getOutputs() {
        return outputs;
    }

    public void setOutputs(Set<DSSpecification<String>> outputs) {
        this.outputs = outputs;
    }

    public DeploymentInfo getDeploymentInfo() {
        return deploymentInfo;
    }

    public void setDeploymentInfo(DeploymentInfo deploymentInfo) {
        this.deploymentInfo = deploymentInfo;
    }

    public Language getLanguage() {
        return language;
    }

    public void setLanguage(Language language) {
        this.language = language;
    }

    public String toString() {
        String temp = null;
        temp = "id=" + id + "\t" + "name=" + name + "\t" + "tenant=" + tenant;
        return temp;
    }


	
	/*public static KpiDetails fromKpiDefinition(KpiDefinition kpiDefinition) {
        KpiDetails rest = new KpiDetails();
		rest.setId(kpiDefinition.getId());
		rest.setName(kpiDefinition.getName());
		rest.setTaxonomy(kpiDefinition.getTaxonomy());
		rest.setVersion(kpiDefinition.getVersion());
		
		
		
		rest.setInputs(kpiDefinition.getInputs());
		rest.setOutputs(kpiDefinition.getOutputs());
		rest.setJobDetails(kpiDefinition.getJob());

		//BeanUtils.copyProperties(kpi, rest);
		return rest;
	}

	public KpiDefinition toKpiDefinition() {
		KpiDefinition transferObject = new KpiDefinition();
		transferObject.setName(this.getName());
		transferObject.setVersion(this.getVersion());
		transferObject.setTaxonomy(this.getTaxonomy());
		
		transferObject.setInputs(this.getInputs());
		transferObject.setOutputs(this.getOutputs());
		transferObject.setJob(this.getJob());
		
		//BeanUtils.copyProperties(this, transferObject);
		return transferObject;
	}
	*/
}

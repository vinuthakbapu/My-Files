package com.ge.automation.OO.metaDataTest;

import com.ge.automation.OO.OOTestUtil;
import com.jayway.restassured.path.json.JsonPath;
import com.jayway.restassured.response.Response;

import java.io.IOException;
import java.net.URISyntaxException;
import java.util.LinkedHashMap;

import static com.ge.microtester.common.core.GETestNGFramework.isEqual;
import static com.ge.microtester.common.utils.FileUtil.generateFile;
import static com.ge.microtester.common.utils.RestAssuredUtil.*;

public class MetaDataTestUtil {

    OOTestUtil ooTestUtil = new OOTestUtil();

    public Response updateMetaData(Response getGeoMetaDataServiceResponse, String payloadPath, String dataToBeUpdated) throws IOException, URISyntaxException {

        JsonPath jsonPath = new JsonPath(getGeoMetaDataServiceResponse.asString());
        String configID = jsonPath.getString("id");
        setSysProperty("dateCreated",jsonPath.getString("dateCreated"));
        setSysProperty("createdBy",jsonPath.getString("createdBy"));
        setSysProperty("lastUpdatedBy", getTestProperty("username"));
        setSysProperty("id", configID);
        setSysProperty("appName", jsonPath.getString("appName"));
        setSysProperty("featureName", jsonPath.getString("featureName"));
        setSysProperty("language", jsonPath.getString("language"));
        setSysProperty("tenant", getTestProperty("tenantUUID"));
        int currentVersion = jsonPath.getInt("currentVersion");

        setSysProperty("currentVersion", String.valueOf(currentVersion));

        setSysProperty("dataToBeUpdated", dataToBeUpdated);

        LinkedHashMap<String, Object> queryParameters = new LinkedHashMap<>();

        String updatePayload = generateFile(payloadPath, "update_meta_data");

        Response response = putServiceResponse(updatePayload,"meta_data_url"+"/tenant/"+configID,queryParameters,ooTestUtil.kpiprovideHeaders());

        return response;
    }

    private void setAttributesToReplace( String appName, String featureName){

        setSysProperty("tenant", getTestProperty("tenantUUID"));
        setSysProperty("featureName", featureName);
        setSysProperty("appName", appName);

    }

    private LinkedHashMap getConfigQueryParams(String[] language){
        LinkedHashMap<String, Object> queryParameters = new LinkedHashMap<>();
        if(language.length>0) {
            queryParameters.put("language",language[0]);
            setSysProperty("language",language[0]);
        }else {
            setSysProperty("language","en_US");
        }
        return  queryParameters;

    }

    private String composeGetConfigEndpoint(String type, String appName, String featureName, int...versionNo){
        if(type.equals("master")){
            if(versionNo.length>0){
                setSysProperty("currentVersion",String.valueOf(versionNo[0]));
            }else {
                setSysProperty("currentVersion",String.valueOf(1));
            }
        }{
            setSysProperty("currentVersion",String.valueOf(0));
        }
        if(versionNo.length>0){

            return "meta_data_url"+"/"+type+"/"+appName+"/"+featureName+"/"+versionNo[0];
        }
        return "meta_data_url"+"/"+type+"/"+appName+"/"+featureName;

    }

    public Response getConfig(String type, String appName, String featureName, int expectedStatusCode,String ... language) throws IOException, URISyntaxException {

        setAttributesToReplace(appName,featureName);
        Response getConfigServiceResponse =getServiceResponse(composeGetConfigEndpoint(type,appName,featureName), getConfigQueryParams(language), ooTestUtil.kpiprovideHeaders()) ;
        isEqual("getMasterConfigService is not successful",expectedStatusCode,getConfigServiceResponse.statusCode());
        return getConfigServiceResponse;

    }

    public Response getMasterConfigOfParticularVersion(String type, String appName, String featureName, int expectedStatusCode,int versionNo) throws IOException, URISyntaxException {
        setAttributesToReplace(appName,featureName);
        Response getConfigServiceResponse =getServiceResponse(composeGetConfigEndpoint(type,appName,featureName,versionNo), ooTestUtil.kpiprovideHeaders()) ;
        isEqual("getMasterConfigService is not successful",expectedStatusCode,getConfigServiceResponse.statusCode());
        return getConfigServiceResponse;

    }

    public Response createTenantConfig(String payloadPath,int expectedStatusCode) throws IOException, URISyntaxException {

        String create_meta_data = generateFile(payloadPath, "create_meta_data");
        Response createConfigServiceResponse =postServiceResponse(create_meta_data,"meta_data_url"+"/"+"tenant"+"/", ooTestUtil.kpiprovideHeaders()) ;
        isEqual("getMasterConfigService is not successful",expectedStatusCode,createConfigServiceResponse.statusCode());
        return createConfigServiceResponse;
    }


}

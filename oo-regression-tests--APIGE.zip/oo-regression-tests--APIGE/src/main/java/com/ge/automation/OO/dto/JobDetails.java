package com.ge.automation.OO.dto;

import java.util.LinkedHashSet;
import java.util.Set;

import javax.validation.constraints.NotNull;
import javax.validation.constraints.Size;

import com.ge.oo.commons.datasources.DSSpecification;

public class JobDetails {
	private long id;
	private long dateCreated;
	private String createdBy;
	private long dateLastUpdated;
	private String lastUpdatedBy;
	private int currentVersion;
	@NotNull
	private String runtime;
	private String runtime_jobId;
	private String runtime_jobIds;
	@NotNull
	private String kpiReferenceId;
	private String kpiReference;
	private String language;
	private String tenant;
	
	@NotNull
	@Size(min = 1,max=10)
	private Set<DSSpecification<String>> inputs = new LinkedHashSet<DSSpecification<String>>();
	
	@NotNull
	@Size(min = 1,max=10)
	private Set<DSSpecification<String>> outputs = new LinkedHashSet<DSSpecification<String>>();
	
	public long getId() {
		return id;
	}
	public void setId(long id) {
		this.id = id;
	}

	public long getDateCreated() {
		return dateCreated;
	}
	public void setDateCreated(long dateCreated) {
		this.dateCreated = dateCreated;
	}
	public String getCreatedBy() {
		return createdBy;
	}
	public void setCreatedBy(String createdBy) {
		this.createdBy = createdBy;
	}
	public long getDateLastUpdated() {
		return dateLastUpdated;
	}
	public void setDateLastUpdated(long dateLastUpdated) {
		this.dateLastUpdated = dateLastUpdated;
	}
	public String getLastUpdatedBy() {
		return lastUpdatedBy;
	}
	public void setLastUpdatedBy(String lastUpdatedBy) {
		this.lastUpdatedBy = lastUpdatedBy;
	}
	public int getCurrentVersion() {
		return currentVersion;
	}
	public void setCurrentVersion(int currentVersion) {
		this.currentVersion = currentVersion;
	}
	public String getRuntime() {
		return runtime;
	}
	public void setRuntime(String runtime) {
		this.runtime = runtime;
	}
	public String getRuntime_jobId() {
		return runtime_jobId;
	}
	public void setRuntime_jobId(String runtime_jobId) {
		this.runtime_jobId = runtime_jobId;
	}
	public String getRuntime_jobIds() {
		return runtime_jobIds;
	}
	public void setRuntime_jobIds(String runtime_jobIds) {
		this.runtime_jobIds = runtime_jobIds;
	}
	public String getKpiReferenceId() {
		return kpiReferenceId;
	}
	public void setKpiReferenceId(String kpiReferenceId) {
		this.kpiReferenceId = kpiReferenceId;
	}
	public String getKpiReference() {
		return kpiReference;
	}
	public void setKpiReference(String kpiReference) {
		this.kpiReference = kpiReference;
	}
	public String getLanguage() {
		return language;
	}
	public void setLanguage(String language) {
		this.language = language;
	}
	public String getTenant() {
		return tenant;
	}
	public void setTenant(String tenant) {
		this.tenant = tenant;
	}
	public Set<DSSpecification<String>> getInputs() {
		return inputs;
	}
	public void setInputs(Set<DSSpecification<String>> inputs) {
		this.inputs = inputs;
	}
	public Set<DSSpecification<String>> getOutputs() {
		return outputs;
	}
	public void setOutputs(Set<DSSpecification<String>> outputs) {
		this.outputs = outputs;
	}
	
	
}
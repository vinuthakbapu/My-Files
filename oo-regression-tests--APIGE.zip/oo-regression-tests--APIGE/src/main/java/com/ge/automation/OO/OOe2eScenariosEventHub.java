package com.ge.automation.OO;

import com.ge.oo.commons.utils.StringUtils;

import com.ge.microtester.common.utils.RestAssuredUtil;
import com.ge.microtester.rally.RallyInfo;

import com.jayway.restassured.path.json.JsonPath;
import com.jayway.restassured.response.Response;

import org.apache.commons.io.FileUtils;
import org.apache.http.HttpStatus;
import org.springframework.boot.test.TestRestTemplate;
import org.springframework.web.client.RestTemplate;
import org.testng.annotations.AfterClass;
import org.testng.annotations.AfterMethod;
import org.testng.annotations.AfterSuite;
import org.testng.annotations.AfterTest;
import org.testng.annotations.BeforeClass;
import org.testng.annotations.BeforeMethod;
import org.testng.annotations.BeforeSuite;
import org.testng.annotations.BeforeTest;
import org.testng.annotations.Test;

import java.io.File;
import java.time.Instant;
import java.util.LinkedHashMap;
import java.util.Map;
import java.util.Properties;

@RallyInfo(ProjectName = "Operations Optimization Execution", FolderPath = "OO/Q4Release")
public class OOe2eScenariosEventHub extends RestAssuredUtil {

	static String jsonfileName;
	Properties configFile = new Properties();
	String truncateDateTime[];
	String tagName;
	String proxyHost;
	String proxyPort;
	Response responseBody;
	String kpiid;
	String kpiJobId;
	String dataSourceId;
	long kpi_id;
	long kpi_id1;
	String path = "src/main/resources/payloadsEventHub";
	String apmTSforIngestionPath;
	boolean apmIngestionDynamicTag;
	String kpiTemplateJsonPath;
	String kpiTemplateAnalyticPath;
	String kpiJobJsonPath;
	String dataIngestionFilePath;
	String inputTag;
	String outputTag;
	String expectedValue;
	String expectedJobStatus;
	boolean createKpiJobWithTag;
	String apmTsUrl = "";

	public OOTestUtil ooTestutil = new OOTestUtil();
	RestTemplate restTemplate = new TestRestTemplate();
	// Generating Query Params
	Map<String, Object> values = new LinkedHashMap<String, Object>();

	@BeforeMethod
	public void beforeMethod() {
	}

	@AfterMethod
	public void afterMethod() {
	}

	@BeforeClass
	public void beforeClass() {

		System.getProperties().put("proxySet", "true");
		System.getProperties().put("http.proxyHost", "sjc1intproxy01.crd.ge.com");
		System.getProperties().put("http.proxyPort", "8080");
		System.getProperties().put("https.proxyHost", "sjc1intproxy01.crd.ge.com");
		System.getProperties().put("https.proxyPort", "8080");
		// getServiceResponse("alert_profile_base_url");
		setSysProperty("currentTimeStamp", "" + getCurrentTimestamp());// ${sys:currentTimeStamp}

	}// end of beforeClass

	@AfterClass
	public void afterClass() {
	}

	@BeforeTest
	public void beforeTest() {

	}// end of beforeTest

	/********************************************************************************************************************
	 * Test Case: StreamTS and AssetDS input data providers OOStream as output
	 * data providers Test Steps: 1) Create Kpi Template. 2) Create Kpi Job with
	 * kpireference id. 3) Start Job 4) Assert data that is written to Kafka
	 * topic.
	 ********************************************************************************************************************/
	@Test(priority = 1, description = "testE2E_AssetNStreamInputs_StreamOutput")
	@RallyInfo(UserStory = "USXXXXX")
	public void testE2E_AssetNStreamInputs_StreamOutput() throws Exception {

		// create kpi template
		kpi_id = ooTestutil.createKpiTemplate("src/main/resources/payloadsEventHub/kpi_templates/kpiTemplate_1.json",
				"src/main/resources/payloadsEventHub/kpi_analytics_1/analytic_1.zip");

		// create kpi job
		String inputTag = "OO_Tag_Temperature_ID40";
		kpiJobId = ooTestutil.createKpiJobWithNoRandomBothInputAndOutputTag(
				"src/main/resources/payloadsEventHub/kpi_jobs/kpiJob_1.json", kpi_id, "OO_Tag_Temperature_ID41",
				inputTag, "");
		// start job
		String runtimeJobId = ooTestutil.startKpiJob(kpiJobId);
		Thread.sleep(15000);
		if (runtimeJobId == null) {
			runtimeJobId = ooTestutil.startKpiJob(kpiJobId);
			Thread.sleep(15000);
		}
		if (runtimeJobId != null) {
			// get status of the job
			String status = ooTestutil.getStatusOfJob(kpiJobId);
			Thread.sleep(30000);

			if (status.equalsIgnoreCase("Running")) {
				// get output tag from Kpi Job response
				String InputtagNamePosted = ooTestutil.getInputtagOfKpiJob(kpiJobId);
				Thread.sleep(10000);

				ooTestutil.postDataPointToEventHubNoRandomTag(
						"src/main/resources/payloadsEventHub/data_files/data_ingestion_1.json", InputtagNamePosted);
				// ooTestutil.postDataPointToKafkaTopicNoRandomTag("src/main/resources/payloadsEventHub/data_files/data_ingestion_1.json",InputtagNamePosted);

				Thread.sleep(30000);

				// get output tag from Kpi Job response
				String OutputtagNamePosted = ooTestutil.getOutputtagOfKpiJob(kpiJobId);
				Thread.sleep(10000);

				String calculatedData = ooTestutil.getDataPointFromKafkaTopic(OutputtagNamePosted);

				// Assert if the Analytic calculated data posted to event hub
				isEqual("Data not calculated", "2009.99", calculatedData);
				if (calculatedData.equalsIgnoreCase("2009.99")) {
					System.out.println("+++ Test Passed== testE2E_AssetNStreamInputs_StreamOutput");
				}

				// data saved to Apm TS by Analytic consumer
				// ooTestutil.getDataFromApmTimeSeries(OutputtagNamePosted,
				// "2009.99");

				// delete kpi job
				ooTestutil.deleteKpiJob(kpiJobId);

				// get status of kpi job
				ooTestutil.getStatusOfJob(kpiJobId);
				Thread.sleep(10000);
			} else {
				isEqual("Job not Started Successfully.Status of the JOB is --->" + status, true, false);
			}
		} else {
			isEqual("Job not Started Successfully.Status of the JOB is --->" + runtimeJobId, true, false);
		}
	}

	/********************************************************************************************************************
	 * Test Case: StreamTS input data provider OOStream as output data provider
	 * Test Steps: 1) Create Kpi Template. 2) Create Kpi Job with kpireference
	 * id. 3) Start Job 4) Assert data that is written to Kafka topic. /
	 ********************************************************************************************************************/
	@Test(priority = 2, description = "testE2E_StreamInput_StreamOutput")
	@RallyInfo(UserStory = "US28339")
	public void testE2E_StreamInput_StreamOutput() throws Exception {

		// create kpi template
		kpi_id = ooTestutil.createKpiTemplate("src/main/resources/payloadsEventHub/kpi_templates/kpiTemplate_2.json",
				"src/main/resources/payloadsEventHub/kpi_analytics_1/analytic_2.zip");
		// create kpijob
		// kpiJobId =
		// ooTestutil.createKpiJob("src/main/resources/payloadsEventHub/kpi_jobs/kpiJob_2.json",kpi_id);

		// create kpi job
		String inputTag = "OO_Tag_LIGHTSPEED";
		kpiJobId = ooTestutil.createKpiJobWithInputAndOutputTag(
				"src/main/resources/payloadsEventHub/kpi_jobs/kpiJob_2.json", kpi_id, "Output_OO_LIGHTSPEED", inputTag);
		// Thread.sleep(60000);
		// String InputtagNamePosted = ooTestutil.getInputtagOfKpiJob(kpiJobId);
		// ooTestutil.postDataPointToKafkaTopicNoRandomTag("src/main/resources/payloadsEventHub/data_files/data_ingestion_ts.json",InputtagNamePosted);
		// start kpi job

		String runtimeJobId = ooTestutil.startKpiJob(kpiJobId);
		Thread.sleep(15000);
		if (runtimeJobId == null) {
			runtimeJobId = ooTestutil.startKpiJob(kpiJobId);
			Thread.sleep(15000);
		}
		if (runtimeJobId != null) {
			// status of the job
			String status = ooTestutil.getStatusOfJob(kpiJobId);
			Thread.sleep(30000);

			if (status.equalsIgnoreCase("Running")) {
				// get output tag from Kpi Job response
				String InputtagNamePosted = ooTestutil.getInputtagOfKpiJob(kpiJobId);
				Thread.sleep(10000);

				ooTestutil.postDataPointToEventHubNoRandomTag(
						"src/main/resources/payloadsEventHub/data_files/data_ingestion_ts.json", InputtagNamePosted);
				// ooTestutil.postDataPointToKafkaTopicNoRandomTag("src/main/resources/payloadsEventHub/data_files/data_ingestion_ts.json",InputtagNamePosted);

				Thread.sleep(30000);

				// get output tag from Kpi Job response
				String OutputtagNamePosted = ooTestutil.getOutputtagOfKpiJob(kpiJobId);
				Thread.sleep(10000);

				String calculatedData = ooTestutil.getDataPointFromKafkaTopic(OutputtagNamePosted);
				Thread.sleep(10000);

				// Assert if the Analytic calculated data posted to event hub
				isEqual("Data not calculated", "900.1515270590845", calculatedData);
				System.out.println("calculated data=" + calculatedData);
				if (calculatedData.equalsIgnoreCase("900.1515270590845")) {
					System.out.println("+++ Test Passed== testE2E_StreamInput_StreamOutput");

				}
				// data posted to APM TS by Analytic Consumer
				// ooTestutil.getDataFromApmTimeSeries(OutputtagNamePosted,
				// "180.0303054118169");

				// delete kpi job
				ooTestutil.deleteKpiJob(kpiJobId);
				Thread.sleep(10000);

				// get status of the job
				ooTestutil.getStatusOfJob(kpiJobId);
				Thread.sleep(10000);
			} else {
				isEqual("Job not Started Successfully.Status of the JOB is --->" + status, true, false);
			}
		} else {
			isEqual("Job not Started Successfully.Status of the JOB is --->" + runtimeJobId, true, false);
		}
	}

	/********************************************************************************************************************
	 * Test Case: StreamTS input data provider OOStream as output data provider
	 * Analytic without Output Tag. Kpi Job specifies Output tag Test Steps: 1)
	 * Create Kpi Template. 2) Create Kpi Job with kpireference id. 3) Start Job
	 * 4) Assert data that is written to Kafka topic. /
	 ********************************************************************************************************************/
	@Test(priority = 3, description = "testE2E_StreamInput_StreamOutputWithConfiguredTag")
	@RallyInfo(UserStory = "US8804")
	public void testE2E_StreamInput_StreamOutputWithConfiguredTag() throws Exception {

		// create kpi template
		kpi_id = ooTestutil.createKpiTemplate("src/main/resources/payloadsEventHub/kpi_templates/kpiTemplate_3.json",
				"src/main/resources/payloadsEventHub/kpi_analytics_1/analytic_3.zip");
		Thread.sleep(10000);

		// create kpi job
		String inputTag = "OO_Tag_AIRDENSITY_ID";
		kpiJobId = ooTestutil.createKpiJobWithInputAndOutputTag(
				"src/main/resources/payloadsEventHub/kpi_jobs/kpiJob_3.json", kpi_id, "Output_OO_Tag_AIRDENSITY",
				inputTag);
		Thread.sleep(10000);

		// start kpi job
		String runtimeJobId = ooTestutil.startKpiJob(kpiJobId);
		Thread.sleep(15000);
		if (runtimeJobId == null) {
			runtimeJobId = ooTestutil.startKpiJob(kpiJobId);
			Thread.sleep(15000);
		}
		if (runtimeJobId != null) {
			// get Status of the job
			String status = ooTestutil.getStatusOfJob(kpiJobId);
			Thread.sleep(30000);

			if (status.equalsIgnoreCase("Running")) {
				// OO_Tag_AIRDENSITY
				// post data to event hub

				// get output tag from Kpi Job response
				String InputtagNamePosted = ooTestutil.getInputtagOfKpiJob(kpiJobId);
				Thread.sleep(10000);

				ooTestutil.postDataPointToEventHubNoRandomTag(
						"src/main/resources/payloadsEventHub/data_files/data_ingestion_3.json", InputtagNamePosted);
				// ooTestutil.postDataPointToKafkaTopicNoRandomTag("src/main/resources/payloadsEventHub/data_files/data_ingestion_3.json",InputtagNamePosted);

				Thread.sleep(30000);

				// get output tag from Kpi Job response
				String OutputtagNamePosted = ooTestutil.getOutputtagOfKpiJob(kpiJobId);
				Thread.sleep(10000);

				// get data from Kafka topic
				String calculatedData = ooTestutil.getDataPointFromKafkaTopic(OutputtagNamePosted);

				// Assert if the Analytic calculated data posted to event hub
				isEqual("Data not calculated", "509.99", calculatedData);
				if (calculatedData.equalsIgnoreCase("509.99")) {
					System.out.println("+++ Test Passed== testE2E_StreamInput_StreamOutputWithConfiguredTag");
				}

				// get data from Apm Ts
				// ooTestutil.getDataFromApmTimeSeries(OutputtagNamePosted,
				// "509.99");
				// Thread.sleep(30000);

				// delete kpi job
				ooTestutil.deleteKpiJob(kpiJobId);
				Thread.sleep(10000);

				// get status of the job
				ooTestutil.getStatusOfJob(kpiJobId);
				Thread.sleep(10000);
			} else {
				isEqual("Job not Started Successfully.Status of the JOB is --->" + status, true, false);
			}
		} else {
			isEqual("Job not Started Successfully.Status of the JOB is --->" + runtimeJobId, true, false);
		}
	}

	/********************************************************************************************************************
	 * Test Case: StreamTS and AssetDs input data providers OOStream as output
	 * data provider Analytic Calculation based on Attributes Test Steps: 1)
	 * Create Kpi Template. 2) Create Kpi Job with kpireference id. 3) Start Job
	 * 4) Assert data that is written to Kafka topic.
	 * 
	 * /
	 ********************************************************************************************************************/
	@Test(priority = 5, description = "testE2E_AssetNStreamInputs_StreamOutput_WithAttributes")
	@RallyInfo(UserStory = "US33399")
	public void testE2E_AssetNStreamInputs_StreamOutput_WithAttributes() throws Exception {

		// create kpi template
		kpi_id = ooTestutil.createKpiTemplate("src/main/resources/payloadsEventHub/kpi_templates/kpiTemplate_5.json",
				"src/main/resources/payloadsEventHub/kpi_analytics_1/analytic_5.zip");
		Thread.sleep(10000);

		// create kpi job
		String inputTag = "OO_Tag_Temperature_ID40";
		kpiJobId = ooTestutil.createKpiJobWithInputAndOutputTag(
				"src/main/resources/payloadsEventHub/kpi_jobs/kpiJob_5.json", kpi_id, "OO_Tag_Temperature_ID41",
				inputTag);
		Thread.sleep(10000);

		// start kpi job
		String runtimeJobId = ooTestutil.startKpiJob(kpiJobId);
		Thread.sleep(30000);
		if (runtimeJobId == null) {
			runtimeJobId = ooTestutil.startKpiJob(kpiJobId);
			Thread.sleep(15000);
		}
		if (runtimeJobId != null) {
			// get status of the job
			String status = ooTestutil.getStatusOfJob(kpiJobId);
			Thread.sleep(30000);

			if (status.equalsIgnoreCase("Running")) {

				String InputtagNamePosted = ooTestutil.getInputtagOfKpiJob(kpiJobId);
				// post data to event hub
				ooTestutil.postDataPointToEventHubNoRandomTag(
						"src/main/resources/payloadsEventHub/data_files/data_ingestion_ts_attributes.json",
						InputtagNamePosted);
				// ooTestutil.postDataPointToKafkaTopicNoRandomTag("src/main/resources/payloadsEventHub/data_files/data_ingestion_ts_attributes.json",InputtagNamePosted);

				Thread.sleep(10000);

				// get outtag from kpi job response
				String OutputtagNamePosted = ooTestutil.getOutputtagOfKpiJob(kpiJobId);
				Thread.sleep(20000);

				// get data from Kafka topic
				String calculatedData = ooTestutil.getDataPointFromKafkaTopic(OutputtagNamePosted);

				Thread.sleep(20000);
				// Assert if the Analytic calculated data posted to event hub
				isEqual("Data not calculated", "6878.651281927272", calculatedData);
				System.out.println("calculated data=" + calculatedData);
				if (calculatedData.equalsIgnoreCase("6878.651281927272")) {
					System.out.println("+++ Test Passed== testE2E_AssetNStreamInputs_StreamOutput_WithAttributes");
				}

				// get data from APM time series
				// ooTestutil.getDataFromApmTimeSeries(OutputtagNamePosted,
				// "6878.651281927272");
				// Thread.sleep(10000);

				// delete kpi job
				ooTestutil.deleteKpiJob(kpiJobId);
				Thread.sleep(10000);

				// get status of the job
				ooTestutil.getStatusOfJob(kpiJobId);

				Thread.sleep(10000);
			} else {
				isEqual("Job not Started Successfully.Status of the JOB is --->" + status, true, false);
			}
		} else {
			isEqual("Job not Started Successfully.Status of the JOB is --->" + runtimeJobId, true, false);
		}
	}

	/*********************************************************************************************************/

	@Test(priority = 6, description = "testE2E_ApmTSInput_ApmTSOutput")
	@RallyInfo(UserStory = "US4776")
	public void testE2E_ApmTSInput_ApmTSOutput() throws Exception {

		// ingest test data into apm time series
		String inputTag = "OO_Tag_Temperature_ID0";
		int valuePosted = ooTestutil.postRandomDataPointToAPMTimeSeries(path + "/data_files/data_ingestion_gen.json",
				inputTag);

		// create kpi template
		kpi_id = ooTestutil.createKpiTemplate(path + "/kpi_templates/kpi_e2e_ooapmts_inputAndOutput.json",
				path + "/kpi_analytics_1/analytic_6.zip");
		Thread.sleep(10000);

		// create kpi job

		kpiJobId = ooTestutil.createKpiJobWithNoRandomBothInputAndOutputTag(
				path + "/kpi_jobs/kpi_e2e_ooapmts_inputAndOutput_job.json", kpi_id, "OO_Tag_Temperature_ID10", inputTag,
				"");
		Thread.sleep(10000);

		// start kpi job
		String runtimeJobId = ooTestutil.startKpiJob(kpiJobId);
		Thread.sleep(30000);
		if (runtimeJobId == null) {
			runtimeJobId = ooTestutil.startKpiJob(kpiJobId);
			Thread.sleep(15000);
		}
		if (runtimeJobId != null) {
			// get Status of the Job
			String status = ooTestutil.getStatusOfJob(kpiJobId);
			Thread.sleep(30000);
			if (status.equalsIgnoreCase("FINISHED")) {
				// get data from Apm time Series
				// Thread.sleep(30000);
				ooTestutil.getDataFromApmTimeSeries("OO_Tag_Temperature_ID10", String.valueOf(valuePosted * 10));

				Thread.sleep(30000);

				// delete kpi job
				ooTestutil.deleteKpiJob(kpiJobId);
				Thread.sleep(10000);

				// get status of the job
				ooTestutil.getStatusOfJob(kpiJobId);

				Thread.sleep(10000);
			} else {
				isEqual("Job not Started Successfully.Status of the JOB is --->" + status, true, false);
			}
		} else {
			isEqual("Job not Started Successfully.Status of the JOB is --->" + runtimeJobId, true, false);
		}
	}

	/*********************************************************************************************************/

	@Test(priority = 6, description = "testE2E_Asset_ApmTSInput_ApmTSOutput")
	@RallyInfo(UserStory = "US4776")
	public void testE2E_Asset_ApmTSInput_ApmTSOutput() throws Exception {

		// ingest test data into apm time series
		String inputTag = "OO_Tag_Temperature_ID0";
		int valuePosted = ooTestutil.postRandomDataPointToAPMTimeSeries(path + "/data_files/data_ingestion_gen.json",
				inputTag);

		// create kpi template
		kpi_id = ooTestutil.createKpiTemplate(path + "/kpi_templates/kpi_e2e_asset_ooapmts_inputAndOutput.json",
				// "src/main/resources/payloads/kpi_analytics/kpi_analytic_asset_ts_int.zip");

				path + "/kpi_analytics_1/asset_analytic6.zip");
		// Thread.sleep(10000);

		// create kpi job

		String asset_filter = "assets=sourceKey%3DOO-CA-SIMUL-ASSET-ID1&tags=sourceKeys%3DOO_Tag_Temperature_ID0";
		setSysProperty("asset_filter", asset_filter);
		String language = "JAVA";
		setSysProperty("language", language);
		kpiJobId = ooTestutil.createKpiJobWithNoRandomBothInputAndOutputTag(
				path + "/kpi_jobs/kpi_e2e_asset_ooapmts_inputAndOutput_job.json", kpi_id, "OO_Tag_Temperature_ID20",
				inputTag, "");
		// Thread.sleep(10000);

		// start kpi job
		String runtimeJobId = ooTestutil.startKpiJob(kpiJobId);
		Thread.sleep(30000);
		if (runtimeJobId == null) {
			runtimeJobId = ooTestutil.startKpiJob(kpiJobId);
			Thread.sleep(15000);
		}
		if (runtimeJobId != null) {
			// get Status of the Job
			String status = ooTestutil.getStatusOfJob(kpiJobId);

			if (status.equalsIgnoreCase("FINISHED") || status.equalsIgnoreCase("RUNNING")) {

				// get data from Apm time Series
				// Thread.sleep(30000);
				ooTestutil.getDataFromApmTimeSeries("OO_Tag_Temperature_ID20", String.valueOf(valuePosted * 10));

				Thread.sleep(30000);

				// delete kpi job
				ooTestutil.deleteKpiJob(kpiJobId);
				Thread.sleep(10000);

				// get status of the job
				ooTestutil.getStatusOfJob(kpiJobId);

				Thread.sleep(10000);
			} else {
				isEqual("Job not Started Successfully.Status of the JOB is --->" + status, true, false);
			}
		} else {
			isEqual("Job not Started Successfully.Status of the JOB is --->" + runtimeJobId, true, false);
		}

	}

	/********************************************************************************************************************/
	@Test(priority = 3, description = "test_ApmIngestion_ApmRetrieval")
	@RallyInfo(UserStory = "US8804")
	public void test_ApmTsIngestion_ApmTsRetrieval() throws Exception {

		// post data to apm
		int valuePosted = ooTestutil.postRandomDataPointToAPMTimeSeries(path + "/data_files/data_ingestion_gen.json",
				"OO_Tag_Temperature_ID21");
		// get data from APM
		ooTestutil.getDataFromApmTimeSeries("OO_Tag_Temperature_ID21", String.valueOf(valuePosted));

		return;
	}

	/********************************************************************************************************************
	 * Test Case: StreamTS input And AssetDS as data provider OO APM TS as
	 * output data provider
	 * 
	 * Test Steps: 1) Create Kpi Template. 2) Create Kpi Job with kpireference
	 * id. 3) Start Job 4) Assert data that is written to Kafka topic.
	 * 
	 * /
	 ********************************************************************************************************************/

	@Test(priority = 6, description = "testE2E_AssetNStreamInputs_ApmTSOutput")
	@RallyInfo(UserStory = "US4776")
	public void testE2E_AssetNStreamInputs_ApmTSOutput() throws Exception {

		// create kpi template
		kpi_id = ooTestutil.createKpiTemplate(path + "/kpi_templates/kpiTemplate_7.json",
				path + "/kpi_analytics_1/analytic_7.zip");
		Thread.sleep(10000);

		// create kpi job
		String inputTag = "OO_Tag_Temperature_ID2";
		String outputTag = "OO_Tag_Temperature_ID3";
		kpiJobId = ooTestutil.createKpiJobWithNoRandomBothInputAndOutputTag(path + "/kpi_jobs/kpiJob_7.json", kpi_id,
				outputTag, inputTag, "");
		Thread.sleep(10000);

		// start kpi job
		String runtimeJobId = ooTestutil.startKpiJob(kpiJobId);
		Thread.sleep(30000);
		if (runtimeJobId == null) {
			runtimeJobId = ooTestutil.startKpiJob(kpiJobId);
			Thread.sleep(15000);
		}
		if (runtimeJobId != null) {
			// get Status of the Job
			String status = ooTestutil.getStatusOfJob(kpiJobId);
			Thread.sleep(20000);

			if (status.equalsIgnoreCase("Running")) {

				// post data point to Event hub
				int valuePosted = ooTestutil.postDataPointToEventHubGenData(
						path + "/data_files/data_ingestion_gen_predixTs.json", inputTag);
				// int valuePosted =
				// ooTestutil.postDataPointToKafkaTopicGenData(path+"/data_files/data_ingestion_gen_predixTs.json",inputTag);
				Thread.sleep(30000);

				// get data from Apm time Series
				// Thread.sleep(30000);//2222.611
				ooTestutil.getDataFromApmTimeSeries(outputTag, String.valueOf(valuePosted * 10));
				Thread.sleep(30000);

				// delete kpi job
				ooTestutil.deleteKpiJob(kpiJobId);
				Thread.sleep(10000);

				// get status of the job
				ooTestutil.getStatusOfJob(kpiJobId);

				Thread.sleep(10000);
			} else {
				isEqual("Job not Started Successfully.Status of the JOB is --->" + status, true, false);
			}
		} else {
			isEqual("Job not Started Successfully.Status of the JOB is --->" + runtimeJobId, true, false);
		}
	}

	/********************************************************************************************************************/
	@Test(priority = 8, description = "testE2E_StreamInput_ApmTSOutput")
	@RallyInfo(UserStory = "DE10414")
	public void testE2E_StreamInput_ApmTSOutput() throws Exception {

		// create kpi template
		kpi_id = ooTestutil.createKpiTemplate(path + "/kpi_templates/kpiTemplate_4.json",
				path + "/kpi_analytics_1/analytic_4.zip");
		Thread.sleep(10000);

		// create kpi job
		String inputTag = "OO_Tag_Temperature_ID4";
		String outputTag = "OO_Tag_Temperature_ID5";
		kpiJobId = ooTestutil.createKpiJobWithNoRandomBothInputAndOutputTag(path + "/kpi_jobs/kpiJob_4.json", kpi_id,
				outputTag, inputTag, "");
		Thread.sleep(10000);

		// start kpi job
		String runtimeJobId = ooTestutil.startKpiJob(kpiJobId);
		Thread.sleep(30000);
		if (runtimeJobId == null) {
			runtimeJobId = ooTestutil.startKpiJob(kpiJobId);
			Thread.sleep(15000);
		}
		if (runtimeJobId != null) {
			// get Status of the Job
			String status = ooTestutil.getStatusOfJob(kpiJobId);
			Thread.sleep(20000);

			if (status.equalsIgnoreCase("Running")) {

				// post data point to Event hub
				int valuePosted = ooTestutil.postDataPointToEventHubGenData(
						path + "/data_files/data_ingestion_gen_predixTs.json", inputTag);
				// int valuePosted =
				// ooTestutil.postDataPointToKafkaTopicGenData(path+"/data_files/data_ingestion_gen_predixTs.json",inputTag);
				Thread.sleep(60000);

				// get data from Apm time Series
				// Thread.sleep(30000);//2222.611
				ooTestutil.getDataFromApmTimeSeries(outputTag, String.valueOf(valuePosted * 10));
				Thread.sleep(30000);

				// delete kpi job
				ooTestutil.deleteKpiJob(kpiJobId);
				Thread.sleep(10000);

				// get status of the job
				ooTestutil.getStatusOfJob(kpiJobId);

				Thread.sleep(10000);
			} else {
				isEqual("Job not Started Successfully.Status of the JOB is --->" + status, true, false);
			}
		} else {
			isEqual("Job not Started Successfully.Status of the JOB is --->" + runtimeJobId, true, false);
		}

	}

	/********************************************************************************************************************/
	@Test(priority = 8, description = "testE2E_StreamInput_StreamOutput_daemon")
	@RallyInfo(UserStory = "DE10414")
	public void testE2E_StreamInput_StreamOutput_daemon() throws Exception {

		// create kpi template
		kpi_id = ooTestutil.createKpiTemplate(path + "/kpi_templates/kpiTemplate_41.json",
				path + "/kpi_analytics_1/analytic_4.zip");
		Thread.sleep(10000);

		// create kpi job
		String inputTag = "OO_Tag_Temperature_ID21";
		String outputTag = "OO_Tag_Temperature_ID22";
		kpiJobId = ooTestutil.createKpiJobWithNoRandomBothInputAndOutputTag(path + "/kpi_jobs/kpiJob_41.json", kpi_id,
				outputTag, inputTag, "");
		Thread.sleep(10000);

		// start kpi job
		String runtimeJobId = ooTestutil.startKpiJob(kpiJobId);
		Thread.sleep(30000);
		if (runtimeJobId == null) {
			runtimeJobId = ooTestutil.startKpiJob(kpiJobId);
			Thread.sleep(15000);
		}
		if (runtimeJobId != null) {
			// get Status of the Job
			String status = ooTestutil.getStatusOfJob(kpiJobId);
			Thread.sleep(20000);

			if (status.equalsIgnoreCase("Running")) {

				// post data point to Event hub
				int valuePosted = ooTestutil.postDataPointToEventHubGenData(
						path + "/data_files/data_ingestion_gen_predixTs.json", inputTag);
				// int valuePosted =
				// ooTestutil.postDataPointToKafkaTopicGenData(path+"/data_files/data_ingestion_gen_predixTs.json",inputTag);
				Thread.sleep(60000);

				// get data from Apm time Series
				// Thread.sleep(30000);//2222.611
				ooTestutil.getDataFromApmTimeSeries(outputTag, String.valueOf(valuePosted * 10));
				Thread.sleep(30000);

				// delete kpi job
				ooTestutil.deleteKpiJob(kpiJobId);
				Thread.sleep(10000);

				// get status of the job
				ooTestutil.getStatusOfJob(kpiJobId);

				Thread.sleep(10000);
			} else {
				isEqual("Job not Started Successfully.Status of the JOB is --->" + status, true, false);
			}
		} else {
			isEqual("Job not Started Successfully.Status of the JOB is --->" + runtimeJobId, true, false);
		}

	}

	/********************************************************************************************************************
	 * Test Case: StreamTS input data provider OOStream as output data provider
	 * Analytic without Output Tag. Kpi Job Also does not specify Output tag
	 * Test Steps: 1) Create Kpi Template. 2) Create Kpi Job with kpireference
	 * id. 3) Start Job 4) Assert data that is written to Kafka topic. /
	 ********************************************************************************************************************/
	// TODO
	// @Test(priority = 4, description =
	// "testE2E_StreamInput_StreamOutputWithMissingConfiguredTag")
	@RallyInfo(UserStory = "US8804")
	public void testE2E_StreamInput_StreamOutputWithMissingConfiguredTag() throws Exception {

		// create kpi template
		kpi_id = ooTestutil.createKpiTemplate(
				"src/main/resources/payloadsEventHub/kpi_templates/kpiTemplateStreamTs.json",
				"src/main/resources/payloadsEventHub/kpi_analytics/analytic_without_tags_v1.zip");
		Thread.sleep(10000);
		// analytic_without_tags_v1.zip
		// create kpi job
		kpiJobId = ooTestutil.createKpiJob("src/main/resources/payloadsEventHub/kpi_jobs/kpiStreamTsJob.json", kpi_id);
		Thread.sleep(10000);

		// start kpi job
		String runtimeJobId = ooTestutil.startKpiJob(kpiJobId);
		Thread.sleep(30000);
		if (runtimeJobId == null) {
			runtimeJobId = ooTestutil.startKpiJob(kpiJobId);
			Thread.sleep(15000);
		}
		if (runtimeJobId != null) {
			// get status of job
			String status = ooTestutil.getStatusOfJob(kpiJobId);
			Thread.sleep(10000);

			isEqual("Job successfully shutdown due to failure in analytic for missing configuration ", true,
					status.equalsIgnoreCase("FINISHED"));
		} else {
			isEqual("Job not Started Successfully.Status of the JOB is --->" + runtimeJobId, true, false);
		}
	}

	/********************************************************************************************************************/
	@Test(priority = 9, description = "testE2E_ApmTSInput_NoTag_ApmTSOutput")
	@RallyInfo(UserStory = "DE11196")
	public void testE2E_ApmTSInput_NoTag_ApmTSOutput() throws Exception {

		// create kpi template
		kpi_id = ooTestutil.createKpiTemplate("src/main/resources/payloadsEventHub/kpi_templates/kpiTemplate_10.json",
				"src/main/resources/payloadsEventHub/kpi_analytics_1/analytic_10.zip");
		Thread.sleep(10000);

		// create kpi job
		String inputTag = "OO_Tag_Temperature_ID6";
		String outputTag = "OO_Tag_Temperature_ID7";
		kpiJobId = ooTestutil.createKpiJobWithNoRandomBothInputAndOutputTag(path + "/kpi_jobs/kpiJob_10.json", kpi_id,
				outputTag, inputTag, "");
		Thread.sleep(10000);

		// start kpi job
		String runtimeJobId = ooTestutil.startKpiJob(kpiJobId);
		Thread.sleep(30000);
		if (runtimeJobId == null) {
			runtimeJobId = ooTestutil.startKpiJob(kpiJobId);
			Thread.sleep(15000);
		}
		if (runtimeJobId != null) {
			// get Status of the Job
			String status = ooTestutil.getStatusOfJob(kpiJobId);
			Thread.sleep(30000);
			isEqual("Job not Started Successfully.Status of the JOB is --->" + status, status, "FINISHED");
		} else {
			isEqual("Job not Started Successfully.Status of the JOB is --->" + runtimeJobId, true, false);
		}

	}

	/**************************************************************************************************/
	@Test(priority = 1, description = "testE2E_ApmInputs_ApmOutput_InputNegativeValue")
	@RallyInfo(UserStory = "USXXXXX")
	public void testE2E_ApmInputs_ApmOutput_InputNegativeValue() throws Exception {

		// ingest test data into apm time series
		String inputTag = "OO_Tag_Temperature_ID9";
		int valuePosted = ooTestutil.postRandomDataPointToAPMTimeSeries(path + "/data_files/data_ingestion_8.json",
				inputTag);

		// create kpi template
		kpi_id = ooTestutil.createKpiTemplate(path + "/kpi_templates/kpiTemplate_8.json",
				path + "/kpi_analytics_1/analytic_8.zip");
		Thread.sleep(10000);

		// create kpi job
		String outputTag = "OO_Tag_Temperature_ID10";
		kpiJobId = ooTestutil.createKpiJobWithNoRandomBothInputAndOutputTag(path + "/kpi_jobs/kpiJob_8.json", kpi_id,
				outputTag, inputTag, "");
		Thread.sleep(10000);

		// start kpi job
		String runtimeJobId = ooTestutil.startKpiJob(kpiJobId);
		Thread.sleep(30000);
		if (runtimeJobId == null) {
			runtimeJobId = ooTestutil.startKpiJob(kpiJobId);
			Thread.sleep(30000);
		}
		if (runtimeJobId != null) {
			// get Status of the Job
			String status = ooTestutil.getStatusOfJob(kpiJobId);
			Thread.sleep(10000);

			if (status.equalsIgnoreCase("FINISHED")) {

				// get data from Apm time Series
				// Thread.sleep(30000);
				ooTestutil.getDataFromApmTimeSeries(outputTag, String.valueOf(valuePosted * 10));

				Thread.sleep(30000);

				// delete kpi job
				ooTestutil.deleteKpiJob(kpiJobId);
				Thread.sleep(10000);

				// get status of the job
				ooTestutil.getStatusOfJob(kpiJobId);

				Thread.sleep(10000);
			} else {
				isEqual("Job not Started Successfully.Status of the JOB is --->" + status, true, false);
			}
		} else {
			isEqual("Job not Started Successfully.Status of the JOB is --->" + runtimeJobId, true, false);
		}
	}

	/**************************************************************************************************/
	@Test(priority = 1, description = "testE2E_ApmInputs_ApmOutput_InputDoubleValue")
	@RallyInfo(UserStory = "DE11062")
	public void testE2E_ApmInputs_ApmOutput_InputDoubleValue() throws Exception {

		// ingest test data into apm time series
		String inputTag = "OO_Tag_Temperature_ID11";
		int valuePosted = ooTestutil.postRandomDataPointToAPMTimeSeries(path + "/data_files/data_ingestion_9.json",
				inputTag);

		// create kpi template
		kpi_id = ooTestutil.createKpiTemplate(path + "/kpi_templates/kpiTemplate_9.json",
				path + "/kpi_analytics_1/analytic_9.zip");
		Thread.sleep(10000);

		// create kpi job
		String outputTag = "OO_Tag_Temperature_ID12";
		kpiJobId = ooTestutil.createKpiJobWithNoRandomBothInputAndOutputTag(path + "/kpi_jobs/kpiJob_9.json", kpi_id,
				outputTag, inputTag, "");
		Thread.sleep(10000);

		// start kpi job
		String runtimeJobId = ooTestutil.startKpiJob(kpiJobId);
		Thread.sleep(30000);
		if (runtimeJobId == null) {
			runtimeJobId = ooTestutil.startKpiJob(kpiJobId);
			Thread.sleep(30000);
		}
		if (runtimeJobId != null) {
			// get Status of the Job
			String status = ooTestutil.getStatusOfJob(kpiJobId);
			Thread.sleep(30000);

			if (status.equalsIgnoreCase("FINISHED")) {

				// get data from Apm time Series
				// Thread.sleep(30000);
				ooTestutil.getDataFromApmTimeSeries(outputTag, "9.223372036854776E15");

				Thread.sleep(30000);

				// delete kpi job
				ooTestutil.deleteKpiJob(kpiJobId);
				Thread.sleep(10000);

				// get status of the job
				ooTestutil.getStatusOfJob(kpiJobId);

				Thread.sleep(10000);
			} else {
				isEqual("Job not Started Successfully.Status of the JOB is --->" + status, true, false);
			}
		} else {
			isEqual("Job not Started Successfully.Status of the JOB is --->" + runtimeJobId, true, false);
		}

		// expectedValue = "9223372036854776";

	}

	/**************************************************************************************************/

	@Test(priority = 1, description = "testE2E_ApmInputs_ApmOutput_multipleDataPoints")
	@RallyInfo(UserStory = "USXXXXX")
	public void testE2E_ApmInputs_ApmOutput_multipleDataPoints() throws Exception {

		apmTSforIngestionPath = path + "/data_files/data_ingestion_12.json";
		kpiTemplateJsonPath = path + "/kpi_templates/kpiTemplate_12.json";
		kpiTemplateAnalyticPath = path + "/kpi_analytics_1/analytic_12.zip";
		kpiJobJsonPath = path + "/kpi_jobs/kpiJob_12.json";
		String inputTag_1 = "OO_Tag_Temperature_ID30";
		String inputTag_2 = "OO_Tag_Temperature_ID31";
		String inputTag_3 = "OO_Tag_Temperature_ID32";
		String outputTag_1 = "OO_Tag_Temperature_ID33";
		String outputTag_2 = "OO_Tag_Temperature_ID34";
		String outputTag_3 = "OO_Tag_Temperature_ID35";
		expectedValue = "";
		expectedJobStatus = "FINISHED";
		apmTsUrl = "operation=raw&startTime=2015-12-31T00:28:03.000&sampleCount=1000&useOnlyGoodData=true&tagList="
				+ inputTag_1 + "," + inputTag_2 + "," + inputTag_3;

		// ingest test data into apm time series

		ooTestutil.printnewLine();
		System.out.println("*****************Post data point to APM TIME SERIES******************");

		int apmTsValue = ooTestutil.generateRandomNumber3Digits();
		int apmTsValue_1 = apmTsValue;
		apmTsValue = ooTestutil.generateRandomNumber3Digits();
		int apmTsValue_2 = apmTsValue;
		apmTsValue = ooTestutil.generateRandomNumber3Digits();
		int apmTsValue_3 = apmTsValue;
		setSysProperty("setTsValue_1", String.valueOf(apmTsValue_1));
		setSysProperty("setTsValue_2", String.valueOf(apmTsValue_2));
		setSysProperty("setTsValue_3", String.valueOf(apmTsValue_3));

		setSysProperty("setTsCurrentTime_1", ooTestutil.getCurrentTime());
		setSysProperty("setTsCurrentTime_2", ooTestutil.getCurrentTime());
		setSysProperty("setTsCurrentTime_3", ooTestutil.getCurrentTime());

		setSysProperty("setTsTag_1", inputTag_1);
		setSysProperty("setTsTag_2", inputTag_2);
		setSysProperty("setTsTag_3", inputTag_3);

		String dataIngestionFile = generateFile(apmTSforIngestionPath, "dataIngestionFile");

		File f1 = new File(dataIngestionFile);
		System.out.println("file path=" + f1.getAbsolutePath());
		String path1 = f1.getAbsolutePath().replace('\\', '/');
		String dataIngestionFileJsonAsString = FileUtils.readFileToString(new File(path1));
		System.out.println("dataIngestionFileJsonAsString------->" + dataIngestionFileJsonAsString);
		Response response_apm_ts_post = postServiceResponse(dataIngestionFileJsonAsString, "timeSeriesIngestionURL",
				ooTestutil.ApmProvideHeaders());
		Thread.sleep(30000);
		System.out.println("response_apm_ts_post------->" + response_apm_ts_post.asString());
		isEqual("Data not Posted to Apm Time Series", 201, response_apm_ts_post.getStatusCode());
		ooTestutil.printnewLine();

		// create kpi template
		kpi_id = ooTestutil.createKpiTemplate(kpiTemplateJsonPath, kpiTemplateAnalyticPath);
		Thread.sleep(10000);

		// create kpi job

		ooTestutil.printnewLine();
		System.out.println("*****************Create KPI JOB*******************");
		ooTestutil.printnewLine();

		setSysProperty("apmTsUrl", apmTsUrl);
		setSysProperty("kpiReferenceId", String.valueOf(kpi_id));
		setSysProperty("setInputTagName_1", inputTag_1);
		setSysProperty("setOutputTagName_1", outputTag_1);
		setSysProperty("setInputTagName_2", inputTag_2);
		setSysProperty("setOutputTagName_2", outputTag_2);
		setSysProperty("setInputTagName_3", inputTag_3);
		setSysProperty("setOutputTagName_3", outputTag_3);

		setSysProperty("setApmTSUrl", apmTsUrl);

		String kpijobJson = generateFile(kpiJobJsonPath, "kpi_job_e2e");
		System.out.println("+++ kpijobJson== " + kpijobJson);
		Response response1 = postServiceResponse(kpijobJson, "job_url", ooTestutil.kpiprovideHeaders());

		System.out.println("+++ response.asString() == " + response1.asString());
		JsonPath jsonPath = new JsonPath(response1.asString());
		String kpiJobId = jsonPath.getString("id");
		System.out.println("+++ kpiJobId== " + kpiJobId);
		isEqual("Not valid response create KPI Job", 201, response1.statusCode());
		Thread.sleep(10000);

		// start kpi job
		String runtimeJobId = ooTestutil.startKpiJob(kpiJobId);
		Thread.sleep(30000);
		if (runtimeJobId == null) {
			runtimeJobId = ooTestutil.startKpiJob(kpiJobId);
			Thread.sleep(30000);
		}
		if (runtimeJobId != null) {
			ooTestutil.printnewLine();
			System.out.println("*****************Get data from APM TIME SERIES******************");

			// check if the tag and data was ingested successfully or not

			Thread.sleep(30000);
			Map<String, Object> queryParams = new LinkedHashMap<String, Object>();
			queryParams.put("tagList", outputTag_1);

			Thread.sleep(30000);
			Response response_apm_ts = getServiceResponse("timeSeriesGetDataURL", queryParams,
					ooTestutil.ApmProvideHeaders());
			System.out.println("+++ string of response_apm_ts == " + response_apm_ts.asString());
			isEqual("Data posted to kafka topic is not posted in APM TS", true,
					response_apm_ts.asString().contains(outputTag_1));
			isEqual("Data posted to kafka topic is not posted in APM TS", true,
					response_apm_ts.asString().contains(String.valueOf(apmTsValue_1 * 10)));

			Thread.sleep(30000);
			queryParams.put("tagList", outputTag_2);
			response_apm_ts = getServiceResponse("timeSeriesGetDataURL", queryParams, ooTestutil.ApmProvideHeaders());
			System.out.println("+++ string of response_apm_ts == " + response_apm_ts.asString());
			isEqual("Data posted to kafka topic is not posted in APM TS", true,
					response_apm_ts.asString().contains(outputTag_2));
			isEqual("Data posted to kafka topic is not posted in APM TS", true,
					response_apm_ts.asString().contains(String.valueOf(apmTsValue_2 * 100)));

			Thread.sleep(30000);
			queryParams.put("tagList", outputTag_3);
			response_apm_ts = getServiceResponse("timeSeriesGetDataURL", queryParams, ooTestutil.ApmProvideHeaders());
			System.out.println("+++ string of response_apm_ts == " + response_apm_ts.asString());
			isEqual("Data posted to kafka topic is not posted in APM TS", true,
					response_apm_ts.asString().contains(outputTag_3));
			isEqual("Data posted to kafka topic is not posted in APM TS", true,
					response_apm_ts.asString().contains(String.valueOf(apmTsValue_3 * 1000)));

			// get Status of the Job
			String status = ooTestutil.getStatusOfJob(kpiJobId);
			Thread.sleep(30000);
		} else {
			isEqual("Job not Started Successfully.Status of the JOB is --->" + runtimeJobId, true, false);
		}
	}

	/********************************************************************************************************************/
	// @Test(priority = 3, description = "test_ApmAssetRetrieval")
	@RallyInfo(UserStory = "US8804")
	public void test_ApmAssetRetrieval() throws Exception {

		// get Asset data from APM
		ooTestutil.getAPMAssets();

		return;
	}

	/*********************************************************************************************************/

	// @Test(priority = 1, description =
	// "testE2E_AssetNStreamInputs_StreamOutput_Perf")
	@RallyInfo(UserStory = "USXXXXX")
	public void testE2E_AssetNStreamInputs_StreamOutput_Perf() throws Exception {

		// create kpi template
		kpi_id = ooTestutil.createKpiTemplate("src/main/resources/payloadsEventHub/kpi_templates/kpiTemplate_1.json",
				"src/main/resources/payloadsEventHub/kpi_analytics_1/analytic_1.zip");

		// create kpi job
		String inputTag = "OO_Tag_Temperature_ID32";
		String outputTag = "OO_Tag_Temperature_ID33";
		kpiJobId = ooTestutil.createKpiJobWithNoRandomBothInputAndOutputTag(
				"src/main/resources/payloadsEventHub/kpi_jobs/kpiJob_1.json", kpi_id, outputTag, inputTag, "");
		// start job
		String runtimeJobId = ooTestutil.startKpiJob(kpiJobId);
		Thread.sleep(30000);
		if (runtimeJobId == null) {
			runtimeJobId = ooTestutil.startKpiJob(kpiJobId);
			Thread.sleep(30000);
		}
		if (runtimeJobId != null) {
			// get status of the job
			String status = ooTestutil.getStatusOfJob(kpiJobId);
			Thread.sleep(30000);

			if (status.equalsIgnoreCase("Running")) {
				// get output tag from Kpi Job response
				String InputtagNamePosted = ooTestutil.getInputtagOfKpiJob(kpiJobId);
				Thread.sleep(10000);

				ooTestutil.postDataPointToEventHubNoRandomTag(
						"src/main/resources/payloadsEventHub/data_files/data_ingestion_2.json", InputtagNamePosted);
				// ooTestutil.postDataPointToEventHubNoRandomTag("src/main/resources/payloadsEventHub/data_files/data_ingestion_2.json",InputtagNamePosted);

				Thread.sleep(30000);

				// get output tag from Kpi Job response
				String OutputtagNamePosted = ooTestutil.getOutputtagOfKpiJob(kpiJobId);
				Thread.sleep(10000);

				String calculatedData = ooTestutil.getDataPointFromKafkaTopic(OutputtagNamePosted);

				// Assert if the Analytic calculated data posted to event hub
				isEqual("Data not calculated", calculatedData.contains("4009.99"), true);
				if (calculatedData.contains("4009.99")) {
					System.out.println("+++ Test Passed== testE2E_AssetNStreamInputs_StreamOutput_Perf");
				}

				// data saved to Apm TS by Analytic consumer
				// ooTestutil.getDataFromApmTimeSeries(OutputtagNamePosted,
				// "2009.99");

				// delete kpi job
				ooTestutil.deleteKpiJob(kpiJobId);

				// get status of kpi job
				ooTestutil.getStatusOfJob(kpiJobId);
				Thread.sleep(10000);
			} else {
				isEqual("Job not Started Successfully.Status of the JOB is --->" + status, true, false);
			}
		} else {
			isEqual("Job not Started Successfully.Status of the JOB is --->" + runtimeJobId, true, false);
		}
	}

	/********************************************************************************************************************/
	// THIS TEST FOR PREDIX TS _ EVENTHUB INTEGRATION
	// @Test(priority = 3, description =
	// "testE2E_StreamInput_StreamOutputWithConfiguredTag")
	@RallyInfo(UserStory = "US8804")
	public void testE2E_StreamInput_StreamOutputWithConfiguredTag_ApmIngestion() throws Exception {

		// post data to event hub
		// String tabingested =
		// ooTestutil.postDataPointToAPMTimeSeries("src/main/resources/payloadsEventHub/data_files_ApmIngestion/data_ingestion_ts.json","OO_Tag_RAMSPEED");

		// ooTestutil.getDataFromApmTimeSeries(tabingested,"40.015");

		// create kpi template
		kpi_id = ooTestutil.createKpiTemplate("src/main/resources/payloadsEventHub/kpi_templates/kpiTemplate_1.json",
				"src/main/resources/payloadsEventHub/kpi_analytics_1/analytic_1.zip");
		Thread.sleep(10000);

		// create kpi job
		String inputTag = "OO_Tag_Temperature_ID28";
		String outputTag = "OO_Tag_Temperature_ID29";
		kpiJobId = ooTestutil.createKpiJobWithNoRandomBothInputAndOutputTag(path + "/kpi_jobs/kpiJob_1.json", kpi_id,
				outputTag, inputTag, "");
		Thread.sleep(10000);

		// start kpi job
		String runtimeJobId = ooTestutil.startKpiJob(kpiJobId);
		Thread.sleep(30000);
		if (runtimeJobId == null) {
			runtimeJobId = ooTestutil.startKpiJob(kpiJobId);
			Thread.sleep(30000);
		}
		if (runtimeJobId != null) {
			// get Status of the job
			String status = ooTestutil.getStatusOfJob(kpiJobId);
			Thread.sleep(30000);

			if (status.equalsIgnoreCase("Running")) {

				// post data to APM time series
				int valuePosted = ooTestutil
						.postRandomDataPointToAPMTimeSeries(path + "/data_files/data_ingestion_gen.json", inputTag);

				Thread.sleep(30000);

				// get data from Apm Ts
				ooTestutil.getDataFromApmTimeSeries(outputTag, String.valueOf(valuePosted));
				Thread.sleep(30000);

				// delete kpi job
				ooTestutil.deleteKpiJob(kpiJobId);
				Thread.sleep(10000);

				// get status of the job
				ooTestutil.getStatusOfJob(kpiJobId);
				Thread.sleep(10000);
			} else {
				isEqual("Job not Started Successfully.Status of the JOB is --->" + status, true, false);
			}
		} else {
			isEqual("Job not Started Successfully.Status of the JOB is --->" + runtimeJobId, true, false);
		}
	}

	/********************************************************************************************************************/

	@Test(priority = 6, description = "testE2E_HDFS_Asset_ApmTSInput_ApmTSOutput")
	@RallyInfo(UserStory = "US4776")
	public void testE2E_HDFS_Asset_ApmTSInput_ApmTSOutput() throws Exception {

		// String hdfs_asset_file="hdfs:///tmp/data/asset_flat.json";
		String hdfs_asset_file = "hdfs:///tmp/data?assets=assets_basic.json&tags=tags_basic.json";
		String hdfs_ts_file = "hdfs:///tmp/data/ts_apm_iso_small7.json";
		setSysProperty("hdfs_asset_file", hdfs_asset_file);
		setSysProperty("hdfs_ts_file", hdfs_ts_file);
		String language = "JAVA";
		setSysProperty("language", language);
		// ingest test data into apm time series
		String inputTag = "OO_Tag_Temperature_ID_3";
		System.out.println(System.currentTimeMillis());
		// int valuePosted =
		// ooTestutil.postRandomDataPointToAPMTimeSeries(path+"/data_files/data_ingestion_gen.json"
		// ,inputTag);

		// create kpi template
		kpi_id = ooTestutil.createKpiTemplate(path + "/kpi_templates/kpi_e2e_asset_ooapmts_inputAndOutput.json",
				path + "/kpi_analytics_1/analytic_6_hdfs.zip");

		// create kpi job
		kpiJobId = ooTestutil.createKpiJobWithNoRandomBothInputAndOutputTag(
				path + "/kpi_jobs/kpi_e2e_hdfs_ooapmts_inputAndOutput_job.json", kpi_id, "OO_Tag_Temperature_ID25",
				inputTag, "");

		// start kpi job
		String runtimeJobId = ooTestutil.startKpiJob(kpiJobId);
		Instant instant = Instant.now();
		String timestamp = instant.toString();
		System.out.println("getCurrent timestamp=" + timestamp);

		Thread.sleep(30000);
		if (runtimeJobId == null) {
			runtimeJobId = ooTestutil.startKpiJob(kpiJobId);
			Thread.sleep(30000);

		}
		if (runtimeJobId != null) {

			// get Status of the Job
			String status = ooTestutil.getStatusOfJob(kpiJobId);

			if (status.equalsIgnoreCase("FINISHED")) {

				// get data from Apm time Series
				String res = ooTestutil.getDataFromApmTimeSeriesWithTimeFilter("OO_Tag_Temperature_ID25", timestamp);
				isEqual("data not found in apm time series:", true, res.contains("132.528"));

				// delete kpi job
				ooTestutil.deleteKpiJob(kpiJobId);
				Thread.sleep(10000);

				// get status of the job
				ooTestutil.getStatusOfJob(kpiJobId);

			} else {
				isEqual("Job not Started Successfully.Status of the JOB is --->" + status, true, false);
			}
		} else {
			isEqual("Job not Started Successfully.Status of the JOB is --->" + runtimeJobId, true, false);
		}

	}

	/********************************************************************************************************************/

	@Test(priority = 6, description = "testE2E_HDFS_Asset_OOFile_ApmTSOutput")
	@RallyInfo(UserStory = "US4776")
	public void testE2E_HDFS_Asset_OOFile_ApmTSOutput() throws Exception {

		String hdfs_asset_file = "hdfs:///tmp/data?assets=assets_basic.json&tags=tags_basic.json";
		String hdfs_ts_file = "hdfs:///tmp/data/ts_apm_iso_small5.json";
		setSysProperty("hdfs_asset_file", hdfs_asset_file);
		setSysProperty("hdfs_ts_file", hdfs_ts_file);
		String language = "JAVA";
		setSysProperty("language", language);
		// ingest test data into apm time series
		String inputTag = "OO_Tag_Temperature_ID_3";
		System.out.println(System.currentTimeMillis());
		// int valuePosted =
		// ooTestutil.postRandomDataPointToAPMTimeSeries(path+"/data_files/data_ingestion_gen.json"
		// ,inputTag);

		// create kpi template
		kpi_id = ooTestutil.createKpiTemplate(path + "/kpi_templates/kpi_e2e_oofile_input_ooapmts_Output.json",

				path + "/kpi_analytics_1/analytic_6_hdfs_oofile.zip");

		// create kpi job

		kpiJobId = ooTestutil.createKpiJobWithNoRandomBothInputAndOutputTag(
				path + "/kpi_jobs/kpi_e2e_oofile_hdfs_ooapmts_Output_job.json", kpi_id, "OO_Tag_Temperature_ID25",
				inputTag, "");

		Instant instant = Instant.now();
		String timestamp = instant.toString();
		System.out.println("getCurrent timestamp=" + timestamp);

		// start kpi job
		ooTestutil.startKpiJobTwice(kpiJobId);

		Thread.sleep(30000);
		Thread.sleep(30000);
		// get Status of the Job
		String status = ooTestutil.getStatusOfJob(kpiJobId);

		if (status.equalsIgnoreCase("FINISHED")) {

			// get data from Apm time Series

			String res = ooTestutil.getDataFromApmTimeSeriesWithTimeFilter("OO_Tag_Temperature_ID25", timestamp);
			isEqual("data not found in apm time series:", true, res.contains("132.528"));

			// delete kpi job
			ooTestutil.deleteKpiJob(kpiJobId);
			Thread.sleep(10000);

			// get status of the job
			ooTestutil.getStatusOfJob(kpiJobId);

		} else {
			isEqual("Job not Started Successfully.Status of the JOB is --->" + status, true, false);
		}

	}

	/********************************************************************************************************************
	 * Delete Kpi: Scenario 1: Create Kpi -> Get Kpi -> Delete Kpi -> Get Kpi
	 * 
	 ********************************************************************************************************************/
	@Test(priority = 1, description = "testDeleteKpiScenario1")
	@RallyInfo(UserStory = "USXXXXX")
	public void testDeleteKpiScenario1() throws Exception {

		System.out.println("*****************Create KPI TEMPLATE*******************");
		ooTestutil.printnewLine();

		// create kpi template
		kpi_id = ooTestutil.createKpiTemplate(
				"src/main/resources/payloadsEventHub/kpi_templates/kpi_e2e_ooapmts_inputAndOutput.json",
				"src/main/resources/payloadsEventHub/kpi_analytics/analytic_ooapmts_outputAndinput.zip");
		// Thread.sleep(10000);

		// *****************Create KPI
		// TEMPLATE***************************************************//

		// GET KPI

		System.out.println("+++ GET KPI BY ID+++++++++++++++++++++++++++++++++++");
		String getKpiUrl = "kpi_url" + "/id/" + kpi_id;
		System.out.println("+++ getkpiByIDurl == " + getKpiUrl);
		Response get_response = getServiceResponse(getKpiUrl, ooTestutil.kpiprovideHeaders());
		String kpi_name = get_response.jsonPath().getString("name[0]");
		System.out.println("+++ kpi_name == " + kpi_name);
		isEqual("Incorrect kpi ID", true, get_response.body().asString().contains(String.valueOf(kpi_id)));
		isEqual("No inputs in response", true, get_response.body().jsonPath().getList("inputs").size() > 0);
		isEqual("No outputs in response", true, get_response.body().jsonPath().getList("outputs").size() > 0);

		ooTestutil.printnewLine();

		// GET KPI BY NAME
		System.out.println("+++ GET KPI BY NAME+++++++++++++++++++++++++++++++++++");
		String getkpiByNameurl = "kpi_url" + "/name/" + kpi_name;
		System.out.println("+++ getkpiByNameurl == " + getkpiByNameurl);
		Response get_response_by_name = getServiceResponse(getkpiByNameurl, ooTestutil.kpiprovideHeaders());
		isEqual("Missing kpi name", true, get_response_by_name.body().asString().contains(String.valueOf(kpi_name)));

		ooTestutil.printnewLine();
		// DELETE KPI
		System.out.println("+++ DELETE KPI+++++++++++++++++++++++++++++++++++");
		String kpiDeleteUrl = getTestProperty("kpi_url") + "/" + kpi_id;
		System.out.println("+++ kpiDeleteUrl == " + kpiDeleteUrl);
		Response delete_response = deleteServiceResponse("kpi_url" + "/" + kpi_id, values,
				ooTestutil.kpiprovideHeaders());
		System.out.println("+++ delete_response.asString() == " + delete_response.asString());
		isEqual("Delete failed", true, delete_response.getStatusCode() == HttpStatus.SC_NO_CONTENT);

		ooTestutil.printnewLine();
		// GET KPI
		System.out.println("+++ GET KPI AFTER DELETE+++++++++++++++++++++++++++++++++++");
		getKpiUrl = "kpi_url" + "/id/" + kpi_id;
		get_response = getServiceResponse(getKpiUrl, ooTestutil.kpiprovideHeaders());
		isEqual("Delete failed", 404, get_response.getStatusCode());
		ooTestutil.printnewLine();
	}

	/********************************************************************************************************************
	 * Delete Kpi:
	 * 
	 * Scenario 2: Create Kpi -> Get Kpi -> Create Kpi Job -> Delete Kpi -> Get
	 * Kpi Should not delete kpi unless Kpi job is deleted.
	 * 
	 ********************************************************************************************************************/
	@Test(priority = 1, description = "testDeleteKpiScenario2")
	@RallyInfo(UserStory = "USXXXXX")
	public void testDeleteKpiScenario2() throws Exception {

		System.out.println("*****************Create KPI TEMPLATE*******************");
		ooTestutil.printnewLine();

		// create kpi template
		kpi_id = ooTestutil.createKpiTemplate("src/main/resources/payloadsEventHub/kpi_templates/kpiTemplate_1.json",
				"src/main/resources/payloadsEventHub/kpi_analytics_1/analytic_1.zip");

		System.out.println("+++ CREATE KPI JOB+++++++++++++++++++++++++++++++++++");
		// create kpi job
		String inputTag = "OO_Tag_Temperature";
		kpiJobId = ooTestutil.createKpiJobWithInputAndOutputTag(
				"src/main/resources/payloadsEventHub/kpi_jobs/kpiJob_1.json", kpi_id, "Output_OO_Tag_Temperature",
				inputTag);
		ooTestutil.printnewLine();

		// ooTestutil.printnewLine();
		// DELETE KPI
		String kpiDeleteUrl = getTestProperty("kpi_url") + "/" + kpi_id;
		System.out.println("+++ DELETE KPI AND CACSCADE DELETE KPI JOB +++++++++++++++++++++++++++++++++++");
		kpiDeleteUrl = getTestProperty("kpi_url") + "/" + kpi_id;
		System.out.println("+++ kpiDeleteUrl == " + kpiDeleteUrl);
		Response delete_response = deleteServiceResponse("kpi_url" + "/" + kpi_id, values,
				ooTestutil.kpiprovideHeaders());
		System.out.println("+++ delete_response.asString() == " + delete_response.asString());
		isEqual("we should be able to delete kpi", true, delete_response.getStatusCode() == HttpStatus.SC_NO_CONTENT);

		// GET KPI
		ooTestutil.printnewLine();
		System.out.println("+++ GET KPI BY ID+++++++++++++++++++++++++++++++++++");
		String getKpiUrl = "kpi_url" + "/id/" + kpi_id;
		Response get_response = getServiceResponse(getKpiUrl, ooTestutil.kpiprovideHeaders());
		isEqual("Delete failed", 404, get_response.getStatusCode());
		if (get_response.getBody().asString().equals("")) {
			System.out.println("testDeleteKpiScenario2 Passed. KPI was deleted successfully");
		}
		ooTestutil.printnewLine();

	}

	/********************************************************************************************************************
	 * Delete Kpi::
	 * 
	 * Scenario: Create Kpi -> Get Kpi -> Create Kpi Job -> Start Kpi Job -> Job
	 * in Running State -> Delete Kpi -> Get Kpi
	 * 
	 ********************************************************************************************************************/
	@Test(priority = 1, description = "testDeleteKpiScenario3")
	@RallyInfo(UserStory = "US28339")
	public void testDeleteKpiScenario3() throws Exception {

		System.out.println("*****************Create KPI TEMPLATE*******************");
		ooTestutil.printnewLine();

		// create kpi template
		kpi_id = ooTestutil.createKpiTemplate("src/main/resources/payloadsEventHub/kpi_templates/kpiTemplate_1.json",
				"src/main/resources/payloadsEventHub/kpi_analytics_1/analytic_1.zip");

		ooTestutil.printnewLine();
		System.out.println("+++ CREATE KPI JOB+++++++++++++++++++++++++++++++++++");
		// create kpi job
		String inputTag = "OO_Tag_Temperature";
		kpiJobId = ooTestutil.createKpiJobWithInputAndOutputTag(
				"src/main/resources/payloadsEventHub/kpi_jobs/kpiJob_1.json", kpi_id, "Output_OO_Tag_Temperature",
				inputTag);
		ooTestutil.printnewLine();

		System.out.println("+++Start KPI JOB+++++++++++++++++++++++++++++++++++");
		// start job
		ooTestutil.startKpiJob(kpiJobId);
		ooTestutil.printnewLine();
		Thread.sleep(15000);

		System.out.println("+++GET STATUS OF KPI JOB+++++++++++++++++++++++++++++++++++");
		// get status of the job
		String status = ooTestutil.getStatusOfJob(kpiJobId);
		ooTestutil.printnewLine();

		if (status.equalsIgnoreCase("RUNNING")) {

			// DELETE KPI
			System.out.println("+++DELETE KPI+++++++++++++++++++++++++++++++++++");
			String kpiDeleteUrl = getTestProperty("kpi_url") + "/" + kpi_id;
			System.out.println("+++ kpiDeleteUrl == " + kpiDeleteUrl);
			Response delete_response = deleteServiceResponse("kpi_url" + "/" + kpi_id, values,
					ooTestutil.kpiprovideHeaders());
			System.out.println("+++ delete_response.asString() == " + delete_response.asString());
			isEqual("we should not be able to delete kpi", true,
					delete_response.getStatusCode() == HttpStatus.SC_FAILED_DEPENDENCY);
			ooTestutil.printnewLine();

			// delete/Stop kpi job
			System.out.println("+++DELETE KPI JOB+++++++++++++++++++++++++++++++++++");
			ooTestutil.deleteKpiJob(kpiJobId);
			ooTestutil.printnewLine();

			// DELETE KPI

			System.out.println("+++DELETE KPI AFTER DELETE JOB+++++++++++++++++++++++++++++++++++");
			kpiDeleteUrl = getTestProperty("kpi_url") + "/" + kpi_id;
			System.out.println("+++ kpiDeleteUrl == " + kpiDeleteUrl);
			delete_response = deleteServiceResponse("kpi_url" + "/" + kpi_id, values, ooTestutil.kpiprovideHeaders());
			System.out.println("+++ delete_response.asString() == " + delete_response.asString());
			isEqual("we should  be able to delete kpi", true,
					delete_response.getStatusCode() == HttpStatus.SC_NO_CONTENT);
			ooTestutil.printnewLine();

			// GET KPI
			System.out.println("+++GET KPI AFTER DELETE KPI+++++++++++++++++++++++++++++++++++");
			String getKpiUrl = "kpi_url" + "/id/" + kpi_id;
			Response get_response = getServiceResponse(getKpiUrl, ooTestutil.kpiprovideHeaders());
			isEqual("Delete Failed", 404, get_response.getStatusCode());
			System.out.println("testDeleteKpiScenario2 Passed. KPI was deleted successfully");
		}

	}

	/********************************************************************************************************************
	 * Delete Kpi::
	 * 
	 * Scenario: Create Kpi -> Get Kpi -> Create Kpi Job -> Start 2-3 Kpi Job ->
	 * Start jobs -> Jobs in Running State -> Delete Kpi -> Get Kpi
	 * 
	 ********************************************************************************************************************/
	@Test(priority = 1, description = "testDeleteKpiScenario4")
	@RallyInfo(UserStory = "US28339")
	public void testDeleteKpiScenario4() throws Exception {

		System.out.println("*****************Create KPI TEMPLATE*******************");
		ooTestutil.printnewLine();

		// create kpi template
		kpi_id = ooTestutil.createKpiTemplate("src/main/resources/payloadsEventHub/kpi_templates/kpiTemplate_1.json",
				"src/main/resources/payloadsEventHub/kpi_analytics_1/analytic_1.zip");

		System.out.println("*****************Create KPI JOB*******************");
		ooTestutil.printnewLine();
		// create kpi job
		String inputTag = "OO_Tag_Temperature";
		String kpiJobId_1 = ooTestutil.createKpiJobWithInputAndOutputTag(
				"src/main/resources/payloadsEventHub/kpi_jobs/kpiJob_1.json", kpi_id, "Output_OO_Tag_Temperature",
				inputTag);

		String kpiJobId_2 = ooTestutil.createKpiJobWithInputAndOutputTag(
				"src/main/resources/payloadsEventHub/kpi_jobs/kpiJob_1.json", kpi_id, "Output_OO_Tag_Temperature",
				inputTag);

		String kpiJobId_3 = ooTestutil.createKpiJobWithInputAndOutputTag(
				"src/main/resources/payloadsEventHub/kpi_jobs/kpiJob_1.json", kpi_id, "Output_OO_Tag_Temperature",
				inputTag);

		// start job
		System.out.println("*****************START KPI JOB*******************");
		ooTestutil.printnewLine();
		ooTestutil.startKpiJob(kpiJobId_1);
		System.out.println("*****************START KPI JOB*******************");
		ooTestutil.printnewLine();
		ooTestutil.startKpiJob(kpiJobId_2);
		System.out.println("*****************START KPI JOB*******************");
		ooTestutil.printnewLine();
		ooTestutil.startKpiJob(kpiJobId_3);
		Thread.sleep(15000);

		// get list of jobs running
		System.out.println("*****************LIST OF JOBS*******************");
		ooTestutil.printnewLine();
		String list = ooTestutil.getListOfJobsForAKpiId(kpi_id);
		// TBD ASSERT list with list of jobs

		// get status of the job
		System.out.println("*****************GET STATUS OF JOBS*******************");
		ooTestutil.printnewLine();
		String status1 = ooTestutil.getStatusOfJob(kpiJobId_1);
		String status2 = ooTestutil.getStatusOfJob(kpiJobId_2);
		String status3 = ooTestutil.getStatusOfJob(kpiJobId_3);

		if (status1.equalsIgnoreCase("Running") || status2.equalsIgnoreCase("Running")
				|| status3.equalsIgnoreCase("Running")) {

			// DELETE KPI
			// DELETE KPI
			System.out.println("+++DELETE KPI+++++++++++++++++++++++++++++++++++");
			String kpiDeleteUrl = getTestProperty("kpi_url") + "/" + kpi_id;
			System.out.println("+++ kpiDeleteUrl == " + kpiDeleteUrl);
			Response delete_response = deleteServiceResponse("kpi_url" + "/" + kpi_id, values,
					ooTestutil.kpiprovideHeaders());
			System.out.println("+++ delete_response.asString() == " + delete_response.asString());
			isEqual("we should not be able to delete kpi", true,
					delete_response.getStatusCode() == HttpStatus.SC_FAILED_DEPENDENCY);
			ooTestutil.printnewLine();

			// delete/Stop kpi job
			System.out.println("*****************DELETE JOB*******************");
			ooTestutil.printnewLine();
			ooTestutil.deleteKpiJob(kpiJobId_1);
			System.out.println("*****************DELETE JOB*******************");
			ooTestutil.printnewLine();
			ooTestutil.deleteKpiJob(kpiJobId_2);
			System.out.println("*****************DELETE JOB*******************");
			ooTestutil.printnewLine();
			ooTestutil.deleteKpiJob(kpiJobId_3);

			// DELETE KPI

			System.out.println("*****************DELETE KPI*******************");
			kpiDeleteUrl = getTestProperty("kpi_url") + "/" + kpi_id;
			System.out.println("+++ kpiDeleteUrl == " + kpiDeleteUrl);
			delete_response = deleteServiceResponse("kpi_url" + "/" + kpi_id, values, ooTestutil.kpiprovideHeaders());
			System.out.println("+++ delete_response.asString() == " + delete_response.asString());
			isEqual("we should  be able to delete kpi", true,
					delete_response.getStatusCode() == HttpStatus.SC_NO_CONTENT);
			ooTestutil.printnewLine();
			// GET KPI

			System.out.println("+++GET KPI AFTER DELETE KPI+++++++++++++++++++++++++++++++++++");
			String getKpiUrl = "kpi_url" + "/id/" + kpi_id;
			Response get_response = getServiceResponse(getKpiUrl, ooTestutil.kpiprovideHeaders());
			isEqual("Delete Failed", 404, get_response.getStatusCode());
			System.out.println("testDeleteKpiScenario2 Passed. KPI was deleted successfully");

		}

	}

	/********************************************************************************************************************
	 * Delete Kpi::
	 * 
	 * Scenario: Create Kpi -> Get Kpi -> Create Kpi Job -> Start Kpi Job -> Job
	 * in Finished State -> Delete Kpi -> Get Kpi
	 * 
	 ********************************************************************************************************************/
	@Test(priority = 1, description = "testDeleteKpiScenario5")
	@RallyInfo(UserStory = "USXXXXX")
	public void testDeleteKpiScenario5() throws Exception {

		System.out.println("*****************Create KPI TEMPLATE*******************");
		ooTestutil.printnewLine();

		// create kpi template
		kpi_id = ooTestutil.createKpiTemplate(path + "/kpi_templates/kpiTemplate_1.json",
				path + "/kpi_analytics_1/analytic_1.zip");
		Thread.sleep(10000);

		// create kpi job
		System.out.println("+++CREATE KPI JOB+++++++++++++++++++++++++++++++++++");
		ooTestutil.printnewLine();

		String inputTag = "OO_Tag_Temperature_ID0";
		kpiJobId = ooTestutil.createKpiJobWithNoRandomBothInputAndOutputTag(path + "/kpi_jobs/kpiJob_1.json", kpi_id,
				"OO_Tag_Temperature_ID1", inputTag, "");
		Thread.sleep(10000);

		// start job
		System.out.println("+++START JOB+++++++++++++++++++++++++++++++++++");
		ooTestutil.printnewLine();
		ooTestutil.startKpiJob(kpiJobId);

		// get status of the job
		System.out.println("+++GET STATUS OF JOB+++++++++++++++++++++++++++++++++++");
		ooTestutil.printnewLine();
		String status = ooTestutil.getStatusOfJob(kpiJobId);

		if (status.equalsIgnoreCase("FINISHED")) {

			// DELETE KPI
			String kpiDeleteUrl = getTestProperty("kpi_url") + "/" + kpi_id;
			System.out.println("+++ DELETE KPI AND CACSCADE DELETE KPI JOB +++++++++++++++++++++++++++++++++++");
			kpiDeleteUrl = getTestProperty("kpi_url") + "/" + kpi_id;
			System.out.println("+++ kpiDeleteUrl == " + kpiDeleteUrl);
			Response delete_response = deleteServiceResponse("kpi_url" + "/" + kpi_id, values,
					ooTestutil.kpiprovideHeaders());
			System.out.println("+++ delete_response.asString() == " + delete_response.asString());
			isEqual("we should be able to delete kpi", true,
					delete_response.getStatusCode() == HttpStatus.SC_NO_CONTENT);

			// GET KPI
			ooTestutil.printnewLine();
			System.out.println("+++ GET KPI BY ID+++++++++++++++++++++++++++++++++++");
			String getKpiUrl = "kpi_url" + "/id/" + kpi_id;
			Response get_response = getServiceResponse(getKpiUrl, ooTestutil.kpiprovideHeaders());
			isEqual("Delete failed", 404, get_response.getStatusCode());
			if (get_response.getBody().asString().equals("")) {
				System.out.println("testDeleteKpiScenario2 Passed. KPI was deleted successfully");
			}

			// get status of the job
			String response = ooTestutil.getStatusOfJob(kpiJobId);
			isEqual("Delete Failed", true, StringUtils.isNullOrEmpty(response));
		}

	}

	// create->schedule->start->delete->failed
	@Test(priority = 1, description = "testDeleteKpiScenarioScheduling1")
	@RallyInfo(UserStory = "USXXXXX")
	public void testDeleteKpiScenarioScheduling1() throws Exception {

		System.out.println("*****************Create KPI TEMPLATE*******************");
		ooTestutil.printnewLine();

		// create kpi template
		kpi_id = ooTestutil.createKpiTemplate(path + "/kpi_templates/kpiTemplate_1.json",
				path + "/kpi_analytics_1/analytic_1.zip");
		Thread.sleep(10000);

		// create kpi job
		System.out.println("+++CREATE KPI JOB+++++++++++++++++++++++++++++++++++");
		ooTestutil.printnewLine();

		String inputTag = "OO_Tag_Temperature_ID0";
		setSysProperty("language", "JAVA");
		kpiJobId = ooTestutil.createKpiJobWithSchedulerInfo(
				path + "/kpi_jobs/kpi_e2e_ooapmts_inputAndOutput_job_with_scheduler.json", kpi_id,
				"OO_Tag_Temperature_ID1", inputTag, inputTag, 30);

		// start job
		System.out.println("+++START JOB+++++++++++++++++++++++++++++++++++");
		ooTestutil.printnewLine();
		ooTestutil.startKpiJob(kpiJobId);

		Thread.sleep(90000);
		// get status of the job
		System.out.println("+++GET STATUS OF JOB+++++++++++++++++++++++++++++++++++");
		ooTestutil.printnewLine();
		String status = ooTestutil.getStatusOfJob(kpiJobId);

		if (status.equalsIgnoreCase("RUNNING")) {

			// DELETE KPI
			System.out.println("+++DELETE KPI+++++++++++++++++++++++++++++++++++");
			String kpiDeleteUrl = getTestProperty("kpi_url") + "/" + kpi_id;
			System.out.println("+++ kpiDeleteUrl == " + kpiDeleteUrl);
			Response delete_response = deleteServiceResponse("kpi_url" + "/" + kpi_id, values,
					ooTestutil.kpiprovideHeaders());
			System.out.println("+++ delete_response.asString() == " + delete_response.asString());
			isEqual("we should not be able to delete kpi", true,
					delete_response.getStatusCode() == HttpStatus.SC_FAILED_DEPENDENCY);
			ooTestutil.printnewLine();

			// delete/Stop kpi job
			System.out.println("+++DELETE KPI JOB+++++++++++++++++++++++++++++++++++");
			ooTestutil.deleteKpiJob(kpiJobId);
			ooTestutil.printnewLine();

			// DELETE KPI

			System.out.println("+++DELETE KPI AFTER DELETE JOB+++++++++++++++++++++++++++++++++++");
			kpiDeleteUrl = getTestProperty("kpi_url") + "/" + kpi_id;
			System.out.println("+++ kpiDeleteUrl == " + kpiDeleteUrl);
			delete_response = deleteServiceResponse("kpi_url" + "/" + kpi_id, values, ooTestutil.kpiprovideHeaders());
			System.out.println("+++ delete_response.asString() == " + delete_response.asString());
			isEqual("we should  be able to delete kpi", true,
					delete_response.getStatusCode() == HttpStatus.SC_NO_CONTENT);
			ooTestutil.printnewLine();

			// GET KPI
			System.out.println("+++GET KPI AFTER DELETE KPI+++++++++++++++++++++++++++++++++++");
			String getKpiUrl = "kpi_url" + "/id/" + kpi_id;
			Response get_response = getServiceResponse(getKpiUrl, ooTestutil.kpiprovideHeaders());
			isEqual("Delete Failed", 404, get_response.getStatusCode());
			System.out.println("testDeleteKpiScenario2 Passed. KPI was deleted successfully");
		}

	}

	@Test(priority = 1, description = "testDeleteKpiScenarioScheduling2")
	@RallyInfo(UserStory = "USXXXXX")
	public void testDeleteKpiScenarioScheduling2() throws Exception {

		System.out.println("*****************Create KPI TEMPLATE*******************");
		ooTestutil.printnewLine();

		// create kpi template
		kpi_id = ooTestutil.createKpiTemplate(path + "/kpi_templates/kpiTemplate_1.json",
				path + "/kpi_analytics_1/analytic_1.zip");
		Thread.sleep(10000);

		// create kpi job
		System.out.println("+++CREATE KPI JOB+++++++++++++++++++++++++++++++++++");
		ooTestutil.printnewLine();

		String inputTag = "OO_Tag_Temperature_ID0";
		setSysProperty("language", "JAVA");
		kpiJobId = ooTestutil.createKpiJobWithSchedulerInfo(
				path + "/kpi_jobs/kpi_e2e_ooapmts_inputAndOutput_job_with_scheduler.json", kpi_id,
				"OO_Tag_Temperature_ID1", inputTag, inputTag, 30);

		// start job
		System.out.println("+++START JOB+++++++++++++++++++++++++++++++++++");
		ooTestutil.printnewLine();
		ooTestutil.startKpiJob(kpiJobId);

		// DELETE KPI

		System.out.println("+++DELETE KPI AFTER DELETE JOB+++++++++++++++++++++++++++++++++++");
		String kpiDeleteUrl = getTestProperty("kpi_url") + "/" + kpi_id;
		System.out.println("+++ kpiDeleteUrl == " + kpiDeleteUrl);
		Response delete_response = deleteServiceResponse("kpi_url" + "/" + kpi_id, values,
				ooTestutil.kpiprovideHeaders());
		System.out.println("+++ delete_response.asString() == " + delete_response.asString());
		isEqual("we should  be able to delete kpi", true, delete_response.getStatusCode() == HttpStatus.SC_NO_CONTENT);
		ooTestutil.printnewLine();

		// GET KPI
		System.out.println("+++GET KPI AFTER DELETE KPI+++++++++++++++++++++++++++++++++++");
		String getKpiUrl = "kpi_url" + "/id/" + kpi_id;
		Response get_response = getServiceResponse(getKpiUrl, ooTestutil.kpiprovideHeaders());
		isEqual("Delete Failed", 404, get_response.getStatusCode());
		System.out.println("testDeleteKpiScenario2 Passed. KPI was deleted successfully");
		
		// get status of the job
		String response = ooTestutil.getStatusOfJob(kpiJobId);
		isEqual("Delete Failed", true, StringUtils.isNullOrEmpty(response));
	}

	/********************************************************************************************************************
	 * UPDATE Kpi::
	 * 
	 * 
	 * 
	 ********************************************************************************************************************/
	// @Test(priority=25,description="testUpdateKpi")
	public void testUpdateKpi() throws Exception {

		System.out.println("*****************Create KPI TEMPLATE*******************");
		ooTestutil.printnewLine();

		// *****************Create KPI
		// TEMPLATE***************************************************//

		// create kpi template
		kpi_id = ooTestutil.createKpiTemplate("src/main/resources/payloadsEventHub/kpi_templates/kpiTemplate_13.json",
				"src/main/resources/payloadsEventHub/kpi_analytics_1/analytic_13.zip");
		Thread.sleep(10000);

		ooTestutil.printnewLine();

		// *****************GET
		// KPI****************************************************************//

		String getKpiUrl = "kpi_url" + "/id/" + kpi_id;
		System.out.println("\n\n+++ getKpiUrl ********== " + getKpiUrl + "\n\n");
		Response get_response = getServiceResponse(getKpiUrl, ooTestutil.kpiprovideHeaders());

		System.out.println("\n\n+++ response.asString() == " + get_response.asString() + "\n\n");
		String kpiName = get_response.jsonPath().getString("name[0]");
		System.out.println("\n\n+++ kpiName ********== " + kpiName + "\n\n");
		isEqual("Incorrect tag name", true, get_response.body().asString().contains(String.valueOf(kpi_id)));
		isEqual("Incorrect tag name", true, get_response.body().jsonPath().getList("inputs").size() > 0);
		isEqual("Incorrect tag name", true, get_response.body().jsonPath().getList("outputs").size() > 0);

		ooTestutil.printnewLine();

		// Update KPI Json
		String KpitemplateJsonPath = "src/main/resources/payloadsEventHub/kpi_templates/kpiTemplate_13_update.json";
		ooTestutil.updateKpiTemplateJsonFile(kpi_id, kpiName, KpitemplateJsonPath);
		ooTestutil.printnewLine();

		// Update KPI Analytic
		String KpitemplateAnalyticPath = "src/main/resources/payloadsEventHub/kpi_analytics_1/analytic_1.zip";
		ooTestutil.updateKpiTemplateAnalyticFile(kpi_id, KpitemplateAnalyticPath);
		ooTestutil.printnewLine();

		// DELETE KPI

		/*
		 * String kpiDeleteUrl = getTestProperty("kpi_url") + "/" + kpi_id;
		 * System.out.println("+++ kpiDeleteUrl == " + kpiDeleteUrl); Response
		 * delete_response = deleteServiceResponse("kpi_url" + "/" + kpi_id,
		 * values, ooTestutil.kpiprovideHeaders());
		 */
		// System.out.println("+++ delete_response.asString() == " +
		// delete_response.asString());
		// isEqual("Incorrect tag name", true,
		// delete_response.body().jsonPath().get("code").equals("OK"));

	}

	// @Test(priority = 1, description = "testOutOfMemoryError")
	// @RallyInfo(UserStory = "US28339")
	public void testOutOfMemoryError() throws Exception {

		System.out.println("*****************Create KPI TEMPLATE*******************");
		ooTestutil.printnewLine();

		// create kpi template
		kpi_id = ooTestutil.createKpiTemplate("src/main/resources/payloadsEventHub/kpi_templates/kpiTemplate_2.json",
				"src/main/resources/payloadsEventHub/kpi_analytics_1/analytic_2.zip");

		ooTestutil.printnewLine();
		System.out.println("+++ CREATE KPI JOB+++++++++++++++++++++++++++++++++++");
		// create kpi job
		String inputTag = "OO_Tag_Temperature";
		kpiJobId = ooTestutil.createKpiJobWithInputAndOutputTag(
				"src/main/resources/payloadsEventHub/kpi_jobs/kpiJob_2.json", kpi_id, "Output_OO_Tag_Temperature",
				inputTag);
		ooTestutil.printnewLine();
		int i = 0;
		while (i < 10) {
			System.out.println("+++Start KPI JOB and iteration=" + i + "+++++++++++++++++++++++++++++++++++");
			// start job
			ooTestutil.startKpiJob(kpiJobId);
			ooTestutil.printnewLine();
			i++;
		}
		// Thread.sleep(15000);
	}

	@AfterTest
	public void afterTest() {
	}

	@BeforeSuite
	public void beforeSuite() {

	}

	@AfterSuite
	public void afterSuite() {
	}
}

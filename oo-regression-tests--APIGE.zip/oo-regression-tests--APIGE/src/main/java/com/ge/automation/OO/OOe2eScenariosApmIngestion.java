package com.ge.automation.OO;

import java.util.LinkedHashMap;
import java.util.Map;
import java.util.Properties;

import org.springframework.boot.test.TestRestTemplate;
import org.springframework.web.client.RestTemplate;
import org.testng.annotations.AfterClass;
import org.testng.annotations.AfterMethod;
import org.testng.annotations.AfterSuite;
import org.testng.annotations.AfterTest;
import org.testng.annotations.BeforeClass;
import org.testng.annotations.BeforeMethod;
import org.testng.annotations.BeforeSuite;
import org.testng.annotations.BeforeTest;
import org.testng.annotations.Test;

import com.ge.microtester.common.utils.RestAssuredUtil;
import com.ge.microtester.rally.RallyInfo;
import com.jayway.restassured.response.Response;

@RallyInfo(ProjectName = "Operations Optimization Execution", FolderPath = "OO/Q3Release")
public class OOe2eScenariosApmIngestion extends RestAssuredUtil {

	static String jsonfileName;
	Properties configFile = new Properties();
	String truncateDateTime[];
	String tagName;
	String proxyHost;
	String proxyPort;
	Response responseBody;
	String kpiid;
	String kpiJobId;
	String dataSourceId;
	long kpi_id;
	long kpi_id1;

	public OOTestUtil ooTestutil = new OOTestUtil();
	RestTemplate restTemplate = new TestRestTemplate();
	// Generating Query Params
	Map<String, Object> values = new LinkedHashMap<String, Object>();

	@BeforeMethod
	public void beforeMethod() {}

	@AfterMethod
	public void afterMethod() {}

	@BeforeClass
	public void beforeClass() {

		System.getProperties().put("proxySet", "true");
		System.getProperties().put("http.proxyHost", "sjc1intproxy01.crd.ge.com");
		System.getProperties().put("http.proxyPort", "8080");
		System.getProperties().put("https.proxyHost", "sjc1intproxy01.crd.ge.com");
		System.getProperties().put("https.proxyPort", "8080");
		getServiceResponse("alert_profile_base_url");
		setSysProperty("currentTimeStamp", "" + getCurrentTimestamp());// ${sys:currentTimeStamp}

	}// end of beforeClass

	@AfterClass
	public void afterClass() {}

	@BeforeTest
	public void beforeTest() {

	}// end of beforeTest



	/********************************************************************************************************************
     Test Case: StreamTS and AssetDS input data providers
                OOStream as output data providers
     Test Steps:         
      1)  Create Kpi Template.
      2)  Create Kpi Job with kpireference id. 
      3)  Start Job
      4)  Assert data that is written to Kafka topic.         
	 ********************************************************************************************************************/
	@Test(priority = 1, description = "testE2E_AssetNStreamInputs_StreamOutput")
	@RallyInfo(UserStory = "USXXXXX")
	public void testE2E_AssetNStreamInputs_StreamOutput() throws Exception {

		//create kpi template
		kpi_id = ooTestutil.createKpiTemplate("src/main/resources/payloadsEventHub/kpi_templates/kpiTemplateStreamTsAssetDS.json", 
				"src/main/resources/payloadsEventHub/kpi_analytics/kpiAnalyticStreamTsAssetDs.zip");
		//create kpi job
		kpiJobId = ooTestutil.createKpiJob("src/main/resources/payloadsEventHub/kpi_jobs/kpiStreamTsAssetDSJob.json",kpi_id);
		//start job
		ooTestutil.startKpiJob(kpiJobId);
		//get status of the job
		String status = ooTestutil.getStatusOfJob(kpiJobId);
		Thread.sleep(30000);

		if(status.equalsIgnoreCase("Running"))
		{
			//post data point to Event hub		
			ooTestutil.postDataPointToAPMTimeSeries("src/main/resources/payloadsEventHub/data_files/data_ingestion.json","OO_Tag_Temperature_ID203");		
			Thread.sleep(30000);

			//get calculated data point from Kafka topic
			String OutputtagNamePosted = "kpioutput_int";
			String calculatedData = ooTestutil.getDataPointFromKafkaTopic(OutputtagNamePosted);

			//Assert if the Analytic calculated data posted to event hub
			isEqual("Data not calculated", "2009.99",calculatedData);

			//data saved to Apm TS by Analytic consumer
			//ooTestutil.getDataFromApmTimeSeries(OutputtagNamePosted, "2009.99");	

			//delete kpi job
			ooTestutil.deleteKpiJob(kpiJobId);

			//get status of kpi job
			ooTestutil.getStatusOfJob(kpiJobId);			
			Thread.sleep(30000);
		}else{
			isEqual("Job not Started Successfully.Status of the JOB is --->"+status,true,false);
		}	
	}
	/********************************************************************************************************************
    Test Case: StreamTS input data provider
               OOStream as output data provider
    Test Steps:         
     1)  Create Kpi Template.
     2)  Create Kpi Job with kpireference id. 
     3)  Start Job
     4)  Assert data that is written to Kafka topic. 
	/********************************************************************************************************************/
	@Test(priority = 2, description = "testE2E_StreamInput_StreamOutput")
	@RallyInfo(UserStory = "US28339")
	public void testE2E_StreamInput_StreamOutput() throws Exception {

		//create kpi template
		kpi_id = ooTestutil.createKpiTemplate("src/main/resources/payloadsEventHub/kpi_templates/kpiTemplateStreamTs.json", 
				"src/main/resources/payloadsEventHub/kpi_analytics/kpiAnalyticStreamTs.zip");
		//create kpijob
		kpiJobId = ooTestutil.createKpiJob("src/main/resources/payloadsEventHub/kpi_jobs/kpiStreamTsJob.json",kpi_id);
		//start kpi job
		ooTestutil.startKpiJob(kpiJobId);
		Thread.sleep(30000);
		//status of the job
		String status = ooTestutil.getStatusOfJob(kpiJobId);
		Thread.sleep(30000);

		if(status.equalsIgnoreCase("Running"))
		{
			//post data to event hub		
			ooTestutil.postDataPointToAPMTimeSeries("src/main/resources/payloadsEventHub/data_files/data_ingestion_ts.json","OO_Tag_Humidity_ID");
			Thread.sleep(30000);
			//get data from Kafka topic
			String OutputtagNamePosted = "qa_kpioutput_ts_doubled";
			String calculatedData = ooTestutil.getDataPointFromKafkaTopic(OutputtagNamePosted);
			Thread.sleep(30000);

			//Assert if the Analytic calculated data posted to event hub
			isEqual("Data not calculated", "180.0303054118169",calculatedData);

			//data posted to APM TS by Analytic Consumer
			//ooTestutil.getDataFromApmTimeSeries(OutputtagNamePosted, "180.0303054118169");	

			//delete kpi job
		    ooTestutil.deleteKpiJob(kpiJobId);
			Thread.sleep(30000);

			//get status of the job
		    ooTestutil.getStatusOfJob(kpiJobId);			
			Thread.sleep(30000);
		}else{
			isEqual("Job not Started Successfully.Status of the JOB is --->"+status,true,false);
		}	
	}
	/********************************************************************************************************************
    Test Case: StreamTS input data provider
               OOStream as output data provider
               Analytic without Output Tag.
               Kpi Job specifies Output tag
    Test Steps:         
     1)  Create Kpi Template.
     2)  Create Kpi Job with kpireference id. 
     3)  Start Job
     4)  Assert data that is written to Kafka topic.
	/********************************************************************************************************************/
	@Test(priority = 3, description = "testE2E_StreamInput_StreamOutputWithConfiguredTag")
	@RallyInfo(UserStory = "US8804")
	public void testE2E_StreamInput_StreamOutputWithConfiguredTag() throws Exception {

		//create kpi template
		kpi_id = ooTestutil.createKpiTemplate("src/main/resources/payloadsEventHub/kpi_templates/kpiTemplateStreamTs.json", 
				"src/main/resources/payloadsEventHub/kpi_analytics/kpiAnalyticWithoutTag.zip");
		Thread.sleep(10000);

		//create kpi job
		kpiJobId = ooTestutil.createKpiJobWithTag("src/main/resources/payloadsEventHub/kpi_jobs/kpiStreamTSWithTagJob.json",kpi_id,"OO_Tag_WINDSPEED");
		Thread.sleep(10000);

		//start kpi job
		ooTestutil.startKpiJob(kpiJobId);
		Thread.sleep(30000);

		//get Status of the job
		String status = ooTestutil.getStatusOfJob(kpiJobId);
		Thread.sleep(30000);

		if(status.equalsIgnoreCase("Running"))
		{

			//post data to event hub		
			ooTestutil.postDataPointToAPMTimeSeries("src/main/resources/payloadsEventHub/data_files/data_ingestion_ts_tag.json","OO_Tag_WINDSPEED");		

			Thread.sleep(30000);

			//get output tag from Kpi Job response
			String OutputtagNamePosted = ooTestutil.getOutputTagFromKpiJob(kpiJobId);		
			Thread.sleep(10000);

			//get data from Kafka topic
			String calculatedData = ooTestutil.getDataPointFromKafkaTopic(OutputtagNamePosted);

			//Assert if the Analytic calculated data posted to event hub
			isEqual("Data not calculated", "509.99",calculatedData);

			//get data from Apm Ts
			//ooTestutil.getDataFromApmTimeSeries(OutputtagNamePosted, "509.99");	
			//Thread.sleep(30000);

			//delete kpi job
			ooTestutil.deleteKpiJob(kpiJobId);
			Thread.sleep(30000);

			//get status of the job
			ooTestutil.getStatusOfJob(kpiJobId);			
			Thread.sleep(30000);
		}else{
			isEqual("Job not Started Successfully.Status of the JOB is --->"+status,true,false);
		}	
	}
	/********************************************************************************************************************
    Test Case: StreamTS input data provider
               OOStream as output data provider
               Analytic without Output Tag.
               Kpi Job Also does not specify Output tag
    Test Steps:         
     1)  Create Kpi Template.
     2)  Create Kpi Job with kpireference id. 
     3)  Start Job
     4)  Assert data that is written to Kafka topic.
	/********************************************************************************************************************/
	@Test(priority = 4, description = "testE2E_StreamInput_StreamOutputWithMissingConfiguredTag")
	@RallyInfo(UserStory = "US8804")
	public void testE2E_StreamInput_StreamOutputWithMissingConfiguredTag() throws Exception {

		//create kpi template
		kpi_id = ooTestutil.createKpiTemplate("src/main/resources/payloadsEventHub/kpi_templates/kpiTemplateStreamTs.json", 
				"src/main/resources/payloadsEventHub/kpi_analytics/kpiAnalyticWithoutTag.zip");
		Thread.sleep(10000);

		//create kpi job
		kpiJobId = ooTestutil.createKpiJob("src/main/resources/payloadsEventHub/kpi_jobs/kpiStreamTsJob.json",kpi_id);
		Thread.sleep(10000);

		//start kpi job
		ooTestutil.startKpiJob(kpiJobId);
		Thread.sleep(30000);

		//get status of job
		String status = ooTestutil.getStatusOfJob(kpiJobId);
		Thread.sleep(10000);
		
		isEqual("Job successfully shutdown due to failure in analytic for missing configuration ", true, status.equalsIgnoreCase("FINISHED"));

	}
	/********************************************************************************************************************
    Test Case: StreamTS and AssetDs input data providers
               OOStream as output data provider
               Analytic Calculation based on Attributes
    Test Steps:         
     1)  Create Kpi Template.
     2)  Create Kpi Job with kpireference id. 
     3)  Start Job
     4)  Assert data that is written to Kafka topic.

	/********************************************************************************************************************/
	@Test(priority = 5, description = "testE2E_AssetNStreamInputs_StreamOutput_WithAttributes")
	@RallyInfo(UserStory = "US33399")
	public void testE2E_AssetNStreamInputs_StreamOutput_WithAttributes() throws Exception {

		//create kpi template
		kpi_id = ooTestutil.createKpiTemplate("src/main/resources/payloadsEventHub/kpi_templates/kpiTemplateStreamTsAssetDS.json", 
				"src/main/resources/payloadsEventHub/kpi_analytics/kpiAnalyticWithAttributesNooutputTag.zip");
		Thread.sleep(10000);

		//create kpi job
		kpiJobId = ooTestutil.createKpiJobWithTag("src/main/resources/payloadsEventHub/kpi_jobs/kpiStreamTsAssetDSJob.json",kpi_id,"OO_Tag_Pressure_ID_OutPut");
		Thread.sleep(10000);

		//start kpi job
		ooTestutil.startKpiJob(kpiJobId);
		Thread.sleep(30000);

		//get status of the job
		String status = ooTestutil.getStatusOfJob(kpiJobId);
		Thread.sleep(30000);

		if(status.equalsIgnoreCase("Running"))
		{

			//post data to event hub		
			ooTestutil.postDataPointToAPMTimeSeries("src/main/resources/payloadsEventHub/data_files/data_ingestion_ts_attributes.json","OO_Tag_Pressure_ID");		
			Thread.sleep(10000);

			//get outtag from kpi job response
			String OutputtagNamePosted = ooTestutil.getOutputTagFromKpiJob(kpiJobId);
			Thread.sleep(20000);

			//get data from Kafka topic
			String calculatedData = ooTestutil.getDataPointFromKafkaTopic(OutputtagNamePosted);

			Thread.sleep(20000);
			//Assert if the Analytic calculated data posted to event hub
			isEqual("Data not calculated","6878.651281927272", calculatedData);

			//get data from APM time series
			//ooTestutil.getDataFromApmTimeSeries(OutputtagNamePosted, "6878.651281927272");	
			//Thread.sleep(10000);

			//delete kpi job
			ooTestutil.deleteKpiJob(kpiJobId);
			Thread.sleep(10000);

			//get status of the job
			ooTestutil.getStatusOfJob(kpiJobId);	

			Thread.sleep(30000);
		}else{
			isEqual("Job not Started Successfully.Status of the JOB is --->"+status,true,false);
		}	
	}

	/********************************************************************************************************************
    Test Case: StreamTS input And AssetDS as data provider
               OO APM TS as output data provider

    Test Steps:         
     1)  Create Kpi Template.
     2)  Create Kpi Job with kpireference id. 
     3)  Start Job
     4)  Assert data that is written to Kafka topic.

	/********************************************************************************************************************/


	@Test(priority = 6, description = "testE2E_AssetNStreamInputs_ApmTSOutput")
	@RallyInfo(UserStory = "US4776")
	public void testE2E_AssetNStreamInputs_ApmTSOutput() throws Exception {

		//create kpi template
		kpi_id = ooTestutil.createKpiTemplate("src/main/resources/payloadsEventHub/kpi_templates/kpiTemplateWriteToOOApmTs.json", 
				"src/main/resources/payloadsEventHub/kpi_analytics/kpiAnalyticWriteToOOApmTs.zip");
		Thread.sleep(10000);

		//create kpi job
		kpiJobId = ooTestutil.createKpiJobWithTag("src/main/resources/payloadsEventHub/kpi_jobs/kpiWriteToOOApmTSJob.json",kpi_id,"OO_Tag_WINDSPEED");
		Thread.sleep(10000);

		//start kpi job
		ooTestutil.startKpiJob(kpiJobId);
		Thread.sleep(30000);

		//get Status of the Job
		String status = ooTestutil.getStatusOfJob(kpiJobId);
		Thread.sleep(30000);


		if(status.equalsIgnoreCase("Running"))
		{
			
			//post data to event hub		
			ooTestutil.postDataPointToAPMTimeSeries("src/main/resources/payloadsEventHub/data_files/data_ingestion_ooapmts.json", "OO_Tag_WINDSPEED");			
			Thread.sleep(20000);

			//get output tag name from job
			String OutputtagNamePosted = ooTestutil.getOutputTagFromKpiJob(kpiJobId);
			Thread.sleep(30000);

			//get data from Kafka topic
			//String calculatedData = ooTestutil.getDataPointFromKafkaTopic(OutputtagNamePosted);
			//Thread.sleep(30000);

			//Assert if the Analytic calculated data posted to event hub
			//isEqual("Data not calculated", "55556.116409636365",calculatedData);

			//Thread.sleep(30000);
			//get data from Apm time Series
			ooTestutil.getDataFromApmTimeSeries(OutputtagNamePosted, "55556.116409636365");	
			Thread.sleep(30000);

			//delete kpi job
			ooTestutil.deleteKpiJob(kpiJobId);
			Thread.sleep(30000);

			//get status of the job
			ooTestutil.getStatusOfJob(kpiJobId);		

			Thread.sleep(30000);
		}else{
			isEqual("Job not Started Successfully.Status of the JOB is --->"+status,true,false);
		}	
	}


	/*********************************************************************************************************/

	@Test(priority = 7, description = "testE2E_ApmTSInput_ApmTSOutput")
	@RallyInfo(UserStory = "US4776")
	public void testE2E_ApmTSInput_ApmTSOutput() throws Exception {
		
		//ingest test data into apm time series
		ooTestutil.postDataPointToAPMTimeSeries("src/main/resources/payloadsEventHub/data_files/apmts_for_pre_ingestion.json");
		
		//create kpi template
		kpi_id = ooTestutil.createKpiTemplate("src/main/resources/payloadsEventHub/kpi_templates/kpi_e2e_ooapmts_inputAndOutput.json", 
				"src/main/resources/payloadsEventHub/kpi_analytics/analytic_ooapmts_outputAndinput.zip");
		Thread.sleep(10000);

		//create kpi job
		kpiJobId = ooTestutil.createKpiJobWithTag("src/main/resources/payloadsEventHub/kpi_jobs/kpi_e2e_ooapmts_inputAndOutput_job.json",kpi_id,"TEST-ASSET-TYPE_KT.Tag_Length_Automation");
		Thread.sleep(10000);

		//start kpi job
		ooTestutil.startKpiJob(kpiJobId);
		Thread.sleep(30000);

		//get Status of the Job
		String status = ooTestutil.getStatusOfJob(kpiJobId);
		Thread.sleep(30000);


		if(status.equalsIgnoreCase("FINISHED"))
		{

			//get output tag name from job
			String OutputtagNamePosted = ooTestutil.getOutputTagFromKpiJob(kpiJobId);
			Thread.sleep(30000);

			//get data from Apm time Series
			//Thread.sleep(30000);
			ooTestutil.getDataFromApmTimeSeries(OutputtagNamePosted, "14.44444444");	
			Thread.sleep(30000);

			//delete kpi job
			ooTestutil.deleteKpiJob(kpiJobId);
			Thread.sleep(30000);

			//get status of the job
			ooTestutil.getStatusOfJob(kpiJobId);		

			Thread.sleep(30000);
		}else{
			isEqual("Job not Started Successfully.Status of the JOB is --->"+status,true,false);
		}

	}
	/********************************************************************************************************************/
	@Test(priority = 8, description = "testE2E_StreamInput_ApmTSOutput")
	@RallyInfo(UserStory = "DE10414")
	public void testE2E_StreamInput_ApmTSOutput() throws Exception {

		//create kpi template
		kpi_id = ooTestutil.createKpiTemplate("src/main/resources/payloadsEventHub/kpi_templates/kpi_e2e_oostream_ooapmts.json", 
				"src/main/resources/payloadsEventHub/kpi_analytics/analytic_oostream_ooapmts.zip");
		Thread.sleep(10000);

		//create kpi job
		kpiJobId = ooTestutil.createKpiJobWithTag("src/main/resources/payloadsEventHub/kpi_jobs/kpi_e2e_oostream_ooapmts_job.json",kpi_id,"OO_Tag_TURBINESPEED_OUTPUT");
		Thread.sleep(10000);

		//start kpi job
		ooTestutil.startKpiJob(kpiJobId);
		Thread.sleep(30000);

		//get Status of the Job
		String status = ooTestutil.getStatusOfJob(kpiJobId);
		Thread.sleep(30000);


		if(status.equalsIgnoreCase("Running"))
		{

			//post data point to Event hub		
			ooTestutil.postDataPointToAPMTimeSeries("src/main/resources/payloadsEventHub/data_files/data_ingestion_oostream_ooapmts.json", "OO_Tag_TURBINESPEED");	


			//get output tag name from job
			String OutputtagNamePosted = ooTestutil.getOutputTagFromKpiJob(kpiJobId);
			Thread.sleep(30000);

	

			//get data from Apm time Series
			//Thread.sleep(30000);
			ooTestutil.getDataFromApmTimeSeries(OutputtagNamePosted, "22226.11640963636");	
			Thread.sleep(30000);

			//delete kpi job
			ooTestutil.deleteKpiJob(kpiJobId);
			Thread.sleep(30000);

			//get status of the job
			ooTestutil.getStatusOfJob(kpiJobId);		

			Thread.sleep(30000);
		}else{
			isEqual("Job not Started Successfully.Status of the JOB is --->"+status,true,false);
		}	

	}
	/********************************************************************************************************************/

	@Test(priority = 9, description = "testE2E_ApmTSInput_NoTag_ApmTSOutput")
	@RallyInfo(UserStory = "DE11196")
	public void testE2E_ApmTSInput_NoTag_ApmTSOutput() throws Exception {
		
		//create kpi template
		kpi_id = ooTestutil.createKpiTemplate("src/main/resources/payloadsEventHub/kpi_templates/kpi_e2e_ooapmts_inputAndOutput.json", 
				"src/main/resources/payloadsEventHub/kpi_analytics/analytic_ooapmts_noTag_outputAndinput.zip");
		Thread.sleep(10000);

		//create kpi job
		kpiJobId = ooTestutil.createKpiJobWithTag("src/main/resources/payloadsEventHub/kpi_jobs/kpi_e2e_ooapmts_NoTag_inputAndOutput_job.json",kpi_id,"TEST-ASSET-TYPE_KT.Tag_Length_Automation");
		Thread.sleep(10000);

		//start kpi job
		ooTestutil.startKpiJob(kpiJobId);
		Thread.sleep(30000);

		//get Status of the Job
		String status = ooTestutil.getStatusOfJob(kpiJobId);
		Thread.sleep(30000);

		isEqual("Job not Started Successfully.Status of the JOB is --->"+status,status,"FINISHED");



	}
	/*********************************************************************************************************/
	@AfterTest
	public void afterTest() {}

	@BeforeSuite
	public void beforeSuite() {

	}

	@AfterSuite
	public void afterSuite() {}
}

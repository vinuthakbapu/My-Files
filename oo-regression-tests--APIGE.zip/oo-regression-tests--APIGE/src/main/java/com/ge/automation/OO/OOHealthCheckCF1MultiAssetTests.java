package com.ge.automation.OO;

import java.io.IOException;
import java.net.URISyntaxException;
import java.util.LinkedHashMap;
import java.util.Map;
import java.util.Properties;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.boot.test.TestRestTemplate;
import org.springframework.web.client.RestTemplate;
import org.testng.Assert;
import org.testng.annotations.AfterClass;
import org.testng.annotations.AfterMethod;
import org.testng.annotations.AfterSuite;
import org.testng.annotations.AfterTest;
import org.testng.annotations.BeforeClass;
import org.testng.annotations.BeforeMethod;
import org.testng.annotations.BeforeSuite;
import org.testng.annotations.BeforeTest;
import org.testng.annotations.Test;

import com.ge.microtester.common.utils.RestAssuredUtil;
import com.ge.microtester.rally.RallyInfo;
import com.jayway.restassured.response.Response;

@RallyInfo(ProjectName ="APM Super Optimo")
public class OOHealthCheckCF1MultiAssetTests extends RestAssuredUtil {
	private static final Logger log = LoggerFactory.getLogger("OOHealthCheckCF1Tests");
	static String jsonfileName;
	Properties configFile = new Properties();
	String truncateDateTime[];
	String tagName;
	String proxyHost;
	String proxyPort;
	Response responseBody;
	String kpiid;
	String kpiJobId;
	String dataSourceId;
	long kpi_id;
	long kpi_id1;
	String path = "src/main/resources/payloadsAndromeda";
	String apmTSforIngestionPath;
	boolean apmIngestionDynamicTag;
	String kpiTemplateJsonPath;
	String kpiTemplateAnalyticPath;
	String kpiJobJsonPath;
	String dataIngestionFilePath;
	String inputTag;
	String outputTag;
	String expectedValue;
	String expectedJobStatus;
	boolean createKpiJobWithTag;
	String apmTsUrl = "";

	public OOTestUtil ooTestutil = new OOTestUtil();
	RestTemplate restTemplate = new TestRestTemplate();
	// Generating Query Params
	Map<String, Object> values = new LinkedHashMap<String, Object>();

	@BeforeMethod
	public void beforeMethod() {}

	@AfterMethod
	public void afterMethod() {}

	@BeforeClass
	public void beforeClass() {

		/*
		 * System.getProperties().put("proxySet", "true"); System.getProperties().put("http.proxyHost",
		 * "sjc1intproxy01.crd.ge.com"); System.getProperties().put("http.proxyPort", "8080");
		 * System.getProperties().put("https.proxyHost", "sjc1intproxy01.crd.ge.com");
		 * System.getProperties().put("https.proxyPort", "8080");
		 */
		// getServiceResponse("alert_profile_base_url");
		setSysProperty("currentTimeStamp", "" + getCurrentTimestamp());// ${sys:currentTimeStamp}

	}// end of beforeClass

	@AfterClass
	public void afterClass() {}

	@BeforeTest
	public void beforeTest() {

	}// end of beforeTest

	/********************************************************************************************************************/
	@Test
	public void test_ApmTsIngestion_ApmTsRetrieval() {
		// post data to apm
		int valuePosted;
		try {
			valuePosted = ooTestutil.postRandomDataPointToAPMTimeSeries(path + "/data_files/data_ingestion_gen.json",
					"OPM_Segment_Tag_Temperature_ID4");

			// get data from APM
			Thread.sleep(20000);
			ooTestutil.getDataFromApmTimeSeries("OPM_Segment_Tag_Temperature_ID4", String.valueOf(valuePosted));
		} catch (IOException | URISyntaxException | InterruptedException e) {
			Assert.fail("test_ApmIngestion_ApmRetrieval failed with message " + e.getMessage());
		}
	}

	/********************************************************************************************************************/
	@Test
	public void test_ApmAssetRetrieval() {
		log.info("Asserting Assets Exists");
		// get Asset data from APM
		try {
			ooTestutil.getAPMAssets();
		} catch (InterruptedException e) {
			Assert.fail("test_ApmAssetRetrieval failed with message " + e.getMessage());
		}
	}
	/********************************************************************************************************************/

	public void run_MultiAsset_Test(String assetEntityKey, String inputTag, String outputTag) throws Exception {
		// create kpi template
		kpi_id = ooTestutil.createKpiTemplate(path + "/kpi_templates/kpi_e2e_ooapmts_inputAndOutput.json",
				path + "/kpi_analytics/simple_java_version2.zip");
		Thread.sleep(10000);

		// create kpi job
		setSysProperty("assetEntityURI", getTestProperty(assetEntityKey));
		setSysProperty("startTimeStamp", Long.toString(System.currentTimeMillis()-2*86400000L));
		setSysProperty("endTimeStamp", Long.toString(System.currentTimeMillis()+2*86400000L));
		kpiJobId = ooTestutil.createKpiJobWithNoRandomBothInputAndOutputTag(
				path + "/kpi_jobs/kpi_e2e_job_multiAsset_java.json", kpi_id, outputTag, inputTag, "");

		int valuePosted =
				ooTestutil.postRandomDataPointToAPMTimeSeries(path + "/data_files/data_ingestion_gen.json", inputTag);

		// start kpi job
		String runtimeJobId = ooTestutil.startKpiJob(kpiJobId);
		Thread.sleep(30000);
		String statusOfJob = ooTestutil.getStatusOfJob(kpiJobId);

		String expectedValue = String.valueOf(valuePosted * 10);
		Thread.sleep(30000);
		ooTestutil.getDataFromApmTimeSeries(outputTag, expectedValue);
		log.info("\n+++ Expected Value ----> " + expectedValue);
		log.info("\n+++ Actual Value ----> " + valuePosted);


		// DELETE KPI
		/*
		 * log.info("+++ DELETE KPI+++++++++++++++++++++++++++++++++++"); String kpiDeleteUrl =
		 * getTestProperty("kpi_url") + "/" + kpi_id; log.info("+++ kpiDeleteUrl == " + kpiDeleteUrl); Response
		 * delete_response = deleteServiceResponse("kpi_url" + "/" + kpi_id, values, ooTestutil.kpiprovideHeaders());
		 * log.info("+++ delete_response.asString() == " + delete_response.asString());
		 */


		ooTestutil.printnewLine();

		ooTestutil.printnewLine();
	}



	/********************************************************************************************************************/
	@Test(dependsOnMethods={"test_ApmTsIngestion_ApmTsRetrieval","test_ApmAssetRetrieval"})
	@RallyInfo(UserStory ="US205678")
	public void testE2E_ApmTSInput_ApmTSOutput_MultiAsset_Java() throws Exception {
		run_MultiAsset_Test("assetURI", "OPM_Asset_Tag_Temperature_ID4", "OPM_Asset_Tag_Temperature_ID5");
	}

	@Test(dependsOnMethods={"test_ApmTsIngestion_ApmTsRetrieval","test_ApmAssetRetrieval"})
	@RallyInfo(UserStory ="US209430")
	public void testE2E_ApmTSInput_ApmTSOutput_MultiAsset_Segment_Java() throws Exception {
		run_MultiAsset_Test("segmentURI", "OPM_Segment_Tag_Temperature_ID4", "OPM_Segment_Tag_Temperature_ID5");
	}

	@Test(dependsOnMethods={"test_ApmTsIngestion_ApmTsRetrieval","test_ApmAssetRetrieval"})
	@RallyInfo(UserStory ="US205684")
	public void testE2E_ApmTSInput_ApmTSOutput_MultiAsset_Site_Java() throws Exception {
		run_MultiAsset_Test("siteURI", "OPM_Site_Tag_Temperature_ID4", "OPM_Site_Tag_Temperature_ID5");
	}

	@Test(dependsOnMethods={"test_ApmTsIngestion_ApmTsRetrieval","test_ApmAssetRetrieval"})
	@RallyInfo(UserStory ="US205678")
	public void testE2E_ApmTSInput_ApmTSOutput_MultiAsset_Enterprise_Java() throws Exception {
		run_MultiAsset_Test("enterpriseURI", "OPM_Enterprise_Tag_Temperature_ID4",
				"OPM_Enterprise_Tag_Temperature_ID5");
	}


	/********************************************************************************************************************/

	@AfterTest
	public void afterTest() {}

	@BeforeSuite
	public void beforeSuite() {

	}

	@AfterSuite
	public void afterSuite() {}
}


package com.ge.automation.OO;

import java.io.File;
import java.util.LinkedHashMap;
import java.util.Map;

import org.springframework.boot.test.TestRestTemplate;
import org.springframework.core.io.FileSystemResource;
import org.springframework.http.HttpEntity;
import org.springframework.http.HttpMethod;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.util.LinkedMultiValueMap;
import org.springframework.util.MultiValueMap;
import org.springframework.web.client.RestTemplate;
import org.testng.Assert;
import org.testng.annotations.AfterClass;
import org.testng.annotations.AfterMethod;
import org.testng.annotations.AfterSuite;
import org.testng.annotations.AfterTest;
import org.testng.annotations.BeforeClass;
import org.testng.annotations.BeforeMethod;
import org.testng.annotations.BeforeSuite;
import org.testng.annotations.BeforeTest;
import org.testng.annotations.Test;

import com.ge.automation.OO.dto.AdciResponse;
import com.ge.automation.OO.dto.DeployStatus;
import com.ge.microtester.common.utils.RestAssuredUtil;
import com.ge.microtester.rally.RallyInfo;

import static org.testng.AssertJUnit.assertEquals;

@RallyInfo(ProjectName = "Operations Optimization Execution", FolderPath = "OO/HealthCheck")
public class AdciTests extends RestAssuredUtil {

    private final String uri = getTestProperty("adci_url");

    private static final int MAX_RETRIES = 3;

    private static volatile int RETRY = 0;

    private static long MAX_WAIT = 50000L;

    String path = "src/main/resources/payloadsAndromeda";

    public OOTestUtil ooTestutil = new OOTestUtil();

    RestTemplate restTemplate = new TestRestTemplate();

    // Generating Query Params
    Map<String, Object> values = new LinkedHashMap<String, Object>();

    @BeforeMethod
    public void beforeMethod() {
    }

    @AfterMethod
    public void afterMethod() {
    }

    @BeforeClass
    public void beforeClass() {

		/*
         * System.getProperties().put("proxySet", "true");
		 * System.getProperties().put("http.proxyHost",
		 * "sjc1intproxy01.crd.ge.com");
		 * System.getProperties().put("http.proxyPort", "8080");
		 * System.getProperties().put("https.proxyHost",
		 * "sjc1intproxy01.crd.ge.com");
		 * System.getProperties().put("https.proxyPort", "8080");
		 */
        // getServiceResponse("alert_profile_base_url");
        setSysProperty("currentTimeStamp", "" + getCurrentTimestamp());// ${sys:currentTimeStamp}
    }// end of beforeClass

    @AfterClass
    public void afterClass() {
    }

    @BeforeTest
    public void beforeTest() {

    }// end of beforeTest

    @Test
    public void test_Java_Analytic_ondemand_e2e_test() throws Exception {

        //create kpi template
        long kpiId = ooTestutil.createKpiTemplate(path + "/kpi_templates/adci_kpi_template_Java.json",
            path + "/adci/simpleJavaAnalytic_cf1_14.zip");

        System.out.println("Kpi Id1:" + kpiId);

        System.out.println("********************   Analytic Template Created   ******************** ");

        String uri = deployAdci(kpiId, kpiId, "adci-analytic-ondemand.zip");

        testAdci(uri);
    }

    @Test
    public void test_Python_Analytic_ondemand_e2e_test() throws Exception {

        //create kpi template
        long kpiId = ooTestutil.createKpiTemplate(path + "/kpi_templates/adci_kpi_template_python.json",
            path + "/adci/analytics_python2.zip");

        System.out.println("Kpi Id1:" + kpiId);

        System.out.println("********************   Analytic Template Created   ******************** ");

        String uri = deployAdci(kpiId, kpiId, "adci-analytic-ondemand.zip");

        testAdci(uri);
    }

    /**
     * run job every 30 mins; may need to adjust it
     */
    @Test
    public void test_Java_Analytic_Scheduled_e2e_test() throws Exception {

        //create kpi template
        long kpiId = ooTestutil.createKpiTemplate(path + "/kpi_templates/adci_kpi_template_Java.json",
            path + "/adci/simpleJavaAnalytic_cf1_14.zip");

        System.out.println("Kpi Id1:" + kpiId);

        System.out.println("********************   Analytic Template Created   ******************** ");

        String uri = deployAdci(kpiId, kpiId, "adci-analytic-scheduled.zip");

        testAdci(uri);
    }

    /**
     * run job every 30 mins; may need to adjust it
     */
    @Test
    public void test_Python_Analytic_Scheduled_e2e_test() throws Exception {

        //create kpi template
        long kpiId = ooTestutil.createKpiTemplate(path + "/kpi_templates/adci_kpi_template_python.json",
            path + "/adci/analytics_python2.zip");

        System.out.println("Kpi Id1:" + kpiId);

        System.out.println("********************   Analytic Template Created   ******************** ");

        String uri = deployAdci(kpiId, kpiId, "adci-analytic-scheduled.zip");

        testAdci(uri);
    }

    @Test
    public void test_Java_Analytic_Streaming_e2e_test() throws Exception {

        //create kpi template
        long kpiId = ooTestutil.createKpiTemplate(path + "/kpi_templates/adci_kpi_template_Java.json",
            path + "/adci/simpleJavaAnalytic_cf1_14.zip");

        System.out.println("Kpi Id1:" + kpiId);

        System.out.println("********************   Analytic Template Created   ******************** ");

        String uri = deployAdci(kpiId, kpiId, "adci-analytic-streaming.zip");

        testAdci(uri);
    }

    @Test
    public void test_Python_Analytic_Streaming_e2e_test() throws Exception {

        //create kpi template
        long kpiId = ooTestutil.createKpiTemplate(path + "/kpi_templates/adci_kpi_template_python.json",
            path + "/adci/analytics_python2.zip");

        System.out.println("Kpi Id1:" + kpiId);

        System.out.println("********************   Analytic Template Created   ******************** ");

        String uri = deployAdci(kpiId, kpiId, "adci-analytic-streaming.zip");

        testAdci(uri);
    }

    @Test
    public void test_Java_Orchestration_e2e_test() throws Exception {

        //create kpi template
        long kpiId = ooTestutil.createKpiTemplate(path + "/kpi_templates/adci_kpi_template_Java.json",
            path + "/adci/simpleJavaAnalytic_cf1_14.zip");

        System.out.println("Kpi Id1:" + kpiId);

        System.out.println("********************   Analytic Template Created   ******************** ");

        String uri = deployAdci(kpiId, kpiId, "adci-orchestration-onestep-ondemand.zip");

        testAdci(uri);
    }

    @Test
    public void test_Python_And_Java_Orchestration_e2e_test() throws Exception {

        //create kpi template
        long kpiId1 = ooTestutil.createKpiTemplate(path + "/kpi_templates/adci_kpi_template_python.json",
            path + "/adci/analytics_python2.zip");
        long kpiId2 = ooTestutil.createKpiTemplate(path + "/kpi_templates/adci_kpi_template_Java.json",
            path + "/adci/simpleJavaAnalytic_cf1_14.zip");
        System.out.println("Kpi Id1:" + kpiId1);
        System.out.println("KPI id2:" + kpiId2);

        System.out.println("********************   Analytic Template Created   ******************** ");

        Thread.sleep(10000);

        // Deploy the adci
        String adciUri = deployAdci(kpiId1, kpiId2, "adci-orchestration-mix.zip");

        testAdci(adciUri);
    }

    @Test
    public void test_Java_Orchestration_Streaming_e2e_test() throws Exception {
        long kpiId1 = ooTestutil.createKpiTemplate(path + "/kpi_templates/adci_kpi_template_Java.json",
            path + "/adci/simpleJavaAnalytic_cf1_14.zip");
        System.out.println("Kpi Id1:" + kpiId1);

        System.out.println("********************   Analytic Template Created   ******************** ");

        Thread.sleep(10000);

        // Deploy the adci
        String uri = deployAdci(kpiId1, kpiId1, "adci-orchestration-streaming.zip");

        testAdci(uri);
    }

    private void testAdci(String adciUri) throws Exception {

        System.out.println("********************   adci deployed   ******************** ");

        //Verify the status
        getAdciStatus(adciUri, DeployStatus.DEPLOYED, DeployStatus.FAILED);

        System.out.println("********************   Verified the adci deployment status  ******************** ");

        //delete adci
        deleteAdci(adciUri);

        System.out.println("********************   Successfully deleted adci  ******************** ");

        System.out.println("********************   Congratulations you have tested E2E adci deployment :-)  "
            + "******************** ");
    }

    private String deployAdci(long kpiId1, long kpiId2, String adciFileName) throws Exception {

        // create kpi job
        ooTestutil.getADCIZipFile(path + "/adci/" + adciFileName, kpiId1, kpiId2);

        String zipPath = new File("").getCanonicalPath() + "/adci.zip";
        System.out.println("Zip Path=" + zipPath);
        File adciZip = new java.io.File(zipPath);

        MultiValueMap<String, Object> parameters = new LinkedMultiValueMap<String, Object>();
        parameters.add("file", new FileSystemResource(adciZip));

        System.out.println("adci url=" + uri);

        try {
            ResponseEntity<AdciResponse> deployResponse = restTemplate.exchange(uri + "/adci", HttpMethod.POST,
                new HttpEntity<MultiValueMap<String, Object>>(parameters, ooTestutil.kpiprovideHeaders_1()),
                AdciResponse.class);

            Assert.assertTrue(deployResponse.getStatusCode() == HttpStatus.ACCEPTED,
                "Adci Deployment service response statuscode is not matching ");
            Assert.assertTrue(deployResponse != null, "Adci Deployment service response is null");
            Assert.assertTrue(deployResponse.getBody() != null, "Adci Deployment service not returned dagId");

            String uri = deployResponse.getBody().getAdciRequestUri();

            System.out.println("adciUri id=" + uri);
            return uri;
        } finally {
            adciZip.delete();
        }
    }

    private void getAdciStatus(String adciUri, DeployStatus expectedStatus, DeployStatus wrongStatus) throws Exception {
        long maxWait = 0L;
        AdciResponse adci = null;
        while (maxWait <= MAX_WAIT) {
            long sleep = 1000 - (System.currentTimeMillis()) % 1000;

            try {
                adci = getAdciDeployStatus(adciUri);
                System.out.println("Adci Status =" + adci.getDeployStatus());
                assertEquals(expectedStatus, adci.getDeployStatus());
                System.out.println("Adci is deployed now.");
                break;
            } catch (Exception | AssertionError ex) {
                if (adci == null || adci.getDeployStatus() == wrongStatus) {
                    if (adci != null) {
                        System.out.println("error message is " + adci.getDeployErrorMessage());
                    }
                    throw new Exception("Failed deploy the adci.");
                }
                System.out.println("Adci is not deployed yet. Now retry getting the status.");
            }
            maxWait += sleep;
            System.out.println("======== sleep for " + sleep + " milli");
            Thread.sleep(sleep);
        }

        assertEquals(expectedStatus, adci.getDeployStatus());
    }

    /**
     * Invoke DAG status check status should be IN-PROGRESS
     * Wait for 10 sec and check status. If status is in-progress.
     * verify in every minute. If status failed then fail the test.
     */
    private AdciResponse getAdciDeployStatus(String adciUri) throws Exception {

        String url = uri + adciUri + "/status";
        System.out.println("get status url is " + url);

        HttpEntity<?> entity = new HttpEntity<>(ooTestutil.kpiprovideHeaders_1());

        ResponseEntity<AdciResponse> response = restTemplate.exchange(url, HttpMethod.GET, entity, AdciResponse.class);

        System.out.println("Status==========" + response.getStatusCode());

        Assert.assertTrue(response.getStatusCode() == HttpStatus.OK,
            "adci Deployment status response  statuscode is not matching ");
        Assert.assertTrue(response != null, "adci Deployment status response is null");
        Assert.assertTrue(response.getBody() != null, "adci Deployment status response body is empty");
        System.out.println("Response ADCI status ****" + response.getBody());

        return response.getBody();
    }

    private void deleteAdci(String adciUri) {

        String url = uri + adciUri;
        System.out.println("delete adci url is " + url);

        HttpEntity<?> entity = new HttpEntity<>(ooTestutil.kpiprovideHeaders_1());

        ResponseEntity<String> response = restTemplate.exchange(url, HttpMethod.DELETE, entity, String.class);

        System.out.println("Status==========" + response.getStatusCode());

        Assert.assertTrue(response.getStatusCode() == HttpStatus.NO_CONTENT,
            "Delete adci failed and the statuscode is " + response.getStatusCode());
    }

    @AfterTest
    public void afterTest() {
    }

    @BeforeSuite
    public void beforeSuite() {

    }

    @AfterSuite
    public void afterSuite() {
    }
}

package com.ge.automation.OO;

import java.io.File;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.IOException;
import java.io.InputStream;
import java.net.URISyntaxException;
import java.util.LinkedHashMap;
import java.util.Map;

import org.apache.commons.io.FileUtils;
import org.apache.commons.logging.Log;
import org.apache.commons.logging.LogFactory;
import org.springframework.boot.test.TestRestTemplate;
import org.springframework.core.io.FileSystemResource;
import org.springframework.http.HttpEntity;
import org.springframework.http.HttpHeaders;
import org.springframework.http.HttpMethod;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.util.LinkedMultiValueMap;
import org.springframework.util.MultiValueMap;
import org.springframework.web.client.RestTemplate;
import org.testng.Assert;
import org.testng.annotations.BeforeClass;
import org.testng.annotations.DataProvider;
import org.testng.annotations.Test;

import com.fasterxml.jackson.databind.ObjectMapper;
import com.ge.microtester.common.core.UseDifferentTestName;
import com.ge.microtester.common.utils.ExcelReaderUtil;
import com.ge.microtester.common.utils.RestAssuredUtil;
import org.apache.poi.ss.usermodel.Cell;
import org.apache.poi.xssf.usermodel.XSSFCell;
import org.apache.poi.xssf.usermodel.XSSFRow;
import org.apache.poi.xssf.usermodel.XSSFSheet;
import org.apache.poi.xssf.usermodel.XSSFWorkbook;
import com.ge.microtester.rally.RallyInfo;
import com.jayway.restassured.path.json.JsonPath;
import com.jayway.restassured.response.Response;


@UseDifferentTestName
@RallyInfo(ProjectName = "Operations Optimization Execution", FolderPath = "OO/Q4Release")
public class OOUserACSTests  extends RestAssuredUtil{


	String kpiid;
	String kpiJobId;
	String dataSourceId;
	long kpi_id;
	long kpi_id1;
	public OOTestUtil ooTestutil = new OOTestUtil();
	RestTemplate restTemplate = new TestRestTemplate();
	private static Log _OOlogger = LogFactory.getLog(OOUserACSTests.class);
	// Generating Query Params
	Map<String, Object> values = new LinkedHashMap<String, Object>();


	@BeforeClass
	public void beforeClass() {

		System.getProperties().put("proxySet", "true");
		System.getProperties().put("http.proxyHost", "sjc1intproxy01.crd.ge.com");
		System.getProperties().put("http.proxyPort", "8080");
		System.getProperties().put("https.proxyHost", "sjc1intproxy01.crd.ge.com");
		System.getProperties().put("https.proxyPort", "8080");

		setSysProperty("currentTimeStamp", "" + getCurrentTimestamp());// ${sys:currentTimeStamp}

	}// end of beforeClass



	/********************************************************************************************************************/
	@Test(dataProvider="MTExcelDataReader",dataProviderClass = ExcelReaderUtil.class,priority = 9, description = "testUserAcsGetTests")
	//@Test(dataProvider="DP1",priority = 9, description = "testUserAcsGetPositiveTests")
	@RallyInfo(UserStory = "US44703")
	public void testUserAcsGetTests(String username,String password,String httpMethod,String endpoint,Double result,String resultMessage,String testcase) throws IOException, InterruptedException, URISyntaxException {
		System.out.println("~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~");
		System.out.println("\n"+"username="+username+"\t"+"pwd="+password+"\t"+"httpMethod="+httpMethod+"\t"+"endpoint="+endpoint+"\t"+"result="+result+"\t"+"resultMessage="+resultMessage+"\t"+"resultMessage="+resultMessage+"\t"+"testcase="+testcase+"\t");



		String uri = getTestProperty("oo_kpi_mgmt_url")+endpoint;

		System.out.println("\n----->"+"uri="+uri);
		final String stuf_uaa_url = getTestProperty("stuf_uaa_url");
		final String stuf_grant_type = getTestProperty("stuf_grant_type");
		final String stuf_clientId = getTestProperty("stuf_clientId");
		final String stuf_clientSecret = "";
		final String stuf_tenant = getTestProperty("stuf_tenantUUID");
		final String stuf_username = getTestProperty("stuf_username");
		final String stuf_password = getTestProperty("stuf_password");
		System.out.println("\n"+"stuf_uaa_url="+stuf_uaa_url+"\n"+"stuf_grant_type="+stuf_grant_type+"\n"+"username="+username+"\n"+"stuf_clientId="+stuf_clientId+"\n"+"stuf_clientSecret="+stuf_clientSecret+"\n"+"password="+password);

		//preparing kpi,job for the test
		if(getSysProperty("acs_GET_kpiId")==null)
			setSysProperty("acs_GET_kpiId", "");
		if(getSysProperty("acs_GET_kpiId").equals(""))
		{
			System.out.println("*******************creating kpi template for GET ACS tests***********************");

			String token1=getAPMToken(stuf_uaa_url,  stuf_username, stuf_password, stuf_clientId, stuf_clientSecret);

			//create kpi template
			ResponseEntity<Object> response = ooTestutil.getResponseFromcreateKpiTemplate(token1,stuf_tenant,stuf_tenant,"POST","src/main/resources/payloadsEventHub/kpi_templates/kpi_e2e.json", 
					"src/main/resources/payloadsEventHub/kpi_analytics/kpi_analytic_asset_ts_int.zip");
			ooTestutil.printResponseEntity(response);
			LinkedHashMap<String, Object> kpiDetails =(LinkedHashMap<String, Object>) response.getBody();
			// System.out.println("+++ response.asString() == " + response.toString());
			long kpi_id =((Integer) kpiDetails.get("id")).intValue();
			String kpi_name =(String)kpiDetails.get("name");
			setSysProperty("acs_GET_kpiId", new Long(kpi_id).toString());
			setSysProperty("acs_GET_kpiName", kpi_name);
			System.out.println("------------->acs_GET_kpiId" + kpi_id);
			System.out.println("------------->acs_GET_kpiName" + kpi_name);



			System.out.println("------------->creating kpi job for GET ACS tests");
			Response jobResponse=ooTestutil.getResponseFromCreateKpiJob(token1,stuf_tenant,stuf_tenant,"POST","src/main/resources/payloadsEventHub/kpi_jobs/kpi_e2e_job.json", new Long(getSysProperty("acs_GET_kpiId")).longValue());
			System.out.println(jobResponse.asString());
			JsonPath jsonPath = new JsonPath(jobResponse.asString());
			String kpiJobId = jsonPath.getString("id");
			setSysProperty("acs_GET_jobId", new Long(kpiJobId).toString());
			System.out.println("------------->acs_GET_jobId=" +kpiJobId);


		}

		if(uri.contains("kpis"))
		{
			uri=uri.replaceFirst("\\{id\\}", getSysProperty("acs_GET_kpiId"));
			uri=uri.replaceFirst("\\{name\\}", getSysProperty("acs_GET_kpiName"));
		}
		else if(uri.contains("job"))
		{
			uri=uri.replaceFirst("\\{id\\}", getSysProperty("acs_GET_jobId"));
		}
		System.out.println("**************Calling actual service*************/");
		Response response=null;
		try{
			//perform the actual test
			String token=getAPMToken(stuf_uaa_url,  username, password, stuf_clientId, stuf_clientSecret);
			response=ooTestutil.getResponseFromGetOrDelete(token,stuf_tenant,httpMethod.trim(),uri);
			if (response.getStatusCode()==417||response.getStatusCode()==500)
			{
				response=ooTestutil.getResponseFromGetOrDelete(token,stuf_tenant,httpMethod.trim(),uri);
			}
			System.out.println("Printing responseBody.getBody()"+response.asString());
			System.out.println("final response status="+ response.getStatusCode());
		}catch(Exception e)
		{
			e.printStackTrace();
			throw e;
		}
		finally
		{
			if(result==200 && uri.contains("stop"))
			{
				String token1=getAPMToken(stuf_uaa_url,  stuf_username, stuf_password, stuf_clientId, stuf_clientSecret);

				ooTestutil.getResponseFromGetOrDelete(token1,stuf_tenant,"DELETE",getTestProperty("job_url")+"/"+getSysProperty("acs_GET_jobId"));
				setSysProperty("acs_GET_jobId", "");
				setSysProperty("acs_GET_kpiId","");
			}
		}


		Assert.assertEquals(response.getStatusCode(), new Double(result).intValue(), "Not valid error response for "+"   :   "+testcase);

		System.out.println("~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~");

	}

	@Test(dataProvider="MTExcelDataReader",dataProviderClass = ExcelReaderUtil.class,priority = 9, description = "testUserAcsPostPutKPITests")
	//@Test(dataProvider="DP2",priority = 9, description = "testUserAcsPostPositiveTests")
	@RallyInfo(UserStory = "US44703")
	public void testUserAcsPostPutKPITests(String username,String password,String httpMethod,String endpoint,Double result,String resultMessage,String testcase,String kpi_json,String analytic_file) throws IOException, InterruptedException, URISyntaxException {
		System.out.println("~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~");
		System.out.println("\n"+"username="+username+"\t"+"pwd="+password+"\t"+"httpMethod="+httpMethod+"\t"+"endpoint="+endpoint+"\t"+"result="+result+"\t"+"resultMessage="+resultMessage+"\t"+"kpi_json="+kpi_json+"\t"+"analytic_file="+analytic_file+"+\t"+"testcase="+testcase+"\t");



		String uri = getTestProperty("oo_kpi_mgmt_url")+endpoint;

		System.out.println("\n"+"uri="+uri);
		final String stuf_uaa_url = getTestProperty("stuf_uaa_url");
		final String stuf_grant_type = getTestProperty("stuf_grant_type");
		final String stuf_clientId = getTestProperty("stuf_clientId");
		final String stuf_clientSecret = "";
		final String stuf_tenant = getTestProperty("stuf_tenantUUID");
		System.out.println("\n"+"stuf_uaa_url="+stuf_uaa_url+"\n"+"stuf_grant_type="+stuf_grant_type+"\n"+"username="+username+"\n"+"stuf_clientId="+stuf_clientId+"\n"+"stuf_clientSecret="+stuf_clientSecret+"\n"+"password="+password);
		System.out.println("*******************creating kpi template for POST / PUT KPI ACS tests***********************");
		//preparing kpi,job for the test
		if(getSysProperty("acs_kpiId")==null)
			setSysProperty("acs_put_kpiId", "");
		if(getSysProperty("acs_put_kpiId").equals(""))
		{
			System.out.println("------------->creating kpi template for create job tests");
			final String stuf_username = getTestProperty("stuf_username");
			final String stuf_password = getTestProperty("stuf_password");
			String token1=getAPMToken(stuf_uaa_url,  stuf_username, stuf_password, stuf_clientId, stuf_clientSecret);

			//System.out.println("\ntoken1="+token1);
			//create kpi template
			ResponseEntity<Object> response = ooTestutil.getResponseFromcreateKpiTemplate(token1,stuf_tenant,stuf_tenant,"POST","src/main/resources/payloadsEventHub/kpi_templates/kpi_e2e.json", 
					"src/main/resources/payloadsEventHub/kpi_analytics/kpi_analytic_asset_ts_int.zip");
			ooTestutil.printResponseEntity(response);
			LinkedHashMap<String, Object> kpiDetails =(LinkedHashMap<String, Object>) response.getBody();
			// System.out.println("+++ response.asString() == " + response.toString());
			long kpi_id =((Integer) kpiDetails.get("id")).intValue();
			setSysProperty("acs_put_kpiId", new Long(kpi_id).toString());

			String kpi_name =(String)kpiDetails.get("name");
			setSysProperty("acs_put_kpiName", kpi_name);
			System.out.println("------------->acs_put_kpiName" + kpi_name);
			System.out.println("------------->acs_put_kpiId" + kpi_id);


		}

		setSysProperty("acs_inputName1", "inputName"+ooTestutil.generateRandomNumberNonUUID());
		setSysProperty("setKpiId", getSysProperty("acs_put_kpiId"));

		setSysProperty("setKpiName", getSysProperty("acs_put_kpiName"));
		System.out.println("**************Calling actual service*************/");

		String token=getAPMToken(stuf_uaa_url,  username, password, stuf_clientId, stuf_clientSecret);

		if(httpMethod.equalsIgnoreCase("POST"))
		{


			//create kpi template
			ResponseEntity<Object> responseEntity = ooTestutil.getResponseFromcreateKpiTemplate(token,stuf_tenant,stuf_tenant,httpMethod,kpi_json,"src/main/resources/payloadsEventHub/kpi_analytics/kpi_analytic_asset_ts_int.zip");

			//ooTestutil.printResponseEntity(responseEntity);

			System.out.println("final response status"+responseEntity.getStatusCode().value());

			Assert.assertEquals(responseEntity.getStatusCode().value(), new Double(result).intValue(), "Not valid error response for "+"   :   "+testcase);
		}
		else if(httpMethod.equalsIgnoreCase("PUT"))
		{
			if(uri.contains("kpis"))
			{
				uri=uri.replaceFirst("\\{id\\}", getSysProperty("acs_put_kpiId"));

			}
			if(uri.contains("artifact"))
			{
				ResponseEntity<Object> responseEntity=ooTestutil.getResponseFromUpdateKpiAnalyticFile( uri, token,  stuf_tenant,httpMethod,analytic_file);
				ooTestutil.printResponseEntity(responseEntity);
				System.out.println("final response status"+responseEntity.getStatusCode().value());

				Assert.assertEquals(responseEntity.getStatusCode().value(), new Double(result).intValue(), "Not valid error response for "+"   :   "+testcase);

			}
			else 
			{
				Response response=ooTestutil.getResponseFromUpdateKpiTemplateJson( uri, token, stuf_tenant,stuf_tenant,httpMethod,kpi_json);
				System.out.println("final response status"+response.getStatusCode());

				Assert.assertEquals(response.getStatusCode(), new Double(result).intValue(), "Not valid error response for "+"   :   "+testcase);

			}


		}

		System.out.println("~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~");

	}
	@Test(dataProvider="MTExcelDataReader",dataProviderClass = ExcelReaderUtil.class,priority = 9, description = "testUserAcsPostPutJobTests")
	//@Test(dataProvider="DP3",priority = 9, description = "testUserAcsJobPositiveTests")
	@RallyInfo(UserStory = "US44703")
	public void testUserAcsPostPutJobTests(String username,String password,String httpMethod,String endpoint,Double result,String resultMessage,String testcase,String jsonjobFile1) throws IOException, InterruptedException, URISyntaxException {
		System.out.println("~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~");
		System.out.println("\n"+"username="+username+"\t"+"pwd="+password+"\t"+"httpMethod="+httpMethod+"\t"+"endpoint="+endpoint+"\t"+"result="+result+"\t"+"resultMessage="+resultMessage+"\t"+"jsonjobFile1="+jsonjobFile1+"\t"+"testcase="+testcase+"\t");



		String uri = getTestProperty("oo_kpi_mgmt_url")+endpoint;

		System.out.println("\n"+"uri="+uri);
		final String stuf_uaa_url = getTestProperty("stuf_uaa_url");
		final String stuf_grant_type = getTestProperty("stuf_grant_type");
		final String stuf_clientId = getTestProperty("stuf_clientId");
		final String stuf_clientSecret = "";
		final String stuf_tenant = getTestProperty("stuf_tenantUUID");
		System.out.println("\n"+"stuf_uaa_url="+stuf_uaa_url+"\n"+"stuf_grant_type="+stuf_grant_type+"\n"+"username="+username+"\n"+"stuf_clientId="+stuf_clientId+"\n"+"stuf_clientSecret="+stuf_clientSecret+"\n"+"password="+password);

		System.out.println("*******************creating kpi template for GET ACS tests***********************");
		//preparing kpi,job for the test
		if(getSysProperty("acs_kpiId")==null)
			setSysProperty("acs_kpiId", "");
		if(getSysProperty("acs_kpiId").equals(""))
		{
			System.out.println("------------->creating kpi template for create job tests");
			final String stuf_username = getTestProperty("stuf_username");
			final String stuf_password = getTestProperty("stuf_password");
			String token1=getAPMToken(stuf_uaa_url,  stuf_username, stuf_password, stuf_clientId, stuf_clientSecret);

			//System.out.println("\ntoken1="+token1);
			//create kpi template
			ResponseEntity<Object> response = ooTestutil.getResponseFromcreateKpiTemplate(token1,stuf_tenant,stuf_tenant,"POST","src/main/resources/payloadsEventHub/kpi_templates/kpi_e2e.json", 
					"src/main/resources/payloadsEventHub/kpi_analytics/kpi_analytic_asset_ts_int.zip");
			ooTestutil.printResponseEntity(response);
			LinkedHashMap<String, Object> kpiDetails =(LinkedHashMap<String, Object>) response.getBody();
			// System.out.println("+++ response.asString() == " + response.toString());
			long kpi_id =((Integer) kpiDetails.get("id")).intValue();
			setSysProperty("acs_kpiId", new Long(kpi_id).toString());
			System.out.println("------------->kpi_id" + kpi_id);

			System.out.println("------------->creating kpi job for POST ACS tests");
			Response jobResponse=ooTestutil.getResponseFromCreateKpiJob(token1,stuf_tenant,stuf_tenant,"POST","src/main/resources/payloadsEventHub/kpi_jobs/kpi_e2e_job.json", new Long(getSysProperty("acs_kpiId")).longValue());
			System.out.println(jobResponse.asString());
			JsonPath jsonPath = new JsonPath(jobResponse.asString());
			String kpiJobId = jsonPath.getString("id");
			setSysProperty("acs_jobId", new Long(kpiJobId).toString());
			System.out.println("------------->acs_jobId=" +kpiJobId);

		}
		System.out.println("**************Calling actual service*************/");
		setSysProperty("acs_inputName1", "inputName"+ooTestutil.generateRandomNumberNonUUID());
		String token=getAPMToken(stuf_uaa_url,  username, password, stuf_clientId, stuf_clientSecret);

		//create kpi template
		Response jobResponse=ooTestutil.getResponseFromCreateKpiJob(token,stuf_tenant,stuf_tenant,httpMethod,jsonjobFile1, new Long(getSysProperty("acs_kpiId")).longValue());
		System.out.println("Jobres="+jobResponse.asString());

		System.out.println("final response status="+jobResponse.getStatusCode());

		Assert.assertEquals(jobResponse.getStatusCode(), new Double(result).intValue(), "Not valid error response for "+"   :   "+testcase);

		System.out.println("~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~");

	}
	@Test(dataProvider="MTExcelDataReader",dataProviderClass = ExcelReaderUtil.class,priority = 9, description = "testUserAcsDeleteTests")
	//@Test(dataProvider="DP3",priority = 9, description = "testUserAcsJobPositiveTests")
	@RallyInfo(UserStory = "US44703")
	public void testUserAcsDeleteTests(String username,String password,String httpMethod,String endpoint,Double result,String resultMessage,String testcase) throws IOException, InterruptedException, URISyntaxException {
		System.out.println("~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~");
		System.out.println("\n"+"username="+username+"\t"+"pwd="+password+"\t"+"httpMethod="+httpMethod+"\t"+"endpoint="+endpoint+"\t"+"result="+result+"\t"+"resultMessage="+resultMessage+"\t"+"resultMessage="+resultMessage+"\t"+"testcase="+testcase+"\t");



		String uri = getTestProperty("oo_kpi_mgmt_url")+endpoint;

		System.out.println("\n"+"uri="+uri);
		final String stuf_uaa_url = getTestProperty("stuf_uaa_url");
		final String stuf_grant_type = getTestProperty("stuf_grant_type");
		final String stuf_clientId = getTestProperty("stuf_clientId");
		final String stuf_clientSecret = "";
		final String stuf_tenant = getTestProperty("stuf_tenantUUID");
		final String stuf_username = getTestProperty("stuf_username");
		final String stuf_password = getTestProperty("stuf_password");
		System.out.println("\n"+"stuf_uaa_url="+stuf_uaa_url+"\n"+"stuf_grant_type="+stuf_grant_type+"\n"+"username="+username+"\n"+"stuf_clientId="+stuf_clientId+"\n"+"stuf_clientSecret="+stuf_clientSecret+"\n"+"password="+password);
		System.out.println("*******************creating kpi template for POST/PUT job ACS tests***********************");
		//preparing kpi for delete kpi tests
		if(getSysProperty("acs_job_kpiId2")==null)
			setSysProperty("acs_job_kpiId2", "");
		if(getSysProperty("acs_job_kpiId2").equals(""))
		{
			System.out.println("------------->creating kpi template for delete  job acs tests");

			String token1=getAPMToken(stuf_uaa_url,  stuf_username, stuf_password, stuf_clientId, stuf_clientSecret);

			//create kpi template
			ResponseEntity<Object> response = ooTestutil.getResponseFromcreateKpiTemplate(token1,stuf_tenant,stuf_tenant,"POST","src/main/resources/payloadsEventHub/kpi_templates/kpi_e2e.json", 
					"src/main/resources/payloadsEventHub/kpi_analytics/kpi_analytic_asset_ts_int.zip");
			ooTestutil.printResponseEntity(response);


			LinkedHashMap<String, Object> kpiDetails =(LinkedHashMap<String, Object>) response.getBody();

			long kpi_id =((Integer) kpiDetails.get("id")).intValue();
			setSysProperty("acs_job_kpiId2", new Long(kpi_id).toString());
			System.out.println("------------->kpi_id2" + kpi_id);
		}

		//preparing kpi,job for the test
		if(getSysProperty("acs_job_kpiId")==null)
			setSysProperty("acs_job_kpiId", "");
		if(getSysProperty("acs_job_kpiId").equals(""))
		{
			System.out.println("------------->creating kpi template for delete  job acs tests");

			String token1=getAPMToken(stuf_uaa_url,  stuf_username, stuf_password, stuf_clientId, stuf_clientSecret);

			//create kpi template
			ResponseEntity<Object> response = ooTestutil.getResponseFromcreateKpiTemplate(token1,stuf_tenant,stuf_tenant,"POST","src/main/resources/payloadsEventHub/kpi_templates/kpi_e2e.json", 
					"src/main/resources/payloadsEventHub/kpi_analytics/kpi_analytic_asset_ts_int.zip");
			ooTestutil.printResponseEntity(response);


			LinkedHashMap<String, Object> kpiDetails =(LinkedHashMap<String, Object>) response.getBody();
			// System.out.println("+++ response.asString() == " + response.toString());
			long kpi_id =((Integer) kpiDetails.get("id")).intValue();
			setSysProperty("acs_job_kpiId", new Long(kpi_id).toString());
			System.out.println("------------->kpi_id" + kpi_id);

			System.out.println("------------->creating kpi job for GET ACS tests");
			Response jobResponse=ooTestutil.getResponseFromCreateKpiJob(token1,stuf_tenant,stuf_tenant,"POST","src/main/resources/payloadsEventHub/kpi_jobs/kpi_e2e_job.json", new Long(getSysProperty("acs_job_kpiId")).longValue());
			System.out.println(jobResponse.asString());
			JsonPath jsonPath = new JsonPath(jobResponse.asString());
			String kpiJobId = jsonPath.getString("id");
			setSysProperty("acs_job_jobId", new Long(kpiJobId).toString());
			System.out.println("------------->acs_job_jobId=" +kpiJobId);



		}
		if(uri.contains("kpis"))
		{
			uri=uri.replaceFirst("\\{id\\}", getSysProperty("acs_job_kpiId2"));

		}
		else if(uri.contains("job"))
		{
			uri=uri.replaceFirst("\\{id\\}", getSysProperty("acs_job_jobId"));
		}
		System.out.println("**************Calling actual service*************/");
		String token=getAPMToken(stuf_uaa_url,  username, password, stuf_clientId, stuf_clientSecret);
		//create kpi template
		Response jobResponse=ooTestutil.getResponseFromGetOrDelete(token,stuf_tenant,"DELETE",uri);
		System.out.println(jobResponse.asString());
		System.out.println("final response status="+jobResponse.getStatusCode());
		if(jobResponse.getStatusCode()==200 && uri.contains("job"))//set flag to recreate after delete job
		{
			setSysProperty("acs_job_jobId", "");
			setSysProperty("acs_job_kpiId", "");
		}
		else if(jobResponse.getStatusCode()==204 && uri.contains("kpis"))//set flag to recreate after delete kpi
		{

			setSysProperty("acs_job_kpiId2", "");
		}

		Assert.assertEquals(jobResponse.getStatusCode(), new Double(result).intValue(), "Not valid error response for "+"   :   "+testcase);

		System.out.println("~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~");

	}


	/********************************************************************************************************************/
	@Test(dataProvider="MTExcelDataReader",dataProviderClass = ExcelReaderUtil.class,priority = 9, description = "testUserAcsTenantFilterTests")
	//@Test(dataProvider="DP1",priority = 9, description = "testUserAcsGetPositiveTests")
	@RallyInfo(UserStory = "US50899")
	public void testUserAcsTenantFilterTests(String username,String password,String tenant,String header_tenant,String httpMethod,String endpoint,Double result,String resultMessage,String json_payload_file,String testcase) throws IOException, InterruptedException, URISyntaxException {
		System.out.println("~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~");
		System.out.println("\n"+"username="+username+"\t"+"pwd="+password+"\t"+"tenant="+tenant+"\t"+"header_tenant="+header_tenant+"\t"+"httpMethod="+httpMethod+"\t"+"endpoint="+endpoint+"\t"+"result="+result+"\t"+"resultMessage="+resultMessage+"\t"+"resultMessage="+resultMessage+"\t"+"json_payload_file="+json_payload_file+"\t"+"testcase="+testcase+"\t");



		String uri = getTestProperty("oo_kpi_mgmt_url")+endpoint;

		System.out.println("\n"+"uri="+uri);
		final String stuf_uaa_url = getTestProperty("stuf_uaa_url");
		final String stuf_grant_type = getTestProperty("stuf_grant_type");
		final String stuf_clientId = getTestProperty("stuf_clientId");
		final String stuf_clientSecret = "";
		final String stuf_tenant = getTestProperty("stuf_tenantUUID");
		final String stuf_username = getTestProperty("stuf_username");
		final String stuf_password = getTestProperty("stuf_password");
		System.out.println("\n"+"stuf_uaa_url="+stuf_uaa_url+"\n"+"stuf_grant_type="+stuf_grant_type+"\n"+"username="+username+"\n"+"stuf_clientId="+stuf_clientId+"\n"+"stuf_clientSecret="+stuf_clientSecret+"\n"+"password="+password);
		System.out.println("*******************creating kpi template for Tenant filter tests***********************");
		//preparing kpi,job for the test
		if(getSysProperty("acs_tenant_kpiId")==null)
			setSysProperty("acs_tenant_kpiId", "");
		if(getSysProperty("acs_tenant_kpiId").equals(""))
		{
			System.out.println("------------->creating kpi template for different tenant  tests");

			String token1=getAPMToken(stuf_uaa_url,  stuf_username, stuf_password, stuf_clientId, stuf_clientSecret);

			//create kpi template
			ResponseEntity<Object> response = ooTestutil.getResponseFromcreateKpiTemplate(token1,stuf_tenant,stuf_tenant,"POST","src/main/resources/payloadsEventHub/kpi_templates/kpi_e2e.json", 
					"src/main/resources/payloadsEventHub/kpi_analytics/kpi_analytic_asset_ts_int.zip");
			ooTestutil.printResponseEntity(response);
			LinkedHashMap<String, Object> kpiDetails =(LinkedHashMap<String, Object>) response.getBody();
			// System.out.println("+++ response.asString() == " + response.toString());
			long kpi_id =((Integer) kpiDetails.get("id")).intValue();
			String kpi_name =(String)kpiDetails.get("name");
			setSysProperty("acs_tenant_kpiId", new Long(kpi_id).toString());
			setSysProperty("acs_tenant_kpiName", kpi_name);
			System.out.println("------------->acs_tenant_kpiId" + kpi_id);
			System.out.println("------------->acs_tenant_kpiName" + kpi_name);



			System.out.println("------------->creating kpi job for different tenant tests");
			Response jobResponse=ooTestutil.getResponseFromCreateKpiJob(token1,stuf_tenant,stuf_tenant,"POST","src/main/resources/payloadsEventHub/kpi_jobs/kpi_e2e_job.json", new Long(getSysProperty("acs_tenant_kpiId")).longValue());
			System.out.println(jobResponse.asString());
			JsonPath jsonPath = new JsonPath(jobResponse.asString());
			String kpiJobId = jsonPath.getString("id");
			setSysProperty("acs_tenant_jobId", new Long(kpiJobId).toString());
			setSysProperty("acs_jobId", new Long(kpiJobId).toString());
			System.out.println("------------->acs_tenant_jobId=" +kpiJobId);


		}

		if(uri.contains("kpis"))
		{
			uri=uri.replaceFirst("\\{id\\}", getSysProperty("acs_tenant_kpiId"));
			uri=uri.replaceFirst("\\{name\\}", getSysProperty("acs_tenant_kpiName"));
		}
		else if(uri.contains("job"))
		{
			uri=uri.replaceFirst("\\{id\\}", getSysProperty("acs_tenant_jobId"));
		}

		System.out.println("*********************Calling actual service**********************/");

		String token=getAPMToken(stuf_uaa_url,  username, password, stuf_clientId, stuf_clientSecret);
		Response response=null;
		String resStr=null;


		if(httpMethod.equalsIgnoreCase("GET") || httpMethod.equalsIgnoreCase("DELETE"))
		{
			response=ooTestutil.getResponseFromGetOrDelete(token,header_tenant,httpMethod,uri);
			resStr=response.asString();
			System.out.println(" response ="+ resStr);
			System.out.println("final response status="+ response.getStatusCode());
			System.out.println("expected response status="+ result);
			if(response.getStatusCode()==200 && httpMethod.equalsIgnoreCase("DELETE"))
			{

				setSysProperty("acs_tenant_jobId", "");
				setSysProperty("acs_tenant_kpiId", "");
			}

			Assert.assertEquals(response.getStatusCode(), new Double(result).intValue(), "Not valid error response for "+"   :   "+testcase);

		}

		else if(httpMethod.equalsIgnoreCase("POST") || httpMethod.equalsIgnoreCase("PUT"))
		{
			if(uri.contains("job"))
			{
				if(uri.contains("start")||uri.contains("stop"))
				{
					try{
						response=ooTestutil.getResponseFromGetOrDelete(token,header_tenant,httpMethod,uri);
						if (response.getStatusCode()==417||response.getStatusCode()==500)
							response=ooTestutil.getResponseFromGetOrDelete(token,header_tenant,httpMethod,uri);
						resStr=response.asString();
						System.out.println(" response ="+ resStr);
						System.out.println("final response status="+ response.getStatusCode());
						System.out.println("expected response status="+ result);
					}catch(Exception e)
					{
						e.printStackTrace();
						throw e;
					}
					finally
					{
						//delete job once stop tests are done
						if( result==200 &&uri.contains("stop"))
						{
							String token1=getAPMToken(stuf_uaa_url,  stuf_username, stuf_password, stuf_clientId, stuf_clientSecret);

							ooTestutil.getResponseFromGetOrDelete(token1,header_tenant,"DELETE",getTestProperty("job_url")+"/"+getSysProperty("acs_tenant_jobId"));
							setSysProperty("acs_tenant_jobId", "");
							setSysProperty("acs_tenant_kpiId", "");

						}
					}
					Assert.assertEquals(response.getStatusCode(), new Double(result).intValue(), "Not valid error response for "+"   :   "+testcase);

				}
				else
				{
					Response jobResponse=ooTestutil.getResponseFromCreateKpiJob(token,tenant,header_tenant,httpMethod,json_payload_file, new Long(getSysProperty("acs_tenant_kpiId")).longValue());
					resStr=jobResponse.asString();
					System.out.println("Jobresponse="+resStr);

					System.out.println("final response status="+jobResponse.getStatusCode());

					Assert.assertEquals(jobResponse.getStatusCode(), new Double(result).intValue(), "Not valid error response for "+"   :   "+testcase);
				}
			}
			else if(uri.contains("kpi"))
			{
				if(httpMethod.equalsIgnoreCase("POST"))
				{

					//create kpi template
					ResponseEntity<Object> responseEntity = ooTestutil.getResponseFromcreateKpiTemplate(token,tenant,header_tenant,httpMethod,json_payload_file,"src/main/resources/payloadsEventHub/kpi_analytics/kpi_analytic_asset_ts_int.zip");
					resStr=ooTestutil.getResponseEntity(responseEntity);
					//ooTestutil.printResponseEntity(responseEntity);

					System.out.println("final response status"+responseEntity.getStatusCode().value());

					Assert.assertEquals(responseEntity.getStatusCode().value(), new Double(result).intValue(), "Not valid error response for "+"   :   "+testcase);
				}
				else if(httpMethod.equalsIgnoreCase("PUT"))
				{
					setSysProperty("setKpiName", getSysProperty("acs_tenant_kpiName"));
					setSysProperty("setKpiId", getSysProperty("acs_tenant_kpiId"));
					if(uri.contains("kpi"))
					{
						uri=uri.replaceFirst("\\{id\\}", getSysProperty("acs_tenant_kpiId"));

					}
					if(uri.contains("artifact"))
					{
						ResponseEntity<Object> responseEntity=ooTestutil.getResponseFromUpdateKpiAnalyticFile( uri, token,  header_tenant,httpMethod,"src/main/resources/payloadsEventHub/kpi_analytics_1/analytic_1.zip");
						ooTestutil.printResponseEntity(responseEntity);
						resStr=ooTestutil.getResponseEntity(responseEntity);
						System.out.println("final response status"+responseEntity.getStatusCode().value());

						Assert.assertEquals(responseEntity.getStatusCode().value(), new Double(result).intValue(), "Not valid error response for "+"   :   "+testcase);

					}
					else 
					{
						Response response1=ooTestutil.getResponseFromUpdateKpiTemplateJson( uri, token, tenant,header_tenant,httpMethod,json_payload_file);
						System.out.println("final response status"+response1.getStatusCode());

						resStr=response1.asString();
						System.out.println("final response "+response1.asString());
						Assert.assertEquals(response1.getStatusCode(), new Double(result).intValue(), "Not valid error response for "+"   :   "+testcase);

					}

				}


			}

			System.out.println("****************assert response message**********************");
			if(!resultMessage.equalsIgnoreCase("na"))
			{
				if(resStr==null)
				{
					Assert.fail("expected text not found in response since response is empty:"+resultMessage);
				}
				if(!resultMessage.startsWith("!"))
				{


					Assert.assertTrue(resStr.contains(resultMessage), "response message didnot contain ="+resultMessage );
				}
				else
				{
					if (resStr!=null){
						String resultSubStr=resultMessage.substring(1,resultMessage.length());
						Assert.assertTrue(!resStr.contains(resultSubStr), "response message should not contain ="+resultSubStr );
					}
				}
			}
		}




		System.out.println("~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~");

	}


	/********************************************************************************************************************/
	@Test(dataProvider="MTExcelDataReader",dataProviderClass = ExcelReaderUtil.class,priority = 9, description = "testUserTokenValidationTests")
	//@Test(dataProvider="DP1",priority = 9, description = "testUserAcsGetPositiveTests")
	@RallyInfo(UserStory = "US44703")
	public void testUserTokenValidationTests(String username,String password,String payload_tenant,String header_tenant,String test_type,String httpMethod,String endpoint,Double result,String resultMessage,String json_payload_file,String testcase) throws IOException, InterruptedException, URISyntaxException {
		try{
			System.out.println("~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~");
			System.out.println("\n"+"username="+username+"\t"+"pwd="+password+"\t"+"tenant="+payload_tenant+"\t"+"header_tenant="+header_tenant+"\t"+"test_type="+test_type+"\t"+"httpMethod="+httpMethod+"\t"+"endpoint="+endpoint+"\t"+"result="+result+"\t"+"resultMessage="+resultMessage+"\t"+"resultMessage="+resultMessage+"\t"+"json_payload_file="+json_payload_file+"\t"+"testcase="+testcase+"\t");



			String uri = getTestProperty("oo_kpi_mgmt_url")+endpoint;

			System.out.println("\n"+"uri="+uri);
			final String stuf_uaa_url = getTestProperty("stuf_uaa_url");
			final String stuf_grant_type = getTestProperty("stuf_grant_type");
			final String stuf_clientId = getTestProperty("stuf_clientId");
			final String stuf_clientSecret = "";
			final String stuf_tenant = getTestProperty("stuf_tenantUUID");
			final String stuf_username = getTestProperty("stuf_username");
			final String stuf_password = getTestProperty("stuf_password");
			System.out.println("\n"+"stuf_uaa_url="+stuf_uaa_url+"\n"+"stuf_grant_type="+stuf_grant_type+"\n"+"username="+username+"\n"+"stuf_clientId="+stuf_clientId+"\n"+"stuf_clientSecret="+stuf_clientSecret+"\n"+"password="+password);


			System.out.println("/***********create kpi and job ahead of time inorder to use in all the tests from excel sheet******/");
			if(getSysProperty("acs_token_kpiId")==null)
				setSysProperty("acs_token_kpiId", "");
			if(getSysProperty("acs_token_kpiId").equals(""))
			{
				System.out.println("------------->creating kpi template for different tenant  tests");

				String token1=getAPMToken(stuf_uaa_url,  stuf_username, stuf_password, stuf_clientId, stuf_clientSecret);

				//create kpi template
				ResponseEntity<Object> response = ooTestutil.getResponseFromcreateKpiTemplate(token1,stuf_tenant,stuf_tenant,"POST","src/main/resources/payloadsEventHub/kpi_templates/kpi_e2e.json", 
						"src/main/resources/payloadsEventHub/kpi_analytics/kpi_analytic_asset_ts_int.zip");
				ooTestutil.printResponseEntity(response);
				LinkedHashMap<String, Object> kpiDetails =(LinkedHashMap<String, Object>) response.getBody();
				// System.out.println("+++ response.asString() == " + response.toString());
				long kpi_id =((Integer) kpiDetails.get("id")).intValue();
				String kpi_name =(String)kpiDetails.get("name");
				setSysProperty("acs_token_kpiId", new Long(kpi_id).toString());
				setSysProperty("acs_token_kpiName", kpi_name);
				System.out.println("------------->acs_token_kpiId" + kpi_id);
				System.out.println("------------->acs_token_kpiName" + kpi_name);



				System.out.println("------------->creating kpi job for different tenant tests");
				Response jobResponse=ooTestutil.getResponseFromCreateKpiJob(token1,stuf_tenant,stuf_tenant,"POST","src/main/resources/payloadsEventHub/kpi_jobs/kpi_e2e_job.json", new Long(getSysProperty("acs_token_kpiId")).longValue());
				System.out.println(jobResponse.asString());
				JsonPath jsonPath = new JsonPath(jobResponse.asString());
				String kpiJobId = jsonPath.getString("id");
				setSysProperty("acs_token_jobId", new Long(kpiJobId).toString());
				setSysProperty("acs_jobId", new Long(kpiJobId).toString());
				System.out.println("------------->acs_jobId=" +kpiJobId);


			}
			System.out.println("/********************replace kpi id,name,job id in url from excel sheet*****************/");
			/***********replace kpi id,name,job id in url from excel sheet******/
			if(uri.contains("kpis"))
			{
				uri=uri.replaceFirst("\\{id\\}", getSysProperty("acs_token_kpiId"));
				uri=uri.replaceFirst("\\{name\\}", getSysProperty("acs_token_kpiName"));
			}
			else if(uri.contains("job"))
			{
				uri=uri.replaceFirst("\\{id\\}", getSysProperty("acs_token_jobId"));
			}

			System.out.println("/*******creating  token for token validation******/");
			String token=null;
			if(test_type.equals("no_token"))
			{
				token="";
			}
			else if(test_type.equals("expired_token"))
			{
				String expiredToken = generateFile("src/main/resources/data/"+getSysProperty("envType")+"/expired_token.json", "kpi_e2e");
				//System.out.println("expiredToken=" + expiredToken);
				File f1 = new File(expiredToken);
				System.out.println("file path=" + f1.getAbsolutePath());
				String path1 = f1.getAbsolutePath().replace('\\', '/');
				token = FileUtils.readFileToString(new File(path1));
				System.out.println("expiredToken_1=" + token);
			}
			else if(test_type.equals("junk_token"))
			{
				token=	getAPMToken(stuf_uaa_url,  username, password, stuf_clientId, stuf_clientSecret);
				token= token.substring(0,token.length()-5);
			}
			else if(test_type.equals("another_user_token"))
			{
				token=	getAPMToken(stuf_uaa_url,  username, password, stuf_clientId, stuf_clientSecret);

			}
			else if(test_type.equals("no_tenant_header"))
			{
				header_tenant=null;
				token=	getAPMToken(stuf_uaa_url,  username, password, stuf_clientId, stuf_clientSecret);
			}
			else
			{
				token=	getAPMToken(stuf_uaa_url,  username, password, stuf_clientId, stuf_clientSecret);
			}

			System.out.println("/********************calling the actual service *****************/");
			/**************call the service***********/
			Response response=null;
			String resStr=null;


			if(httpMethod.equalsIgnoreCase("GET") || httpMethod.equalsIgnoreCase("DELETE"))
			{
				response=ooTestutil.getResponseFromGetOrDelete(token,header_tenant,httpMethod,uri);
				resStr=response.asString();
				System.out.println(" response ="+ resStr);
				System.out.println("final response status="+ response.getStatusCode());
				System.out.println("expected response status="+ result);
				//recreate kpi id and jobid only if deleted
				if(response.getStatusCode()==200 && httpMethod.equalsIgnoreCase("DELETE"))
				{
					setSysProperty("acs_token_jobId", "");
					setSysProperty("acs_token_kpiId", "");
				}

				Assert.assertEquals(response.getStatusCode(), new Double(result).intValue(), "Not valid error response for "+"   :   "+testcase);

			}

			else if(httpMethod.equalsIgnoreCase("POST") || httpMethod.equalsIgnoreCase("PUT"))
			{
				if(uri.contains("job"))
				{

					if(uri.contains("start")||uri.contains("stop"))
					{
						try{
							response=ooTestutil.getResponseFromGetOrDelete(token,header_tenant,httpMethod,uri);
							if (response.getStatusCode()==417||response.getStatusCode()==500)
								response=ooTestutil.getResponseFromGetOrDelete(token,header_tenant,httpMethod,uri);
							resStr=response.asString();
							System.out.println(" response ="+ resStr);
							System.out.println("final response status="+ response.getStatusCode());
							System.out.println("expected response status="+ result);
						}catch(Exception e)
						{
							e.printStackTrace();
							throw e;

						}
						finally
						{//delete job once stop tests are done
							if( result==200 && uri.contains("stop"))
							{
								String token1=getAPMToken(stuf_uaa_url,  stuf_username, stuf_password, stuf_clientId, stuf_clientSecret);

								ooTestutil.getResponseFromGetOrDelete(token1,header_tenant,"DELETE",getTestProperty("job_url")+"/"+getSysProperty("acs_tenant_jobId"));
								setSysProperty("acs_token_jobId", "");
								setSysProperty("acs_token_kpiId", "");

							}
						}



						Assert.assertEquals(response.getStatusCode(), new Double(result).intValue(), "Not valid error response for "+"   :   "+testcase);

					}
					else{
						Response jobResponse=ooTestutil.getResponseFromCreateKpiJob(token,payload_tenant,header_tenant,httpMethod,json_payload_file, new Long(getSysProperty("acs_token_kpiId")).longValue());
						resStr=jobResponse.asString();
						System.out.println("Jobres="+resStr);

						System.out.println("final response status="+jobResponse.getStatusCode());

						Assert.assertEquals(jobResponse.getStatusCode(), new Double(result).intValue(), "Not valid error response for "+"   :   "+testcase);
					}
				}
				else if(uri.contains("kpi"))
				{
					if(httpMethod.equalsIgnoreCase("POST"))
					{

						//create kpi template
						ResponseEntity<Object> responseEntity = ooTestutil.getResponseFromcreateKpiTemplate(token,payload_tenant,header_tenant,httpMethod,json_payload_file,"src/main/resources/payloadsEventHub/kpi_analytics/kpi_analytic_asset_ts_int.zip");
						//ooTestutil.printResponseEntity(responseEntity);
						resStr=ooTestutil.getResponseEntity(responseEntity);
						System.out.println("final response status"+responseEntity.getStatusCode().value());

						Assert.assertEquals(responseEntity.getStatusCode().value(), new Double(result).intValue(), "Not valid error response for "+"   :   "+testcase);
					}
					else if(httpMethod.equalsIgnoreCase("PUT"))
					{
						setSysProperty("setKpiName", getSysProperty("acs_token_kpiName"));
						setSysProperty("setKpiId", getSysProperty("acs_token_kpiId"));
						if(uri.contains("kpi"))
						{
							uri=uri.replaceFirst("\\{id\\}", getSysProperty("acs_token_kpiId"));

						}
						if(uri.contains("artifact"))
						{
							ResponseEntity<Object> responseEntity=ooTestutil.getResponseFromUpdateKpiAnalyticFile( uri, token,  header_tenant,httpMethod,"src/main/resources/payloadsEventHub/kpi_analytics_1/analytic_1.zip");
							ooTestutil.printResponseEntity(responseEntity);
							resStr=ooTestutil.getResponseEntity(responseEntity);
							System.out.println("final response status"+responseEntity.getStatusCode().value());

							Assert.assertEquals(responseEntity.getStatusCode().value(), new Double(result).intValue(), "Not valid error response for "+"   :   "+testcase);

						}
						else 
						{
							Response response1=ooTestutil.getResponseFromUpdateKpiTemplateJson( uri, token, payload_tenant,header_tenant,httpMethod,json_payload_file);
							System.out.println("final response status"+response1.getStatusCode());

							resStr=response1.asString();
							System.out.println("final response "+response1.asString());
							Assert.assertEquals(response1.getStatusCode(), new Double(result).intValue(), "Not valid error response for "+"   :   "+testcase);

						}

					}


				}
			}

			System.out.println("***********************assert response message88******************************");
			if(!resultMessage.equalsIgnoreCase("na"))
			{
				System.out.println(" resStr ="+ resStr);
				if(resStr==null)
				{
					Assert.fail("expected text not found in response:"+resultMessage);
				}
				if(!resultMessage.startsWith("!"))
				{


					Assert.assertTrue(resStr.contains(resultMessage), "response message didnot contain ="+resultMessage );
				}
				else
				{
					String resultSubStr=resultMessage.substring(1,resultMessage.length());
					Assert.assertTrue(!resStr.contains(resultSubStr), "response message should not contain ="+resultSubStr );
				}
			}


			System.out.println("~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~");
		}catch(Exception e)
		{
			e.printStackTrace();
			throw e;
		}
	}



}

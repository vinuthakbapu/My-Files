package com.ge.automation.OO;

import java.io.IOException;
import java.net.URISyntaxException;
import java.util.LinkedHashMap;
import java.util.Map;
import java.util.Properties;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.boot.test.TestRestTemplate;
import org.springframework.web.client.RestTemplate;
import org.testng.Assert;
import org.testng.annotations.AfterClass;
import org.testng.annotations.AfterMethod;
import org.testng.annotations.AfterSuite;
import org.testng.annotations.AfterTest;
import org.testng.annotations.BeforeClass;
import org.testng.annotations.BeforeMethod;
import org.testng.annotations.BeforeSuite;
import org.testng.annotations.BeforeTest;
import org.testng.annotations.Test;

import com.ge.microtester.common.utils.RestAssuredUtil;
import com.ge.microtester.rally.RallyInfo;
import com.jayway.restassured.response.Response;

@RallyInfo(ProjectName="APM Super Optimo")
public class OOHealthCheckCF1AssetAndTagsWithAttributes extends RestAssuredUtil {
	private static final Logger log = LoggerFactory.getLogger("OOHealthCheckCF1Tests");
	static String jsonfileName;
	Properties configFile = new Properties();
	String truncateDateTime[];
	String tagName;
	String proxyHost;
	String proxyPort;
	Response responseBody;
	String kpiid;
	String kpiJobId;
	String dataSourceId;
	long kpi_id;
	long kpi_id1;
	String path = "src/main/resources/payloadsAndromeda";
	String apmTSforIngestionPath;
	boolean apmIngestionDynamicTag;
	String kpiTemplateJsonPath;
	String kpiAnalyticZipFilePath;
	String kpiJobJsonPath;
	String dataIngestionFilePath;
	String inputTag;
	String outputTag;
	String expectedValue;
	String expectedJobStatus;
	boolean createKpiJobWithTag;
	String apmTsUrl = "";
	String batchOrStream;
	String postDataPath;



	public OOTestUtil ooTestutil = new OOTestUtil();
	RestTemplate restTemplate = new TestRestTemplate();
	// Generating Query Params
	Map<String, Object> values = new LinkedHashMap<String, Object>();

	@BeforeMethod
	public void beforeMethod() {}

	@AfterMethod
	public void afterMethod() {}

	@BeforeClass
	public void beforeClass() {

		/*
		 * System.getProperties().put("proxySet", "true"); System.getProperties().put("http.proxyHost",
		 * "sjc1intproxy01.crd.ge.com"); System.getProperties().put("http.proxyPort", "8080");
		 * System.getProperties().put("https.proxyHost", "sjc1intproxy01.crd.ge.com");
		 * System.getProperties().put("https.proxyPort", "8080");
		 */
		// getServiceResponse("alert_profile_base_url");
		setSysProperty("currentTimeStamp", "" + getCurrentTimestamp());// ${sys:currentTimeStamp}

	}// end of beforeClass

	@AfterClass
	public void afterClass() {}

	@BeforeTest
	public void beforeTest() {

	}// end of beforeTest

	/********************************************************************************************************************/
	//@Test
	public void test_ApmTsIngestion_ApmTsRetrieval() {
		// post data to apm
		int valuePosted;
		try {
			valuePosted = ooTestutil.postRandomDataPointToAPMTimeSeries(path + "/data_files/data_ingestion_gen.json",
					"OO_Tag_Temperature_ID2");

			// get data from APM
			Thread.sleep(20000);
			ooTestutil.getDataFromApmTimeSeries("OO_Tag_Temperature_ID2", String.valueOf(valuePosted));
		} catch (IOException | URISyntaxException | InterruptedException e) {
			Assert.fail("test_ApmIngestion_ApmRetrieval failed with message " + e.getMessage());
		}
	}

	/**********************************************************************************************************************
	 * @throws URISyntaxException
	 * @throws IOException
	 * ******************************************************************************************************************/

	//@Test
	public void test_PostDataToEventhub_GetDataFromEventhub() throws IOException, URISyntaxException {
		log.info("Asserting EventHub Available");
		// get Asset data from APM
		try {
			// post data to event hub
			int valuePosted = ooTestutil
					.postDataPointToEventHubGenData(path + "/data_files/data_ingestion_gen_predixTs.json", "inputTag");
			Thread.sleep(30000);

			// get data from Apm time Series
			ooTestutil.getDataPointFromEventHub("inputTag", valuePosted+"");
			Thread.sleep(30000);
		} catch (InterruptedException e) {
			fail("test_PostDataToEventhub_GetDataFromEventhub failed with message " + e.getMessage());
		}
	}
	/********************************************************************************************************************/
	//@Test
	public void test_ApmAssetRetrievalWithAttributes() {
		log.info("Asserting Assets Exists");
		// get Asset data from APM
		try {
			ooTestutil.getAPMAssets();
		} catch (InterruptedException e) {
			Assert.fail("test_ApmAssetRetrieval failed with message " + e.getMessage());
		}
	}

	/********************************************************************************************************************/
	//run analytic that reads Asset Attributes and writes to TM tag
	//@Test(dependsOnMethods={"test_ApmTsIngestion_ApmTsRetrieval","test_ApmAssetRetrievalWithAttributes"})

	@Test
	@RallyInfo(UserStory ="US230877")
	public void testE2E_AssetAttributesInput_TSOutput() throws Exception {

		inputTag = "Analytics-CA-ASSET-ID1.Analytics_Tag_Pressure_ID";
		outputTag = "Analytics-CA-ASSET-ID1.Analytics_Tag_Pressure_ID1";
		kpiTemplateJsonPath = path + "/kpi_templates/kpi_e2e_ooapmts_inputAndOutput.json";
		kpiAnalyticZipFilePath = path + "/kpi_analytics/kpi-job-asset-attributes.zip";
		kpiJobJsonPath = path + "/kpi_jobs/assetWithAttributes_job.json";
		batchOrStream = "Batch";
		postDataPath = path + "/data_files/data_ingestion_gen.json";


		deployAnalytic(inputTag, outputTag,kpiTemplateJsonPath,
				kpiAnalyticZipFilePath,kpiJobJsonPath,batchOrStream ,postDataPath);


	}
	/***********************************************************************************************************************/

	@Test
	@RallyInfo(UserStory ="US230877")
	public void testE2E_TagAttributesInput_TSOutput() throws Exception {

		inputTag = "Analytics-CA-ASSET-ID1.Analytics_Tag_Pressure_ID";
		outputTag = "Analytics-CA-ASSET-ID1.Analytics_Tag_Pressure_ID1";
		kpiTemplateJsonPath = path + "/kpi_templates/kpi_e2e_ooapmts_inputAndOutput.json";
		kpiAnalyticZipFilePath = path + "/kpi_analytics/kpi-job-tag-attributes.zip";
		kpiJobJsonPath = path + "/kpi_jobs/tagWithAttributes_job.json";
		batchOrStream = "Batch";
		postDataPath = path + "/data_files/data_ingestion_gen.json";


		deployAnalytic(inputTag, outputTag,kpiTemplateJsonPath,
				kpiAnalyticZipFilePath,kpiJobJsonPath,batchOrStream ,postDataPath);


	}
	/***********************************************************************************************************************/
	//run analytic that reads Asset Attributes and writes to TM tag
	//@Test(dependsOnMethods={"test_ApmTsIngestion_ApmTsRetrieval","test_ApmAssetRetrievalWithAttributes"})
	//@Test
	@RallyInfo(UserStory ="US230877")
	public void testE2E_AssetAttributesInput_Stream() throws Exception {

		inputTag = "Analytics-CA-ASSET-ID1.Analytics_Tag_Pressure_ID";
		outputTag = "Analytics-CA-ASSET-ID1.Analytics_Tag_Pressure_ID1";
		kpiTemplateJsonPath = path + "/kpi_templates/kpiTemplate_assetAttributes.json";
		kpiAnalyticZipFilePath = path + "/kpi_analytics/kpi-job-asset-attributes.zip";
		kpiJobJsonPath = path + "/kpi_jobs/assetWithAttributesStream_job.json";
		batchOrStream = "Stream";
		postDataPath = path + "/data_files/data_ingestion_gen_predixTs.json";


		deployAnalytic(inputTag, outputTag,kpiTemplateJsonPath,
				kpiAnalyticZipFilePath,kpiJobJsonPath,batchOrStream ,postDataPath);


	}
	/***********************************************************************************************************************/

	//@Test(dependsOnMethods={"test_ApmTsIngestion_ApmTsRetrieval","test_ApmAssetRetrievalWithAttributes"})
	//@RallyInfo(UserStory ="US230877")
	public void testE2E_TagAttributesInput_Stream() throws Exception {

		inputTag = "OO_InputTag_Python_" + ooTestutil.generateRandomNumberNonUUID();
		outputTag = "OO_OutputTag_Python_" + ooTestutil.generateRandomNumberNonUUID();
		kpiTemplateJsonPath = path + "/kpi_templates/kpiTemplate_2.json";
		kpiAnalyticZipFilePath = path + "/kpi_analytics/simple_python_version3.zip";
		kpiJobJsonPath = path + "/kpi_jobs/kpiJob_6.json";
		batchOrStream = "Stream";
		postDataPath = path + "/data_files/data_ingestion_gen_predixTs.json";


		deployAnalytic(inputTag, outputTag,kpiTemplateJsonPath,
				kpiAnalyticZipFilePath,kpiJobJsonPath,batchOrStream ,postDataPath);

	}
/***********************************************************************************************************************/
	public void deployAnalytic(String inputTag, String outputTag, String kpiTemplateJsonPath,
			String kpiAnalyticZipFilePath, String kpiJobJsonPath,String batchOrStream , String postDataPath) throws IOException, URISyntaxException, InterruptedException{


		// create kpi template
		kpi_id = ooTestutil.createKpiTemplate(kpiTemplateJsonPath,kpiAnalyticZipFilePath);
		String statusOfJob;
		Thread.sleep(10000);

		// create kpi job
		kpiJobId = ooTestutil.createKpiJobWithNoRandomBothInputAndOutputTag(kpiJobJsonPath, kpi_id,
				outputTag, inputTag, "");

		if(batchOrStream.equalsIgnoreCase("Stream"))
		{

			// start kpi job
			ooTestutil.startStreamingKpiJob(kpiJobId);
			Thread.sleep(30000);
			statusOfJob = ooTestutil.getStatusOfJob(kpiJobId);

			// post data to event hub
			int valuePosted = ooTestutil.postDataPointToEventHubGenData(postDataPath, inputTag);
			Thread.sleep(30000);

			// get data from Apm time Series
			ooTestutil.getDataPointFromEventHub(outputTag, String.valueOf(valuePosted * 10));
			Thread.sleep(30000);

			// stop kpi job
			ooTestutil.stopKpiJob(kpiJobId);
			Thread.sleep(15000);
		}
		if(batchOrStream.equalsIgnoreCase("Batch"))
		{
			int valuePosted = ooTestutil.postRandomDataPointToAPMTimeSeries(path + "/data_files/data_ingestion_gen.json",
					inputTag);
			Thread.sleep(10000);
			// start kpi job
			String runtimeJobId = ooTestutil.startKpiJob(kpiJobId);
			Thread.sleep(30000);
			statusOfJob = ooTestutil.getStatusOfJob(kpiJobId);
			Thread.sleep(30000);
			ooTestutil.getDataFromApmTimeSeries(outputTag, String.valueOf(valuePosted * 10));
		}


		// delete kpi job
		ooTestutil.deleteKpiJob(kpiJobId);
		Thread.sleep(20000);
		// get status of the job
		statusOfJob = ooTestutil.getStatusOfJob(kpiJobId);

		//DELETE KPI
		log.info("+++ DELETE KPI+++++++++++++++++++++++++++++++++++");
		String kpiDeleteUrl = getTestProperty("kpi_url") + "/" + kpi_id;
		log.info("+++ kpiDeleteUrl == " + kpiDeleteUrl);
		Response delete_response = deleteServiceResponse("kpi_url" + "/" + kpi_id, values,
				ooTestutil.kpiprovideHeaders());
		log.info("+++ delete_response.asString() == " + delete_response.asString());

	}

	/********************************************************************************************************************/

	@AfterTest
	public void afterTest() {}

	@BeforeSuite
	public void beforeSuite() {

	}

	@AfterSuite
	public void afterSuite() {}
}

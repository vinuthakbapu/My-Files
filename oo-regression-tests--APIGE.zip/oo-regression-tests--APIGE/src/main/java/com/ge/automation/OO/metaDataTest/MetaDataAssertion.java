package com.ge.automation.OO.metaDataTest;

import com.google.gson.Gson;
import com.jayway.restassured.path.json.JsonPath;

import java.io.File;
import java.io.IOException;
import java.net.URISyntaxException;
import java.util.ArrayList;
import java.util.List;
import java.util.Map;

import static com.ge.microtester.common.core.GETestNGFramework.isEqual;
import static com.ge.microtester.common.core.GETestNGFramework.isJsonEqual;
import static com.ge.microtester.common.utils.FileUtil.generateFile;
import static com.ge.microtester.common.utils.RestAssuredUtil.getSysProperty;
import com.jayway.restassured.response.Response;

public class MetaDataAssertion{


    private List<String> getFieldsToIgnore(String serviceName){
        List<String> fieldsToIgnore = new ArrayList<String>();
        fieldsToIgnore.add("$.dateCreated");
        fieldsToIgnore.add("$.createdBy");
        fieldsToIgnore.add("$.dateLastUpdated");
        fieldsToIgnore.add("$.lastUpdatedBy");
        fieldsToIgnore.add("$.id");

        if (serviceName.equals("master")){
//            fieldsToIgnore.add("$.currentVersion");
            fieldsToIgnore.add("$.tenant");
//            fieldsToIgnore.addAll(getFieldsToIgnoreForGetMetaData());
        }
        if(serviceName.equals("updateMetaData")){
            fieldsToIgnore.remove("$.lastUpdatedBy");
            fieldsToIgnore.remove("$.id");
            fieldsToIgnore.remove("$.dateCreated");
            fieldsToIgnore.remove("$.createdBy");
        }

        return fieldsToIgnore;

    }

    public void verifyUpdateMetaData(Response updateGeoMetaDataResponse, String expectedJsonFilePath,String expectedUpdatedConfigPath) throws IOException, URISyntaxException {
        //verifies the update meta data response


//        verifyDateAndVersion(updateGeoMetaDataResponse.asString());
        expectedJsonFilePath = generateFile(expectedJsonFilePath, "updateMetaData");
        isJsonEqual(new File(expectedJsonFilePath), updateGeoMetaDataResponse.asString(), false,getFieldsToIgnore("updateMetaData"));

        String updatedConfig = updateGeoMetaDataResponse.getBody().jsonPath().getString("config");

//        updatedConfig = updatedConfig.replace("/","");
        verifyConfigVal(updatedConfig,expectedUpdatedConfigPath);

    }

    public void verifyTenantConfigIsEmpty(String jsonResponse)  {

        //verifies the get meta data response for non existing config

        System.out.println("^^^^^^AFTER^^^^^^^");
        isEqual("get geo metadata with non existing configuration: Json response is not empty",0,jsonResponse.length() );

    }

    public void verifyMasterConfigIsEmpty(List<Object> jsonResponse)  {

        //verifies the get meta data response for non existing config

        System.out.println("^^^^^^AFTER^^^^^^^");
        isEqual("get geo metadata with non existing configuration: Json response is not empty",0,jsonResponse.size());

    }

    public void verifyConfigVal(String actualConfig,String expectedConfig) throws IOException, URISyntaxException {
        System.out.println("before replace..>>>>>"+actualConfig);

        actualConfig = actualConfig.replace("/","");

        System.out.println("After substring..>>>>>"+actualConfig);

        expectedConfig =generateFile(expectedConfig, "jst");
        isJsonEqual(new File(expectedConfig), actualConfig, false);

    }

    private String getActualStringResponseVal(String serviceName, Response jsonResponse, int version){
        if(serviceName.equals("master")){
            Map responseMap;
            if (version > 0) {
                responseMap    = (Map)jsonResponse.getBody().jsonPath().getMap(".");

            }else {
              responseMap    = (Map)jsonResponse.getBody().jsonPath().getList(".").get(0);
            }

            if(responseMap.get("tenant")== null) {
                responseMap.put("tenant", "ignore");
            }else {
                throw new RuntimeException("master config has tenant id");
            }
            Gson gson = new Gson();
            return gson.toJson(responseMap);
        }
        return jsonResponse.asString();
    }

    public void verifyConfig(String serviceName, Response jsonResponse, String expectedJsonResponse, String expectedConfig, int...version) throws IOException, URISyntaxException {
        //verifies the get meta data

        expectedJsonResponse = generateFile(expectedJsonResponse, "geoMetaData");
        String ActualConfig = jsonResponse.getBody().jsonPath().getString("config");

        isJsonEqual(new File(expectedJsonResponse), getActualStringResponseVal(serviceName,jsonResponse,version.length), false, getFieldsToIgnore(serviceName));

        ActualConfig = ActualConfig.replace("/","");

        System.out.println("After replace..>>>>>"+ActualConfig);

        if(serviceName.equals("master")&& version.length==0){
            ActualConfig = ActualConfig.substring(1,ActualConfig.length()-1);
            System.out.println("After substring..>>>>>"+ActualConfig);
        }

        verifyConfigVal(ActualConfig,expectedConfig);
    }


}

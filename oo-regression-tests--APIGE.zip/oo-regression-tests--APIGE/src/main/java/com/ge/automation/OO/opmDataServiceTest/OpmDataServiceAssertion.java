package com.ge.automation.OO.opmDataServiceTest;

import java.util.List;
import java.util.stream.Collectors;

import static com.ge.microtester.common.core.GETestNGFramework.isEqual;
import static java.util.Arrays.asList;
import static org.junit.Assert.assertEquals;
import static org.junit.Assert.assertTrue;

public class OpmDataServiceAssertion {

    static void assertStatusCode(int actualStatusCode, int expectedStatusCode) {
        isEqual(OpmDataServiceProperties.STATUS_CODE_ERROR, actualStatusCode, expectedStatusCode);
    }

    static void assertForIndividualDataPoints(List<Long> dataPointList) {
        assertEquals(dataPointList.size(), OpmDataServiceProperties.NUMBER_OF_DAYS + 1);
    }

    static void assertForSummaryTags(String response) {
        assertForAggregatedTags(response);
        assertTrue(response.contains(OpmDataServiceProperties.TOTAL_PIDF_CHANGES));
        assertTrue(response.contains(OpmDataServiceProperties.OVERALL_PERFORMANCE));
        assertTrue(response.contains(OpmDataServiceProperties.PERCENTAGE_GOOD_QUALITY));
        assertTrue(response.contains(OpmDataServiceProperties.PV_ERROR_ABSOLUTE_AVERAGE));
        assertTrue(response.contains(OpmDataServiceProperties.PV_VARIABILITY));
        assertTrue(response.contains(OpmDataServiceProperties.MOVEMENT_INDEX));
    }

    static void assertForAggregatedTags(String response) {
        assertTrue(response.contains(OpmDataServiceProperties.PERCENTAGE_LIMITS_EXCEEDED));
        assertTrue(response.contains(OpmDataServiceProperties.PERCENTAGE_MANUAL));
        assertTrue(response.contains(OpmDataServiceProperties.PERCENTAGE_CASCADE));
        assertTrue(response.contains(OpmDataServiceProperties.PERCENTAGE_SHUTDOWN));
        assertTrue(response.contains(OpmDataServiceProperties.PERCENTAGE_AUTO));
    }

    static void assertForAssetFieldsInSummaryResponse(String summaryResponse) {
        assertTrue(summaryResponse.contains(OpmDataServiceProperties.ASSET_NAME));
        assertTrue(summaryResponse.contains(OpmDataServiceProperties.DESCRIPTION));
        assertTrue(summaryResponse.contains(OpmDataServiceProperties.SUMMARY_ASSET_URI));
        assertTrue(summaryResponse.contains(OpmDataServiceProperties.TAG_LIST));
    }

    static void assertForTagFieldsInAggregatedResponse(String aggregatedResponse) {
        assertTrue(aggregatedResponse.contains(OpmDataServiceProperties.TAG_NAME));
        assertTrue(aggregatedResponse.contains(OpmDataServiceProperties.DATA));
    }

    static List<Long> convertToLongArray(String[] arr) {
        return asList(arr).stream().map(s -> Long.parseLong(s)).collect(Collectors.toList());
    }

}
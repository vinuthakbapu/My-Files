package com.ge.automation.OO;

import java.io.IOException;
import java.net.URISyntaxException;
import java.time.LocalDateTime;
import java.time.ZoneId;
import java.util.LinkedHashMap;
import java.util.Map;
import java.util.Properties;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.boot.test.TestRestTemplate;
import org.springframework.web.client.RestTemplate;
import org.testng.annotations.AfterClass;
import org.testng.annotations.AfterMethod;
import org.testng.annotations.AfterSuite;
import org.testng.annotations.AfterTest;
import org.testng.annotations.BeforeClass;
import org.testng.annotations.BeforeMethod;
import org.testng.annotations.BeforeSuite;
import org.testng.annotations.BeforeTest;
import org.testng.annotations.Test;

import com.ge.microtester.common.utils.RestAssuredUtil;
import com.ge.microtester.rally.RallyInfo;
import com.jayway.restassured.response.Response;

@RallyInfo(ProjectName ="APM Super Optimo")
public class OOHealthCheckCF1StreamingTests extends RestAssuredUtil {
	private static final Logger log = LoggerFactory.getLogger("OOHealthCheckCF1Tests");
	static String jsonfileName;
	Properties configFile = new Properties();
	String truncateDateTime[];
	String tagName;
	String proxyHost;
	String proxyPort;
	Response responseBody;
	String kpiid;
	String kpiJobId;
	String dataSourceId;
	long kpi_id;
	long kpi_id1;
	String path = "src/main/resources/payloadsAndromeda";
	String apmTSforIngestionPath;
	boolean apmIngestionDynamicTag;
	String kpiTemplateJsonPath;
	String kpiTemplateAnalyticPath;
	String kpiJobJsonPath;
	String dataIngestionFilePath;
	String inputTag;
	String outputTag;
	String expectedValue;
	String expectedJobStatus;
	boolean createKpiJobWithTag;
	String apmTsUrl = "";

	public OOTestUtil ooTestutil = new OOTestUtil();
	RestTemplate restTemplate = new TestRestTemplate();
	// Generating Query Params
	Map<String, Object> values = new LinkedHashMap<String, Object>();

	@BeforeMethod
	public void beforeMethod() {
	}

	@AfterMethod
	public void afterMethod() {
	}

	@BeforeClass
	public void beforeClass() {

		/*
		 * System.getProperties().put("proxySet", "true");
		 * System.getProperties().put("http.proxyHost",
		 * "sjc1intproxy01.crd.ge.com");
		 * System.getProperties().put("http.proxyPort", "8080");
		 * System.getProperties().put("https.proxyHost",
		 * "sjc1intproxy01.crd.ge.com");
		 * System.getProperties().put("https.proxyPort", "8080");
		 */
		// getServiceResponse("alert_profile_base_url");
		setSysProperty("currentTimeStamp", "" + getCurrentTimestamp());// ${sys:currentTimeStamp}

	}// end of beforeClass

	@AfterClass
	public void afterClass() {
	}

	@BeforeTest
	public void beforeTest() {

	}// end of beforeTest


	/**********************************************************************************************************************
	 * @throws URISyntaxException 
	 * @throws IOException 
	 * ******************************************************************************************************************/

	@Test
	public void test_PostDataToEventhub_GetDataFromEventhub() throws IOException, URISyntaxException {
		log.info("Asserting EventHub Available");
		// get Asset data from APM
		try {
			// post data to event hub
			int valuePosted = ooTestutil
					.postDataPointToEventHubGenData(path + "/data_files/data_ingestion_gen_predixTs.json", "inputTag");
			Thread.sleep(30000);

			// get data from Apm time Series
			ooTestutil.getDataPointFromEventHub("inputTag", valuePosted+"");
			Thread.sleep(30000);
		} catch (InterruptedException e) {
			fail("test_PostDataToEventhub_GetDataFromEventhub failed with message " + e.getMessage());
		}
	}
	/********************************************************************************************************************
	 * Test Case: Asset and StreamTS input data provider OOStream as output data
	 * provider Test Steps: 1) Create Kpi Template. 2) Create Kpi Job with
	 * kpireference id. 3) Start Job 4) Assert data that is written to Kafka
	 * topic. /
	 ********************************************************************************************************************/
	//@Test(dependsOnMethods = "test_PostDataToEventhub_GetDataFromEventhub" )
	@RallyInfo(UserStory ="US223441")
	public void testE2E_AssetNStreamInputs_ApmTSOutput() throws Exception {

		// create kpi template
		kpi_id = ooTestutil.createKpiTemplate(path + "/kpi_templates/kpiTemplate_7.json",
				path + "/kpi_analytics/simple_java_version2.zip");
		Thread.sleep(10000);

		// create kpi job
		String inputTag = "OO_InputStreamTag_Java_" + ooTestutil.generateRandomNumberNonUUID();
		String outputTag = "OO_Tag_Temperature_ID25";
		kpiJobId = ooTestutil.createKpiJobWithNoRandomBothInputAndOutputTag(path + "/kpi_jobs/kpiJob_7.json", kpi_id,
				outputTag, inputTag, "");
		Thread.sleep(10000);

		ooTestutil.startStreamingKpiJob(kpiJobId);
		Thread.sleep(40000);
		String statusOfJob = ooTestutil.getStatusOfJob(kpiJobId);

		// if(statusOfJob.equalsIgnoreCase("RUNNING"))
		// {
		int valuePosted = ooTestutil
				.postDataPointToEventHubGenData(path + "/data_files/data_ingestion_gen_predixTs.json", inputTag);
		Thread.sleep(25000);
		ooTestutil.getDataFromApmTimeSeries(outputTag, String.valueOf(valuePosted * 10));
		Thread.sleep(15000);

		//		ooTestutil.postDataPointToEventHubGenData(path + "/data_files/data_ingestion_gen_predixTs.json", inputTag);
		//		Thread.sleep(15000);
		//		ooTestutil.getDataFromApmTimeSeries(outputTag, String.valueOf(valuePosted * 10));
		//		Thread.sleep(15000);
		//		
		// stop kpi job
		ooTestutil.stopKpiJob(kpiJobId);
		// delete kpi job
		Thread.sleep(10000);
		ooTestutil.deleteKpiJob(kpiJobId);
		Thread.sleep(20000);
		// get status of the job
		statusOfJob = ooTestutil.getStatusOfJob(kpiJobId);

		// DELETE KPI
		log.info("+++ DELETE KPI+++++++++++++++++++++++++++++++++++");
		String kpiDeleteUrl = getTestProperty("kpi_url") + "/" + kpi_id;
		log.info("+++ kpiDeleteUrl == " + kpiDeleteUrl);
		Response delete_response = deleteServiceResponse("kpi_url" + "/" + kpi_id, values,
				ooTestutil.kpiprovideHeaders());
		log.info("+++ delete_response.asString() == " + delete_response.asString());
		// isEqual("Delete failed", true, delete_response.getStatusCode() ==
		// HttpStatus.SC_NO_CONTENT);

		ooTestutil.printnewLine();

	}

	/********************************************************************************************************************
	 * Test Case: StreamTS input data provider OOStream as output data provider
	 * Test Steps: 1) Create Kpi Template. 2) Create Kpi Job with kpireference
	 * id. 3) Start Job 4) Assert data that is written to Kafka topic. /
	 ********************************************************************************************************************/
	@Test(dependsOnMethods = "test_PostDataToEventhub_GetDataFromEventhub" )
	@RallyInfo(UserStory ="US223441")
	public void testE2E_StreamInput_ApmTSOutput() throws Exception {

		// create kpi template
		kpi_id = ooTestutil.createKpiTemplate(path + "/kpi_templates/kpiTemplate_stream_ts.json",
				path + "/kpi_analytics/simple_java_version2.zip");
		Thread.sleep(10000);

		// create kpi job
		// String inputTag = "OO_Tag_Temperature_ID28";
		String inputTag = "OO_InputStreamInput_Java_" + ooTestutil.generateRandomNumberNonUUID();
		String outputTag = "OO_Tag_Temperature_ID29";
		kpiJobId = ooTestutil.createKpiJobWithNoRandomBothInputAndOutputTag(path + "/kpi_jobs/kpiJob_stream_ts.json",
				kpi_id, outputTag, inputTag, "");

		// start kpi job
		ooTestutil.startStreamingKpiJob(kpiJobId);
		Thread.sleep(40000);
		String statusOfJob = ooTestutil.getStatusOfJob(kpiJobId);
		// if(statusOfJob.equalsIgnoreCase("RUNNING"))
		// {
		// post data to event hub
		int valuePosted = ooTestutil
				.postDataPointToEventHubGenData(path + "/data_files/data_ingestion_gen_predixTs.json", inputTag);
		Thread.sleep(30000);
		LocalDateTime startTime = LocalDateTime.now(ZoneId.of("UTC"));

		//		ooTestutil.postDataPointToEventHubGenData(path + "/data_files/data_ingestion_gen_predixTs.json", inputTag);
		//		Thread.sleep(15000);
		startTime = LocalDateTime.now(ZoneId.of("UTC"));

		// get data from Apm time Series
		ooTestutil.getDataFromApmTimeSeries(outputTag, String.valueOf(valuePosted * 10));

		Thread.sleep(20000);
		// stop kpi job
		ooTestutil.stopKpiJob(kpiJobId);
		// delete kpi job
		Thread.sleep(10000);
		ooTestutil.deleteKpiJob(kpiJobId);
		Thread.sleep(20000);
		// get status of the job
		statusOfJob = ooTestutil.getStatusOfJob(kpiJobId);

		// DELETE KPI
		log.info("+++ DELETE KPI+++++++++++++++++++++++++++++++++++");
		String kpiDeleteUrl = getTestProperty("kpi_url") + "/" + kpi_id;
		log.info("+++ kpiDeleteUrl == " + kpiDeleteUrl);
		Response delete_response = deleteServiceResponse("kpi_url" + "/" + kpi_id, values,
				ooTestutil.kpiprovideHeaders());
		log.info("+++ delete_response.asString() == " + delete_response.asString());
		// isEqual("Delete failed", true, delete_response.getStatusCode() ==
		// HttpStatus.SC_NO_CONTENT);

		ooTestutil.printnewLine();


	}

	/********************************************************************************************************************
	 * Test Case: APM-TS input data provider OOStream as output data provider
	 * Test Steps:1) Create Kpi Template.2) Create Kpi Job with kpireference
	 * id.3) Start Job 4) Assert data that is written to Kafka topic.
	 * 
	 ********************************************************************************************************************/
	@Test(dependsOnMethods = "test_PostDataToEventhub_GetDataFromEventhub" )
	@RallyInfo(UserStory ="US223441")
	public void testE2E_ApmTSInput_StreamOutput() throws Exception {

		// create kpi template
		kpi_id = ooTestutil.createKpiTemplate(path + "/kpi_templates/kpiTemplate_ts_stream.json",
				path + "/kpi_analytics/simple_java_version2.zip");
		Thread.sleep(10000);

		// create kpi job
		String inputTag = "OO_Tag_Temperature_ID28";
		// String outputTag = "OO_OutputTag_testE2E_ApmTSInput_StreamOutput";
		String outputTag = "OO_OutputTagStream_Java_" + ooTestutil.generateRandomNumberNonUUID();

		kpiJobId = ooTestutil.createKpiJobWithNoRandomBothInputAndOutputTag(path + "/kpi_jobs/kpiJob_ts_stream.json",
				kpi_id, outputTag, inputTag, "");

		int valuePosted = ooTestutil
				.postRandomDataPointToAPMTimeSeries(path + "/data_files/data_ingestion_gen_ts_stream.json", inputTag);
		Thread.sleep(20000);

		// start kpi job
		ooTestutil.startStreamingKpiJob(kpiJobId);
		Thread.sleep(40000);
		String statusOfJob = ooTestutil.getStatusOfJob(kpiJobId);
		// if(statusOfJob.equalsIgnoreCase("RUNNING"))
		// {

		// get data from Apm time Series
		ooTestutil.getDataPointFromEventHub(outputTag, String.valueOf(valuePosted * 10));
		Thread.sleep(20000);

		// ooTestutil.postRandomDataPointToAPMTimeSeries(path +
		// "/data_files/data_ingestion_gen_ts_stream.json",
		// inputTag);
		// // get data from Apm time Series
		// ooTestutil.getDataPointFromEventHub(outputTag,
		// String.valueOf(valuePosted * 10));
		// Thread.sleep(20000);

		// stop kpi job
		ooTestutil.stopKpiJob(kpiJobId);
		Thread.sleep(15000);
		// delete kpi job
		ooTestutil.deleteKpiJob(kpiJobId);
		Thread.sleep(15000);
		// get status of the job
		statusOfJob = ooTestutil.getStatusOfJob(kpiJobId);


		// DELETE KPI
		log.info("+++ DELETE KPI+++++++++++++++++++++++++++++++++++");
		String kpiDeleteUrl = getTestProperty("kpi_url") + "/" + kpi_id;
		log.info("+++ kpiDeleteUrl == " + kpiDeleteUrl);
		Response delete_response = deleteServiceResponse("kpi_url" + "/" + kpi_id, values,
				ooTestutil.kpiprovideHeaders());
		log.info("+++ delete_response.asString() == " + delete_response.asString());
		// isEqual("Delete failed", true, delete_response.getStatusCode() ==
		// HttpStatus.SC_NO_CONTENT);


	}

	/********************************************************************************************************************
	 * Test Case: StreamTS input data provider OOStream as output data provider
	 * Test Steps:1) Create Kpi Template.2) Create Kpi Job with kpireference
	 * id.3) Start Job 4) Assert data that is written to Kafka topic.
	 * 
	 ********************************************************************************************************************/
	@Test(dependsOnMethods = "test_PostDataToEventhub_GetDataFromEventhub" )
	@RallyInfo(UserStory ="US223441")
	public void testE2E_StreamInput_StreamOutput_Java() throws Exception {

		// String zipfilename =
		// "simpleJavaAnalytic_cf1_"+ooTestutil.generateRandomNumberNonUUID();
		// ooTestutil.ZipAnalyticFile("sample-1.0.0-SNAPSHOT.jar", zipfilename);

		// create kpi template
		kpi_id = ooTestutil.createKpiTemplate(path + "/kpi_templates/kpiTemplate_2.json",
				path + "/kpi_analytics/" + "simple_java_version2.zip");

		Thread.sleep(10000);
		// ooTestutil.DeleteAnalyticZipFile(zipfilename);

		// create kpi job
		//String inputTag = "OO_InputTag_Java_" + ooTestutil.generateRandomNumberNonUUID();
		//String outputTag = "OO_OutputTag_Java_" + ooTestutil.generateRandomNumberNonUUID();
		String inputTag = "OO_Tag_Temperature_ID20";
		String outputTag = "OO_Tag_Temperature_ID21";

		kpiJobId = ooTestutil.createKpiJobWithNoRandomBothInputAndOutputTag(path + "/kpi_jobs/kpiJob_5.json", kpi_id,
				outputTag, inputTag, "");

		// start kpi job
		ooTestutil.startStreamingKpiJob(kpiJobId);
		Thread.sleep(30000);
		String statusOfJob = ooTestutil.getStatusOfJob(kpiJobId);
		// if(statusOfJob.equalsIgnoreCase("RUNNING"))
		// {

		// post data to event hub
		int valuePosted = ooTestutil
				.postDataPointToEventHubGenData(path + "/data_files/data_ingestion_gen_predixTs.json", inputTag);
		Thread.sleep(30000);

		// get data from Apm time Series
		ooTestutil.getDataPointFromEventHub(outputTag, String.valueOf(valuePosted * 10));
		Thread.sleep(30000);

		// stop kpi job
		ooTestutil.stopKpiJob(kpiJobId);
		Thread.sleep(15000);
		// delete kpi job
		ooTestutil.deleteKpiJob(kpiJobId);
		Thread.sleep(20000);
		// get status of the job
		statusOfJob = ooTestutil.getStatusOfJob(kpiJobId);

		 //DELETE KPI
		log.info("+++ DELETE KPI+++++++++++++++++++++++++++++++++++");
		String kpiDeleteUrl = getTestProperty("kpi_url") + "/" + kpi_id;
		log.info("+++ kpiDeleteUrl == " + kpiDeleteUrl);
		Response delete_response = deleteServiceResponse("kpi_url" + "/" + kpi_id, values,
				ooTestutil.kpiprovideHeaders());
		log.info("+++ delete_response.asString() == " + delete_response.asString());
		// isEqual("Delete failed", true, delete_response.getStatusCode() == HttpStatus.SC_NO_CONTENT);
		}


	/********************************************************************************************************************
	 * Test Case: StreamTS input data provider OOStream as output data provider
	 * Test Steps:1) Create Kpi Template.2) Create Kpi Job with kpireference
	 * id.3) Start Job 4) Assert data that is written to Kafka topic.
	 * 
	 ********************************************************************************************************************/
	@Test(dependsOnMethods = "test_PostDataToEventhub_GetDataFromEventhub" )
	@RallyInfo(UserStory ="US223441")
	public void testE2E_StreamInput_StreamOutput_Python() throws Exception {

		// create kpi template
		kpi_id = ooTestutil.createKpiTemplate(path + "/kpi_templates/kpiTemplate_2.json",
				path + "/kpi_analytics/simple_python_version3.zip");
		Thread.sleep(10000);

		// create kpi job

		String inputTag = "OO_InputTag_Python_" + ooTestutil.generateRandomNumberNonUUID();
		String outputTag = "OO_OutputTag_Python_" + ooTestutil.generateRandomNumberNonUUID();

		kpiJobId = ooTestutil.createKpiJobWithNoRandomBothInputAndOutputTag(path + "/kpi_jobs/kpiJob_6.json", kpi_id,
				outputTag, inputTag, "");

		// start kpi job
		ooTestutil.startStreamingKpiJob(kpiJobId);
		Thread.sleep(30000);
		String statusOfJob = ooTestutil.getStatusOfJob(kpiJobId);
		// if(statusOfJob.equalsIgnoreCase("RUNNING"))
		// {
		Thread.sleep(10000);
		// post data to event hub
		int valuePosted = ooTestutil
				.postDataPointToEventHubGenData(path + "/data_files/data_ingestion_gen_predixTs.json", inputTag);
		Thread.sleep(30000);

		// get data from Apm time Series
		ooTestutil.getDataPointFromEventHub(outputTag, String.valueOf(valuePosted * 10));
		Thread.sleep(40000);

		// stop kpi job
		ooTestutil.stopKpiJob(kpiJobId);
		Thread.sleep(15000);
		// delete kpi job
		ooTestutil.deleteKpiJob(kpiJobId);
		Thread.sleep(20000);
		// get status of the job
		statusOfJob = ooTestutil.getStatusOfJob(kpiJobId);

		// DELETE KPI
		log.info("+++ DELETE KPI+++++++++++++++++++++++++++++++++++");
		String kpiDeleteUrl = getTestProperty("kpi_url") + "/" + kpi_id;
		log.info("+++ kpiDeleteUrl == " + kpiDeleteUrl);
		Response delete_response = deleteServiceResponse("kpi_url" + "/" + kpi_id, values,
				ooTestutil.kpiprovideHeaders());
		log.info("+++ delete_response.asString() == " + delete_response.asString());
		// isEqual("Delete failed", true, delete_response.getStatusCode() ==
		// HttpStatus.SC_NO_CONTENT);


	}

	/*********************************************************************************************************
	 * Python Analytic - Forecasting Model and Streaming Job
	 * 
	 *********************************************************************************************************/

	//@Test(dependsOnMethods = "test_PostDataToEventhub_GetDataFromEventhub" )
	@RallyInfo(UserStory ="US223441")
	public void testE2E_ForeCastingModel_StreamingJob() throws Exception {

		// ingest test data into apm time series
		String observabletag = "OO_Tag_Temperature_ID26";
		String forecastingtag = "OO_Tag_Temperature_ID28";



		// ***************************Forecasting Model***************************//

		int valuePosted = ooTestutil.postRandomDataPointToAPMTimeSeries(path + "/data_files/data_ingestion_observable_data.json",
				observabletag);

		// create kpi template
		kpi_id = ooTestutil.createKpiTemplate(path + "/kpi_templates/kpi_payload_ML.json",
				path + "/kpi_analytics/train_ar_v4.zip");
		Thread.sleep(10000);

		// create kpi job
		String filter = "operation=raw&tagList="+observabletag+"&startTime=1506896578000&endTime=1507674178000&interval=60000";
		kpiJobId = ooTestutil.createPEKpiJobWithNoRandomBothInputAndOutputTag(path + "/kpi_jobs/job_payload_ML.json",
				kpi_id, forecastingtag, observabletag, "",filter);
		Thread.sleep(10000);

		// Deploy Forecasting Model
		String runtimeJobId = ooTestutil.startKpiJob(kpiJobId);
		Thread.sleep(120000);

		// get list of jobs running
		log.info("\n*****************LIST OF JOBS*******************");
		ooTestutil.printnewLine();
		String list = ooTestutil.getListOfJobsForAKpiId(kpi_id);

		// get PE kpi name
		log.info("\n*****************LIST PE KPI NAME*******************");

		String kpiName = ooTestutil.getKpiNameTemplateById(kpi_id);

		ooTestutil.printnewLine();
		//	String peKpiName = ooTestutil.getKpiTemplateByIdOrName("PE_"+kpiName+"_Automation");

		//String kpiName = ooTestutil.getKpiNameTemplateById(kpi_id);
		String appName = kpiName + "_Automation";
		//
		// post data to event hub
		int valuePosted1 = ooTestutil
				.postDataPointToEventHubForecastData(path + "/data_files/data_ingestion_gen_forecast.json",filter, appName,
						observabletag,forecastingtag);
		Thread.sleep(30000);

		// get last data point on Event hub
		ooTestutil.getDataPointFromEventHubPE(forecastingtag);
		Thread.sleep(30000);

		// delete kpi job
		// ooTestutil.deleteKpiJob(kpiJobId);
		// Thread.sleep(10000);
		// // get status of the job
		// ooTestutil.getStatusOfJob(kpiJobId);
		// // DELETE KPI
		// log.info("+++ DELETE KPI+++++++++++++++++++++++++++++++++++");
		// String kpiDeleteUrl = getTestProperty("kpi_url") + "/" + kpi_id;
		// log.info("+++ kpiDeleteUrl == " + kpiDeleteUrl);
		// Response delete_response = deleteServiceResponse("kpi_url" + "/" +
		// kpi_id, values,
		// ooTestutil.kpiprovideHeaders());
		// log.info("+++ delete_response.asString() == " +
		// delete_response.asString());

		ooTestutil.printnewLine();

	}

	/********************************************************************************************************************
	 * Test Case: StreamTS input data provider OOStream as output data provider
	 * Test Steps:1) Create Kpi Template.2) Create Kpi Job with kpireference
	 * id.3) Start Job 4) Assert data that is written to Kafka topic.
	 * 
	 ********************************************************************************************************************/
	//@Test(dependsOnMethods = "test_PostDataToEventhub_GetDataFromEventhub" )
	@RallyInfo(UserStory ="US223441")
	public void testE2E_Deploy_Streaming_And_Batch() throws Exception {

		// create kpi template
		kpi_id = ooTestutil.createKpiTemplate(path + "/kpi_templates/kpiTemplate_2.json",
				path + "/kpi_analytics/" + "simple_java_version2.zip");

		Thread.sleep(10000);

		// *********************Deploy Streaming Job******************************************

		// create kpi job
		String inputTag = "OO_InputTag_Java_" + ooTestutil.generateRandomNumberNonUUID();
		String outputTag = "OO_OutputTag_Java_" + ooTestutil.generateRandomNumberNonUUID();
		String kpiJobId_stream = ooTestutil.createKpiJobWithNoRandomBothInputAndOutputTag(
				path + "/kpi_jobs/kpiJob_5.json", kpi_id, outputTag, inputTag, "");

		// start kpi job
		ooTestutil.startStreamingKpiJob(kpiJobId_stream);
		Thread.sleep(30000);
		String statusOfJob = ooTestutil.getStatusOfJob(kpiJobId_stream);

		// *********************Deploy Batch Job******************************************

		// create kpi job
		String kpiJobId_batch = ooTestutil.createKpiJobWithNoRandomBothInputAndOutputTag(
				path + "/kpi_jobs/kpi_e2e_ooapmts_inputAndOutput_1_job.json", kpi_id, outputTag, inputTag, "");

		// start kpi job
		String runtimeJobId = ooTestutil.startKpiJob(kpiJobId_batch);
		Thread.sleep(20000);

		statusOfJob = ooTestutil.getStatusOfJob(kpiJobId_batch);
		Thread.sleep(10000);

		// *******************************************************************************
		// delete kpi job
		ooTestutil.deleteKpiJob(kpiJobId_stream);
		Thread.sleep(10000);

		// get status of the job
		statusOfJob = ooTestutil.getStatusOfJob(kpiJobId_stream);

		// delete kpi job
		ooTestutil.deleteKpiJob(kpiJobId_batch);
		Thread.sleep(10000);

		// get status of the job
		statusOfJob = ooTestutil.getStatusOfJob(kpiJobId_batch);


		// DELETE KPI
		log.info("+++ DELETE KPI+++++++++++++++++++++++++++++++++++");
		String kpiDeleteUrl = getTestProperty("kpi_url") + "/" + kpi_id;
		log.info("+++ kpiDeleteUrl == " + kpiDeleteUrl);
		Response delete_response = deleteServiceResponse("kpi_url" + "/" + kpi_id, values,
				ooTestutil.kpiprovideHeaders());
		log.info("+++ delete_response.asString() == " + delete_response.asString());
		// isEqual("Delete failed", true, delete_response.getStatusCode() ==
		// HttpStatus.SC_NO_CONTENT);

	}



	/********************************************************************************************************************/
	@AfterTest
	public void afterTest() {
	}

	@BeforeSuite
	public void beforeSuite() {

	}

	@AfterSuite
	public void afterSuite() {
	}
}

package com.ge.automation.OO;

import java.util.LinkedHashMap;
import java.util.Map;
import java.util.Properties;

import org.springframework.boot.test.TestRestTemplate;
import org.springframework.http.ResponseEntity;
import org.springframework.web.client.RestTemplate;
import org.testng.Assert;
import org.testng.annotations.AfterClass;
import org.testng.annotations.AfterMethod;
import org.testng.annotations.AfterSuite;
import org.testng.annotations.AfterTest;
import org.testng.annotations.BeforeClass;
import org.testng.annotations.BeforeMethod;
import org.testng.annotations.BeforeSuite;
import org.testng.annotations.BeforeTest;
import org.testng.annotations.Test;

import com.fasterxml.jackson.databind.ObjectMapper;
import com.ge.automation.OO.dto.JobDetails;
import com.ge.automation.OO.dto.KpiDetails;
import com.ge.microtester.common.utils.RestAssuredUtil;
import com.ge.microtester.rally.RallyInfo;
import com.jayway.restassured.response.Response;

@RallyInfo(ProjectName = "Operations Optimization Execution", FolderPath = "OO/HealthCheck")
public class OOHealthCheckTests extends RestAssuredUtil {

	static String jsonfileName;
	Properties configFile = new Properties();
	String truncateDateTime[];
	String tagName;
	String proxyHost;
	String proxyPort;
	Response responseBody;
	String kpiid;
	String kpiJobId;
	String dataSourceId;
	long kpi_id;
	long kpi_id1;
	String path = "src/main/resources/payloadsEventHub";
	String apmTSforIngestionPath;
	boolean apmIngestionDynamicTag;
	String kpiTemplateJsonPath;
	String kpiTemplateAnalyticPath;
	String kpiJobJsonPath;
	String dataIngestionFilePath;
	String inputTag;
	String outputTag;
	String expectedValue;
	String expectedJobStatus;
	boolean createKpiJobWithTag;
	String apmTsUrl = "";

	public OOTestUtil ooTestutil = new OOTestUtil();
	RestTemplate restTemplate = new TestRestTemplate();
	// Generating Query Params
	Map<String, Object> values = new LinkedHashMap<String, Object>();

	@BeforeMethod
	public void beforeMethod() {}

	@AfterMethod
	public void afterMethod() {}

	@BeforeClass
	public void beforeClass() {

		System.getProperties().put("proxySet", "true");
		System.getProperties().put("http.proxyHost", "sjc1intproxy01.crd.ge.com");
		System.getProperties().put("http.proxyPort", "8080");
		System.getProperties().put("https.proxyHost", "sjc1intproxy01.crd.ge.com");
		System.getProperties().put("https.proxyPort", "8080");
		//getServiceResponse("alert_profile_base_url");
		setSysProperty("currentTimeStamp", "" + getCurrentTimestamp());// ${sys:currentTimeStamp}

	}// end of beforeClass

	@AfterClass
	public void afterClass() {}

	@BeforeTest
	public void beforeTest() {

	}// end of beforeTest

	/********************************************************************************************************************
    Test Case: Asset and StreamTS input data provider
               OOStream as output data provider
    Test Steps:         
     1)  Create Kpi Template.
     2)  Create Kpi Job with kpireference id. 
     3)  Start Job
     4)  Assert data that is written to Kafka topic. 
	/********************************************************************************************************************/
	@Test(priority = 1, description = "testE2E_AssetNStreamInputs_ApmTSOutput")
	@RallyInfo(UserStory = "US4776")
	public void testE2E_AssetNStreamInputs_ApmTSOutput() throws Exception {

		//create kpi template
		kpi_id = ooTestutil.createKpiTemplate(path+"/kpi_templates/kpiTemplate_7.json", 
				path+"/kpi_analytics_1/analytic_7.zip");
		Thread.sleep(10000);

		//create kpi job	
		String inputTag = "OO_Tag_Temperature_ID38";
		String outputTag = "OO_Tag_Temperature_ID39";
		kpiJobId = ooTestutil.createKpiJobWithNoRandomBothInputAndOutputTag(path+"/kpi_jobs/kpiJob_7.json",kpi_id,
				outputTag,inputTag,"");
		Thread.sleep(10000);

		//start kpi job
		String runtimeJobId = ooTestutil.startKpiJob(kpiJobId);
		Thread.sleep(30000);
		if(runtimeJobId == null)
		{
			runtimeJobId = ooTestutil.startKpiJob(kpiJobId);
			Thread.sleep(15000);
		}
		if(runtimeJobId != null)
		{
			//get Status of the Job
			String status = ooTestutil.getStatusOfJob(kpiJobId);
			Thread.sleep(20000);


			if(status.equalsIgnoreCase("Running"))
			{

				//post data point to Event hub		
				int valuePosted = ooTestutil.postDataPointToEventHubGenData(path+"/data_files/data_ingestion_gen_predixTs.json",inputTag);		
				//int valuePosted = ooTestutil.postDataPointToKafkaTopicGenData(path+"/data_files/data_ingestion_gen_predixTs.json",inputTag);		
				Thread.sleep(40000);


				//get data from Apm time Series
				//Thread.sleep(30000);//2222.611
				ooTestutil.getDataFromApmTimeSeries(outputTag, String.valueOf(valuePosted *10));
				Thread.sleep(30000);

				//delete kpi job
				ooTestutil.deleteKpiJob(kpiJobId);
				Thread.sleep(10000);

				//get status of the job
				ooTestutil.getStatusOfJob(kpiJobId);		

				Thread.sleep(10000);
			}else{
				isEqual("Job not Started Successfully.Status of the JOB is --->"+status,true,false);
			}
		}else{
			isEqual("Job not Started Successfully.Status of the JOB is --->"+runtimeJobId,true,false);
		}
	}


	/********************************************************************************************************************
    Test Case: StreamTS input data provider
               OOStream as output data provider
    Test Steps:         
     1)  Create Kpi Template.
     2)  Create Kpi Job with kpireference id. 
     3)  Start Job
     4)  Assert data that is written to Kafka topic. 
	/********************************************************************************************************************/
	@Test(priority = 2, description = "testE2E_StreamInput_ApmTSOutput")
	@RallyInfo(UserStory = "DE10414")
	public void testE2E_StreamInput_ApmTSOutput() throws Exception {

		//create kpi template
		kpi_id = ooTestutil.createKpiTemplate(path+"/kpi_templates/kpiTemplate_4.json", 
				path+"/kpi_analytics_1/analytic_4.zip");
		Thread.sleep(10000);

		//create kpi job
		String inputTag = "OO_Tag_Temperature_ID40";
		String outputTag = "OO_Tag_Temperature_ID41";
		kpiJobId = ooTestutil.createKpiJobWithNoRandomBothInputAndOutputTag(path+"/kpi_jobs/kpiJob_4.json",kpi_id,
				outputTag,inputTag,"");


		//start kpi job
		String runtimeJobId = ooTestutil.startKpiJobTwice(kpiJobId);
		Thread.sleep(15000);
		if(runtimeJobId != null)
		{
			//get Status of the Job
			String status = ooTestutil.getStatusOfJob(kpiJobId);
			Thread.sleep(20000);

			if(status.equalsIgnoreCase("Running"))
			{

				//post data point to Event hub		
				int valuePosted = ooTestutil.postDataPointToEventHubGenData(path+"/data_files/data_ingestion_gen_predixTs.json",inputTag);		
				//int valuePosted = ooTestutil.postDataPointToKafkaTopicGenData(path+"/data_files/data_ingestion_gen_predixTs.json",inputTag);		
				Thread.sleep(70000);

				//get data from Apm time Series
				//Thread.sleep(30000);//2222.611
				ooTestutil.getDataFromApmTimeSeries(outputTag, String.valueOf(valuePosted *10));


				//delete kpi job
				ooTestutil.deleteKpiJob(kpiJobId);
				Thread.sleep(10000);

				//get status of the job
				status=ooTestutil.getStatusOfJob(kpiJobId);		


			}else{
				isEqual("Job not Started Successfully.Status of the JOB is --->"+status,true,false);
			}	
		}else{
			isEqual("Job not Started Successfully.runtimeJobId of the JOB is --->"+runtimeJobId,true,false);
		}

	}
	/********************************************************************************************************************/
	//@Test(priority = 3, description = "test_ApmIngestion_ApmRetrieval")
	@RallyInfo(UserStory = "US8804")
	public void test_ApmTsIngestion_ApmTsRetrieval() throws Exception {

		//post data to apm					
		int valuePosted = ooTestutil.postRandomDataPointToAPMTimeSeries(path+"/data_files/data_ingestion_gen.json"
				,"OO_Tag_Pressure_ID2");
		//get data from APM
		Thread.sleep(20000);
		ooTestutil.getDataFromApmTimeSeries("OO_Tag_Pressure_ID2", String.valueOf(valuePosted));

		return;
	}


	/********************************************************************************************************************/
	@Test(priority = 4, description = "test_ApmAssetRetrieval")
	@RallyInfo(UserStory = "US8804")
	public void test_ApmAssetRetrieval() throws Exception {

		//get Asset data from APM
		ooTestutil.getAPMAssets();

		return;
	}

	/********************************************************************************************************************/
	@Test(priority = 5, description = "testE2E_ApmTSInput_ApmTSOutput")
	@RallyInfo(UserStory = "US4776")
	public void testE2E_ApmTSInput_ApmTSOutput() throws Exception {


		//ingest test data into apm time series
		String inputTag = "OO_Tag_Temperature_ID40";
		int valuePosted = ooTestutil.postRandomDataPointToAPMTimeSeries(path+"/data_files/data_ingestion_gen.json"
				,inputTag);

		//create kpi template
		kpi_id = ooTestutil.createKpiTemplate(path+"/kpi_templates/kpi_e2e_ooapmts_inputAndOutput.json", 
				path+"/kpi_analytics_1/analytic_14.zip");
		Thread.sleep(10000);

		//create kpi job


		kpiJobId = ooTestutil.createKpiJobWithNoRandomBothInputAndOutputTag(path+"/kpi_jobs/kpi_e2e_ooapmts_inputAndOutput_1_job.json"
				,kpi_id,"OO_Tag_Temperature_ID41",inputTag,"");


		//start kpi job
		String runtimeJobId = ooTestutil.startKpiJob(kpiJobId);
		Thread.sleep(20000);
		if(runtimeJobId == null)
		{
			runtimeJobId = ooTestutil.startKpiJob(kpiJobId);
			Thread.sleep(15000);
		}
		if(runtimeJobId != null)
		{
			//get Status of the Job
			String status = ooTestutil.getStatusOfJob(kpiJobId);
			Thread.sleep(10000);

			if(status.equalsIgnoreCase("FINISHED"))
			{

				//get data from Apm time Series
				//Thread.sleep(30000);
				ooTestutil.getDataFromApmTimeSeries("OO_Tag_Temperature_ID41", String.valueOf(valuePosted *10));	


				//delete kpi job
				ooTestutil.deleteKpiJob(kpiJobId);
				Thread.sleep(10000);

				//get status of the job
				ooTestutil.getStatusOfJob(kpiJobId);		


			}else{
				isEqual("Job not Started Successfully.Status of the JOB is --->"+status,true,false);
			}
		}else{
			isEqual("Job not Started Successfully.runtimeJobId of the JOB is --->"+runtimeJobId,true,false);
		}
	}
	/*********************************************************************************************************
	 * Python Analytic - Read APM TS as input and write output to APM TS
	 * 
	 *********************************************************************************************************/

	@Test(priority = 1, description = "testE2E_ApmTSInput_ApmTSOutput_Python")
	@RallyInfo(UserStory = "USXXXX")
	public void testE2E_ApmTSInput_ApmTSOutput_Python() throws Exception {

		//ingest test data into apm time series
		String sourcetag = "OO_Tag_Temperature_ID1";
		String targettag = "OO_Tag_Temperature_ID2";
		int valuePosted = ooTestutil.postRandomDataPointToAPMTimeSeries(path+"/data_files/data_ingestion_gen.json"
				,sourcetag);

		//create kpi template
		kpi_id = ooTestutil.createKpiTemplate(path+"/kpi_templates/kpi_e2e_ooapmts_inputAndOutput_python.json", 
				path+"/kpi_analytics_1/kpiapmtspy1.zip");
		Thread.sleep(10000);

		//create kpi job
		kpiJobId = ooTestutil.createKpiJobWithNoRandomBothInputAndOutputTag(path+"/kpi_jobs/kpi_e2e_ooapmts_inputAndOutput_job_python.json"
				,kpi_id,targettag,sourcetag,"");
		Thread.sleep(10000);

		//start kpi job
		String runtimeJobId = ooTestutil.startKpiJobTwice(kpiJobId);

		if(runtimeJobId != null)
		{
			//get Status of the Job
			Thread.sleep(15000);
			//String status = ooTestutil.getStatusOfJob(kpiJobId);
			String message = ooTestutil.getMessageOfJob(kpiJobId);

			Thread.sleep(30000);

			if(message.equalsIgnoreCase("SUCCESS"))
			{

				//get data from Apm time Series
				//Thread.sleep(30000);
				ooTestutil.getDataFromApmTimeSeries(targettag, String.valueOf(valuePosted *10));	
				Thread.sleep(30000);

				//delete kpi job
				ooTestutil.deleteKpiJob(kpiJobId);
				Thread.sleep(10000);

				//get status of the job
				ooTestutil.getStatusOfJob(kpiJobId);		
				Thread.sleep(10000);
			}else{
				isEqual("Job not Started Successfully.Status of the JOB is --->"+message,true,false);
			}
		}else{
			isEqual("Job not Started Successfully.runtimeJobId of the JOB is --->"+runtimeJobId,true,false);
		}

	}
	/********************************************************************************************************************/
	@Test(priority =6, description = "testAnalyticConsumerDaemon")
	@RallyInfo(UserStory = "DE9424")
	public void testAnalyticConsumerDaemon() throws Exception {

		ooTestutil.printnewLine();

		String tagPostedToKafkaTopic = ooTestutil.postDataPointToKafkaTopicNoRandomTag("src/main/resources/payloads/data_files/data_ingestion_ts_analyticdaemon.json","OO_Tag_Temperature_ID4");
		Thread.sleep(10000);

		ooTestutil.printnewLine();
		String valueConsumedFromKafkaTopic = ooTestutil.getDataPointFromKafkaTopic(tagPostedToKafkaTopic);

		Thread.sleep(20000);
		ooTestutil.printnewLine();
		ooTestutil.getDataFromApmTimeSeries(tagPostedToKafkaTopic,"1.119");

		return;

	}

	/********************************************************************************************************************
	UPDATE Kpi::



	 ********************************************************************************************************************/
	@Test(priority=7,description="testUpdateDeleteKpi")
	public void testUpdateDeleteKpi() throws Exception {

		System.out.println("*****************Create KPI TEMPLATE*******************");
		ooTestutil.printnewLine();

		// *****************Create KPI TEMPLATE***************************************************//


		//create kpi template
		kpi_id = ooTestutil.createKpiTemplate("src/main/resources/payloadsEventHub/kpi_templates/kpiTemplate_13.json", 
				"src/main/resources/payloadsEventHub/kpi_analytics_1/analytic_13.zip");
		Thread.sleep(10000);

		ooTestutil.printnewLine();

		// *****************GET KPI****************************************************************//

		String getKpiUrl = "kpi_url"+"/id/"+kpi_id;
		System.out.println("\n\n+++ getKpiUrl ********== " + getKpiUrl+"\n\n");
		Response get_response = getServiceResponse(getKpiUrl, ooTestutil.kpiprovideHeaders());

		System.out.println("\n\n+++ response.asString() == " + get_response.asString()+"\n\n");
		String kpiName = get_response.jsonPath().getString("name[0]");
		System.out.println("\n\n+++ kpiName ********== " + kpiName+"\n\n");
		isEqual("Incorrect tag name", true, get_response.body().asString().contains(String.valueOf(kpi_id)));
		isEqual("Incorrect tag name", true, get_response.body().jsonPath().getList("inputs").size() > 0);
		isEqual("Incorrect tag name", true, get_response.body().jsonPath().getList("outputs").size() > 0);

		ooTestutil.printnewLine();

		// Update KPI Json
		String KpitemplateJsonPath = "src/main/resources/payloadsEventHub/kpi_templates/kpiTemplate_13_update.json";
		ooTestutil.updateKpiTemplateJsonFile(kpi_id,kpiName,KpitemplateJsonPath);
		ooTestutil.printnewLine();

		// Update KPI Analytic
		String KpitemplateAnalyticPath = "src/main/resources/payloadsEventHub/kpi_analytics_1/analytic_1.zip";
		ooTestutil.updateKpiTemplateAnalyticFile(kpi_id,KpitemplateAnalyticPath);
		ooTestutil.printnewLine();



		// DELETE KPI

		String kpiDeleteUrl = getTestProperty("kpi_url") + "/" + kpi_id;
		System.out.println("+++ kpiDeleteUrl == " + kpiDeleteUrl);
		Response delete_response = deleteServiceResponse("kpi_url" + "/" + kpi_id, values, ooTestutil.kpiprovideHeaders());
		System.out.println("+++ delete_response.asString() == " + delete_response.asString());
		System.out.println("+++ delete_response.getStatusCode() == " + delete_response.getStatusCode());
		//isEqual("Invalid reponse for delete kpi", true, delete_response.body().jsonPath().get("code").equals("OK"));
		isEqual("Invalid reponse for delete kpi", 204, delete_response.getStatusCode());

		System.out.println("+++ kpiGetUrl == " + kpiDeleteUrl);
		get_response = getServiceResponse("kpi_url" + "/id/" + kpi_id, values, ooTestutil.kpiprovideHeaders());
		System.out.println("+++ get_response.asString() == " + get_response.asString());
		System.out.println("+++ get_response.getStatusCode() == " + get_response.getStatusCode());
		isEqual("should not get kpi after delete kpi ", 404, get_response.getStatusCode());

	}


	/********************************************************************************************************************/
	@Test(priority = 8, description = "testUpdateDeleteKPIJob")
	public void testUpdateDeleteKPIJob() throws Exception {

		System.out.println("~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~");
		final String uri = getTestProperty("kpi_url");


		//create kpi template
		ResponseEntity<KpiDetails> response = ooTestutil.getResponseFromcreateKpiTemplate("src/main/resources/payloadsEventHub/kpi_templates/kpi_e2e.json",
				"src/main/resources/payloadsEventHub/kpi_analytics/kpi_analytic_asset_ts_int.zip");

		KpiDetails kpiDetails = response.getBody();
		// System.out.println("+++ response.asString() == " + response.toString());
		long kpi_id = kpiDetails.getId();
		System.out.println("------------->" + kpiDetails.getId());
		Response jobResponse=ooTestutil.getResponseFroCreateKpiJob("src/main/resources/payloadsEventHub/kpi_jobs/kpi_e2e_job.json", kpi_id);
		JobDetails jd=new ObjectMapper().readValue(jobResponse.asString(), JobDetails.class);

		long kpiJobId = jd.getId();
		System.out.println("+++ kpiJobId== " + kpiJobId);

		setSysProperty("kpiReferenceId", String.valueOf(kpi_id));
		setSysProperty("acs_jobId", String.valueOf(kpiJobId));
		String inputName="input"+ooTestutil.generateRandomNumber();
		setSysProperty("acs_inputName1",inputName);
		System.out.println("+++ inputName== " + inputName);
		Response jobResponse1=ooTestutil.UpdateKpiJob("src/main/resources/payloadsEventHub/kpi_jobs/kpi_acs_job_update.json");
		JobDetails jd1=new ObjectMapper().readValue(jobResponse1.asString(), JobDetails.class);
		kpiJobId = jd.getId();
		System.out.println("+++ kpiJobId== " + kpiJobId);


		Assert.assertNotNull(kpiJobId);
		Assert.assertNotEquals(jd1.getKpiReferenceId(),"","KPI reference id is missing");
		Assert.assertNotEquals(jd1.getInputs().size(),0,"KPI inputs are missing");
		Assert.assertNotEquals(jd1.getOutputs().size(),0,"KPI outputs are missing");
		isEqual("Not valid response Update KPI Job", 200, jobResponse1.statusCode());


		String response3=ooTestutil.getKpiJob(String.valueOf(kpiJobId));
		Assert.assertTrue(response3.contains(inputName), "job is not updated");

		//delete kpi job
		ooTestutil.deleteKpiJob(String.valueOf(kpiJobId));

		String response4=ooTestutil.getKpiJob(String.valueOf(kpiJobId));
		Assert.assertTrue(!response4.contains(inputName), "job is not deleted");

		System.out.println("~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~");
	}


	/********************************************************************************************************************/
	@AfterTest
	public void afterTest() {}

	@BeforeSuite
	public void beforeSuite() {

	}

	@AfterSuite
	public void afterSuite() {}
}

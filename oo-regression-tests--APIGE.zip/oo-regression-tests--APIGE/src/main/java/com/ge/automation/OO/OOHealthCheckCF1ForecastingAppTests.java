package com.ge.automation.OO;

import com.ge.microtester.common.utils.RestAssuredUtil;
import com.ge.microtester.rally.RallyInfo;
import com.ge.oo.commons.utils.StringUtils;
import com.jayway.restassured.response.Response;



import org.apache.http.HttpStatus;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.boot.test.TestRestTemplate;
import org.springframework.web.client.RestTemplate;
import org.testng.Assert;
import org.testng.annotations.AfterClass;
import org.testng.annotations.AfterMethod;
import org.testng.annotations.AfterSuite;
import org.testng.annotations.AfterTest;
import org.testng.annotations.BeforeClass;
import org.testng.annotations.BeforeMethod;
import org.testng.annotations.BeforeSuite;
import org.testng.annotations.BeforeTest;
import org.testng.annotations.Test;

import java.io.IOException;
import java.net.URISyntaxException;
import java.time.LocalDateTime;
import java.time.ZoneId;
import java.time.temporal.ChronoUnit;
import java.util.LinkedHashMap;
import java.util.Map;
import java.util.Properties;

@RallyInfo(ProjectName ="APM Super Optimo")
public class OOHealthCheckCF1ForecastingAppTests extends RestAssuredUtil {
	private static final Logger log = LoggerFactory.getLogger("OOHealthCheckCF1Tests");
	static String jsonfileName;
	Properties configFile = new Properties();
	String truncateDateTime[];
	String tagName;
	String proxyHost;
	String proxyPort;
	Response responseBody;
	String kpiid;
	String kpiJobId;
	String dataSourceId;
	long kpi_id;
	long kpi_id1;
	String path = "src/main/resources/payloadsAndromeda";
	String apmTSforIngestionPath;
	boolean apmIngestionDynamicTag;
	String kpiTemplateJsonPath;
	String kpiTemplateAnalyticPath;
	String kpiJobJsonPath;
	String dataIngestionFilePath;
	String inputTag;
	String outputTag;
	String expectedValue;
	String expectedJobStatus;
	boolean createKpiJobWithTag;
	String apmTsUrl = "";

	public OOTestUtil ooTestutil = new OOTestUtil();
	RestTemplate restTemplate = new TestRestTemplate();
	// Generating Query Params
	Map<String, Object> values = new LinkedHashMap<String, Object>();

	@BeforeMethod
	public void beforeMethod() {
	}

	@AfterMethod
	public void afterMethod() {
	}

	@BeforeClass
	public void beforeClass() {

		/*
		 * System.getProperties().put("proxySet", "true");
		 * System.getProperties().put("http.proxyHost",
		 * "sjc1intproxy01.crd.ge.com");
		 * System.getProperties().put("http.proxyPort", "8080");
		 * System.getProperties().put("https.proxyHost",
		 * "sjc1intproxy01.crd.ge.com");
		 * System.getProperties().put("https.proxyPort", "8080");
		 */
		// getServiceResponse("alert_profile_base_url");
		setSysProperty("currentTimeStamp", "" + getCurrentTimestamp());// ${sys:currentTimeStamp}

	}// end of beforeClass

	@AfterClass
	public void afterClass() {
	}

	@BeforeTest
	public void beforeTest() {

	}// end of beforeTest


	/**********************************************************************************************************************
	 * @throws URISyntaxException 
	 * @throws IOException 
	 * ******************************************************************************************************************/

	@Test
	public void test_PostDataToEventhub_GetDataFromEventhub() throws IOException, URISyntaxException {
		log.info("Asserting EventHub Available");
		// get Asset data from APM
		try {
			// post data to event hub
			int valuePosted = ooTestutil
					.postDataPointToEventHubGenData(path + "/data_files/data_ingestion_gen_predixTs.json", "inputTag");
			Thread.sleep(30000);

			// get data from Apm time Series
			ooTestutil.getDataPointFromEventHub("inputTag", valuePosted+"");
			Thread.sleep(30000);
		} catch (InterruptedException e) {
			fail("test_PostDataToEventhub_GetDataFromEventhub failed with message " + e.getMessage());
		}
	}


	/*********************************************************************************************************
	 * Python Analytic - Forecasting Model and Streaming Job
	 * 
	 *********************************************************************************************************/

	@Test(dependsOnMethods = "test_PostDataToEventhub_GetDataFromEventhub" )
	@RallyInfo(UserStory ="US214073")
	public void testE2E_ForeCastingModel_StreamingJob() throws Exception {

		// ingest test data into apm time series
		String observabletag = "opm-test-11";
		String forecastingtag = "OO_Tag_Temperature_ID28";

		String payload = OOTestUtil.prepareAPMTsDataForObservableTag(observabletag);
		ooTestutil.postTSdataToAPMTimeSeries(payload);

		// ***************************Forecasting Model***************************//

		// create kpi template
		kpi_id = ooTestutil.createKpiTemplate(path + "/kpi_templates/kpi_payload_ML.json",
				path + "/kpi_analytics/train_ar_v4.zip");
		Thread.sleep(10000);

		// create kpi job	
		String filter = "operation=raw&startTime=1509494400000&endTime=1510947639000&tagList=opm-test-11";
		kpiJobId = ooTestutil.createPEKpiJobWithNoRandomBothInputAndOutputTag(path + "/kpi_jobs/job_payload_ML.json",
				kpi_id, forecastingtag, observabletag, "",filter);
		Thread.sleep(10000);

		// Deploy Forecasting Model
		String runtimeJobId = ooTestutil.startKpiJob(kpiJobId);
		Thread.sleep(5000);
		// Deploy Forecasting Model
		runtimeJobId = ooTestutil.startSecondTimeKpiJob(kpiJobId);
		Thread.sleep(120000);

		// get list of jobs running
		log.info("\n*****************LIST OF JOBS*******************");
		ooTestutil.printnewLine();
		String list = ooTestutil.getListOfJobsForAKpiId(kpi_id);

		// get PE kpi name
		log.info("\n*****************LIST PE KPI NAME*******************");

		String kpiName = ooTestutil.getKpiNameTemplateById(kpi_id);
		Thread.sleep(30000);

		ooTestutil.printnewLine();

		String appName = kpiName + "_Automation";
		//
		// post data to event hub
		int valuePosted1 = ooTestutil
				.postDataPointToEventHubForecastData(path + "/data_files/data_ingestion_gen_forecast.json",filter, appName,
						observabletag,forecastingtag);
		Thread.sleep(30000);

		// get last data point on Event hub
		ooTestutil.getDataPointFromEventHubPE(forecastingtag);
		Thread.sleep(30000);

		// delete kpi job
		 ooTestutil.deleteKpiJob(kpiJobId);
		 Thread.sleep(10000);
		 
		 // get status of the job
		 ooTestutil.getStatusOfJob(kpiJobId);
		 
		 // DELETE KPI
		 log.info("+++ DELETE KPI+++++++++++++++++++++++++++++++++++");
		 String kpiDeleteUrl = getTestProperty("kpi_url") + "/" + kpi_id;
		 log.info("+++ kpiDeleteUrl == " + kpiDeleteUrl);
		 Response delete_response = deleteServiceResponse("kpi_url" + "/" +kpi_id, values,
		 ooTestutil.kpiprovideHeaders());
		 log.info("+++ delete_response.asString() == " +delete_response.asString());

		ooTestutil.printnewLine();

	}

	/********************************************************************************************************************/
	@AfterTest
	public void afterTest() {
	}

	@BeforeSuite
	public void beforeSuite() {

	}

	@AfterSuite
	public void afterSuite() {
	}
}

package com.ge.automation.OO.opmDataServiceTest;

import com.ge.automation.OO.OOTestUtil;
import com.jayway.restassured.response.Response;

import java.io.IOException;
import java.net.URISyntaxException;
import java.sql.Timestamp;
import java.time.LocalDate;
import java.time.LocalDateTime;
import java.time.LocalTime;

import static com.ge.microtester.common.utils.FileUtil.generateFile;
import static com.ge.microtester.common.utils.RestAssuredUtil.*;

public class OpmDataServiceTestHelper {

    private static OOTestUtil ooTestUtil = new OOTestUtil();

    static Response getClpmResponse(String jsonFilePath) throws IOException, URISyntaxException {
        setSystemProperties();
        return postServiceResponse(createClpmServicePayload(jsonFilePath), OpmDataServiceProperties.CLPM_URL,
                ooTestUtil.kpiprovideHeaders());
    }

    private static void setSystemProperties() {
        setSysProperty(OpmDataServiceProperties.ASSET_URI, getTestProperty(OpmDataServiceProperties.ASSET_URI));
        setSysProperty(OpmDataServiceProperties.SEGMENT_URI, getTestProperty(OpmDataServiceProperties.SEGMENT_URI));
        setStartAndEndDate();
    }

    private static String createClpmServicePayload(String jsonFilepath) throws IOException, URISyntaxException {
        String path = OpmDataServiceProperties.PAYLOAD_BASE_PATH.concat(jsonFilepath).concat(OpmDataServiceProperties
                .JSON_EXTENSION);
        return generateFile(path, jsonFilepath);
    }

    private static void setStartAndEndDate() {
        LocalTime midnight = LocalTime.MIDNIGHT;
        LocalDate today = LocalDate.now();
        LocalDateTime todayMidnight = LocalDateTime.of(today, midnight);
        LocalDateTime tomorrowMidnight = todayMidnight.plusDays(1);
        LocalDateTime sevenDaysAgoMidnight = todayMidnight.minusDays(OpmDataServiceProperties.NUMBER_OF_DAYS);
        setSysProperty(OpmDataServiceProperties.END_DATE, String.valueOf(Timestamp.valueOf(tomorrowMidnight).getTime
                ()));
        setSysProperty(OpmDataServiceProperties.START_DATE, String.valueOf(Timestamp.valueOf(sevenDaysAgoMidnight)
                .getTime()));
    }
}

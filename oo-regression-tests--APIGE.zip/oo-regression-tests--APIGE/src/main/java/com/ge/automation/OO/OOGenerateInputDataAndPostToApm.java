package com.ge.automation.OO;

import org.springframework.boot.test.TestRestTemplate;
import org.springframework.web.client.RestTemplate;
import org.testng.annotations.Test;

import com.ge.microtester.common.utils.RestAssuredUtil;
import com.ge.microtester.rally.RallyInfo;

@RallyInfo(ProjectName ="APM Super Optimo")
public class OOGenerateInputDataAndPostToApm extends RestAssuredUtil {
	
	public OOTestUtil ooTestutil = new OOTestUtil();
	RestTemplate restTemplate = new TestRestTemplate();


	/*********************************************************************************************************
	 * Generate Data And Post To Apm
	 * 
	 *********************************************************************************************************/

	@Test
	public void testGenerateDataAndPostToApm() throws Exception {

		// ingest test data into apm time series
		String observabletag = "OO_Tag_Temperature_ID20";

		String payload = OOTestUtil.prepareAPMTsDataForObservableTag(observabletag);
		ooTestutil.postTSdataToAPMTimeSeries(payload);

	
		ooTestutil.printnewLine();

	}

	/********************************************************************************************************************/

}

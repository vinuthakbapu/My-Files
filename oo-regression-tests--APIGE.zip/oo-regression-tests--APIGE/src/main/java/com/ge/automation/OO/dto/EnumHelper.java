package com.ge.automation.OO.dto;

import java.util.HashMap;
import java.util.Map;
import java.util.Set;

import org.apache.commons.lang.StringUtils;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import com.ge.automation.OO.dto.EnumHelper.IEnumStrValue;

public class EnumHelper<E extends Enum<E> & IEnumStrValue> {

    private static final Logger LOGGER = LoggerFactory.getLogger(EnumHelper.class);

    private final Map<String, E> valueToEnums = new HashMap<>();

    private final Map<String, E> upperCaseValueToEnums = new HashMap<>();

    public void initialize(Class<E> enumType) {
        for (E type : enumType.getEnumConstants()) {
            valueToEnums.put(type.getStrValue(), type);
            upperCaseValueToEnums.put(type.getStrValue().toUpperCase(), type);
        }
    }

    public E getEnumForStrValue(String strValue) {
        return getEnumForStrValue(strValue, "" /* className */);
    }

    public E getEnumForStrValue(String strValue, String className) {
        final String methodName = "EnumHelper.getEnumForStrValue";

        if (strValue == null || strValue.isEmpty()) {
            return null;
        }

        E type = upperCaseValueToEnums.get(strValue.toUpperCase());

        if (type == null) {
            throw new RuntimeException("No such type for Enum");
        }

        return type;
    }

    public E getEnumForStrValueNoThrow(String strValue) {
        if (strValue == null || strValue.isEmpty()) {
            return null;
        }
        return upperCaseValueToEnums.get(strValue.toUpperCase());
    }

    public String getValidStrValues() {
        return StringUtils.join(valueToEnums.keySet(), ", ");
    }

    public Set<String> getStrValues() {
        return valueToEnums.keySet();
    }

    public boolean contains(String strEnumValue) {
        return getEnumForStrValueNoThrow(strEnumValue) != null;
    }

    public Map<String, E> getStrValueToEnumMap() {
        return valueToEnums;
    }

    public void validateStrValue(String strValue) {
        getEnumForStrValue(strValue);
    }

    public interface IEnumStrValue {

        String getStrValue();
    }
}


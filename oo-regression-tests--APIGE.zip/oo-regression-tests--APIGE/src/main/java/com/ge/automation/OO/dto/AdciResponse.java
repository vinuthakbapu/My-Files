package com.ge.automation.OO.dto;

import java.util.Date;

public class AdciResponse {

    private DeployStatus deployStatus;

    private String deployErrorMessage;

    private Date deployedTime;

    private String adciRequestUri;

    public AdciResponse() {
    }

    public DeployStatus getDeployStatus() {
        return deployStatus;
    }

    public void setDeployStatus(DeployStatus deployStatus) {
        this.deployStatus = deployStatus;
    }

    public String getDeployErrorMessage() {
        return deployErrorMessage;
    }

    public void setDeployErrorMessage(String deployErrorMessage) {
        this.deployErrorMessage = deployErrorMessage;
    }

    public Date getDeployedTime() {
        return deployedTime;
    }

    public void setDeployedTime(Date deployedTime) {
        this.deployedTime = deployedTime;
    }

    public String getAdciRequestUri() {
        return adciRequestUri;
    }

    public void setAdciRequestUri(String adciRequestUri) {
        this.adciRequestUri = adciRequestUri;
    }
}

package com.ge.automation.OO;

import com.ge.automation.OO.dto.KpiDetails;
import com.ge.microtester.common.utils.RestAssuredUtil;

import com.fasterxml.jackson.databind.ObjectMapper;
import com.jayway.restassured.response.Response;

import org.apache.commons.io.FileUtils;
import org.apache.commons.logging.Log;
import org.apache.commons.logging.LogFactory;
import org.springframework.boot.test.TestRestTemplate;
import org.springframework.http.HttpEntity;
import org.springframework.http.HttpHeaders;
import org.springframework.http.HttpMethod;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.util.LinkedMultiValueMap;
import org.springframework.util.MultiValueMap;
import org.springframework.web.client.RestTemplate;
import org.testng.Assert;
// import org.apache.logging.log4j.LogManager;
// import org.apache.logging.log4j.Logger;
import org.testng.annotations.AfterClass;
import org.testng.annotations.AfterMethod;
import org.testng.annotations.AfterSuite;
import org.testng.annotations.AfterTest;
import org.testng.annotations.BeforeClass;
import org.testng.annotations.BeforeMethod;
import org.testng.annotations.BeforeSuite;
import org.testng.annotations.BeforeTest;
import org.testng.annotations.Test;

import java.io.File;
import java.io.FileInputStream;
import java.io.IOException;
import java.net.URISyntaxException;
import java.util.LinkedHashMap;
import java.util.Map;
import java.util.Properties;

public class OOUserProfileTests extends RestAssuredUtil {

    private static Log _OOlogger = LogFactory.getLog(OOUserProfileTests.class);
    private String token;
    private String oouaa_token;
    private String kpioouaa_token;
    private String idTenant;
    static String jsonfileName;
    Properties configFile = new Properties();
    String truncateDateTime[];
    String tagName;
    String proxyHost;
    String proxyPort;
    Response responseBody;
    String kpiid;
    String kpiJobId;
    String dataSourceId;
    long kpi_id;
    long kpi_id1;

    RestTemplate restTemplate = new TestRestTemplate();

    @BeforeMethod
    public void beforeMethod() {}

    @AfterMethod
    public void afterMethod() {}

    @BeforeClass
    public void beforeClass() {

        System.getProperties().put("proxySet", "true");
        System.getProperties().put("http.proxyHost", "sjc1intproxy01.crd.ge.com");
        System.getProperties().put("http.proxyPort", "8080");
        System.getProperties().put("https.proxyHost", "sjc1intproxy01.crd.ge.com");
        System.getProperties().put("https.proxyPort", "8080");
       // getServiceResponse("alert_profile_base_url");
        setSysProperty("currentTimeStamp", "" + getCurrentTimestamp());// ${sys:currentTimeStamp}
        try {
            configFile.load(new FileInputStream(new File("colo.configuration.properties")));

            idTenant = configFile.getProperty("tenantUUID");
            tagName = configFile.getProperty("tagName");
            proxyHost = configFile.getProperty("proxyHost");
            proxyPort = configFile.getProperty("proxyPort");

            // token = getAPMIngestorToken();
            token = getToken("tokenRequestURL", "grant_type", "tokenUsername", "tokenPassword", "tokenClientID",
                            "tokenClientSecret");
            System.out.println("token-------------->" + token);

            oouaa_token = getToken("uaaUrl", "grant_type", "username", "password", "clientId", "clientSecret");

            kpioouaa_token = getToken("kpi-uaaUrl", "grant_type", "kpi-uaaUserName", "kpi-uaaPassword",
                            "kpi-uaaClientId", "kpi-uaaClientSecret");
            System.out.println("kpioouaa_token-------------->" + kpioouaa_token);

        } catch (IOException e) {
            e.printStackTrace();
        }
    }// end of beforeClass

    @AfterClass
    public void afterClass() {}

    @BeforeTest
    public void beforeTest() {

    }// end of beforeTest

    // Generating headers for authorization and content-type
    public Map<String, Object> provideHeaders() {
        Map<String, Object> headersMap = new LinkedHashMap<>();
        // LOGGER.info("idTenant UUID ------------> " +
        // getProperty("tenantUUID")[0]);
        headersMap.put("idTenant", getProperty("tenantUUID")[0]);
        headersMap.put("Authorization", "Bearer " + token);
        headersMap.put("Content-Type", "application/json");
        headersMap.put("idTenant", idTenant);
        return headersMap;
    }

    public Map<String, Object> kpiprovideHeaders() {
        Map<String, Object> headersMap = new LinkedHashMap<>();
        headersMap.put("Authorization", "Bearer " + oouaa_token);
        headersMap.put("Content-Type", "application/json");
        headersMap.put("idTenant", idTenant);
        return headersMap;
    }

    public Map<String, Object> provideHeadersRabbitMQ() {
        Map<String, Object> headersMap = new LinkedHashMap<>();
        headersMap.put("Content-Type", "application/json");
        headersMap.put("idTenant", idTenant);
        return headersMap;
    }

    public HttpHeaders kpiprovideHeaders_1() {
        HttpHeaders headers = new HttpHeaders();
        headers.set("Authorization", "Bearer " + oouaa_token);
        headers.set("Content-Type", "multipart/form-data");
        return headers;
    }

    public HttpHeaders kpiprovideMultipartHeaders(String token) {
        HttpHeaders headers = new HttpHeaders();
        headers.set("Authorization", "Bearer " + token);
        headers.set("Content-Type", "multipart/form-data");
        return headers;
    }

    public Map<String, Object> kpiprovideHeaders_2() {
        Map<String, Object> headersMap = new LinkedHashMap<>();
        headersMap.put("Authorization", "Bearer " + oouaa_token);
        headersMap.put("Content-Type", "multipart/form-data");
        return headersMap;
    }


    public Map<String, Object> kpiprovideHeaders(String authToken) {
        Map<String, Object> headersMap = new LinkedHashMap<>();
        headersMap.put("Authorization", "Bearer " + oouaa_token);
        headersMap.put("Content-Type", "multipart/form-data");
        return headersMap;
    }



    /********************************************************************************************************************/
    @Test(priority = 2)
    public void TC62_testOOUAAInstance() throws IOException, InterruptedException, URISyntaxException {

        oouaa_token = getToken("uaaUrl", "grant_type", "username", "password", "clientId", "clientSecret");
        System.out.println("oouaa_token-------------->" + oouaa_token);

    }

    /********************************************************************************************************************/
    @Test(priority = 3)
    public void TC84_86_testOOLogger() throws IOException, InterruptedException, URISyntaxException {

        _OOlogger.error("Testing logger Error message");
        _OOlogger.info("Testing logger info message");
        _OOlogger.fatal("Testing logger fatal message");
        _OOlogger.debug("Testing logger debug message");
        _OOlogger.warn("Testing logger warn message");
        _OOlogger.trace("Testing logger trace message");

    }

    /********************************************************************************************************************/
    /*
     * Test to verify view access profile can't create a kpi.
     */
    @Test(priority = 4)
    public void T_____testCreateKpiWithViewProfileAccess()
                    throws IOException, InterruptedException, URISyntaxException {


        final String uri = getTestProperty("kpi_url");
        final String readOnlyToken = "";

        String kpiJson = FileUtils.readFileToString(new java.io.File("src/main/resources/payloads/kpi.json"));
        MultiValueMap<String, Object> parameters = new LinkedMultiValueMap<String, Object>();
        // parameters.add("kpi", new ObjectMapper().readValue(kpiJson, KpiDetails.class));
        //
        //
        // ResponseEntity<KpiDetails> response = restTemplate.exchange(uri, HttpMethod.POST,
        // new HttpEntity<MultiValueMap<String, Object>>(parameters, kpiprovideHeaders(readOnlyToken)),
        // KpiDetails.class);
        //
        // Assert.assertNotNull(response);
        // Assert.assertEquals(response.getStatusCode(), HttpStatus.UNAUTHORIZED);
    }



    /********************************************************************************************************************/
    /*
     * Test to verify view access profile can't update a kpi.
     */
    @Test(priority = 4)
    public void T_____testUpdateKpiWithViewProfileAccess()
                    throws IOException, InterruptedException, URISyntaxException {


        final String kpiId = "anyid";
        final String uri = getTestProperty("kpi_url") + "/" + kpiId;
        final String readOnlyToken = "";


        String kpiJson = FileUtils.readFileToString(new java.io.File("src/main/resources/payloads/kpi.json"));
        MultiValueMap<String, Object> parameters = new LinkedMultiValueMap<>();
        parameters.add("kpi", new ObjectMapper().readValue(kpiJson, KpiDetails.class));

        ResponseEntity<KpiDetails> response =
                        restTemplate.exchange(uri, HttpMethod.PUT, new HttpEntity<MultiValueMap<String, Object>>(
                                        parameters, kpiprovideMultipartHeaders(readOnlyToken)), KpiDetails.class);

        Assert.assertNotNull(response);
        Assert.assertEquals(response.getStatusCode(), HttpStatus.UNAUTHORIZED);
    }


    /********************************************************************************************************************/
    /*
     * Test to verify view access profile can't delete a kpi.
     */
    @Test(priority = 6)
    public void TC620_testDeleteKpiWithViewProfileAccess()
                    throws IOException, InterruptedException, URISyntaxException {

        // Generating Query Params
        Map<String, Object> values = new LinkedHashMap<>();
        values.put("", "");

        final String readOnlyToken = "";
        String kpiId = "any";
        String kpiDeleteUrl = getTestProperty("kpi_url") + "/" + kpi_id;
        System.out.println("+++ kpiDeleteUrl == " + kpiDeleteUrl);
        Response response = deleteServiceResponse("kpi_url" + "/" + kpi_id, values, kpiprovideHeaders(readOnlyToken));

        Assert.assertNotNull(response);
        Assert.assertEquals(response.getStatusCode(), HttpStatus.UNAUTHORIZED);

    }



    /********************************************************************************************************************/
    /*
     * Test to verify view access profile can view all kpis.
     */
    @Test(priority = 5)
    public void T_______________testGetAllKpisWithViewProfileAccess()
                    throws IOException, InterruptedException, URISyntaxException {


        // Generating Query Params
        Map<String, Object> values = new LinkedHashMap<>();
        values.put("", "");

        final String readOnlyToken = "";
        Response response = getServiceResponse("kpi_url", values, kpiprovideHeaders(readOnlyToken));

        Assert.assertNotNull(response);
        Assert.assertEquals(response.getStatusCode(), HttpStatus.OK);

    }

    /********************************************************************************************************************/
    /*
     * Test to verify view access profile can view kpi by kpi id.
     */
    @Test(priority = 22)
    public void T_______________testGetKpiByIdWithViewProfileAccess()
                    throws IOException, InterruptedException, URISyntaxException {
        // Generating Query Params
        Map<String, Object> values = new LinkedHashMap<>();
        values.put("", "");

        final String readOnlyToken = "";
        Response response = getServiceResponse("kpi_url" + "/id/1", values, kpiprovideHeaders(readOnlyToken));

        Assert.assertEquals(response.getStatusCode(), HttpStatus.OK);


    }


    /********************************************************************************************************************/
    /*
     * Test to verify view access profile can view kpi by kpi name.
     */
    @Test(priority = 22)
    public void T_______________testGetKpiByNameWithViewProfileAccess()
                    throws IOException, InterruptedException, URISyntaxException {

        // Generating Query Params
        Map<String, Object> values = new LinkedHashMap<>();
        values.put("", "");
        final String readOnlyToken = "";
        Response response = getServiceResponse("kpi_url" + "/name/anyname", values, kpiprovideHeaders(readOnlyToken));

        Assert.assertEquals(response.getStatusCode(), HttpStatus.OK);


    }


    /********************************************************************************************************************/
    /*
     * Test to verify edit access profile can view all kpis.
     */
    @Test(priority = 5)
    public void T_______________testGetAllKpisWithEditProfileAccess()
                    throws IOException, InterruptedException, URISyntaxException {



        // Generating Query Params
        Map<String, Object> values = new LinkedHashMap<>();
        values.put("", "");

        final String editKpiToken = "";
        Response response = getServiceResponse("kpi_url", values, kpiprovideHeaders(editKpiToken));

        Assert.assertNotNull(response);
        Assert.assertEquals(response.getStatusCode(), HttpStatus.OK);


    }

    /********************************************************************************************************************/
    /*
     * Test to verify edit access profile can view kpi by kpi id.
     */
    @Test(priority = 22)
    public void T_______________testGetKpiByIdWithEditProfileAccess()
                    throws IOException, InterruptedException, URISyntaxException {

        // Generating Query Params
        Map<String, Object> values = new LinkedHashMap<>();
        values.put("", "");

        final String editKpiToken = "";
        Response response = getServiceResponse("kpi_url" + "/id/1", values, kpiprovideHeaders(editKpiToken));

        Assert.assertEquals(response.getStatusCode(), HttpStatus.OK);


    }


    /********************************************************************************************************************/
    /*
     * Test to verify view access profile can view kpi by kpi name.
     */
    @Test(priority = 22)
    public void T_______________testGetKpiByNameWithEditProfileAccess()
                    throws IOException, InterruptedException, URISyntaxException {

        // Generating Query Params
        Map<String, Object> values = new LinkedHashMap<>();
        values.put("", "");
        final String editKpiToken = "";
        Response response = getServiceResponse("kpi_url" + "/name/anyname", values, kpiprovideHeaders(editKpiToken));

        Assert.assertEquals(response.getStatusCode(), HttpStatus.OK);


    }



    /********************************************************************************************************************/
    /*
     * Test to verify edit access profile can create a kpi
     */
    @Test(priority = 4)
    public void T__testCreateKpiWithEditAccessProfile() throws IOException, InterruptedException, URISyntaxException {


        final String uri = getTestProperty("kpi_url");

        String kpiJson = FileUtils.readFileToString(new java.io.File("src/main/resources/payloads/kpi.json"));
        MultiValueMap<String, Object> parameters = new LinkedMultiValueMap<>();
        parameters.add("kpi", new ObjectMapper().readValue(kpiJson, KpiDetails.class));


        final String editKpiToken = "";
        ResponseEntity<KpiDetails> response =
                        restTemplate.exchange(uri, HttpMethod.POST, new HttpEntity<MultiValueMap<String, Object>>(
                                        parameters, kpiprovideMultipartHeaders(editKpiToken)), KpiDetails.class);

        Assert.assertEquals(response.getStatusCode(), HttpStatus.CREATED);
        Assert.assertTrue(response.getBody() instanceof KpiDetails);
        KpiDetails kpiDetails = response.getBody();
        kpi_id1 = kpiDetails.getId();
        System.out.println("------------->" + kpiDetails.getId());
    }



    /********************************************************************************************************************/
    /*
     * Test to verify edit access profile can update a kpi
     */
    @Test(priority = 4)
    public void T__testUpdateKpiWithEditAccessProfile() throws IOException, InterruptedException, URISyntaxException {


        final String uri = getTestProperty("kpi_url");

        String kpiJson = FileUtils.readFileToString(new java.io.File("src/main/resources/payloads/kpi.json"));
        MultiValueMap<String, Object> parameters = new LinkedMultiValueMap<>();
        parameters.add("kpi", new ObjectMapper().readValue(kpiJson, KpiDetails.class));


        final String editKpiToken = "";
        ResponseEntity<KpiDetails> response =
                        restTemplate.exchange(uri, HttpMethod.PUT, new HttpEntity<MultiValueMap<String, Object>>(
                                        parameters, kpiprovideMultipartHeaders(editKpiToken)), KpiDetails.class);

        Assert.assertEquals(response.getStatusCode(), HttpStatus.CREATED);
        Assert.assertTrue(response.getBody() instanceof KpiDetails);
    }

    /********************************************************************************************************************/
    /*
     * Test to verify edit access profile can delete a kpi
     */
    @Test(priority = 6)
    public void TC620_testDeleteKpi() throws IOException, InterruptedException, URISyntaxException {



        // Generating Query Params
        Map<String, Object> values = new LinkedHashMap<>();

        values.put("", "");

        final String editKpiToken = "";
        String kpiDeleteUrl = getTestProperty("kpi_url") + "/" + kpi_id1;
        System.out.println("+++ kpiDeleteUrl == " + kpiDeleteUrl);
        Response response = deleteServiceResponse("kpi_url" + "/" + kpi_id1, values, kpiprovideHeaders(editKpiToken));


        Assert.assertNotNull(response);
        Assert.assertNotNull(response.getStatusCode());
        Assert.assertEquals(response.getStatusCode(), HttpStatus.OK);


    }

    @AfterTest
    public void afterTest() {}

    @BeforeSuite
    public void beforeSuite() {

    }

    @AfterSuite
    public void afterSuite() {}
}



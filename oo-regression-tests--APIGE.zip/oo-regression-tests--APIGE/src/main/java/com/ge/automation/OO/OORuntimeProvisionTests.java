package com.ge.automation.OO;

import java.io.File;

import org.apache.commons.io.FileUtils;
import org.testng.Assert;
import org.testng.annotations.Test;

import com.ge.microtester.common.utils.RestAssuredUtil;
import com.ge.microtester.rally.RallyInfo;
import com.jayway.restassured.response.Response;

@RallyInfo(ProjectName = "APM Super Optimo")
public class OORuntimeProvisionTests extends RestAssuredUtil {

	public OOTestUtil ooTestutil = new OOTestUtil();
	//********************************************************************************************************************//*

		//@Test(priority = 6, description = "testCreateRTGProvision" )
		public void testCreateRTGProvision() throws Exception {

			ooTestutil.printnewLine();
			String tenant = getTestProperty("runtime_tenantUUID");
			setSysProperty("tenant", tenant);
			
			
			 String runtime_gateway_provision_url = getTestProperty("runtime_gateway_provision_url");
			// String runtime_gateway_tenant_url = getTestProperty("runtime_gateway_tenant_url");
			System.out.println("find me runtime_gateway_provision_url:"+ runtime_gateway_provision_url);
			System.out.println("**************Deleting runtime provision*******************");
			Response response = deleteServiceResponse("runtime_gateway_provision_url",
						ooTestutil.runtimeProvisionHeaderWithClientCredentialsToken());
				System.out.println("deleteServiceResponse:"+ response.asString());
				System.out.println("deleteServiceResponse:" + response.getStatusCode());

				
			Thread.sleep(30000);
			
			
			String tenantCreate = "./src/main/resources/payloadsEventHub/runtime_provision/tenant-create.json";
			String tenantJson = generateFile(tenantCreate, "kpi_e2e1");

			System.out.println("**************creating runtime provision*******************");
			
			Response response1 = postServiceResponse(tenantJson, "runtime_gateway_provision_url",
					ooTestutil.runtimeProvisionHeaderWithClientCredentialsToken());
			Thread.sleep(60000);
			System.out.println("postServiceResponse:"+ response1.asString());

			System.out.println("postServiceResponse:" + response1.getStatusCode());
			Assert.assertEquals( true, response1.getStatusCode() == 201,"not able to create provision for tenant.");
			ooTestutil.printnewLine();
			
			
			
		}
		
		//@Test(priority = 6, description = "testGetRTGProvision" ,dependsOnMethods = { "testCreateRTGProvision" })
		public void testGetRTGProvision() throws Exception {

			ooTestutil.printnewLine();
			String tenant = getTestProperty("runtime_tenantUUID");
			 String runtime_gateway_provision_url = getTestProperty("runtime_gateway_provision_url");
			// String runtime_gateway_tenant_url = getTestProperty("runtime_gateway_tenant_url");
			System.out.println("find me runtime_gateway_provision_url:"+ runtime_gateway_provision_url);
			System.out.println("**************getting runtime provision*******************");
			Response response = getServiceResponse("runtime_gateway_provision_url",
						ooTestutil.runtimeProvisionHeaderWithClientCredentialsToken());
				System.out.println("getServiceResponse:"+ response.asString());
				System.out.println("getServiceResponse:" + response.getStatusCode());
				
				Assert.assertEquals( true, response.getStatusCode() == 200,"can't Retrieve runtime provision for " + tenant);
				
				
				
				
			
			
			
			
		}
		@Test(priority = 6, description = "testGetRTGProvisionInvalidAccessRights" )
		public void testGetRTGProvisionInvalidAccessRights() throws Exception {

			ooTestutil.printnewLine();
			String tenant = getTestProperty("runtime_tenantUUID");
			 String runtime_gateway_provision_url = getTestProperty("runtime_gateway_provision_url");
			// String runtime_gateway_tenant_url = getTestProperty("runtime_gateway_tenant_url");
			System.out.println("find me runtime_gateway_provision_url:"+ runtime_gateway_provision_url);
			System.out.println("**************getting runtime provision*******************");
			Response response = getServiceResponse("runtime_gateway_provision_url",
						ooTestutil.runtimeProvisionHeaderInvalidAccess());
				System.out.println("getServiceResponse:"+ response.asString());
				System.out.println("getServiceResponse:" + response.getStatusCode());
				
				Assert.assertEquals( true, response.getStatusCode() == 403,"should not be able to  Retrieve runtime provision for " + tenant);
				
				
			
		}
		@Test(priority = 6, description = "testGetRTGProvisionInvalidAccessRights2" )
		public void testGetRTGProvisionInvalidAccessRights2() throws Exception {

			ooTestutil.printnewLine();
			String tenant = getTestProperty("runtime_tenantUUID");
			 String runtime_gateway_provision_url = getTestProperty("runtime_gateway_provision_url");
			// String runtime_gateway_tenant_url = getTestProperty("runtime_gateway_tenant_url");
			System.out.println("find me runtime_gateway_provision_url:"+ runtime_gateway_provision_url);
			System.out.println("**************getting runtime provision*******************");
			Response response = getServiceResponse("runtime_gateway_provision_url",
						ooTestutil.runtimeProvisionHeader());
				System.out.println("getServiceResponse:"+ response.asString());
				System.out.println("getServiceResponse:" + response.getStatusCode());
				
				Assert.assertEquals( true, response.getStatusCode() == 403,"should not be able to  Retrieve runtime provision for " + tenant);
				
				
			
		}
		@Test(priority = 6, description = "testCreateRTGProvisionInvalidAccessRights1" )
		public void testCreateRTGProvisionInvalidAccessRights1() throws Exception {

			ooTestutil.printnewLine();
			String tenant = getTestProperty("runtime_tenantUUID");
			 String runtime_gateway_provision_url = getTestProperty("runtime_gateway_provision_url");
			// String runtime_gateway_tenant_url = getTestProperty("runtime_gateway_tenant_url");
			System.out.println("find me runtime_gateway_provision_url:"+ runtime_gateway_provision_url);
			
			
			
			String tenantCreate = "./src/main/resources/payloadsEventHub/runtime_provision/tenant-create.json";
			String tenantJson = generateFile(tenantCreate, "kpi_e2e1");

			System.out.println("**************creating runtime provision with edit deployments user*******************");
			
			Response response1 = postServiceResponse(tenantJson, "runtime_gateway_provision_url",
					ooTestutil.runtimeProvisionHeaderInvalidAccess());
			System.out.println("postServiceResponse:"+ response1.asString());

			System.out.println("postServiceResponse:" + response1.getStatusCode());
			Assert.assertEquals( true, response1.getStatusCode() == 403,"should not be able to   create provision for tenant.");
			ooTestutil.printnewLine();
			
		
			
			
		}
		
		@Test(priority = 6, description = "testCreateRTGProvisionInvalidAccessRights2" )
		public void testCreateRTGProvisionInvalidAccessRights2() throws Exception {

			ooTestutil.printnewLine();
			String tenant = getTestProperty("runtime_tenantUUID");
			 String runtime_gateway_provision_url = getTestProperty("runtime_gateway_provision_url");
			// String runtime_gateway_tenant_url = getTestProperty("runtime_gateway_tenant_url");
			System.out.println("find me runtime_gateway_provision_url:"+ runtime_gateway_provision_url);
			
			
			
			String tenantCreate = "./src/main/resources/payloadsEventHub/runtime_provision/tenant-create.json";
			String tenantJson = generateFile(tenantCreate, "kpi_e2e1");

			System.out.println("**************creating runtime provision using runtime gateway admin user*******************");
			
			
			
			Response response1 = postServiceResponse(tenantJson, "runtime_gateway_provision_url",
					ooTestutil.runtimeProvisionHeader());
			System.out.println("postServiceResponse:"+ response1.asString());

			System.out.println("postServiceResponse:" + response1.getStatusCode());
			Assert.assertEquals( true, response1.getStatusCode() == 403,"should not be able to create provision for tenant.");
			ooTestutil.printnewLine();
			
		
			
			
		}
		
		
		//@Test(priority = 6, description = "testDeleteRTGProvision" ,dependsOnMethods = { "testGetRTGProvision" })
		public void testDeleteRTGProvision() throws Exception {

			ooTestutil.printnewLine();
			String tenant = getTestProperty("runtime_tenantUUID");
			 String runtime_gateway_provision_url = getTestProperty("runtime_gateway_provision_url");
			// String runtime_gateway_tenant_url = getTestProperty("runtime_gateway_tenant_url");
			System.out.println("find me runtime_gateway_provision_url:"+ runtime_gateway_provision_url);
			System.out.println("**************deleting runtime provision*******************");
			Response response = deleteServiceResponse("runtime_gateway_provision_url",
						ooTestutil.runtimeProvisionHeaderWithClientCredentialsToken());
				System.out.println("delelteServiceResponse:"+ response.asString());
				System.out.println("delelteServiceResponse:" + response.getStatusCode());
				Thread.sleep(10000);
				Assert.assertEquals( true, response.getStatusCode() == 204,"can't delete runtime provision for " + tenant);
				
				
			
				
			
			
			
			
		}
		@Test(priority = 6, description = "testDeleteRTGProvisionInvalidAccessRights")
		public void testDeleteRTGProvisionInvalidAccessRights() throws Exception {

			ooTestutil.printnewLine();
			String tenant = getTestProperty("runtime_tenantUUID");
			 String runtime_gateway_provision_url = getTestProperty("runtime_gateway_provision_url");
			// String runtime_gateway_tenant_url = getTestProperty("runtime_gateway_tenant_url");
			System.out.println("find me runtime_gateway_provision_url:"+ runtime_gateway_provision_url);
			System.out.println("**************deleting runtime provision*******************");
			Response response = deleteServiceResponse("runtime_gateway_provision_url",
						ooTestutil.runtimeProvisionHeaderInvalidAccess());
				System.out.println("delelteServiceResponse:"+ response.asString());
				System.out.println("delelteServiceResponse:" + response.getStatusCode());
				
				Assert.assertEquals( true, response.getStatusCode() == 403,"should not be able to  delete runtime provision for " + tenant);
				
		
			
			
			
		}
		@Test(priority = 6, description = "testDeleteRTGProvisionInvalidAccessRights2")
		public void testDeleteRTGProvisionInvalidAccessRights2() throws Exception {

			ooTestutil.printnewLine();
			String tenant = getTestProperty("runtime_tenantUUID");
			 String runtime_gateway_provision_url = getTestProperty("runtime_gateway_provision_url");
			// String runtime_gateway_tenant_url = getTestProperty("runtime_gateway_tenant_url");
			System.out.println("find me runtime_gateway_provision_url:"+ runtime_gateway_provision_url);
			System.out.println("**************deleting runtime provision*******************");
			Response response = deleteServiceResponse("runtime_gateway_provision_url",
						ooTestutil.runtimeProvisionHeader());
				System.out.println("delelteServiceResponse:"+ response.asString());
				System.out.println("delelteServiceResponse:" + response.getStatusCode());
				
				Assert.assertEquals( true, response.getStatusCode() == 403,"should not be able to  delete runtime provision for " + tenant);
				
		
			
			
			
		}


	}

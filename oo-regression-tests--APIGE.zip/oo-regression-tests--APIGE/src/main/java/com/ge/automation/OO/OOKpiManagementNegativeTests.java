package com.ge.automation.OO;

import java.io.File;
import java.util.LinkedHashMap;
import java.util.Map;

import org.apache.commons.io.FileUtils;
import org.apache.commons.logging.Log;
import org.apache.commons.logging.LogFactory;
import org.springframework.boot.test.TestRestTemplate;
import org.springframework.core.io.FileSystemResource;
import org.springframework.http.HttpEntity;
import org.springframework.http.HttpHeaders;
import org.springframework.http.HttpMethod;
import org.springframework.http.ResponseEntity;
import org.springframework.util.LinkedMultiValueMap;
import org.springframework.util.MultiValueMap;
import org.springframework.web.client.RestTemplate;
import org.testng.Assert;
import org.testng.annotations.BeforeClass;
import org.testng.annotations.DataProvider;
import org.testng.annotations.Test;

import com.fasterxml.jackson.databind.ObjectMapper;

import com.ge.automation.OO.dto.JobDetails;
import com.ge.automation.OO.dto.KpiDetails;
import com.ge.microtester.common.utils.RestAssuredUtil;
import com.ge.microtester.rally.RallyInfo;

import com.jayway.restassured.response.Response;

@RallyInfo(ProjectName ="APM Super Optimo")
public class OOKpiManagementNegativeTests  extends RestAssuredUtil{

	String kpiid;
	String kpiJobId;
	String dataSourceId;
	long kpi_id;
	long kpi_id1;
	String path = "src/main/resources/payloadsAndromeda";
	public OOTestUtil ooTestutil = new OOTestUtil();
	RestTemplate restTemplate = new TestRestTemplate();
	private static Log _OOlogger = LogFactory.getLog(OOKpiManagementNegativeTests.class);
	// Generating Query Params
	Map<String, Object> values = new LinkedHashMap<String, Object>();
	@BeforeClass
	public void beforeClass() {

		System.getProperties().put("proxySet", "true");
		System.getProperties().put("http.proxyHost", "sjc1intproxy01.crd.ge.com");
		System.getProperties().put("http.proxyPort", "8080");
		System.getProperties().put("https.proxyHost", "sjc1intproxy01.crd.ge.com");
		System.getProperties().put("https.proxyPort", "8080");
		//getServiceResponse("alert_profile_base_url");
		setSysProperty("currentTimeStamp", "" + getCurrentTimestamp());// ${sys:currentTimeStamp}

	}// end o

	@DataProvider(name = "test1")
	public Object[][] createKPIJsons() {
		return new Object[][] {

			{ "src/main/resources/payloadsEventHub/kpi_templates/kpi_templates_negative/create_kpi_without_name.json" },
			{ "src/main/resources/payloadsEventHub/kpi_templates/kpi_templates_negative/create_kpi_without_input_and_output.json"},
			{ "src/main/resources/payloadsEventHub/kpi_templates/kpi_templates_negative/create_kpi_empty_fields.json"},
			{ "src/main/resources/payloadsEventHub/kpi_templates/kpi_templates_negative/create_kpi_empty_payload.json"},
			{ "src/main/resources/payloadsEventHub/kpi_templates/kpi_templates_negative/create_kpi_no_input_data_provider.json"},
			{ "src/main/resources/payloadsEventHub/kpi_templates/kpi_templates_negative/create_kpi_no_output_data_provider.json"},
			//{ "src/main/resources/payloadsEventHub/kpi_templates/kpi_templates_negative/create_kpi_nonexisting_input_data_provider.json"},
			//{ "src/main/resources/payloadsEventHub/kpi_templates/kpi_templates_negative/create_kpi_nonexisting_output_data_provider.json"},
			{ "src/main/resources/payloadsEventHub/kpi_templates/kpi_templates_negative/create_kpi_name_special_chars.json"}


		};
	}






	/********************************************************************************************************************/
	@Test(priority = 9, description = "testCreateKpiErrorValidationInputOutputProviders",dataProvider = "createKPIJsons")
	@RallyInfo(UserStory ="US223441")
	public void testCreateKpiErrorValidationInputOutputProviders(String kpiJsonStr) throws Exception {

		final String uri = getTestProperty("kpi_url");
		System.out.println("~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~");
		System.out.println("kpi json file="+ kpiJsonStr);
		//create kpi template
		ResponseEntity<KpiDetails> response = ooTestutil.getResponseFromcreateKpiTemplate(kpiJsonStr,
				"src/main/resources/payloadsEventHub/kpi_analytics/kpi_analytic_asset_ts_int.zip");

		System.out.println("response="+ response);
		Assert.assertEquals(response.getStatusCode().value(), 400, "Not valid error response for creating kpi");
		//isEqual("Not valid error response for creating kpi", 400,response.getStatusCode().value());
		System.out.println("~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~");
	}

	/********************************************************************************************************************/
	@Test(priority = 9, description = "testCreateKpiErrorValidationDifferentSchemaJson")
	@RallyInfo(UserStory ="US223441")
	public void testCreateKpiErrorValidationDifferentSchemaJson() throws Exception {

		System.out.println("~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~");
		final String uri = getTestProperty("kpi_url");

		setSysProperty("setKpiName", "kpiname" + ooTestutil.generateRandomNumber());
		setSysProperty("tenant", getTestProperty("tenantUUID"));
		String kpiFile = "src/main/resources/payloadsEventHub/kpi_templates/kpi_templates_negative/create_kpi_different_schema.json";
		String kpiJson = generateFile(kpiFile, "kpi_e2e");
		System.out.println("kpijson1=" + kpiJson);
		File f = new File(kpiJson);
		System.out.println("file path=" + f.getAbsolutePath());

		String path = f.getAbsolutePath().replace('\\', '/');

		// String kpiJson = FileUtils.readFileToString(new
		// java.io.File("src/main/resources/payloadsEventHub/finale2eScenarios/kpi_e2e.json"));
		String kpiJson_1 = FileUtils.readFileToString(new File(path));
		System.out.println("kpijson2=" + kpiJson_1);
		File analyticFile =
				new java.io.File("src/main/resources/payloadsEventHub/kpi_analytics/kpi_analytic_asset_ts_int.zip");

		MultiValueMap<String, Object> parameters = new LinkedMultiValueMap<String, Object>();
		parameters.add("uploadfile", new FileSystemResource(analyticFile));
		parameters.add("kpi", new ObjectMapper().readValue(kpiJson_1, JobDetails.class));

		ResponseEntity<JobDetails> response = restTemplate.exchange(uri, HttpMethod.POST,
				new HttpEntity<MultiValueMap<String, Object>>(parameters, ooTestutil.kpiprovideHeaders_1()),
				JobDetails.class);

		System.out.println("response="+ response);
		Assert.assertEquals(response.getStatusCode().value(), 400, "Not valid error response for creating kpi");
		//isEqual("Not valid response for Start Job for Error validation Name field missing", 400,response.getStatusCode().value());
		System.out.println("~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~");
	}

	/********************************************************************************************************************/
	//@Test(priority = 9, description = "testCreateKpiErrorValidationAnalyticWithJunkClass")
	public void testCreateKpiErrorValidationAnalyticWithJunkClass() throws Exception {

		System.out.println("~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~");
		final String uri = getTestProperty("kpi_url");
		ResponseEntity<KpiDetails> response = ooTestutil.getResponseFromcreateKpiTemplate("src/main/resources/payloadsEventHub/kpi_templates/kpi_e2e.json", 
				"src/main/resources/payloadsEventHub/kpi_analytics/junkClass.zip");


		System.out.println("response="+ response);
		Assert.assertEquals(response.getStatusCode().value(), 400, "Not valid error response for creating kpi");
		//isEqual("Not valid response for Start Job for Error validation Name field missing", 400,response.getStatusCode().value());
		System.out.println("~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~");
	}
	/********************************************************************************************************************/
	//@Test(priority = 9, description = "testCreateKpiErrorValidationNoAnalyticFile")
	public void testCreateKpiErrorValidationNoAnalyticFile() throws Exception {

		System.out.println("~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~");

		final String uri = getTestProperty("kpi_url");

		setSysProperty("setKpiName", "kpiname" + ooTestutil.generateRandomNumber());
		setSysProperty("tenant", getTestProperty("tenantUUID"));
		String kpiFile = "src/main/resources/payloadsEventHub/kpi_templates/kpi_e2e.json";
		String kpiJson = generateFile(kpiFile, "kpi_e2e");
		System.out.println("kpijson1=" + kpiJson);
		File f = new File(kpiJson);
		System.out.println("file path=" + f.getAbsolutePath());

		String path = f.getAbsolutePath().replace('\\', '/');

		// String kpiJson = FileUtils.readFileToString(new
		// java.io.File("src/main/resources/payloadsEventHub/finale2eScenarios/kpi_e2e.json"));
		String kpiJson_1 = FileUtils.readFileToString(new File(path));
		System.out.println("kpijson2=" + kpiJson_1);

		MultiValueMap<String, Object> parameters = new LinkedMultiValueMap<String, Object>();

		parameters.add("kpi", new ObjectMapper().readValue(kpiJson_1, KpiDetails.class));

		ResponseEntity<KpiDetails> response = restTemplate.exchange(uri, HttpMethod.POST,
				new HttpEntity<MultiValueMap<String, Object>>(parameters, ooTestutil.kpiprovideHeaders_1()),
				KpiDetails.class);

		System.out.println("response="+ response);
		Assert.assertEquals(response.getStatusCode().value(), 400, "Not valid error response for creating kpi");
		//isEqual("Not valid response for Start Job for Error validation Name field missing", 400,response.getStatusCode().value());
		System.out.println("~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~");
	}
	/********************************************************************************************************************/
	//@Test(priority = 9, description = "testCreateKpiErrorValidationNoToken")
	public void testCreateKpiErrorValidationNoToken() throws Exception {

		System.out.println("~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~");

		final String uri = getTestProperty("kpi_url");

		setSysProperty("setKpiName", "kpiname" + ooTestutil.generateRandomNumber());
		setSysProperty("tenant", getTestProperty("tenantUUID"));
		String kpiFile = "src/main/resources/payloadsEventHub/kpi_templates/kpi_e2e.json";
		String kpiJson = generateFile(kpiFile, "kpi_e2e");
		System.out.println("kpijson1=" + kpiJson);
		File f = new File(kpiJson);
		System.out.println("file path=" + f.getAbsolutePath());

		String path = f.getAbsolutePath().replace('\\', '/');

		// String kpiJson = FileUtils.readFileToString(new
		// java.io.File("src/main/resources/payloadsEventHub/finale2eScenarios/kpi_e2e.json"));
		String kpiJson_1 = FileUtils.readFileToString(new File(path));
		System.out.println("kpijson2=" + kpiJson_1);
		File analyticFile =
				new java.io.File("src/main/resources/payloadsEventHub/kpi_analytics/kpi_analytic_asset_ts_int.zip");

		MultiValueMap<String, Object> parameters = new LinkedMultiValueMap<String, Object>();
		parameters.add("uploadfile", new FileSystemResource(analyticFile));
		parameters.add("kpi", new ObjectMapper().readValue(kpiJson_1, KpiDetails.class));
		HttpHeaders headers = new HttpHeaders();
		headers=ooTestutil.kpiprovideHeaders_3(getTestProperty("tenantUUID"), "Bearer " + "");
		
		ResponseEntity<String> response = restTemplate.exchange(uri, HttpMethod.POST,
				new HttpEntity<MultiValueMap<String, Object>>(parameters,headers),
				String.class);

		System.out.println("response="+ response);
		Assert.assertEquals(response.getStatusCode().value(), 400, "Not valid error response for creating kpi");
		//isEqual("Not valid response for Start Job for Error validation Name field missing", 400,response.getStatusCode().value());
		System.out.println("~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~");
	}
	/********************************************************************************************************************/
	//@Test(priority = 9, description = "testCreateKpiErrorValidationExpiredToken")
	public void testCreateKpiErrorValidationExpiredToken() throws Exception {

		System.out.println("~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~");

		final String uri = getTestProperty("kpi_url");

		setSysProperty("setKpiName", "kpiname" + ooTestutil.generateRandomNumber());
		setSysProperty("tenant", getTestProperty("tenantUUID"));
		String kpiFile = "src/main/resources/payloadsEventHub/kpi_templates/kpi_e2e.json";
		String kpiJson = generateFile(kpiFile, "kpi_e2e");
		System.out.println("kpijson1=" + kpiJson);
		File f = new File(kpiJson);
		System.out.println("file path=" + f.getAbsolutePath());

		String path = f.getAbsolutePath().replace('\\', '/');

		// String kpiJson = FileUtils.readFileToString(new
		// java.io.File("src/main/resources/payloadsEventHub/finale2eScenarios/kpi_e2e.json"));
		String kpiJson_1 = FileUtils.readFileToString(new File(path));
		System.out.println("kpijson2=" + kpiJson_1);



		MultiValueMap<String, Object> parameters = new LinkedMultiValueMap<String, Object>();
		//parameters.add("uploadfile", new FileSystemResource(analyticFile));

		parameters.add("kpi", new ObjectMapper().readValue(kpiJson_1, KpiDetails.class));
		String expiredToken = generateFile("src/main/resources/data/"+getSysProperty("envType")+"/expired_token.json", "kpi_e2e");
		System.out.println("expiredToken=" + expiredToken);
		File f1 = new File(expiredToken);
		System.out.println("file path=" + f1.getAbsolutePath());
		String path1 = f1.getAbsolutePath().replace('\\', '/');
		String expiredToken_1 = FileUtils.readFileToString(new File(path1));
		System.out.println("expiredToken_1=" + expiredToken_1);
		HttpHeaders headers = new HttpHeaders();
		headers=ooTestutil.kpiprovideHeaders_3(getTestProperty("tenantUUID"),  expiredToken_1);
		

		RestTemplate restTemplate = new TestRestTemplate();
		ResponseEntity<Map> response=null;
		//try{
			/*HttpHost proxy = new HttpHost(getTestProperty("httpProxy"),new Integer(getTestProperty("portNumber")).intValue());
		       
	        
	        HttpComponentsClientHttpRequestFactory h=new   HttpComponentsClientHttpRequestFactory();
	       
	        DefaultProxyRoutePlanner routePlanner = new DefaultProxyRoutePlanner(proxy);
	        CloseableHttpClient httpclient = HttpClients.custom()
	                            .setRoutePlanner(routePlanner)
	                            .build();*/
		response= restTemplate.exchange(uri, HttpMethod.POST,
				new HttpEntity<MultiValueMap<String, Object>>(parameters, headers),
				Map.class);
		System.out.println("response expired token ="+ response.getBody());
		Assert.assertEquals(response.getStatusCode().value(), 401, "Not valid error response for creating kpi");
		/*}catch(HttpClientErrorException e )
			{
				System.out.println(e.getStatusCode());
			      System.out.println(e.getResponseBodyAsString());
			      Assert.assertEquals(e.getStatusCode().value(), 401, "Not valid error response for creating kpi");
			}*/
		 

		System.out.println("~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~");


	}
	/********************************************************************************************************************/
	//@Test(priority = 9, description = "testCreateKpiErrorValidationDifferentUAAToken")
	public void testCreateKpiErrorValidationDifferentUAAToken() throws Exception {

		System.out.println("~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~");

		final String uri = getTestProperty("kpi_url");

		setSysProperty("setKpiName", "kpiname" + ooTestutil.generateRandomNumber());
		setSysProperty("tenant", getTestProperty("tenantUUID"));
		String kpiFile = "src/main/resources/payloadsEventHub/kpi_templates/kpi_e2e.json";
		String kpiJson = generateFile(kpiFile, "kpi_e2e");
		System.out.println("kpijson1=" + kpiJson);
		File f = new File(kpiJson);
		System.out.println("file path=" + f.getAbsolutePath());

		String path = f.getAbsolutePath().replace('\\', '/');

		// String kpiJson = FileUtils.readFileToString(new
		// java.io.File("src/main/resources/payloadsEventHub/finale2eScenarios/kpi_e2e.json"));
		String kpiJson_1 = FileUtils.readFileToString(new File(path));
		System.out.println("kpijson2=" + kpiJson_1);

		File analyticFile =
				new java.io.File("src/main/resources/payloadsEventHub/kpi_analytics/kpi_analytic_asset_ts_int.zip");

		MultiValueMap<String, Object> parameters = new LinkedMultiValueMap<String, Object>();
		parameters.add("uploadfile", new FileSystemResource(analyticFile));
		parameters.add("kpi", new ObjectMapper().readValue(kpiJson_1, KpiDetails.class));
		HttpHeaders headers = new HttpHeaders();
		headers=ooTestutil.kpiprovideHeaders_3(getTestProperty("another_tenantUUID"),  getToken("another_uaa_url", "another_grant_type", "another_username", "another_password", "another_clientId", "another_clientSecret"));

		System.out.println("headers="+ headers);

		RestTemplate restTemplate = new TestRestTemplate();
		ResponseEntity<Map> response=null;
		//try{
		response= restTemplate.exchange(uri, HttpMethod.POST,
				new HttpEntity<MultiValueMap<String, Object>>(parameters, headers),
				Map.class);
		System.out.println("response expired token ="+ response.getBody());
		Assert.assertEquals(response.getStatusCode().value(), 403, "Not valid error response for creating kpi");
		/*}catch(HttpClientErrorException e )
			{
				System.out.println(e.getStatusCode());
			      System.out.println(e.getResponseBodyAsString());
			      Assert.assertEquals(e.getStatusCode().value(), 401, "Not valid error response for creating kpi");
			}
		 */
		System.out.println("~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~");
	}

	/********************************************************************************************************************/
	//@Test(priority = 9, description = "testCreateKPIJobHappyPath")
	public void testCreateKPIJobHappyPath() throws Exception {

		System.out.println("~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~");
		final String uri = getTestProperty("kpi_url");
		

		//create kpi template
		ResponseEntity<KpiDetails> response = ooTestutil.getResponseFromcreateKpiTemplate(path + "/kpi_templates/kpiTemplate_2.json",
				path + "/kpi_analytics/simpleJavaAnalytic_cf1_14.zip");
	

		KpiDetails kpiDetails = response.getBody();
		// System.out.println("+++ response.asString() == " + response.toString());
		long kpi_id = kpiDetails.getId();
		System.out.println("------------->" + kpiDetails.getId());
		Response jobResponse=ooTestutil.getResponseFroCreateKpiJob(path + "/kpi_jobs/kpiJob_5.json", kpi_id);
		JobDetails jd=new ObjectMapper().readValue(jobResponse.asString(), JobDetails.class);

		long kpiJobId = jd.getId();
		System.out.println("+++ kpiJobId== " + kpiJobId);
		Assert.assertNotNull(kpiJobId);
		Assert.assertNotEquals(jd.getKpiReferenceId(),"","KPI reference id is missing");
		Assert.assertNotEquals(jd.getInputs().size(),0,"KPI inputs are missing");
		Assert.assertNotEquals(jd.getOutputs().size(),0,"KPI outputs are missing");
		isEqual("Not valid response create KPI Job", 201, jobResponse.statusCode());

		// delete kpi job
		ooTestutil.deleteKpiJob(String.valueOf(kpiJobId));
		Response delete_response = deleteServiceResponse("kpi_url" + "/" + kpi_id, values,
						ooTestutil.kpiprovideHeaders());
		delete_response = deleteServiceResponse("kpi_url" + "/" + kpi_id, values,
				ooTestutil.kpiprovideHeaders());
		System.out.println("+++ delete_response.asString() == " + delete_response.asString());
		System.out.println("~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~");
	}

	@DataProvider(name = "test2")
	public Object[][] createKPIJobJsons() {
		return new Object[][] {

			//{ "src/main/resources/payloadsEventHub/kpi_jobs/kpi_jobs_negative/create_job_aplhanumeric_kpiid.json" },
			//{ "src/main/resources/payloadsEventHub/kpi_jobs/kpi_jobs_negative/create_job_empty_fields.json"},
			{ "src/main/resources/payloadsEventHub/kpi_jobs/kpi_jobs_negative/create_job_empty_json.json"},
			//{ "src/main/resources/payloadsEventHub/kpi_jobs/kpi_jobs_negative/create_job_input_with_no_read_capability.json"},
			{ "src/main/resources/payloadsEventHub/kpi_jobs/kpi_jobs_negative/create_job_no_input_provider.json"},
			{ "src/main/resources/payloadsEventHub/kpi_jobs/kpi_jobs_negative/create_job_no_output_provider.json"},
			//{ "src/main/resources/payloadsEventHub/kpi_jobs/kpi_jobs_negative/create_job_non_existing_input_provider.json"},
			//{ "src/main/resources/payloadsEventHub/kpi_jobs/kpi_jobs_negative/create_job_non_existing_output_provider.json"},
			//{ "src/main/resources/payloadsEventHub/kpi_jobs/kpi_jobs_negative/create_job_non_existing_kpi_id.json"},
			//{ "src/main/resources/payloadsEventHub/kpi_jobs/kpi_jobs_negative/create_job_output_with_no_write_capability.json"},
			//{ "src/main/resources/payloadsEventHub/kpi_jobs/kpi_jobs_negative/create_job_special_chars_kpi_id.json"},
			{ "src/main/resources/payloadsEventHub/kpi_jobs/kpi_jobs_negative/create_job_missing_kpiid_field.json"}

		};
	}
	/********************************************************************************************************************/
	@Test(priority = 9, description = "testCreateKPIJobJsonValidations",dataProvider = "createKPIJobJsons")
	@RallyInfo(UserStory ="US223441")
	public void testCreateKPIJobJsonValidations(String jobStr) throws Exception {

		System.out.println("~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~");
		System.out.println("job file="+jobStr);
		final String uri = getTestProperty("kpi_url");

		//setSysProperty("kpiId", "");

		if(getSysProperty("kpiId")==null)
		{
			//create kpi template
			ResponseEntity<KpiDetails> response = ooTestutil.getResponseFromcreateKpiTemplate("src/main/resources/payloadsEventHub/kpi_templates/kpi_e2e.json", 
					"src/main/resources/payloadsEventHub/kpi_analytics/kpi_analytic_asset_ts_int.zip");

			KpiDetails kpiDetails = response.getBody();
			// System.out.println("+++ response.asString() == " + response.toString());
			long kpi_id = kpiDetails.getId();
			setSysProperty("kpiId", new Long(kpi_id).toString());
			setSysProperty("tenant", getTestProperty("tenantUUID"));
			System.out.println("------------->" + kpiDetails.getId());
		}

		Response jobResponse=ooTestutil.getResponseFroCreateKpiJob(jobStr, new Long(getSysProperty("kpiId")).longValue());

		System.out.println("job file="+jobStr);
		System.out.println("job response="+ jobResponse.asString());
		System.out.println(" response status="+ jobResponse.getStatusCode());

		Assert.assertEquals(jobResponse.getStatusCode(), 400, "Not valid error response for creating job");

		System.out.println("~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~");
	}

	/********************************************************************************************************************/
	@Test(priority = 9, description = "testCreateKpiJobErrorValidationDifferentSchemaJson")
	@RallyInfo(UserStory ="US223441")
	public void testCreateKpiJobErrorValidationDifferentSchemaJson() throws Exception {

		System.out.println("~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~");

		ResponseEntity<KpiDetails> response = ooTestutil.getResponseFromcreateKpiTemplate("src/main/resources/payloadsEventHub/kpi_templates/kpi_e2e.json", 
				"src/main/resources/payloadsEventHub/kpi_analytics/kpi_analytic_asset_ts_int.zip");

		KpiDetails kpiDetails = response.getBody();
		// System.out.println("+++ response.asString() == " + response.toString());
		long kpi_id = kpiDetails.getId();
		setSysProperty("kpiId", new Long(kpi_id).toString());
		System.out.println("------------->" + kpiDetails.getId());

		
		setSysProperty("kpiReferenceId", String.valueOf(kpi_id));
		setSysProperty("tenant", getTestProperty("tenantUUID"));

		String kpijobFile = "src/main/resources/payloadsEventHub/data_files/data_ingestion_attributes.json";
		String kpijobJson = generateFile(kpijobFile, "kpi_job_e2e");
		System.out.println("+++ kpijobJson== " + kpijobJson);
		Response response1 = postServiceResponse(kpijobJson, "job_url", ooTestutil.kpiprovideHeaders());

		
		System.out.println("response="+ response1.getBody().asString());
		System.out.println("response="+ response1.getStatusCode());
		Assert.assertEquals(response1.getStatusCode(), 400, "Not valid error response for creating kpi");
		System.out.println("~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~");
	}


	/********************************************************************************************************************/
	//@Test(priority = 9, description = "testCreateJobErrorValidationNoToken")
	public void testCreateJobErrorValidationNoToken() throws Exception {

		System.out.println("~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~");
		

		ResponseEntity<KpiDetails> response = ooTestutil.getResponseFromcreateKpiTemplate("src/main/resources/payloadsEventHub/kpi_templates/kpi_e2e.json", 
				"src/main/resources/payloadsEventHub/kpi_analytics/kpi_analytic_asset_ts_int.zip");

		KpiDetails kpiDetails = response.getBody();
		// System.out.println("+++ response.asString() == " + response.toString());
		long kpi_id = kpiDetails.getId();
		setSysProperty("kpiId", new Long(kpi_id).toString());
		System.out.println("------------->" + kpiDetails.getId());

		
		setSysProperty("kpiReferenceId", String.valueOf(kpi_id));
		setSysProperty("tenant", getTestProperty("tenantUUID"));

		String kpijobFile = "src/main/resources/payloadsEventHub/kpi_jobs/kpi_e2e_job.json";
		String kpijobJson = generateFile(kpijobFile, "kpi_job_e2e");
		System.out.println("+++ kpijobJson== " + kpijobJson);
		Map<String, Object> headersMap = new LinkedHashMap<String, Object>();
		headersMap=ooTestutil.kpiprovideHeaders_4(getTestProperty("tenantUUID"),"Bearer ");
		
		Response response1 = postServiceResponse(kpijobJson, "job_url", headersMap);

		
		
		System.out.println("response="+ response1.asString());
		Assert.assertEquals(response1.getStatusCode(), 400, "Not valid error response for creating kpi");
		//isEqual("Not valid response for Start Job for Error validation Name field missing", 400,response.getStatusCode().value());
		System.out.println("~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~");
	}
	/********************************************************************************************************************/
	//@Test(priority = 9, description = "testCreateKpiErrorValidationExpiredToken")
	public void testCreateKpiJobErrorValidationExpiredToken() throws Exception {

		System.out.println("~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~");

		ResponseEntity<KpiDetails> response = ooTestutil.getResponseFromcreateKpiTemplate("src/main/resources/payloadsEventHub/kpi_templates/kpi_e2e.json", 
				"src/main/resources/payloadsEventHub/kpi_analytics/kpi_analytic_asset_ts_int.zip");

		KpiDetails kpiDetails = response.getBody();
		// System.out.println("+++ response.asString() == " + response.toString());
		long kpi_id = kpiDetails.getId();
		setSysProperty("kpiId", new Long(kpi_id).toString());
		System.out.println("------------->" + kpiDetails.getId());

		
		setSysProperty("kpiReferenceId", String.valueOf(kpi_id));
		setSysProperty("tenant", getTestProperty("tenantUUID"));

		String kpijobFile = "src/main/resources/payloadsEventHub/kpi_jobs/kpi_e2e_job.json";
		String kpijobJson = generateFile(kpijobFile, "kpi_job_e2e");
		System.out.println("+++ kpijobJson== " + kpijobJson);
		
		
		String expiredToken = generateFile("src/main/resources/payloadsEventHub/kpi_templates/kpi_templates_negative/expired_token.json", "kpi_e2e");
		System.out.println("expiredToken=" + expiredToken);
		File f1 = new File(expiredToken);
		System.out.println("file path=" + f1.getAbsolutePath());
		String path1 = f1.getAbsolutePath().replace('\\', '/');
		String expiredToken_1 = FileUtils.readFileToString(new File(path1));
		System.out.println("expiredToken_1=" + expiredToken_1);
		
		
		Map<String, Object> headersMap = new LinkedHashMap<String, Object>();
		headersMap=ooTestutil.kpiprovideHeaders_4(getTestProperty("tenantUUID"),expiredToken_1);
		
		Response response1 = postServiceResponse(kpijobJson, "job_url", headersMap);
		System.out.println("response expired token ="+ response1.asString());
		Assert.assertEquals(response1.getStatusCode(), 401, "Not valid error response for creating kpi");
		

		System.out.println("~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~");


	}
	/********************************************************************************************************************/
	//@Test(priority = 9, description = "testCreateKpiErrorValidationDifferentUAAToken")
	public void testCreateKpiJobErrorValidationDifferentUAAToken() throws Exception {

		System.out.println("~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~");
		ResponseEntity<KpiDetails> response = ooTestutil.getResponseFromcreateKpiTemplate("src/main/resources/payloadsEventHub/kpi_templates/kpi_e2e.json", 
				"src/main/resources/payloadsEventHub/kpi_analytics/kpi_analytic_asset_ts_int.zip");

		KpiDetails kpiDetails = response.getBody();
		// System.out.println("+++ response.asString() == " + response.toString());
		long kpi_id = kpiDetails.getId();
		setSysProperty("kpiId", new Long(kpi_id).toString());
		System.out.println("------------->" + kpiDetails.getId());

		
		setSysProperty("kpiReferenceId", String.valueOf(kpi_id));
		setSysProperty("tenant", getTestProperty("tenantUUID"));

		String kpijobFile = "src/main/resources/payloadsEventHub/kpi_jobs/kpi_e2e_job.json";
		String kpijobJson = generateFile(kpijobFile, "kpi_job_e2e");
		System.out.println("+++ kpijobJson== " + kpijobJson);
		Map<String, Object> headersMap = new LinkedHashMap<String, Object>();
		headersMap=ooTestutil.kpiprovideHeaders_4(getTestProperty("another_tenantUUID"),  getToken("another_uaa_url", "another_grant_type", "another_username", "another_password", "another_clientId", "another_clientSecret"));
		
		
		Response response1 = postServiceResponse(kpijobJson, "job_url", headersMap);
		System.out.println("response expired token ="+ response.getBody());
		Assert.assertEquals(response1.getStatusCode(), 403, "Not valid error response for creating kpi");
		System.out.println("~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~");
	}


}

package com.ge.automation.OO;

import com.ge.microtester.common.utils.RestAssuredUtil;
import com.ge.microtester.rally.RallyInfo;
import com.jayway.restassured.response.Response;
import org.springframework.boot.test.TestRestTemplate;
import org.springframework.web.client.RestTemplate;
import org.testng.annotations.*;

import java.util.HashSet;
import java.util.LinkedHashMap;
import java.util.Map;
import java.util.Set;

@RallyInfo(ProjectName ="APM Super Optimo")
public class OOAuditTest extends RestAssuredUtil {


    String kpiJobId;
    long kpi_id;
    String path = "src/main/resources/payloadsAndromeda";
    OOTestUtil ooTestutil = new OOTestUtil();
    RestTemplate restTemplate = new TestRestTemplate();
    // Generating Query Params
    Map<String, Object> values = new LinkedHashMap<String, Object>();

    private final String VERIFICATION_KEY_ORIGINATOR = "Kpi-Management";
    private String verificationKeyUserName;

    @BeforeMethod
    public void beforeMethod() {
    }

    @AfterMethod
    public void afterMethod() {
    }

    @BeforeClass
    public void beforeClass() {

    }// end of beforeClass

    @AfterClass
    public void afterClass() {
    }

    @BeforeTest
    public void beforeTest() {
        verificationKeyUserName = getProperty("username")[0];
    }// end of beforeTest

    private String buildVerificationKey(String resource, String actionType, String description) {
        return ooTestutil.buildAuditPayloadVerificationKey(VERIFICATION_KEY_ORIGINATOR, resource, actionType,
            description, verificationKeyUserName);
    }

    @Test(priority = 1, description = "testAuditForKpiServices")
	@RallyInfo(UserStory ="US223441")
    public void testAuditForKpiServices() throws Exception {
        Set<String> verificationKeys = new HashSet<>();

        // ingest test data into apm time series
        String sourcetag = "OO_Tag_Temperature_ID16";
        String targettag = "OO_Tag_Temperature_ID17";

        long startDate = System.currentTimeMillis();

//         create kpi template
        kpi_id = ooTestutil.createKpiTemplate(path + "/kpi_templates/kpi_e2e_ooapmts_inputAndOutput_python.json",
                path + "/kpi_analytics/audit_analytic.zip");
        verificationKeys.add(buildVerificationKey("/kpis", "Create Template", "Attempted Template Creation"));
        verificationKeys.add(buildVerificationKey("/kpis", "Create Template", "Template Creation Successful"));
        Thread.sleep(10000);

        // create get template details
        getServiceResponse("kpi_url" + "/" + kpi_id, ooTestutil.kpiprovideHeaders());
        verificationKeys.add(buildVerificationKey("/kpis/" + kpi_id, "Filter KPI Details", "Attempted to filter KPI Details"));
        verificationKeys.add(buildVerificationKey("/kpis/" + kpi_id, "Filter KPI Details", "KPI Details Filter Successful "));

        // create kpi job
        kpiJobId = ooTestutil.createKpiJobWithNoRandomBothInputAndOutputTag(
                path + "/kpi_jobs/kpi_e2e_ooapmts_inputAndOutput_job_python.json", kpi_id, targettag, sourcetag, "");
        verificationKeys.add(buildVerificationKey("/job", "Create Job", "Attempted Job Creation"));
        verificationKeys.add(buildVerificationKey("/job", "Create Job", "Job Creation Successful"));
        Thread.sleep(10000);

        // start kpi job
        String runtimeJobId = ooTestutil.startKpiJob(kpiJobId);
        verificationKeys.add(buildVerificationKey("/job/manager/start/" + kpiJobId, "Start Job", "Attempted Job Start"));
        verificationKeys.add(buildVerificationKey("/job/manager/start/" + kpiJobId, "Start Job", "Job Start Successful "));
        Thread.sleep(30000);

        System.out.println("&&&&&&&&&&&--"+kpiJobId);

        // get job details
        ooTestutil.getListOfJobsForAKpiId(kpi_id);
        verificationKeys.add(buildVerificationKey("/kpis/" + kpi_id + "/jobs", "Access Job Details", "Attempted Access Job Details"));
        verificationKeys.add(buildVerificationKey("/kpis/" + kpi_id + "/jobs", "Access Job Details", "Job Details Access Successful"));
        Thread.sleep(30000);

        getServiceResponse("kpi_url" + "/" + kpi_id+"/manager/jobs", ooTestutil.kpiprovideHeaders());
        verificationKeys.add(buildVerificationKey("/kpis/" + kpi_id + "/manager/jobs", "List Jobs by KpiRefecenceId", "Attempted  to list Jobs by KpiRefecenceId "));
        verificationKeys.add(buildVerificationKey("/kpis/" + kpi_id + "/manager/jobs", "List Jobs by KpiRefecenceId", " List jobs by KpiRefecenceId Successful"));
        Thread.sleep(10000);

        //stop job
        postServiceResponse("stop_job_url" + "/" + kpiJobId, ooTestutil.kpiprovideHeaders());
        verificationKeys.add(buildVerificationKey("/job/manager/stop/" + kpiJobId, "Stop Job", "Attempted Job Stop"));
        verificationKeys.add(buildVerificationKey("/job/manager/stop/" + kpiJobId, "Stop Job", "Job Stop Successful "));
//       delete kpi job
        Thread.sleep(10000);

        ooTestutil.deleteKpiJob(kpiJobId);
        verificationKeys.add(buildVerificationKey("/job/" + kpiJobId, "Delete Job", "Attempted Job Deletion"));
        verificationKeys.add(buildVerificationKey("/job/" + kpiJobId, "Delete Job", "Job Deletion Successful"));
        Thread.sleep(10000);


        // DELETE KPI template
        deleteServiceResponse("kpi_url" + "/" + kpi_id, values, ooTestutil.kpiprovideHeaders());
        verificationKeys.add(buildVerificationKey("/kpis/" + kpi_id, "Delete Template", "Attempted Template Deletion"));
        verificationKeys.add(buildVerificationKey("/kpis/" + kpi_id, "Delete Template", "Template Deletion Successful"));

        ooTestutil.printnewLine();

        System.out.println("verification keys - \n");
        verificationKeys.stream().forEach(s -> System.out.println(s));

        long endDate = System.currentTimeMillis()+ (4*60*1000)+(30*1000);
        Thread.sleep(10000);
        ooTestutil.queryAudit(startDate,endDate, verificationKeys);

        //ooTestutil.verifyAuditDetails(kpi_id,kpiJobId,response.asString());

    }


    /********************************************************************************************************************/
    @AfterTest
    public void afterTest() {
    }

    @BeforeSuite
    public void beforeSuite() {

    }

    @AfterSuite
    public void afterSuite() {
    }
}

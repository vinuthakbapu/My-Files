package com.ge.automation.OO.metaDataTest;

import com.ge.microtester.rally.RallyInfo;
import com.google.gson.Gson;
import com.jayway.restassured.path.json.JsonPath;
import com.jayway.restassured.response.Response;
import org.testng.annotations.AfterClass;
import org.testng.annotations.Test;

import java.io.IOException;
import java.net.URISyntaxException;
import java.util.Map;


//@RallyInfo(ProjectName = "APM OPM India", FolderPath = "2018_Q1/Backend Tests")
public class OOMedataDataServiceTest extends BaseTest {

    @Test(priority = 1, description = "testGetMasterConfigWithoutLanguage")
    @RallyInfo(UserStory = "US209724")
    public void testGetMasterConfigWithoutLanguage() throws Exception {

        Response metaData = metaDataTestUtil.getConfig("master",getTestProperty("meta_data_app"),getTestProperty("view_meta_data_feature"),200);
        metaDataAssertion.verifyConfig("master", metaData, path + "/meta_data/geo_meta_data.json",path + "/meta_data/view_geo_config.json");
    }


    @Test(priority = 1, description = "testGetMasterConfigOfParticularVersion")
    @RallyInfo(UserStory = "US209724")
    public void testGetMasterConfigOfParticularVersion() throws Exception {

        Response metaData = metaDataTestUtil.getMasterConfigOfParticularVersion("master",getTestProperty("meta_data_app"),getTestProperty("view_meta_data_feature"),200,1);
        metaDataAssertion.verifyConfig("master", metaData, path + "/meta_data/geo_meta_data.json",path + "/meta_data/view_geo_config.json",1);
    }


    @Test(priority = 1, description = "testGetMasterConfigWithNonExistingLanguage")
    @RallyInfo(UserStory = "US209724")
    public void testGetMasterConfigWithNonExistingLanguage() throws Exception {
        Response metaData = metaDataTestUtil.getConfig("master",getTestProperty("meta_data_app"),getTestProperty("view_meta_data_feature"), 200,"fr_FR");
        JsonPath jsonPathMetaData = new JsonPath(metaData.getBody().asString());
        metaDataAssertion.verifyMasterConfigIsEmpty(jsonPathMetaData.getList("."));
    }


    @Test(priority = 1, description = "testGetMasterConfigWithNonExistingAppAndFeature")
    @RallyInfo(UserStory = "US209724")
    public void testGetMasterConfigWithNonExistingAppAndFeature() throws Exception {

        Response metaData = metaDataTestUtil.getConfig("meta_data_app", "view_meta_data_feature", "en_US",403);
    }

    @Test(priority = 1, description = "testGetMasterConfigWithLanguage")
    @RallyInfo(UserStory = "US209724")
    public void testGetMasterConfigWithLanguage() throws Exception {

        Response metaData = metaDataTestUtil.getConfig("master",getTestProperty("meta_data_app"), getTestProperty("view_meta_data_feature"), 200,"en_US");
        metaDataAssertion.verifyConfig("master",metaData, path + "/meta_data/geo_meta_data.json",path + "/meta_data/view_geo_config.json");
    }


    @Test(priority = 1, description = "testGetTenantConfigWithoutLanguage")
    @RallyInfo(UserStory = "US209724")
    public void testGetTenantConfigWithoutLanguage() throws Exception {

        Response metaData = metaDataTestUtil.getConfig("tenant", getTestProperty("meta_data_app"),getTestProperty("view_meta_data_feature"),200);
        metaDataAssertion.verifyConfig("tenant",metaData, path + "/meta_data/geo_meta_data.json",path + "/meta_data/view_geo_config.json");
    }

    @Test(priority = 1, description = "testGetTenantConfigWithNonExistingLanguage")
    @RallyInfo(UserStory = "US209724")
    public void testGetTenantConfigWithNonExistingLanguage() throws Exception {

        Response metaData = metaDataTestUtil.getConfig("tenant", getTestProperty("meta_data_app"),getTestProperty("view_meta_data_feature"), 200,"fr_FR");
        metaDataAssertion.verifyTenantConfigIsEmpty(metaData.asString());
    }


    @Test(priority = 1, description = "testGetTenantConfigWithNonExistingAppAndFeature")
    @RallyInfo(UserStory = "US209724")
    public void testGetTenantConfigWithNonExistingAppAndFeature() throws Exception {

        Response metaData = metaDataTestUtil.getConfig("tenant","meta_data_app", "view_meta_data_feature", 200,"en_US");
        metaDataAssertion.verifyTenantConfigIsEmpty(metaData.asString());
    }


    @Test(priority = 1, description = "testGetTenantConfigWithLanguage")
    @RallyInfo(UserStory = "US209724")
    public void testGetTenantConfigWithLanguage() throws Exception {

        Response metaData = metaDataTestUtil.getConfig("tenant",getTestProperty("meta_data_app"), getTestProperty("view_meta_data_feature"),200, "en_US");
        metaDataAssertion.verifyConfig("tenant",metaData, path + "/meta_data/geo_meta_data.json",path + "/meta_data/view_geo_config.json");
    }


    @Test(priority = 1, description = "testUpdateTenantConfigWithLanguage")
    @RallyInfo(UserStory = "US209724")
    public void testUpdateTenantConfigWithLanguage() throws Exception {

        Response metaData = metaDataTestUtil.getConfig("tenant", getTestProperty("meta_data_app"), getTestProperty("view_meta_data_feature"), 200,"en_US");
        metaDataAssertion.verifyConfig("tenant",metaData, path + "/meta_data/geo_meta_data.json",path + "/meta_data/view_geo_config.json");

        Response updateMetaData = metaDataTestUtil.updateMetaData(metaData, path + "/meta_data/update_meta_data_payload.json", "15 minutes");
        metaDataAssertion.verifyUpdateMetaData(updateMetaData, path + "/meta_data/updated_meta_data.json",path + "/meta_data/updated_view_geo_config.json");

    }


    @Test(priority = 1, description = "testCreateTenantConfig")
    @RallyInfo(UserStory = "US209724")
    public void testCreateTenantConfig() throws Exception {

        Response metaData = metaDataTestUtil.getConfig("tenant", getTestProperty("meta_data_app"),getTestProperty("view_meta_data_feature"),200);

        if(metaData.asString().length()==0){
                metaDataTestUtil.createTenantConfig(path+"/meta_data/create_meta_data_payload.json",200);
        }else{
            metaDataTestUtil.createTenantConfig(path+"/meta_data/create_meta_data_payload.json",500);
        }

    }



}

package com.ge.automation.OO;

import com.ge.automation.OO.dto.KpiDetails;
import com.ge.microtester.common.utils.RestAssuredUtil;
import com.ge.microtester.rally.RallyInfo;

import com.fasterxml.jackson.databind.ObjectMapper;
import com.jayway.restassured.path.json.JsonPath;
import com.jayway.restassured.response.Response;

import org.apache.commons.io.FileUtils;
import org.springframework.boot.test.TestRestTemplate;
import org.springframework.core.io.FileSystemResource;
import org.springframework.http.HttpEntity;
import org.springframework.http.HttpMethod;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.util.LinkedMultiValueMap;
import org.springframework.util.MultiValueMap;
import org.springframework.web.client.RestTemplate;
import org.testng.Assert;
import org.testng.annotations.AfterClass;
import org.testng.annotations.AfterMethod;
import org.testng.annotations.AfterSuite;
import org.testng.annotations.AfterTest;
import org.testng.annotations.BeforeClass;
import org.testng.annotations.BeforeMethod;
import org.testng.annotations.BeforeSuite;
import org.testng.annotations.BeforeTest;
import org.testng.annotations.Test;

import java.io.File;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;
import java.util.Properties;

@RallyInfo(ProjectName = "Operations Optimization Execution", FolderPath = "OO/Q3Release")
public class OOe2eScenarios extends RestAssuredUtil {

	private String oouaa_token;
	private String idTenant;
	static String jsonfileName;
	Properties configFile = new Properties();
	String truncateDateTime[];
	String tagName;
	String proxyHost;
	String proxyPort;
	Response responseBody;
	String kpiid;
	String kpiJobId;
	String dataSourceId;
	long kpi_id;
	long kpi_id1;

	public OOTestUtil ooTestutil = new OOTestUtil();
	RestTemplate restTemplate = new TestRestTemplate();
	// Generating Query Params
	Map<String, Object> values = new LinkedHashMap<String, Object>();

	@BeforeMethod
	public void beforeMethod() {}

	@AfterMethod
	public void afterMethod() {}

	@BeforeClass
	public void beforeClass() {

		System.getProperties().put("proxySet", "true");
		System.getProperties().put("http.proxyHost", "sjc1intproxy01.crd.ge.com");
		System.getProperties().put("http.proxyPort", "8080");
		System.getProperties().put("https.proxyHost", "sjc1intproxy01.crd.ge.com");
		System.getProperties().put("https.proxyPort", "8080");
		getServiceResponse("alert_profile_base_url");
		setSysProperty("currentTimeStamp", "" + getCurrentTimestamp());// ${sys:currentTimeStamp}

	}// end of beforeClass

	@AfterClass
	public void afterClass() {}

	@BeforeTest
	public void beforeTest() {

	}// end of beforeTest



	/********************************************************************************************************************/
	@Test(priority = 1, description = "testEnd2EndScenariosAssetTsDataProviders")
	@RallyInfo(UserStory = "US28339")
	public void testEnd2EndScenariosAssetTsDataProviders() throws Exception {

		ooTestutil.printnewLine();

		// Input tags:OO_Tag_Temperature_ID281
		// Output tags:OO_Tag_Temperature_Demo

		System.out.println("*****************Create KPI TEMPLATE*******************");
		ooTestutil.printnewLine();


		final String uri = getTestProperty("kpi_url");

		setSysProperty("setKpiName", "kpiname" + ooTestutil.generateRandomNumber());
		String kpiFile = "src/main/resources/payloads/kpi_templates/kpi_e2e.json";
		String kpiJson = generateFile(kpiFile, "kpi_e2e");

		File f = new File(kpiJson);
		System.out.println("file path=" + f.getAbsolutePath());

		String path = f.getAbsolutePath().replace('\\', '/');

		// String kpiJson = FileUtils.readFileToString(new
		// java.io.File("src/main/resources/payloads/finale2eScenarios/kpi_e2e.json"));
		String kpiJson_1 = FileUtils.readFileToString(new File(path));
		File analyticFile =
				new java.io.File("src/main/resources/payloads/kpi_analytics/kpi_analytic_asset_ts_int.zip");

		MultiValueMap<String, Object> parameters = new LinkedMultiValueMap<String, Object>();
		parameters.add("uploadfile", new FileSystemResource(analyticFile));
		parameters.add("kpi", new ObjectMapper().readValue(kpiJson_1, KpiDetails.class));

		ResponseEntity<KpiDetails> response = restTemplate.exchange(uri, HttpMethod.POST,
				new HttpEntity<MultiValueMap<String, Object>>(parameters, ooTestutil.kpiprovideHeaders_1()),
				KpiDetails.class);

		Assert.assertEquals(response.getStatusCode(), HttpStatus.CREATED);
		Assert.assertTrue(response.getBody() instanceof KpiDetails);
		KpiDetails kpiDetails = response.getBody();
		// System.out.println("+++ response.asString() == " + response.toString());
		kpi_id = kpiDetails.getId();
		System.out.println("------------->" + kpiDetails.getId());

		// *****************Create KPI JOB***************************************************//

		ooTestutil.printnewLine();
		System.out.println("*****************Create KPI JOB*******************");
		ooTestutil.printnewLine();

		setSysProperty("kpiReferenceId", String.valueOf(kpi_id));

		String kpijobFile = "src/main/resources/payloads/kpi_jobs/kpi_e2e_job.json";
		String kpijobJson = generateFile(kpijobFile, "kpi_job_e2e");
		System.out.println("+++ kpijobJson== " + kpijobJson);
		Response response1 = postServiceResponse(kpijobJson, "job_url", ooTestutil.kpiprovideHeaders());

		// System.out.println("+++ response.asString() == " +
		// response1.asString());
		JsonPath jsonPath = new JsonPath(response1.asString());
		kpiJobId = jsonPath.getString("id");
		System.out.println("+++ kpiJobId== " + kpiJobId);
		isEqual("Not valid response create KPI Job", 201, response1.statusCode());

		// *****************START JOB***************************************************//
		ooTestutil.printnewLine();
		System.out.println("*****************START KPI JOB*******************");
		ooTestutil.printnewLine();

		Response response2 = getServiceResponse("start_job_url" + "/" + kpiJobId, ooTestutil.kpiprovideHeaders_2());
		isEqual("Not valid response for Start Job", 200, response2.statusCode());

		// System.out.println("+++ response2.asString() == " + response2.asString());
		JsonPath jsonPath1 = new JsonPath(response2.asString());
		String runtimeJobId = jsonPath1.getString("runtimeJobId");
		System.out.println("+++runtimeJobId== " + runtimeJobId);
		ooTestutil.printnewLine();


		Thread.sleep(30000);



		// *****************Status of JOB***************************************************//
		ooTestutil.printnewLine();
		System.out.println("*****************Status of JOB********************");
		ooTestutil.printnewLine();

		Response response_status = getServiceResponse("status_of_job_url" + "/" + kpiJobId, ooTestutil.kpiprovideHeaders_2());
		isEqual("Not valid response for Start Job", 200, response_status.statusCode());

		// System.out.println("+++ response2.asString() == " + response2.asString());
		JsonPath jsonPath_status = new JsonPath(response_status.asString());
		String status = jsonPath_status.getString("status");
		String message = jsonPath_status.getString("message");
		String jobId = jsonPath_status.getString("jobId");
		String runtimeJobId_status = jsonPath_status.getString("runtimeJobId");

		System.out.println("+++status== " + status);
		System.out.println("+++message== " + message);
		System.out.println("+++jobId== " + jobId);
		System.out.println("+++runtimeJobId_status== " + runtimeJobId_status);
		ooTestutil.printnewLine();


		Thread.sleep(30000);

		if(status.equalsIgnoreCase("Running"))
		{

			// ****************Post data point to Kafka Topic*************************************************//

			ooTestutil.printnewLine();
			System.out.println("*****************POST DATA TO KAFKA TOPIC******************");
			ooTestutil.printnewLine();

			String dataingestionFile = "src/main/resources/payloads/data_files/data_ingestion.json";
			Response response_producer =
					postServiceResponse(dataingestionFile, "kafka_producer_url", ooTestutil.kpiprovideHeaders());

			// System.out.println("+++ response_producer.asString() == " + response_producer.asString());

			System.out.println("+++ string of timestamp == "
					+ com.jayway.jsonpath.JsonPath.read(response_producer.asString(), "$..datapoints[*][0]"));

			List<String> timestamp_producedData =
					com.jayway.jsonpath.JsonPath.read(response_producer.asString(), "$..datapoints[*][0]");
			List<String> value_producedData =
					com.jayway.jsonpath.JsonPath.read(response_producer.asString(), "$..datapoints[*][1]");

			System.out.println("+++timestamp_ingestedData== " + String.valueOf(timestamp_producedData.get(0)));
			System.out.println("+++value_producedData== " + String.valueOf(value_producedData.get(0)));
			isEqual("Data not Posted to Kafka Topic", 200, response_producer.getStatusCode());

			Thread.sleep(30000);

			// ***************Get data point from Kafka Topic*************************************************//
			ooTestutil.printnewLine();
			System.out.println("*****************GET DATA FROM KAFKA TOPIC******************");
			ooTestutil.printnewLine();
			Response response_consumer = getServiceResponse("kafka_consumer_url", ooTestutil.kpiprovideHeaders());
			// System.out.println("+++ response_consumer.asString() == " + response_consumer.asString());

			isEqual("Data not retrieved from Kafka topic", 200, response_consumer.statusCode());

			System.out.println("+++ string of timestamp == "
					+ com.jayway.jsonpath.JsonPath.read(response_consumer.asString(), "$..datapoints[*][0]"));

			List<String> timestamp_consumerData =
					com.jayway.jsonpath.JsonPath.read(response_consumer.asString(), "$..datapoints[*][0]");
			System.out.println("+++timestamp_ingestedData== " + String.valueOf(timestamp_consumerData.get(0)));

			List<String> value_consumerData =
					com.jayway.jsonpath.JsonPath.read(response_consumer.asString(), "$..datapoints[*][1]");
			System.out.println("+++value_consumerData== " + String.valueOf(value_consumerData.get(0)));

			// ****************Assert input and output data points *************************************************//
			Thread.sleep(30000);
			isEqual("Raw data point was not calculated", String.valueOf(timestamp_producedData.get(0)),
					String.valueOf(timestamp_consumerData.get(0)));
			if (String.valueOf(value_producedData.get(0)) != null && String.valueOf(value_consumerData.get(0)) != null) {
				Double value_ingested = Double.parseDouble(String.valueOf(value_producedData.get(0)));
				Double value_consumed = Double.parseDouble(String.valueOf(value_consumerData.get(0)));
				// Assert.assertTrue(!value_ingested.equals(value_consumed),
				// "Raw data point was not calculated--> raw and calculated data points-->"
				// +value_ingested+" "+value_consumed);
				isEqual("Raw data point was not calculated", 2009.99, value_consumed);
			}

			// ****************Stop the Job*************************************************//

	/*		Thread.sleep(30000);
			ooTestutil.printnewLine();
			System.out.println("*****************STOP KPI JOB*******************");
			ooTestutil.printnewLine();

			Response response3 = getServiceResponse("stop_job_url" + "/" + kpiJobId, ooTestutil.kpiprovideHeaders_2());
			isEqual("Not valid response for Start Job", 200, response3.statusCode());

			// System.out.println("+++ response3.asString() == " + response3.asString());
			isEqual("KPI JOB not killed", true, response3.asString().contains("KILLED"));
			isEqual("KPI JOB not killed", 200, response3.statusCode());

			// {"status":"KILLED","message":null,"jobId":"149","runtimeJobId":"78caf8a9-671f-48c8-bb17-3757735a77a1"}

			ooTestutil.printnewLine();*/

			// **********************************************************************************//


		/*		ooTestutil.printnewLine();
			System.out.println("*****************DELETE KPI*******************");
			ooTestutil.printnewLine();

			System.out.println("+++ kpiDeleteUrl == " + uri);
			response1 = deleteServiceResponse("kpi_url" + "/" + kpi_id, ooTestutil.kpiprovideHeaders());
			// System.out.println("+++ response.asString() == " + response1.asString());
			isEqual("Not valid response for Delete Kpi", 200, response1.statusCode());

			ooTestutil.printnewLine();
			Thread.sleep(30000);*/
			
			ooTestutil.printnewLine();
			System.out.println("*****************DELETE KPI JOB*******************");
			ooTestutil.printnewLine();

			System.out.println("+++ kpiDeleteUrl == " + uri);
			response1 = deleteServiceResponse("job_url" + "/" + kpiJobId, ooTestutil.kpiprovideHeaders());
			/*KNOWN BUG--> DELETE JOB NOT WORKING CONSISTENTLY*/
			//isEqual("Not valid response for Delete Kpi", 200, response1.statusCode());
			//isEqual("KPI JOB not killed", true, response1.asString().contains("KPI Job with Id "+kpiJobId+" is marked for deletion. Please check job status"));
			

			ooTestutil.printnewLine();
			Thread.sleep(60000);

			// *****************Status of JOB***************************************************//
			ooTestutil.printnewLine();
			System.out.println("*****************Status of JOB after Delete Job********************");
			ooTestutil.printnewLine();

			Response response_job = getServiceResponse("status_of_job_url" + "/" + kpiJobId, ooTestutil.kpiprovideHeaders_2());
			/*KNOWN BUG--> DELETE JOB NOT WORKING CONSISTENTLY*/
			//isEqual("Not valid response for Start Job", 400, response_job.statusCode());

			// System.out.println("+++ response2.asString() == " + response2.asString());
			JsonPath jsonPath_job = new JsonPath(response_job.asString());
			String status_job = jsonPath_job.getString("status");
			String message_job = jsonPath_job.getString("message");
			String jobId_job = jsonPath_job.getString("jobId");
			String runtimeJobId_job = jsonPath_job.getString("runtimeJobId");

			System.out.println("After Delete Job +++status== " + status_job);
			System.out.println("After Delete Job +++message== " + message_job);
			System.out.println("After Delete Job +++jobId== " + jobId_job);
			System.out.println("After Delete Job +++runtimeJobId_status== " + runtimeJobId_job);
			ooTestutil.printnewLine();


			Thread.sleep(30000);
		}

		

	}

	/********************************************************************************************************************/

	@Test(priority = 2, description = "testEnd2EndScenarioTsProvider")
	@RallyInfo(UserStory = "US28339")
	public void testEnd2EndScenarioTsProvider() throws Exception {

		ooTestutil.printnewLine();

		// Input tags: OO_Tag_Temperature_ID281
		// Output tags:OO_Tag_Temperature_Demo_tsstream

		System.out.println("*****************Create KPI TEMPLATE*******************");
		ooTestutil.printnewLine();

		// *****************Create KPI TEMPLATE***************************************************//

		final String uri = getTestProperty("kpi_url");

		setSysProperty("setKpiName", "kpiname" + ooTestutil.generateRandomNumber());
		String kpiFile = "src/main/resources/payloads/kpi_templates/kpi_e2e_streamInput.json";
		String kpiJson = generateFile(kpiFile, "kpi_e2e");

		File f = new File(kpiJson);
		System.out.println("file path=" + f.getAbsolutePath());

		String path = f.getAbsolutePath().replace('\\', '/');

		// String kpiJson = FileUtils.readFileToString(new
		// java.io.File("src/main/resources/payloads/finale2eScenarios/kpi_e2e.json"));
		String kpiJson_1 = FileUtils.readFileToString(new File(path));
		File analyticFile = new java.io.File("src/main/resources/payloads/kpi_analytics/analytic_tsstream.zip");

		MultiValueMap<String, Object> parameters = new LinkedMultiValueMap<String, Object>();
		parameters.add("uploadfile", new FileSystemResource(analyticFile));
		parameters.add("kpi", new ObjectMapper().readValue(kpiJson_1, KpiDetails.class));

		ResponseEntity<KpiDetails> response = restTemplate.exchange(uri, HttpMethod.POST,
				new HttpEntity<MultiValueMap<String, Object>>(parameters, ooTestutil.kpiprovideHeaders_1()),
				KpiDetails.class);

		Assert.assertEquals(response.getStatusCode(), HttpStatus.CREATED);
		Assert.assertTrue(response.getBody() instanceof KpiDetails);
		KpiDetails kpiDetails = response.getBody();
		kpi_id = kpiDetails.getId();
		System.out.println("------------->" + kpiDetails.getId());

		// *****************Create KPI JOB***************************************************//

		ooTestutil.printnewLine();
		System.out.println("*****************Create KPI JOB*******************");
		ooTestutil.printnewLine();

		setSysProperty("kpiReferenceId", String.valueOf(kpi_id));

		String kpijobFile = "src/main/resources/payloads/kpi_jobs/kpi_e2e_job_tsstream.json";
		String kpijobJson = generateFile(kpijobFile, "kpi_job_e2e");
		System.out.println("+++ kpijobJson== " + kpijobJson);
		Response response1 = postServiceResponse(kpijobJson, "job_url", ooTestutil.kpiprovideHeaders());

		// System.out.println("+++ response.asString() == " +
		// response1.asString());
		JsonPath jsonPath = new JsonPath(response1.asString());
		kpiJobId = jsonPath.getString("id");
		System.out.println("+++ kpiJobId== " + kpiJobId);
		isEqual("Not valid response create KPI Job", 201, response1.statusCode());

		// *****************START JOB***************************************************//
		ooTestutil.printnewLine();
		System.out.println("*****************START KPI JOB*******************");
		ooTestutil.printnewLine();

		
		Response response2 = getServiceResponse("start_job_url" + "/" + kpiJobId, ooTestutil.kpiprovideHeaders_2());
		isEqual("Not valid response for Start Job", 200, response2.statusCode());

	
		JsonPath jsonPath1 = new JsonPath(response2.asString());
		String runtimeJobId = jsonPath1.getString("runtimeJobId");
		System.out.println("+++runtimeJobId== " + runtimeJobId);
		ooTestutil.printnewLine();


		// *****************Status of JOB***************************************************//
		ooTestutil.printnewLine();
		System.out.println("*****************Status of JOB********************");
		ooTestutil.printnewLine();

		Response response_status = getServiceResponse("status_of_job_url" + "/" + kpiJobId, ooTestutil.kpiprovideHeaders_2());
		isEqual("Not valid response for Start Job", 200, response_status.statusCode());

		JsonPath jsonPath_status = new JsonPath(response_status.asString());
		String status = jsonPath_status.getString("status");
		String message = jsonPath_status.getString("message");
		String jobId = jsonPath_status.getString("jobId");
		String runtimeJobId_status = jsonPath_status.getString("runtimeJobId");

		System.out.println("+++status== " + status);
		System.out.println("+++message== " + message);
		System.out.println("+++jobId== " + jobId);
		System.out.println("+++runtimeJobId_status== " + runtimeJobId_status);
		ooTestutil.printnewLine();


		Thread.sleep(30000);

		if(status.equalsIgnoreCase("Running"))
		{

			// ****************Post data point to Kafka Topic*************************************************//

			ooTestutil.printnewLine();
			System.out.println("*****************POST DATA TO KAFKA TOPIC******************");
			ooTestutil.printnewLine();

			String dataingestionFile = "src/main/resources/payloads/data_files/data_ingestion_ts.json";
			Response response_producer =
					postServiceResponse(dataingestionFile, "kafka_producer_url", ooTestutil.kpiprovideHeaders());

	

			System.out.println("+++ string of timestamp == "
					+ com.jayway.jsonpath.JsonPath.read(response_producer.asString(), "$..datapoints[*][0]"));

			List<String> timestamp_producedData =
					com.jayway.jsonpath.JsonPath.read(response_producer.asString(), "$..datapoints[*][0]");
			List<String> value_producedData =
					com.jayway.jsonpath.JsonPath.read(response_producer.asString(), "$..datapoints[*][1]");

			System.out.println("+++timestamp_ingestedData== " + String.valueOf(timestamp_producedData.get(0)));
			isEqual("Data not Posted to Kafka Topic", 200, response_producer.getStatusCode());

			System.out.println("+++value_ingestedData== " + String.valueOf(value_producedData.get(0)));

			Thread.sleep(30000);

			// ***************Get data point from Kafka Topic*************************************************//
			ooTestutil.printnewLine();
			System.out.println("*****************GET DATA FROM KAFKA TOPIC******************");
			ooTestutil.printnewLine();
			Response response_consumer = getServiceResponse("kafka_consumer_url", ooTestutil.kpiprovideHeaders());
			// System.out.println("+++ response_consumer.asString() == " + response_consumer.asString());

			isEqual("Data not retrieved from Kafka topic", 200, response_consumer.statusCode());

			System.out.println("+++ string of timestamp == "
					+ com.jayway.jsonpath.JsonPath.read(response_consumer.asString(), "$..datapoints[*][0]"));

			List<String> timestamp_consumerData =
					com.jayway.jsonpath.JsonPath.read(response_consumer.asString(), "$..datapoints[*][0]");
			System.out.println("+++timestamp_ingestedData== " + String.valueOf(timestamp_consumerData.get(0)));

			List<String> value_consumerData =
					com.jayway.jsonpath.JsonPath.read(response_consumer.asString(), "$..datapoints[*][1]");
			System.out.println("+++value_consumerData== " + String.valueOf(value_consumerData.get(0)));

			// ****************Assert input and output data points *************************************************//

			Thread.sleep(30000);
			isEqual("Raw data point was not calculated", String.valueOf(timestamp_producedData.get(0)),
					String.valueOf(timestamp_consumerData.get(0)));
			if (String.valueOf(value_producedData.get(0)) != null && String.valueOf(value_consumerData.get(0)) != null) {
				Double value_ingested = Double.parseDouble(String.valueOf(value_producedData.get(0)));
				Double value_consumed = Double.parseDouble(String.valueOf(value_consumerData.get(0)));
				// Assert.assertTrue(!value_ingested.equals(value_consumed), "Raw data point was not calculated");
				isEqual("Raw data point was not calculated", 180.0303054118169, value_consumed);
			}

			// ****************Stop the Job*************************************************//

			/*Thread.sleep(30000);
			ooTestutil.printnewLine();
			System.out.println("*****************STOP KPI JOB*******************");
			ooTestutil.printnewLine();

			Response response3 = getServiceResponse("stop_job_url" + "/" + kpiJobId, ooTestutil.kpiprovideHeaders_2());
			isEqual("Not valid response for Start Job", 200, response3.statusCode());

			// System.out.println("+++ response2.asString() == " + response3.asString());
			isEqual("KPI JOB not killed", true, response3.asString().contains("KILLED"));
			isEqual("Not valid response create KPI Job", 200, response3.statusCode());

			ooTestutil.printnewLine();*/

			// *****************Delete KPI***************************************************//
/*
			ooTestutil.printnewLine();

			System.out.println("+++ kpiDeleteUrl == " + uri);
			response1 = deleteServiceResponse("kpi_url" + "/" + kpi_id, ooTestutil.kpiprovideHeaders());
			// System.out.println("+++ response.asString() == " + response1.asString());
			isEqual("Not valid response for Delete Kpi", 200, response1.statusCode());

			ooTestutil.printnewLine();*/
	
			
			
			System.out.println("*****************DELETE KPI JOB*******************");
			ooTestutil.printnewLine();

			System.out.println("+++ kpiDeleteUrl == " + uri);
			response1 = deleteServiceResponse("job_url" + "/" + kpiJobId, ooTestutil.kpiprovideHeaders());
			// System.out.println("+++ response.asString() == " + response1.asString());
			/*KNOWN BUG--> DELETE JOB NOT WORKING CONSISTENTLY*/
			//isEqual("Not valid response for Delete Kpi job", 200, response1.statusCode());
			//isEqual("KPI JOB not killed", true, response1.asString().contains("KPI Job with Id "+kpiJobId+" is marked for deletion. Please check job status"));


			ooTestutil.printnewLine();
			Thread.sleep(60000);

			// *****************Status of JOB after Delete Job***************************************************//
			ooTestutil.printnewLine();
			System.out.println("*****************Status of JOB after Delete Job********************");
			ooTestutil.printnewLine();

			Response response_job = getServiceResponse("status_of_job_url" + "/" + kpiJobId, ooTestutil.kpiprovideHeaders_2());
			/*KNOWN BUG--> DELETE JOB NOT WORKING CONSISTENTLY*/
			//isEqual("Not valid response for Status Job after delete", 400, response_job.statusCode());
            //isEqual("KPI JOB not Deleted", true, response_job.asString().contains("Job "+kpiJobId+" not found"));

	
			JsonPath jsonPath_job = new JsonPath(response_job.asString());
			String status_job = jsonPath_job.getString("status");
			String message_job = jsonPath_job.getString("message");
			String jobId_job = jsonPath_job.getString("jobId");
			String runtimeJobId_job = jsonPath_job.getString("runtimeJobId");

			System.out.println("After Delete Job +++status== " + status_job);
			System.out.println("After Delete Job +++message== " + message_job);
			System.out.println("After Delete Job +++jobId== " + jobId_job);
			System.out.println("After Delete Job +++runtimeJobId_status== " + runtimeJobId_job);
			ooTestutil.printnewLine();


			Thread.sleep(30000);
		}
	}
	
	
	/********************************************************************************************************************/

	@Test(priority = 2, description = "testEnd2EndScenarioTsProvider")
	@RallyInfo(UserStory = "US8804")
	public void testEnd2EndScenarioTsProviderWithTag() throws Exception {

		ooTestutil.printnewLine();

		// Input tags: OO_Tag_Temperature_ID281
		// Output tags:OO_Tag_Temperature_Demo_tsstream

		System.out.println("*****************Create KPI TEMPLATE*******************");
		ooTestutil.printnewLine();

		// *****************Create KPI TEMPLATE***************************************************//

		final String uri = getTestProperty("kpi_url");

		setSysProperty("setKpiName", "kpiname" + ooTestutil.generateRandomNumber());
		String kpiFile = "src/main/resources/payloads/kpi_templates/kpi_e2e_streamInput.json";
		String kpiJson = generateFile(kpiFile, "kpi_e2e");

		File f = new File(kpiJson);
		System.out.println("file path=" + f.getAbsolutePath());

		String path = f.getAbsolutePath().replace('\\', '/');
		String kpiJson_1 = FileUtils.readFileToString(new File(path));
		File analyticFile = new java.io.File("src/main/resources/payloads/kpi_analytics/analytic_without_tags.zip");

		MultiValueMap<String, Object> parameters = new LinkedMultiValueMap<String, Object>();
		parameters.add("uploadfile", new FileSystemResource(analyticFile));
		parameters.add("kpi", new ObjectMapper().readValue(kpiJson_1, KpiDetails.class));

		ResponseEntity<KpiDetails> response = restTemplate.exchange(uri, HttpMethod.POST,
				new HttpEntity<MultiValueMap<String, Object>>(parameters, ooTestutil.kpiprovideHeaders_1()),
				KpiDetails.class);

		Assert.assertEquals(response.getStatusCode(), HttpStatus.CREATED);
		Assert.assertTrue(response.getBody() instanceof KpiDetails);
		KpiDetails kpiDetails = response.getBody();
		kpi_id = kpiDetails.getId();
		System.out.println("------------->" + kpiDetails.getId());

		// *****************Create KPI JOB***************************************************//

		ooTestutil.printnewLine();
		System.out.println("*****************Create KPI JOB*******************");
		ooTestutil.printnewLine();

		setSysProperty("kpiReferenceId", String.valueOf(kpi_id));

		String kpijobFile = "src/main/resources/payloads/kpi_jobs/kpi_e2e_job_tsstream_output_tag.json";
		String kpijobJson = generateFile(kpijobFile, "kpi_job_e2e");
		System.out.println("+++ kpijobJson== " + kpijobJson);
		Response response1 = postServiceResponse(kpijobJson, "job_url", ooTestutil.kpiprovideHeaders());


		JsonPath jsonPath = new JsonPath(response1.asString());
		kpiJobId = jsonPath.getString("id");
		System.out.println("+++ kpiJobId== " + kpiJobId);
		isEqual("Not valid response create KPI Job", 201, response1.statusCode());

		// *****************START JOB***************************************************//
		ooTestutil.printnewLine();
		System.out.println("*****************START KPI JOB*******************");
		ooTestutil.printnewLine();

		Response response2 = getServiceResponse("start_job_url" + "/" + kpiJobId, ooTestutil.kpiprovideHeaders_2());
		isEqual("Not valid response for Start Job", 200, response2.statusCode());

		JsonPath jsonPath1 = new JsonPath(response2.asString());
		String runtimeJobId = jsonPath1.getString("runtimeJobId");
		System.out.println("+++runtimeJobId== " + runtimeJobId);
		ooTestutil.printnewLine();


		// *****************Status of JOB***************************************************//
		ooTestutil.printnewLine();
		System.out.println("*****************Status of JOB********************");
		ooTestutil.printnewLine();

		Response response_status = getServiceResponse("status_of_job_url" + "/" + kpiJobId, ooTestutil.kpiprovideHeaders_2());
		isEqual("Not valid response for Start Job", 200, response_status.statusCode());

		// System.out.println("+++ response2.asString() == " + response2.asString());
		JsonPath jsonPath_status = new JsonPath(response_status.asString());
		String status = jsonPath_status.getString("status");
		String message = jsonPath_status.getString("message");
		String jobId = jsonPath_status.getString("jobId");
		String runtimeJobId_status = jsonPath_status.getString("runtimeJobId");

		System.out.println("+++status== " + status);
		System.out.println("+++message== " + message);
		System.out.println("+++jobId== " + jobId);
		System.out.println("+++runtimeJobId_status== " + runtimeJobId_status);
		ooTestutil.printnewLine();


		Thread.sleep(30000);

		if(status.equalsIgnoreCase("Running"))
		{

			// ****************Post data point to Kafka Topic*************************************************//

			ooTestutil.printnewLine();
			System.out.println("*****************POST DATA TO KAFKA TOPIC******************");
			ooTestutil.printnewLine();

			String dataingestionFile = "src/main/resources/payloads/data_files/data_ingestion_ts_tag.json";
			Response response_producer =
					postServiceResponse(dataingestionFile, "kafka_producer_url", ooTestutil.kpiprovideHeaders());


			System.out.println("+++ string of timestamp == "
					+ com.jayway.jsonpath.JsonPath.read(response_producer.asString(), "$..datapoints[*][0]"));

			List<String> timestamp_producedData =
					com.jayway.jsonpath.JsonPath.read(response_producer.asString(), "$..datapoints[*][0]");
			List<String> value_producedData =
					com.jayway.jsonpath.JsonPath.read(response_producer.asString(), "$..datapoints[*][1]");

			System.out.println("+++timestamp_ingestedData== " + String.valueOf(timestamp_producedData.get(0)));
			isEqual("Data not Posted to Kafka Topic", 200, response_producer.getStatusCode());

			System.out.println("+++value_ingestedData== " + String.valueOf(value_producedData.get(0)));

			Thread.sleep(30000);

			// ***************Get data point from Kafka Topic*************************************************//
			ooTestutil.printnewLine();
			System.out.println("*****************GET DATA FROM KAFKA TOPIC******************");
			ooTestutil.printnewLine();
			Response response_consumer = getServiceResponse("kafka_consumer_url", ooTestutil.kpiprovideHeaders());

			isEqual("Data not retrieved from Kafka topic", 200, response_consumer.statusCode());

			System.out.println("+++ string of timestamp == "
					+ com.jayway.jsonpath.JsonPath.read(response_consumer.asString(), "$..datapoints[*][0]"));

			List<String> timestamp_consumerData =
					com.jayway.jsonpath.JsonPath.read(response_consumer.asString(), "$..datapoints[*][0]");
			System.out.println("+++timestamp_ingestedData== " + String.valueOf(timestamp_consumerData.get(0)));

			List<String> value_consumerData =
					com.jayway.jsonpath.JsonPath.read(response_consumer.asString(), "$..datapoints[*][1]");
			System.out.println("+++value_consumerData== " + String.valueOf(value_consumerData.get(0)));

			// ****************Assert input and output data points *************************************************//

			Thread.sleep(30000);
			isEqual("Raw data point was not calculated", String.valueOf(timestamp_producedData.get(0)),
					String.valueOf(timestamp_consumerData.get(0)));
			if (String.valueOf(value_producedData.get(0)) != null && String.valueOf(value_consumerData.get(0)) != null) {
				Double value_ingested = Double.parseDouble(String.valueOf(value_producedData.get(0)));
				Double value_consumed = Double.parseDouble(String.valueOf(value_consumerData.get(0)));
				isEqual("Raw data point was not calculated", 509.99, value_consumed);
			}
			// *****************Delete KPI JOB***************************************************//
			
			ooTestutil.printnewLine();
			System.out.println("*****************DELETE KPI JOB*******************");
			ooTestutil.printnewLine();

			System.out.println("+++ kpiDeleteUrl == " + uri);
			response1 = deleteServiceResponse("job_url" + "/" + kpiJobId, ooTestutil.kpiprovideHeaders());
		
			/*KNOWN BUG--> DELETE JOB NOT WORKING CONSISTENTLY*/
			//isEqual("Not valid response for Delete Kpi job", 200, response1.statusCode());
			//isEqual("KPI JOB not killed", true, response1.asString().contains("KPI Job with Id "+kpiJobId+" is marked for deletion. Please check job status"));


			ooTestutil.printnewLine();
			Thread.sleep(60000);

			// *****************Status of JOB after Delete Job***************************************************//
			ooTestutil.printnewLine();
			System.out.println("*****************Status of JOB after Delete Job********************");
			ooTestutil.printnewLine();

			Response response_job = getServiceResponse("status_of_job_url" + "/" + kpiJobId, ooTestutil.kpiprovideHeaders_2());
			/*KNOWN BUG--> DELETE JOB NOT WORKING CONSISTENTLY*/
			//isEqual("Not valid response for Status Job after delete", 400, response_job.statusCode());
            //isEqual("KPI JOB not Deleted", true, response_job.asString().contains("Job "+kpiJobId+" not found"));

			
			JsonPath jsonPath_job = new JsonPath(response_job.asString());
			String status_job = jsonPath_job.getString("status");
			String message_job = jsonPath_job.getString("message");
			String jobId_job = jsonPath_job.getString("jobId");
			String runtimeJobId_job = jsonPath_job.getString("runtimeJobId");

			System.out.println("After Delete Job +++status== " + status_job);
			System.out.println("After Delete Job +++message== " + message_job);
			System.out.println("After Delete Job +++jobId== " + jobId_job);
			System.out.println("After Delete Job +++runtimeJobId_status== " + runtimeJobId_job);
			ooTestutil.printnewLine();


			Thread.sleep(30000);
		}
	}

	/********************************************************************************************************************/

	@Test(priority = 2, description = "testEnd2EndScenarioTsProviderWithMissingTagInKpiJob")
	@RallyInfo(UserStory = "US8804")
	public void testEnd2EndScenarioTsProviderWithMissingTagInKpiJob() throws Exception {

		ooTestutil.printnewLine();

		System.out.println("*****************Create KPI TEMPLATE*******************");
		ooTestutil.printnewLine();

		// *****************Create KPI TEMPLATE***************************************************//

		final String uri = getTestProperty("kpi_url");

		setSysProperty("setKpiName", "kpiname" + ooTestutil.generateRandomNumber());
		String kpiFile = "src/main/resources/payloads/kpi_templates/kpi_e2e_streamInput.json";
		String kpiJson = generateFile(kpiFile, "kpi_e2e");

		File f = new File(kpiJson);
		System.out.println("file path=" + f.getAbsolutePath());

		String path = f.getAbsolutePath().replace('\\', '/');

		String kpiJson_1 = FileUtils.readFileToString(new File(path));
		File analyticFile = new java.io.File("src/main/resources/payloads/kpi_analytics/analytic_without_missing_tags.zip");

		MultiValueMap<String, Object> parameters = new LinkedMultiValueMap<String, Object>();
		parameters.add("uploadfile", new FileSystemResource(analyticFile));
		parameters.add("kpi", new ObjectMapper().readValue(kpiJson_1, KpiDetails.class));

		ResponseEntity<KpiDetails> response = restTemplate.exchange(uri, HttpMethod.POST,
				new HttpEntity<MultiValueMap<String, Object>>(parameters, ooTestutil.kpiprovideHeaders_1()),
				KpiDetails.class);

		Assert.assertEquals(response.getStatusCode(), HttpStatus.CREATED);
		Assert.assertTrue(response.getBody() instanceof KpiDetails);
		KpiDetails kpiDetails = response.getBody();
		kpi_id = kpiDetails.getId();
		System.out.println("------------->" + kpiDetails.getId());

		// *****************Create KPI JOB***************************************************//

		ooTestutil.printnewLine();
		System.out.println("*****************Create KPI JOB*******************");
		ooTestutil.printnewLine();

		setSysProperty("kpiReferenceId", String.valueOf(kpi_id));

		String kpijobFile = "src/main/resources/payloads/kpi_jobs/kpi_e2e_job_tsstream_output_missing_tag.json";
		String kpijobJson = generateFile(kpijobFile, "kpi_job_e2e");
		System.out.println("+++ kpijobJson== " + kpijobJson);
		Response response1 = postServiceResponse(kpijobJson, "job_url", ooTestutil.kpiprovideHeaders());
		JsonPath jsonPath = new JsonPath(response1.asString());
		kpiJobId = jsonPath.getString("id");
		System.out.println("+++ kpiJobId== " + kpiJobId);
		isEqual("Not valid response create KPI Job", 201, response1.statusCode());

		// *****************START JOB***************************************************//
		ooTestutil.printnewLine();
		System.out.println("*****************START KPI JOB*******************");
		ooTestutil.printnewLine();

		Response response2 = getServiceResponse("start_job_url" + "/" + kpiJobId, ooTestutil.kpiprovideHeaders_2());
		isEqual("Not valid response for Start Job", 200, response2.statusCode());

		JsonPath jsonPath1 = new JsonPath(response2.asString());
		String runtimeJobId = jsonPath1.getString("runtimeJobId");
		System.out.println("+++runtimeJobId== " + runtimeJobId);
		ooTestutil.printnewLine();

		// *****************Status of JOB***************************************************//
		ooTestutil.printnewLine();
		System.out.println("*****************Status of JOB********************");
		ooTestutil.printnewLine();

		Response response_status = getServiceResponse("status_of_job_url" + "/" + kpiJobId, ooTestutil.kpiprovideHeaders_2());
		isEqual("Not valid response for Start Job", 200, response_status.statusCode());

		JsonPath jsonPath_status = new JsonPath(response_status.asString());
		String status = jsonPath_status.getString("status");
		String message = jsonPath_status.getString("message");
		String jobId = jsonPath_status.getString("jobId");
		String runtimeJobId_status = jsonPath_status.getString("runtimeJobId");

		System.out.println("+++status== " + status);
		System.out.println("+++message== " + message);
		System.out.println("+++jobId== " + jobId);
		System.out.println("+++runtimeJobId_status== " + runtimeJobId_status);
		ooTestutil.printnewLine();


		Thread.sleep(30000);

		if(status.equalsIgnoreCase("Running"))
		{

			// ****************Post data point to Kafka Topic*************************************************//

			ooTestutil.printnewLine();
			System.out.println("*****************POST DATA TO KAFKA TOPIC******************");
			ooTestutil.printnewLine();

			String dataingestionFile = "src/main/resources/payloads/data_files/data_ingestion_ts_missing_tag.json";
			Response response_producer =
					postServiceResponse(dataingestionFile, "kafka_producer_url", ooTestutil.kpiprovideHeaders());

			System.out.println("+++ string of timestamp == "
					+ com.jayway.jsonpath.JsonPath.read(response_producer.asString(), "$..datapoints[*][0]"));

			List<String> timestamp_producedData =
					com.jayway.jsonpath.JsonPath.read(response_producer.asString(), "$..datapoints[*][0]");
			List<String> value_producedData =
					com.jayway.jsonpath.JsonPath.read(response_producer.asString(), "$..datapoints[*][1]");

			System.out.println("+++timestamp_ingestedData== " + String.valueOf(timestamp_producedData.get(0)));
			isEqual("Data not Posted to Kafka Topic", 200, response_producer.getStatusCode());

			System.out.println("+++value_ingestedData== " + String.valueOf(value_producedData.get(0)));

			Thread.sleep(30000);

			// ***************Get data point from Kafka Topic*************************************************//
			ooTestutil.printnewLine();
			System.out.println("*****************GET DATA FROM KAFKA TOPIC******************");
			ooTestutil.printnewLine();
			Response response_consumer = getServiceResponse("kafka_consumer_url", ooTestutil.kpiprovideHeaders());

			isEqual("Data not retrieved from Kafka topic", 200, response_consumer.statusCode());

			System.out.println("+++ string of timestamp == "
					+ com.jayway.jsonpath.JsonPath.read(response_consumer.asString(), "$..datapoints[*][0]"));

			List<String> timestamp_consumerData =
					com.jayway.jsonpath.JsonPath.read(response_consumer.asString(), "$..datapoints[*][0]");
			System.out.println("+++timestamp_ingestedData== " + String.valueOf(timestamp_consumerData.get(0)));

			List<String> value_consumerData =
					com.jayway.jsonpath.JsonPath.read(response_consumer.asString(), "$..datapoints[*][1]");
			System.out.println("+++value_consumerData== " + String.valueOf(value_consumerData.get(0)));

			// ****************Assert input and output data points *************************************************//

			Thread.sleep(30000);
			isEqual("Raw data point was not calculated", String.valueOf(timestamp_producedData.get(0)),
					String.valueOf(timestamp_consumerData.get(0)));
			if (String.valueOf(value_producedData.get(0)) != null && String.valueOf(value_consumerData.get(0)) != null) {
				Double value_ingested = Double.parseDouble(String.valueOf(value_producedData.get(0)));
				Double value_consumed = Double.parseDouble(String.valueOf(value_consumerData.get(0)));
				isEqual("Raw data point was not calculated", 70.999, value_consumed);
			}
			// *****************Delete KPI JOB***************************************************//
			
			ooTestutil.printnewLine();
			System.out.println("*****************DELETE KPI JOB*******************");
			ooTestutil.printnewLine();

			System.out.println("+++ kpiDeleteUrl == " + uri);
			response1 = deleteServiceResponse("job_url" + "/" + kpiJobId, ooTestutil.kpiprovideHeaders());
			/*KNOWN BUG--> DELETE JOB NOT WORKING CONSISTENTLY*/
			//isEqual("Not valid response for Delete Kpi job", 200, response1.statusCode());
			//isEqual("KPI JOB not killed", true, response1.asString().contains("KPI Job with Id "+kpiJobId+" is marked for deletion. Please check job status"));


			ooTestutil.printnewLine();
			Thread.sleep(60000);

			// *****************Status of JOB after Delete Job***************************************************//
			ooTestutil.printnewLine();
			System.out.println("*****************Status of JOB after Delete Job********************");
			ooTestutil.printnewLine();

			Response response_job = getServiceResponse("status_of_job_url" + "/" + kpiJobId, ooTestutil.kpiprovideHeaders_2());
			/*KNOWN BUG--> DELETE JOB NOT WORKING CONSISTENTLY*/
			//isEqual("Not valid response for Status Job after delete", 400, response_job.statusCode());
            //isEqual("KPI JOB not Deleted", true, response_job.asString().contains("Job "+kpiJobId+" not found"));

			
			JsonPath jsonPath_job = new JsonPath(response_job.asString());
			String status_job = jsonPath_job.getString("status");
			String message_job = jsonPath_job.getString("message");
			String jobId_job = jsonPath_job.getString("jobId");
			String runtimeJobId_job = jsonPath_job.getString("runtimeJobId");

			System.out.println("After Delete Job +++status== " + status_job);
			System.out.println("After Delete Job +++message== " + message_job);
			System.out.println("After Delete Job +++jobId== " + jobId_job);
			System.out.println("After Delete Job +++runtimeJobId_status== " + runtimeJobId_job);
			ooTestutil.printnewLine();


			Thread.sleep(30000);
		}
	}

	
	
	/********************************************************************************************************************/
	@Test(priority = 3, description = "testEnd2EndScenariosAssetTsWithAttributesDataProviders")
	@RallyInfo(UserStory = "US33399")
	public void testEnd2EndScenariosAssetTsWithAttributesDataProviders() throws Exception {

		ooTestutil.printnewLine();

		System.out.println("*****************Create KPI TEMPLATE*******************");
		ooTestutil.printnewLine();

		// *****************Create KPI TEMPLATE***************************************************//

		final String uri = getTestProperty("kpi_url");

		setSysProperty("setKpiName", "kpiname" + ooTestutil.generateRandomNumber());
		String kpiFile = "src/main/resources/payloads/kpi_templates/kpi_e2e.json";
		String kpiJson = generateFile(kpiFile, "kpi_e2e");

		File f = new File(kpiJson);
		System.out.println("file path=" + f.getAbsolutePath());

		String path = f.getAbsolutePath().replace('\\', '/');


		String kpiJson_1 = FileUtils.readFileToString(new File(path));
		File analyticFile = new java.io.File(
				"src/main/resources/payloads/kpi_analytics/analytic_with_attributes_1.zip");

		MultiValueMap<String, Object> parameters = new LinkedMultiValueMap<String, Object>();
		parameters.add("uploadfile", new FileSystemResource(analyticFile));
		parameters.add("kpi", new ObjectMapper().readValue(kpiJson_1, KpiDetails.class));

		ResponseEntity<KpiDetails> response = restTemplate.exchange(uri, HttpMethod.POST,
				new HttpEntity<MultiValueMap<String, Object>>(parameters, ooTestutil.kpiprovideHeaders_1()),
				KpiDetails.class);

		Assert.assertEquals(response.getStatusCode(), HttpStatus.CREATED);
		Assert.assertTrue(response.getBody() instanceof KpiDetails);
		KpiDetails kpiDetails = response.getBody();
		kpi_id = kpiDetails.getId();
		System.out.println("------------->" + kpiDetails.getId());

		// *****************Create KPI JOB***************************************************//

		ooTestutil.printnewLine();
		System.out.println("*****************Create KPI JOB*******************");
		ooTestutil.printnewLine();

		setSysProperty("kpiReferenceId", String.valueOf(kpi_id));

		String kpijobFile = "src/main/resources/payloads/kpi_jobs/kpi_e2e_job.json";
		String kpijobJson = generateFile(kpijobFile, "kpi_job_e2e");
		System.out.println("+++ kpijobJson== " + kpijobJson);
		Response response1 = postServiceResponse(kpijobJson, "job_url", ooTestutil.kpiprovideHeaders());

		JsonPath jsonPath = new JsonPath(response1.asString());
		kpiJobId = jsonPath.getString("id");
		System.out.println("+++ kpiJobId== " + kpiJobId);
		isEqual("Not valid response create KPI Job", 201, response1.statusCode());

		// *****************START JOB***************************************************//
		ooTestutil.printnewLine();
		System.out.println("*****************START KPI JOB*******************");
		ooTestutil.printnewLine();

		Response response2 = getServiceResponse("start_job_url" + "/" + kpiJobId, ooTestutil.kpiprovideHeaders_2());
		isEqual("Not valid response for Start Job", 200, response2.statusCode());

		JsonPath jsonPath1 = new JsonPath(response2.asString());
		String runtimeJobId = jsonPath1.getString("runtimeJobId");
		System.out.println("+++runtimeJobId== " + runtimeJobId);
		ooTestutil.printnewLine();


		// *****************Status of JOB***************************************************//
		ooTestutil.printnewLine();
		System.out.println("*****************Status of JOB********************");
		ooTestutil.printnewLine();

		Response response_status = getServiceResponse("status_of_job_url" + "/" + kpiJobId, ooTestutil.kpiprovideHeaders_2());
		isEqual("Not valid response for Start Job", 200, response_status.statusCode());

		JsonPath jsonPath_status = new JsonPath(response_status.asString());
		String status = jsonPath_status.getString("status");
		String message = jsonPath_status.getString("message");
		String jobId = jsonPath_status.getString("jobId");
		String runtimeJobId_status = jsonPath_status.getString("runtimeJobId");

		System.out.println("+++status== " + status);
		System.out.println("+++message== " + message);
		System.out.println("+++jobId== " + jobId);
		System.out.println("+++runtimeJobId_status== " + runtimeJobId_status);
		ooTestutil.printnewLine();


		Thread.sleep(30000);

		if(status.equalsIgnoreCase("Running"))
		{
			// ****************Post data point to Kafka Topic*************************************************//
			Thread.sleep(30000);
			ooTestutil.printnewLine();
			System.out.println("*****************POST DATA TO KAFKA TOPIC******************");
			ooTestutil.printnewLine();

			String dataingestionFile = "src/main/resources/payloads/data_files/data_ingestion_ts_attributes.json";
			Response response_producer =
					postServiceResponse(dataingestionFile, "kafka_producer_url", ooTestutil.kpiprovideHeaders());


			System.out.println("+++ string of timestamp == "
					+ com.jayway.jsonpath.JsonPath.read(response_producer.asString(), "$..datapoints[*][0]"));

			List<String> timestamp_producedData =
					com.jayway.jsonpath.JsonPath.read(response_producer.asString(), "$..datapoints[*][0]");
			List<String> value_producedData =
					com.jayway.jsonpath.JsonPath.read(response_producer.asString(), "$..datapoints[*][1]");

			System.out.println("+++timestamp_ingestedData== " + String.valueOf(timestamp_producedData.get(0)));
			System.out.println("+++value_producedData== " + String.valueOf(value_producedData.get(0)));
			isEqual("Data not Posted to Kafka Topic", 200, response_producer.getStatusCode());

			Thread.sleep(30000);

			// ***************Get data point from Kafka Topic*************************************************//
			ooTestutil.printnewLine();
			System.out.println("*****************GET DATA FROM KAFKA TOPIC******************");
			ooTestutil.printnewLine();
			Response response_consumer = getServiceResponse("kafka_consumer_url", ooTestutil.kpiprovideHeaders());

			isEqual("Data not retrieved from Kafka topic", 200, response_consumer.statusCode());

			System.out.println("+++ string of timestamp == "
					+ com.jayway.jsonpath.JsonPath.read(response_consumer.asString(), "$..datapoints[*][0]"));

			List<String> timestamp_consumerData =
					com.jayway.jsonpath.JsonPath.read(response_consumer.asString(), "$..datapoints[*][0]");
			System.out.println("+++timestamp_ingestedData== " + String.valueOf(timestamp_consumerData.get(0)));

			List<String> value_consumerData =
					com.jayway.jsonpath.JsonPath.read(response_consumer.asString(), "$..datapoints[*][1]");
			System.out.println("+++value_consumerData== " + String.valueOf(value_consumerData.get(0)));

			// ****************Assert input and output data points *************************************************//

			Thread.sleep(30000);

			if (String.valueOf(value_producedData.get(0)) != null && String.valueOf(value_consumerData.get(0)) != null) {
				Double value_ingested = Double.parseDouble(String.valueOf(value_producedData.get(0)));
				Double value_consumed = Double.parseDouble(String.valueOf(value_consumerData.get(0)));
				Assert.assertTrue(!value_ingested.equals(value_consumed),
						"Raw data point was not calculated--> raw and calculated data points-->" + value_ingested
						+ "   " + value_consumed);
				isEqual("Raw data point was not calculated", 6878.651281927272, value_consumed);
			}

			// ****************Stop the Job*************************************************//

			Thread.sleep(30000);
			ooTestutil.printnewLine();
			System.out.println("*****************STOP KPI JOB*******************");
			ooTestutil.printnewLine();

			Response response3 = getServiceResponse("stop_job_url" + "/" + kpiJobId, ooTestutil.kpiprovideHeaders_2());
			isEqual("Not valid response for Start Job", 200, response3.statusCode());

			isEqual("KPI JOB not killed", true, response3.asString().contains("KILLED"));
			isEqual("KPI JOB not killed", 200, response3.statusCode());


			ooTestutil.printnewLine();
			// **********************************************************************************//

			/*ooTestutil.printnewLine();
			System.out.println("*****************DELETE KPI*******************");
			ooTestutil.printnewLine();

			System.out.println("+++ kpiDeleteUrl == " + uri);
			response1 = deleteServiceResponse("kpi_url" + "/" + kpi_id, ooTestutil.kpiprovideHeaders());
			// System.out.println("+++ response.asString() == " + response1.asString());
			isEqual("Not valid response for Delete Kpi", 200, response1.statusCode());

			ooTestutil.printnewLine();

			Thread.sleep(30000);
			ooTestutil.printnewLine();*/
			System.out.println("*****************DELETE KPI JOB*******************");
			ooTestutil.printnewLine();

			System.out.println("+++ kpiDeleteUrl == " + uri);
			response1 = deleteServiceResponse("job_url" + "/" + kpiJobId, ooTestutil.kpiprovideHeaders());
			/*KNOWN BUG--> DELETE JOB NOT WORKING CONSISTENTLY*/
			//isEqual("Not valid response for Delete Kpi", 200, response1.statusCode());
			//isEqual("KPI JOB not killed", true, response1.asString().contains("KPI Job with Id "+kpiJobId+" is marked for deletion. Please check job status"));


			ooTestutil.printnewLine();
			Thread.sleep(60000);

			// *****************Status of JOB after Delete Job***************************************************//
			ooTestutil.printnewLine();
			System.out.println("*****************Status of JOB after Delete Job********************");
			ooTestutil.printnewLine();

			Response response_job = getServiceResponse("status_of_job_url" + "/" + kpiJobId, ooTestutil.kpiprovideHeaders_2());
			/*KNOWN BUG--> DELETE JOB NOT WORKING CONSISTENTLY*/
			//isEqual("Not valid response for Status Job after delete", 400, response_job.statusCode());
           // isEqual("KPI JOB not Deleted", true, response_job.asString().contains("Job "+kpiJobId+" not found"));

			
			JsonPath jsonPath_job = new JsonPath(response_job.asString());
			String status_job = jsonPath_job.getString("status");
			String message_job = jsonPath_job.getString("message");
			String jobId_job = jsonPath_job.getString("jobId");
			String runtimeJobId_job = jsonPath_job.getString("runtimeJobId");

			System.out.println("After Delete Job +++status== " + status_job);
			System.out.println("After Delete Job +++message== " + message_job);
			System.out.println("After Delete Job +++jobId== " + jobId_job);
			System.out.println("After Delete Job +++runtimeJobId_status== " + runtimeJobId_job);
			ooTestutil.printnewLine();


			Thread.sleep(30000);
		}
	}
	
	/********************************************************************************************************************/
	@Test(priority = 2, description = "testEnd2EndScenarioApmOOTsProvider")
	@RallyInfo(UserStory = "DE9424")
	public void testEnd2EndScenarioAnalyticConsumerDaemon() throws Exception {

		ooTestutil.printnewLine();

		System.out.println("*****************Post data point into Kafka producer*******************");
		ooTestutil.printnewLine();

		// ****************Post data point to Kafka Topic*************************************************//
		Thread.sleep(30000);


		setSysProperty("setTagName", "Tag_Name" + ooTestutil.generateRandomNumber());
		String d = "src/main/resources/payloads/data_files/data_ingestion_ts_analyticdaemon.json";
		
		
		String dataIngestionFileJson = generateFile(d, "dataIngestionFile");

		File f = new File(dataIngestionFileJson);
		System.out.println("file path=" + f.getAbsolutePath());
		String path = f.getAbsolutePath().replace('\\', '/');
		String dataIngestionFileJsonAsString = FileUtils.readFileToString(new File(path));


		Response response_producer =
				postServiceResponse(dataIngestionFileJsonAsString, "kafka_producer_url", ooTestutil.kpiprovideHeaders());

		System.out.println("+++ string of Tag Name == "
				+ com.jayway.jsonpath.JsonPath.read(response_producer.asString(), "$..name"));
		

		System.out.println("+++ string of timestamp == "
				+ com.jayway.jsonpath.JsonPath.read(response_producer.asString(), "$..datapoints[*][0]"));

		List<String> timestamp_producedData =
				com.jayway.jsonpath.JsonPath.read(response_producer.asString(), "$..datapoints[*][0]");
		List<String> value_producedData =
				com.jayway.jsonpath.JsonPath.read(response_producer.asString(), "$..datapoints[*][1]");
		String valuePosted = String.valueOf(value_producedData.get(0));
		
		List<String> list_of_tags =com.jayway.jsonpath.JsonPath.read(response_producer.asString(), "$..name");
		String tagNamePosted = String.valueOf(list_of_tags.get(0));
		

		System.out.println("+++timestamp_ingestedData== " + String.valueOf(timestamp_producedData.get(0)));
		System.out.println("+++value_producedData== " + String.valueOf(value_producedData.get(0)));
		isEqual("Data not Posted to Kafka Topic", 200, response_producer.getStatusCode());

		Thread.sleep(30000);

		// ***************Get data point from Kafka Topic*************************************************//
		ooTestutil.printnewLine();
		System.out.println("*****************GET DATA FROM KAFKA TOPIC******************");
		ooTestutil.printnewLine();
		Response response_consumer = getServiceResponse("kafka_consumer_url", ooTestutil.kpiprovideHeaders());
		// System.out.println("+++ response_consumer.asString() == " + response_consumer.asString());

		isEqual("Data not retrieved from Kafka topic", 200, response_consumer.statusCode());
		
		List<String> list_of_tags_consumed =com.jayway.jsonpath.JsonPath.read(response_producer.asString(), "$..name");
		String tagNameConsumed = String.valueOf(list_of_tags_consumed.get(0));


		System.out.println("+++ string of timestamp == "
				+ com.jayway.jsonpath.JsonPath.read(response_consumer.asString(), "$..datapoints[*][0]"));

		List<String> timestamp_consumerData =
				com.jayway.jsonpath.JsonPath.read(response_consumer.asString(), "$..datapoints[*][0]");
		System.out.println("+++timestamp_ingestedData== " + String.valueOf(timestamp_consumerData.get(0)));

		List<String> value_consumerData =
				com.jayway.jsonpath.JsonPath.read(response_consumer.asString(), "$..datapoints[*][1]");
		System.out.println("+++value_consumerData== " + String.valueOf(value_consumerData.get(0)));

		
		
		isEqual("Data not posted to kafka topic",true,tagNameConsumed.equalsIgnoreCase(tagNamePosted));
		// ***************Get data from APM TIME SERIES*************************************************//
		ooTestutil.printnewLine();
		System.out.println("*****************Get data from APM TIME SERIES******************");	

		
		Map<String, Object> queryParams = new LinkedHashMap<String, Object>();
        queryParams.put("tagList", tagNamePosted);
		
		Response response_apm_ts = getServiceResponse("timeSeriesGetDataURL",queryParams, ooTestutil.ApmProvideHeaders());
		System.out.println("+++ string of response_apm_ts == "+response_apm_ts.asString());
		isEqual("Data posted to kafka topic is not posted in APM TS",true,response_apm_ts.asString().contains(tagNamePosted));
		isEqual("Data posted to kafka topic is not posted in APM TS",true,response_apm_ts.asString().contains(valuePosted));
		
	}


	/********************************************************************************************************************/
	
	
	@Test(priority = 2, description = "testEnd2EndScenarioApmOOTsProvider")
	@RallyInfo(UserStory = "US4776")
	public void testEnd2EndScenarioApmOOTsProvider() throws Exception {

		ooTestutil.printnewLine();

		System.out.println("*****************Create KPI TEMPLATE*******************");
		ooTestutil.printnewLine();

		// *****************Create KPI TEMPLATE***************************************************//

		final String uri = getTestProperty("kpi_url");

		setSysProperty("setKpiName", "kpiname" + ooTestutil.generateRandomNumber());
		String kpiFile = "src/main/resources/payloads/kpi_templates/kpi_e2e_ooapmts_output.json";
		String kpiJson = generateFile(kpiFile, "kpi_e2e");

		File f = new File(kpiJson);
		System.out.println("file path=" + f.getAbsolutePath());

		String path = f.getAbsolutePath().replace('\\', '/');

		// String kpiJson = FileUtils.readFileToString(new
		// java.io.File("src/main/resources/payloads/finale2eScenarios/kpi_e2e.json"));
		String kpiJson_1 = FileUtils.readFileToString(new File(path));
		File analyticFile = new java.io.File("src/main/resources/payloads/kpi_analytics/analytic_ooapm_timeseries.zip");

		MultiValueMap<String, Object> parameters = new LinkedMultiValueMap<String, Object>();
		parameters.add("uploadfile", new FileSystemResource(analyticFile));
		parameters.add("kpi", new ObjectMapper().readValue(kpiJson_1, KpiDetails.class));

		ResponseEntity<KpiDetails> response = restTemplate.exchange(uri, HttpMethod.POST,
				new HttpEntity<MultiValueMap<String, Object>>(parameters, ooTestutil.kpiprovideHeaders_1()),
				KpiDetails.class);

		Assert.assertEquals(response.getStatusCode(), HttpStatus.CREATED);
		Assert.assertTrue(response.getBody() instanceof KpiDetails);
		KpiDetails kpiDetails = response.getBody();
		kpi_id = kpiDetails.getId();
		System.out.println("------------->" + kpiDetails.getId());

		// *****************Create KPI JOB***************************************************//

		ooTestutil.printnewLine();
		System.out.println("*****************Create KPI JOB*******************");
		ooTestutil.printnewLine();

		setSysProperty("kpiReferenceId", String.valueOf(kpi_id));
		
		String outputTag = "OO_Tag_WINDSPEED" + ooTestutil.generateRandomNumber();
		setSysProperty("setOutputTagName",outputTag);


		String kpijobFile = "src/main/resources/payloads/kpi_jobs/kpi_e2e_ooapmts_output_job.json";
		String kpijobJson = generateFile(kpijobFile, "kpi_job_e2e");
		System.out.println("+++ kpijobJson== " + kpijobJson);
		Response response1 = postServiceResponse(kpijobJson, "job_url", ooTestutil.kpiprovideHeaders());

		// System.out.println("+++ response.asString() == " +
		// response1.asString());
		JsonPath jsonPath = new JsonPath(response1.asString());
		kpiJobId = jsonPath.getString("id");
		System.out.println("+++ kpiJobId== " + kpiJobId);
		isEqual("Not valid response create KPI Job", 201, response1.statusCode());

		// *****************START JOB***************************************************//
		ooTestutil.printnewLine();
		System.out.println("*****************START KPI JOB*******************");
		ooTestutil.printnewLine();


		
		Response response2 = getServiceResponse("start_job_url" + "/" + kpiJobId, ooTestutil.kpiprovideHeaders_2());
		isEqual("Not valid response for Start Job", 200, response2.statusCode());

		// System.out.println("+++ response2.asString() == " +
		// response2.asString());
		JsonPath jsonPath1 = new JsonPath(response2.asString());
		String runtimeJobId = jsonPath1.getString("runtimeJobId");
		System.out.println("+++runtimeJobId== " + runtimeJobId);
		ooTestutil.printnewLine();
		

		// *****************Status of JOB***************************************************//
		ooTestutil.printnewLine();
		System.out.println("*****************Status of JOB********************");
		ooTestutil.printnewLine();

		Response response_status = getServiceResponse("status_of_job_url" + "/" + kpiJobId, ooTestutil.kpiprovideHeaders_2());
		isEqual("Not valid response for Start Job", 200, response_status.statusCode());

		JsonPath jsonPath_status = new JsonPath(response_status.asString());
		String status = jsonPath_status.getString("status");
		String message = jsonPath_status.getString("message");
		String jobId = jsonPath_status.getString("jobId");
		String runtimeJobId_status = jsonPath_status.getString("runtimeJobId");

		System.out.println("+++status== " + status);
		System.out.println("+++message== " + message);
		System.out.println("+++jobId== " + jobId);
		System.out.println("+++runtimeJobId_status== " + runtimeJobId_status);
		ooTestutil.printnewLine();


		Thread.sleep(30000);

		if(status.equalsIgnoreCase("Running"))
		{
			System.out.println("*****************Post data point into Kafka producer*******************");
			ooTestutil.printnewLine();

			// ****************Post data point to Kafka Topic*************************************************//
			Thread.sleep(30000);


			setSysProperty("setTagName", "OO_Tag_WINDSPEED" + ooTestutil.generateRandomNumber());
			String d = "src/main/resources/payloads/data_files/data_ingestion_ooapmts.json";
			
			
			String dataIngestionFileJson = generateFile(d, "dataIngestionFile");

			File f1 = new File(dataIngestionFileJson);
			System.out.println("file path=" + f1.getAbsolutePath());
			String path1 = f1.getAbsolutePath().replace('\\', '/');
			String dataIngestionFileJsonAsString = FileUtils.readFileToString(new File(path1));


			//String dataIngestionFileJsonAsString = "src/main/resources/payloads/data_files/data_ingestion_ooapmts.json";
			Response response_producer =
					postServiceResponse(dataIngestionFileJsonAsString, "kafka_producer_url", ooTestutil.kpiprovideHeaders());

			System.out.println("+++ string of Tag Name == "
					+ com.jayway.jsonpath.JsonPath.read(response_producer.asString(), "$..name"));
			

			System.out.println("+++ string of timestamp == "
					+ com.jayway.jsonpath.JsonPath.read(response_producer.asString(), "$..datapoints[*][0]"));

			List<String> timestamp_producedData =
					com.jayway.jsonpath.JsonPath.read(response_producer.asString(), "$..datapoints[*][0]");
			List<String> value_producedData =
					com.jayway.jsonpath.JsonPath.read(response_producer.asString(), "$..datapoints[*][1]");
			String valuePosted = String.valueOf(value_producedData.get(0));
			
			List<String> list_of_tags =com.jayway.jsonpath.JsonPath.read(response_producer.asString(), "$..name");
			String tagNamePosted = String.valueOf(list_of_tags.get(0));
			

			System.out.println("+++timestamp_ingestedData== " + String.valueOf(timestamp_producedData.get(0)));
			System.out.println("+++value_producedData== " + String.valueOf(value_producedData.get(0)));
			isEqual("Data not Posted to Kafka Topic", 200, response_producer.getStatusCode());

			Thread.sleep(30000);

			// ***************Get data point from Kafka Topic*************************************************//
			ooTestutil.printnewLine();
			System.out.println("*****************GET DATA FROM KAFKA TOPIC******************");
			ooTestutil.printnewLine();
			Response response_consumer = getServiceResponse("kafka_consumer_url", ooTestutil.kpiprovideHeaders());
			// System.out.println("+++ response_consumer.asString() == " + response_consumer.asString());

			isEqual("Data not retrieved from Kafka topic", 200, response_consumer.statusCode());
			
			List<String> list_of_tags_consumed =com.jayway.jsonpath.JsonPath.read(response_producer.asString(), "$..name");
			String tagNameConsumed = String.valueOf(list_of_tags_consumed.get(0));


			System.out.println("+++ string of timestamp == "
					+ com.jayway.jsonpath.JsonPath.read(response_consumer.asString(), "$..datapoints[*][0]"));

			List<String> timestamp_consumerData =
					com.jayway.jsonpath.JsonPath.read(response_consumer.asString(), "$..datapoints[*][0]");
			System.out.println("+++timestamp_ingestedData== " + String.valueOf(timestamp_consumerData.get(0)));

			List<String> value_consumerData =
					com.jayway.jsonpath.JsonPath.read(response_consumer.asString(), "$..datapoints[*][1]");
			System.out.println("+++value_consumerData== " + String.valueOf(value_consumerData.get(0)));

			
			
			isEqual("Data not posted to kafka topic",true,tagNameConsumed.equalsIgnoreCase(tagNamePosted));
			
			// ***************Get data from APM TIME SERIES*************************************************//
			ooTestutil.printnewLine();
			System.out.println("*****************Get data from APM TIME SERIES******************");	

		
			Map<String, Object> queryParams = new LinkedHashMap<String, Object>();
	        queryParams.put("tagList", outputTag);
			
			Response response_apm_ts = getServiceResponse("timeSeriesGetDataURL",queryParams, ooTestutil.ApmProvideHeaders());
			System.out.println("+++ string of response_apm_ts == "+response_apm_ts.asString());
			isEqual("Data posted to kafka topic is not posted in APM TS",true,response_apm_ts.asString().contains(outputTag));
			isEqual("Data posted to kafka topic is not posted in APM TS",true,response_apm_ts.asString().contains("55556.116409636365"));
	
			// **********************************************************************************//
			

			System.out.println("*****************DELETE KPI JOB*******************");
			ooTestutil.printnewLine();

			System.out.println("+++ kpiDeleteUrl == " + uri);
			response1 = deleteServiceResponse("job_url" + "/" + kpiJobId, ooTestutil.kpiprovideHeaders());
			/*KNOWN BUG--> DELETE JOB NOT WORKING CONSISTENTLY*/
			//isEqual("Not valid response for Delete Kpi", 200, response1.statusCode());
			//isEqual("KPI JOB not killed", true, response1.asString().contains("KPI Job with Id "+kpiJobId+" is marked for deletion. Please check job status"));


			ooTestutil.printnewLine();
			Thread.sleep(60000);

			// *****************Status of JOB after Delete Job***************************************************//
			ooTestutil.printnewLine();
			System.out.println("*****************Status of JOB after Delete Job********************");
			ooTestutil.printnewLine();

			Response response_job = getServiceResponse("status_of_job_url" + "/" + kpiJobId, ooTestutil.kpiprovideHeaders_2());
			/*KNOWN BUG--> DELETE JOB NOT WORKING CONSISTENTLY*/
			//isEqual("Not valid response for Status Job after delete", 400, response_job.statusCode());
			// isEqual("KPI JOB not Deleted", true, response_job.asString().contains("Job "+kpiJobId+" not found"));


			JsonPath jsonPath_job = new JsonPath(response_job.asString());
			String status_job = jsonPath_job.getString("status");
			String message_job = jsonPath_job.getString("message");
			String jobId_job = jsonPath_job.getString("jobId");
			String runtimeJobId_job = jsonPath_job.getString("runtimeJobId");

			System.out.println("After Delete Job +++status== " + status_job);
			System.out.println("After Delete Job +++message== " + message_job);
			System.out.println("After Delete Job +++jobId== " + jobId_job);
			System.out.println("After Delete Job +++runtimeJobId_status== " + runtimeJobId_job);
			ooTestutil.printnewLine();


			Thread.sleep(30000);
			
		
		}

	
	}

	
/********************************************************************************************************************/
	
	
	@Test(priority = 2, description = "testEnd2EndScenarioOOStreamInputApmOOTsOutputProvider")
	@RallyInfo(UserStory = "DE10414")
	public void testEnd2EndScenarioOOStreamInputApmOOTsOutputProvider() throws Exception {

		ooTestutil.printnewLine();

		System.out.println("*****************Create KPI TEMPLATE*******************");
		ooTestutil.printnewLine();

		// *****************Create KPI TEMPLATE***************************************************//

		final String uri = getTestProperty("kpi_url");

		setSysProperty("setKpiName", "kpiname" + ooTestutil.generateRandomNumber());
		String kpiFile = "src/main/resources/payloads/kpi_templates/kpi_e2e_oostream_ooapmts.json";
		String kpiJson = generateFile(kpiFile, "kpi_e2e");

		File f = new File(kpiJson);
		System.out.println("file path=" + f.getAbsolutePath());

		String path = f.getAbsolutePath().replace('\\', '/');

		// String kpiJson = FileUtils.readFileToString(new
		// java.io.File("src/main/resources/payloads/finale2eScenarios/kpi_e2e.json"));
		String kpiJson_1 = FileUtils.readFileToString(new File(path));
		File analyticFile = new java.io.File("src/main/resources/payloads/kpi_analytics/analytic_oostream_ooapmts.zip");

		MultiValueMap<String, Object> parameters = new LinkedMultiValueMap<String, Object>();
		parameters.add("uploadfile", new FileSystemResource(analyticFile));
		parameters.add("kpi", new ObjectMapper().readValue(kpiJson_1, KpiDetails.class));

		ResponseEntity<KpiDetails> response = restTemplate.exchange(uri, HttpMethod.POST,
				new HttpEntity<MultiValueMap<String, Object>>(parameters, ooTestutil.kpiprovideHeaders_1()),
				KpiDetails.class);

		Assert.assertEquals(response.getStatusCode(), HttpStatus.CREATED);
		Assert.assertTrue(response.getBody() instanceof KpiDetails);
		KpiDetails kpiDetails = response.getBody();
		kpi_id = kpiDetails.getId();
		System.out.println("------------->" + kpiDetails.getId());

		// *****************Create KPI JOB***************************************************//

		ooTestutil.printnewLine();
		System.out.println("*****************Create KPI JOB*******************");
		ooTestutil.printnewLine();

		setSysProperty("kpiReferenceId", String.valueOf(kpi_id));
		
		String outputTag = "OO_Tag_TURBINESPEED_OUTPUT" + ooTestutil.generateRandomNumber();
		setSysProperty("setOutputTagName",outputTag);


		String kpijobFile = "src/main/resources/payloads/kpi_jobs/kpi_e2e_oostream_ooapmts_job.json";
		String kpijobJson = generateFile(kpijobFile, "kpi_job_e2e");
		System.out.println("+++ kpijobJson== " + kpijobJson);
		Response response1 = postServiceResponse(kpijobJson, "job_url", ooTestutil.kpiprovideHeaders());

		// System.out.println("+++ response.asString() == " +
		// response1.asString());
		JsonPath jsonPath = new JsonPath(response1.asString());
		kpiJobId = jsonPath.getString("id");
		System.out.println("+++ kpiJobId== " + kpiJobId);
		isEqual("Not valid response create KPI Job", 201, response1.statusCode());

		// *****************START JOB***************************************************//
		ooTestutil.printnewLine();
		System.out.println("*****************START KPI JOB*******************");
		ooTestutil.printnewLine();


		
		Response response2 = getServiceResponse("start_job_url" + "/" + kpiJobId, ooTestutil.kpiprovideHeaders_2());
		isEqual("Not valid response for Start Job", 200, response2.statusCode());

		// System.out.println("+++ response2.asString() == " +
		// response2.asString());
		JsonPath jsonPath1 = new JsonPath(response2.asString());
		String runtimeJobId = jsonPath1.getString("runtimeJobId");
		System.out.println("+++runtimeJobId== " + runtimeJobId);
		ooTestutil.printnewLine();
		

		// *****************Status of JOB***************************************************//
		ooTestutil.printnewLine();
		System.out.println("*****************Status of JOB********************");
		ooTestutil.printnewLine();

		Response response_status = getServiceResponse("status_of_job_url" + "/" + kpiJobId, ooTestutil.kpiprovideHeaders_2());
		isEqual("Not valid response for Start Job", 200, response_status.statusCode());

		JsonPath jsonPath_status = new JsonPath(response_status.asString());
		String status = jsonPath_status.getString("status");
		String message = jsonPath_status.getString("message");
		String jobId = jsonPath_status.getString("jobId");
		String runtimeJobId_status = jsonPath_status.getString("runtimeJobId");

		System.out.println("+++status== " + status);
		System.out.println("+++message== " + message);
		System.out.println("+++jobId== " + jobId);
		System.out.println("+++runtimeJobId_status== " + runtimeJobId_status);
		ooTestutil.printnewLine();


		Thread.sleep(30000);

		if(status.equalsIgnoreCase("Running"))
		{
			System.out.println("*****************Post data point into Kafka producer*******************");
			ooTestutil.printnewLine();

			// ****************Post data point to Kafka Topic*************************************************//
			Thread.sleep(30000);


			setSysProperty("setTagName", "OO_Tag_TURBINESPEED" + ooTestutil.generateRandomNumber());
			String d = "src/main/resources/payloads/data_files/data_ingestion_oostream_ooapmts.json";
			
			
			String dataIngestionFileJson = generateFile(d, "dataIngestionFile");

			File f1 = new File(dataIngestionFileJson);
			System.out.println("file path=" + f1.getAbsolutePath());
			String path1 = f1.getAbsolutePath().replace('\\', '/');
			String dataIngestionFileJsonAsString = FileUtils.readFileToString(new File(path1));


			//String dataIngestionFileJsonAsString = "src/main/resources/payloads/data_files/data_ingestion_ooapmts.json";
			Response response_producer =
					postServiceResponse(dataIngestionFileJsonAsString, "kafka_producer_url", ooTestutil.kpiprovideHeaders());

			System.out.println("+++ string of Tag Name == "
					+ com.jayway.jsonpath.JsonPath.read(response_producer.asString(), "$..name"));
			

			System.out.println("+++ string of timestamp == "
					+ com.jayway.jsonpath.JsonPath.read(response_producer.asString(), "$..datapoints[*][0]"));

			List<String> timestamp_producedData =
					com.jayway.jsonpath.JsonPath.read(response_producer.asString(), "$..datapoints[*][0]");
			List<String> value_producedData =
					com.jayway.jsonpath.JsonPath.read(response_producer.asString(), "$..datapoints[*][1]");
			String valuePosted = String.valueOf(value_producedData.get(0));
			
			List<String> list_of_tags =com.jayway.jsonpath.JsonPath.read(response_producer.asString(), "$..name");
			String tagNamePosted = String.valueOf(list_of_tags.get(0));
			

			System.out.println("+++timestamp_ingestedData== " + String.valueOf(timestamp_producedData.get(0)));
			System.out.println("+++value_producedData== " + String.valueOf(value_producedData.get(0)));
			isEqual("Data not Posted to Kafka Topic", 200, response_producer.getStatusCode());

			Thread.sleep(30000);

			// ***************Get data point from Kafka Topic*************************************************//
			ooTestutil.printnewLine();
			System.out.println("*****************GET DATA FROM KAFKA TOPIC******************");
			ooTestutil.printnewLine();
			Response response_consumer = getServiceResponse("kafka_consumer_url", ooTestutil.kpiprovideHeaders());
			// System.out.println("+++ response_consumer.asString() == " + response_consumer.asString());

			isEqual("Data not retrieved from Kafka topic", 200, response_consumer.statusCode());
			
			List<String> list_of_tags_consumed =com.jayway.jsonpath.JsonPath.read(response_producer.asString(), "$..name");
			String tagNameConsumed = String.valueOf(list_of_tags_consumed.get(0));


			System.out.println("+++ string of timestamp == "
					+ com.jayway.jsonpath.JsonPath.read(response_consumer.asString(), "$..datapoints[*][0]"));

			List<String> timestamp_consumerData =
					com.jayway.jsonpath.JsonPath.read(response_consumer.asString(), "$..datapoints[*][0]");
			System.out.println("+++timestamp_ingestedData== " + String.valueOf(timestamp_consumerData.get(0)));

			List<String> value_consumerData =
					com.jayway.jsonpath.JsonPath.read(response_consumer.asString(), "$..datapoints[*][1]");
			System.out.println("+++value_consumerData== " + String.valueOf(value_consumerData.get(0)));

			
			
			isEqual("Data not posted to kafka topic",true,tagNameConsumed.equalsIgnoreCase(tagNamePosted));
			
			// ***************Get data from APM TIME SERIES*************************************************//
			ooTestutil.printnewLine();
			System.out.println("*****************Get data from APM TIME SERIES******************");	

		
			Map<String, Object> queryParams = new LinkedHashMap<String, Object>();
	        queryParams.put("tagList", outputTag);
			
			Response response_apm_ts = getServiceResponse("timeSeriesGetDataURL",queryParams, ooTestutil.ApmProvideHeaders());
			System.out.println("+++ string of response_apm_ts == "+response_apm_ts.asString());
			isEqual("Data posted to kafka topic is not posted in APM TS",true,response_apm_ts.asString().contains(outputTag));
			isEqual("Data posted to kafka topic is not posted in APM TS",true,response_apm_ts.asString().contains("22226.11640963636"));
	
			// **********************************************************************************//
			

			System.out.println("*****************DELETE KPI JOB*******************");
			ooTestutil.printnewLine();

			System.out.println("+++ kpiDeleteUrl == " + uri);
			response1 = deleteServiceResponse("job_url" + "/" + kpiJobId, ooTestutil.kpiprovideHeaders());
			/*KNOWN BUG--> DELETE JOB NOT WORKING CONSISTENTLY*/
			//isEqual("Not valid response for Delete Kpi", 200, response1.statusCode());
			//isEqual("KPI JOB not killed", true, response1.asString().contains("KPI Job with Id "+kpiJobId+" is marked for deletion. Please check job status"));


			ooTestutil.printnewLine();
			Thread.sleep(60000);

			// *****************Status of JOB after Delete Job***************************************************//
			ooTestutil.printnewLine();
			System.out.println("*****************Status of JOB after Delete Job********************");
			ooTestutil.printnewLine();

			Response response_job = getServiceResponse("status_of_job_url" + "/" + kpiJobId, ooTestutil.kpiprovideHeaders_2());
			/*KNOWN BUG--> DELETE JOB NOT WORKING CONSISTENTLY*/
			//isEqual("Not valid response for Status Job after delete", 400, response_job.statusCode());
			// isEqual("KPI JOB not Deleted", true, response_job.asString().contains("Job "+kpiJobId+" not found"));


			JsonPath jsonPath_job = new JsonPath(response_job.asString());
			String status_job = jsonPath_job.getString("status");
			String message_job = jsonPath_job.getString("message");
			String jobId_job = jsonPath_job.getString("jobId");
			String runtimeJobId_job = jsonPath_job.getString("runtimeJobId");

			System.out.println("After Delete Job +++status== " + status_job);
			System.out.println("After Delete Job +++message== " + message_job);
			System.out.println("After Delete Job +++jobId== " + jobId_job);
			System.out.println("After Delete Job +++runtimeJobId_status== " + runtimeJobId_job);
			ooTestutil.printnewLine();


			Thread.sleep(30000);
			
		
		}

	
	}

	
	/*********************************************************************************************************/
	
	@Test(priority = 2, description = "testEnd2EndScenarioApmOOTsInputAndOutputProvider")
	@RallyInfo(UserStory = "US4776")
	public void testEnd2EndScenarioApmOOTsInputAndOutputProvider() throws Exception {

		ooTestutil.printnewLine();

		System.out.println("*****************Create KPI TEMPLATE*******************");
		ooTestutil.printnewLine();

		// *****************Create KPI TEMPLATE***************************************************//

		final String uri = getTestProperty("kpi_url");

		setSysProperty("setKpiName", "kpiname" + ooTestutil.generateRandomNumber());
		String kpiFile = "src/main/resources/payloads/kpi_templates/kpi_e2e_ooapmts_inputAndOutput.json";
		String kpiJson = generateFile(kpiFile, "kpi_e2e");

		File f = new File(kpiJson);
		System.out.println("file path=" + f.getAbsolutePath());

		String path = f.getAbsolutePath().replace('\\', '/');

		// String kpiJson = FileUtils.readFileToString(new
		// java.io.File("src/main/resources/payloads/finale2eScenarios/kpi_e2e.json"));
		String kpiJson_1 = FileUtils.readFileToString(new File(path));
		File analyticFile = new java.io.File("src/main/resources/payloads/kpi_analytics/analytic_ooapmts_outputAndinput.zip");

		MultiValueMap<String, Object> parameters = new LinkedMultiValueMap<String, Object>();
		parameters.add("uploadfile", new FileSystemResource(analyticFile));
		parameters.add("kpi", new ObjectMapper().readValue(kpiJson_1, KpiDetails.class));

		ResponseEntity<KpiDetails> response = restTemplate.exchange(uri, HttpMethod.POST,
				new HttpEntity<MultiValueMap<String, Object>>(parameters, ooTestutil.kpiprovideHeaders_1()),
				KpiDetails.class);

		Assert.assertEquals(response.getStatusCode(), HttpStatus.CREATED);
		Assert.assertTrue(response.getBody() instanceof KpiDetails);
		KpiDetails kpiDetails = response.getBody();
		kpi_id = kpiDetails.getId();
		System.out.println("------------->" + kpiDetails.getId());

		// *****************Create KPI JOB***************************************************//

		ooTestutil.printnewLine();
		System.out.println("*****************Create KPI JOB*******************");
		ooTestutil.printnewLine();

		setSysProperty("kpiReferenceId", String.valueOf(kpi_id));
		
		String outputTag = "TEST-ASSET-TYPE_KT.Tag_Length_Automation" + ooTestutil.generateRandomNumber();
		setSysProperty("setOutputTagName",outputTag);


		String kpijobFile = "src/main/resources/payloads/kpi_jobs/kpi_e2e_ooapmts_inputAndOutput_job.json";
		String kpijobJson = generateFile(kpijobFile, "kpi_job_e2e");
		System.out.println("+++ kpijobJson== " + kpijobJson);
		Response response1 = postServiceResponse(kpijobJson, "job_url", ooTestutil.kpiprovideHeaders());

		// System.out.println("+++ response.asString() == " +
		// response1.asString());
		JsonPath jsonPath = new JsonPath(response1.asString());
		kpiJobId = jsonPath.getString("id");
		System.out.println("+++ kpiJobId== " + kpiJobId);
		isEqual("Not valid response create KPI Job", 201, response1.statusCode());

		// *****************START JOB***************************************************//
		ooTestutil.printnewLine();
		System.out.println("*****************START KPI JOB*******************");
		ooTestutil.printnewLine();


		
		Response response2 = getServiceResponse("start_job_url" + "/" + kpiJobId, ooTestutil.kpiprovideHeaders_2());
		isEqual("Not valid response for Start Job", 200, response2.statusCode());

		// System.out.println("+++ response2.asString() == " +
		// response2.asString());
		JsonPath jsonPath1 = new JsonPath(response2.asString());
		String runtimeJobId = jsonPath1.getString("runtimeJobId");
		System.out.println("+++runtimeJobId== " + runtimeJobId);
		ooTestutil.printnewLine();
		

		// *****************Status of JOB***************************************************//
		ooTestutil.printnewLine();
		System.out.println("*****************Status of JOB********************");
		ooTestutil.printnewLine();

		Response response_status = getServiceResponse("status_of_job_url" + "/" + kpiJobId, ooTestutil.kpiprovideHeaders_2());
		isEqual("Not valid response for Start Job", 200, response_status.statusCode());

		JsonPath jsonPath_status = new JsonPath(response_status.asString());
		String status = jsonPath_status.getString("status");
		String message = jsonPath_status.getString("message");
		String jobId = jsonPath_status.getString("jobId");
		String runtimeJobId_status = jsonPath_status.getString("runtimeJobId");

		System.out.println("+++status== " + status);
		System.out.println("+++message== " + message);
		System.out.println("+++jobId== " + jobId);
		System.out.println("+++runtimeJobId_status== " + runtimeJobId_status);
		ooTestutil.printnewLine();


		Thread.sleep(30000);

		if(status.equalsIgnoreCase("Running"))
		{
			
			// ***************Get data from APM TIME SERIES*************************************************//
			ooTestutil.printnewLine();
			System.out.println("*****************Get data from APM TIME SERIES******************");	

		
			Map<String, Object> queryParams = new LinkedHashMap<String, Object>();
	        queryParams.put("tagList", outputTag);
			
			Response response_apm_ts = getServiceResponse("timeSeriesGetDataURL",queryParams, ooTestutil.ApmProvideHeaders());
			System.out.println("+++ string of response_apm_ts == "+response_apm_ts.asString());
			isEqual("Data posted to kafka topic is not posted in APM TS",true,response_apm_ts.asString().contains(outputTag));
			isEqual("Data posted to kafka topic is not posted in APM TS",true,response_apm_ts.asString().contains("14.44444444"));
	
			// **********************************************************************************//
			

			System.out.println("*****************DELETE KPI JOB*******************");
			ooTestutil.printnewLine();

			System.out.println("+++ kpiDeleteUrl == " + uri);
			response1 = deleteServiceResponse("job_url" + "/" + kpiJobId, ooTestutil.kpiprovideHeaders());
			/*KNOWN BUG--> DELETE JOB NOT WORKING CONSISTENTLY*/
			//isEqual("Not valid response for Delete Kpi", 200, response1.statusCode());
			//isEqual("KPI JOB not killed", true, response1.asString().contains("KPI Job with Id "+kpiJobId+" is marked for deletion. Please check job status"));


			ooTestutil.printnewLine();
			Thread.sleep(60000);

			// *****************Status of JOB after Delete Job***************************************************//
			ooTestutil.printnewLine();
			System.out.println("*****************Status of JOB after Delete Job********************");
			ooTestutil.printnewLine();

			Response response_job = getServiceResponse("status_of_job_url" + "/" + kpiJobId, ooTestutil.kpiprovideHeaders_2());
			/*KNOWN BUG--> DELETE JOB NOT WORKING CONSISTENTLY*/
			//isEqual("Not valid response for Status Job after delete", 400, response_job.statusCode());
			// isEqual("KPI JOB not Deleted", true, response_job.asString().contains("Job "+kpiJobId+" not found"));


			JsonPath jsonPath_job = new JsonPath(response_job.asString());
			String status_job = jsonPath_job.getString("status");
			String message_job = jsonPath_job.getString("message");
			String jobId_job = jsonPath_job.getString("jobId");
			String runtimeJobId_job = jsonPath_job.getString("runtimeJobId");

			System.out.println("After Delete Job +++status== " + status_job);
			System.out.println("After Delete Job +++message== " + message_job);
			System.out.println("After Delete Job +++jobId== " + jobId_job);
			System.out.println("After Delete Job +++runtimeJobId_status== " + runtimeJobId_job);
			ooTestutil.printnewLine();


			Thread.sleep(30000);
			
		
		}

	
	}

	
	

	/*********************************************************************************************************/
	//@Test(priority = 3, description = "testEnd2EndScenariosAttributes")
	@RallyInfo(UserStory = "DE9255")
	public void testEnd2EndScenariosAttributes() throws Exception {

		ooTestutil.printnewLine();

		// Input tags:OO_Tag_Temperature_ID281
		// Output tags:OO_Tag_Temperature_Demo

		System.out.println("*****************Create KPI TEMPLATE*******************");
		ooTestutil.printnewLine();

		// *****************Create KPI TEMPLATE***************************************************//

		final String uri = getTestProperty("kpi_url");

		setSysProperty("setKpiName", "kpiname" + ooTestutil.generateRandomNumber());
		String kpiFile = "src/main/resources/payloads/kpi_templates/kpi_e2e_streamInput.json";
		String kpiJson = generateFile(kpiFile, "kpi_e2e");

		File f = new File(kpiJson);
		System.out.println("file path=" + f.getAbsolutePath());

		String path = f.getAbsolutePath().replace('\\', '/');


		String kpiJson_1 = FileUtils.readFileToString(new File(path));
		File analyticFile = new java.io.File(
				"src/main/resources/payloads/kpi_analytics/attributes_linda.zip");

		MultiValueMap<String, Object> parameters = new LinkedMultiValueMap<String, Object>();
		parameters.add("uploadfile", new FileSystemResource(analyticFile));
		parameters.add("kpi", new ObjectMapper().readValue(kpiJson_1, KpiDetails.class));

		ResponseEntity<KpiDetails> response = restTemplate.exchange(uri, HttpMethod.POST,
				new HttpEntity<MultiValueMap<String, Object>>(parameters, ooTestutil.kpiprovideHeaders_1()),
				KpiDetails.class);

		Assert.assertEquals(response.getStatusCode(), HttpStatus.CREATED);
		Assert.assertTrue(response.getBody() instanceof KpiDetails);
		KpiDetails kpiDetails = response.getBody();
		// System.out.println("+++ response.asString() == " + response.toString());
		kpi_id = kpiDetails.getId();
		System.out.println("------------->" + kpiDetails.getId());

		// *****************Create KPI JOB***************************************************//

		ooTestutil.printnewLine();
		System.out.println("*****************Create KPI JOB*******************");
		ooTestutil.printnewLine();

		setSysProperty("kpiReferenceId", String.valueOf(kpi_id));

		String kpijobFile = "src/main/resources/payloads/kpi_jobs/kpi_e2e_job_tsstream.json";
		String kpijobJson = generateFile(kpijobFile, "kpi_job_e2e");
		System.out.println("+++ kpijobJson== " + kpijobJson);
		Response response1 = postServiceResponse(kpijobJson, "job_url", ooTestutil.kpiprovideHeaders());

		// System.out.println("+++ response.asString() == " +
		// response1.asString());
		JsonPath jsonPath = new JsonPath(response1.asString());
		kpiJobId = jsonPath.getString("id");
		System.out.println("+++ kpiJobId== " + kpiJobId);
		isEqual("Not valid response create KPI Job", 201, response1.statusCode());

		// *****************START JOB***************************************************//
		ooTestutil.printnewLine();
		System.out.println("*****************START KPI JOB*******************");
		ooTestutil.printnewLine();

		Response response2 = getServiceResponse("start_job_url" + "/" + kpiJobId, ooTestutil.kpiprovideHeaders_2());
		isEqual("Not valid response for Start Job", 200, response2.statusCode());

		// System.out.println("+++ response2.asString() == " + response2.asString());
		JsonPath jsonPath1 = new JsonPath(response2.asString());
		String runtimeJobId = jsonPath1.getString("runtimeJobId");
		System.out.println("+++runtimeJobId== " + runtimeJobId);
		ooTestutil.printnewLine();

		// *****************Status of JOB***************************************************//
		ooTestutil.printnewLine();
		System.out.println("*****************Status of JOB********************");
		ooTestutil.printnewLine();

		Response response_status = getServiceResponse("status_of_job_url" + "/" + kpiJobId, ooTestutil.kpiprovideHeaders_2());
		isEqual("Not valid response for Start Job", 200, response_status.statusCode());

		JsonPath jsonPath_status = new JsonPath(response_status.asString());
		String status = jsonPath_status.getString("status");
		String message = jsonPath_status.getString("message");
		String jobId = jsonPath_status.getString("jobId");
		String runtimeJobId_status = jsonPath_status.getString("runtimeJobId");

		System.out.println("+++status== " + status);
		System.out.println("+++message== " + message);
		System.out.println("+++jobId== " + jobId);
		System.out.println("+++runtimeJobId_status== " + runtimeJobId_status);
		ooTestutil.printnewLine();

		if(status.equalsIgnoreCase("Running"))
		{
			// ****************Post data point to Kafka Topic*************************************************//
			Thread.sleep(30000);
			ooTestutil.printnewLine();
			System.out.println("*****************POST DATA TO KAFKA TOPIC******************");
			ooTestutil.printnewLine();

			String dataingestionFile = "src/main/resources/payloads/data_files/data_ingestion_tsstream_attributes.json";
			Response response_producer =
					postServiceResponse(dataingestionFile, "kafka_producer_url", ooTestutil.kpiprovideHeaders());

			// System.out.println("+++ response_producer.asString() == " + response_producer.asString());

			System.out.println("+++ string of timestamp == "
					+ com.jayway.jsonpath.JsonPath.read(response_producer.asString(), "$..datapoints[*][0]"));

			List<String> timestamp_producedData =
					com.jayway.jsonpath.JsonPath.read(response_producer.asString(), "$..datapoints[*][0]");
			List<String> value_producedData =
					com.jayway.jsonpath.JsonPath.read(response_producer.asString(), "$..datapoints[*][1]");

			System.out.println("+++timestamp_ingestedData== " + String.valueOf(timestamp_producedData.get(0)));
			System.out.println("+++value_producedData== " + String.valueOf(value_producedData.get(0)));
			isEqual("Data not Posted to Kafka Topic", 200, response_producer.getStatusCode());

			Thread.sleep(30000);

			// ***************Get data point from Kafka Topic*************************************************//
			ooTestutil.printnewLine();
			System.out.println("*****************GET DATA FROM KAFKA TOPIC******************");
			ooTestutil.printnewLine();
			Response response_consumer = getServiceResponse("kafka_consumer_url", ooTestutil.kpiprovideHeaders());
			// System.out.println("+++ response_consumer.asString() == " + response_consumer.asString());

			isEqual("Data not retrieved from Kafka topic", 200, response_consumer.statusCode());

			System.out.println("+++ string of timestamp == "
					+ com.jayway.jsonpath.JsonPath.read(response_consumer.asString(), "$..datapoints[*][0]"));

			List<String> timestamp_consumerData =
					com.jayway.jsonpath.JsonPath.read(response_consumer.asString(), "$..datapoints[*][0]");
			System.out.println("+++timestamp_ingestedData== " + String.valueOf(timestamp_consumerData.get(0)));

			List<String> value_consumerData =
					com.jayway.jsonpath.JsonPath.read(response_consumer.asString(), "$..datapoints[*][1]");
			System.out.println("+++value_consumerData== " + String.valueOf(value_consumerData.get(0)));

			// ****************Assert input and output data points *************************************************//

			Thread.sleep(30000);
			// isEqual("Raw data point was not calculated", String.valueOf(timestamp_producedData.get(0)),
			// String.valueOf(timestamp_consumerData.get(0)));
			if (String.valueOf(value_producedData.get(0)) != null && String.valueOf(value_consumerData.get(0)) != null) {
				Double value_ingested = Double.parseDouble(String.valueOf(value_producedData.get(0)));
				Double value_consumed = Double.parseDouble(String.valueOf(value_consumerData.get(0)));
				Assert.assertTrue(!value_ingested.equals(value_consumed),
						"Raw data point was not calculated--> raw and calculated data points-->" + value_ingested
						+ "   " + value_consumed);
				isEqual("Raw data point was not calculated", 6878.651281927272, value_consumed);
			}

			// ****************Stop the Job*************************************************//

			/*Thread.sleep(30000);
			ooTestutil.printnewLine();
			System.out.println("*****************STOP KPI JOB*******************");
			ooTestutil.printnewLine();

			Response response3 = getServiceResponse("stop_job_url" + "/" + kpiJobId, ooTestutil.kpiprovideHeaders_2());
			isEqual("Not valid response for Start Job", 200, response3.statusCode());

			// System.out.println("+++ response3.asString() == " + response3.asString());
			isEqual("KPI JOB not killed", true, response3.asString().contains("KILLED"));
			isEqual("KPI JOB not killed", 200, response3.statusCode());

			// {"status":"KILLED","message":null,"jobId":"149","runtimeJobId":"78caf8a9-671f-48c8-bb17-3757735a77a1"}

			ooTestutil.printnewLine();*/
			// **********************************************************************************//

			/*ooTestutil.printnewLine();
			System.out.println("*****************DELETE KPI*******************");
			ooTestutil.printnewLine();

			System.out.println("+++ kpiDeleteUrl == " + uri);
			response1 = deleteServiceResponse("kpi_url" + "/" + kpi_id, ooTestutil.kpiprovideHeaders());
			// System.out.println("+++ response.asString() == " + response1.asString());
			isEqual("Not valid response for Delete Kpi", 200, response1.statusCode());

			ooTestutil.printnewLine();

			Thread.sleep(30000);
			ooTestutil.printnewLine();*/
			System.out.println("*****************DELETE KPI JOB*******************");
			ooTestutil.printnewLine();

			System.out.println("+++ kpiDeleteUrl == " + uri);
			response1 = deleteServiceResponse("job_url" + "/" + kpiJobId, ooTestutil.kpiprovideHeaders());
			// System.out.println("+++ response.asString() == " + response1.asString());
			isEqual("Not valid response for Delete Kpi", 200, response1.statusCode());
			isEqual("KPI JOB not killed", true, response1.asString().contains("KPI Job with Id "+kpiJobId+" is marked for deletion. Please check job status"));
	

			ooTestutil.printnewLine();
			Thread.sleep(60000);

			// *****************Status of JOB after Delete Job***************************************************//
			ooTestutil.printnewLine();
			System.out.println("*****************Status of JOB after Delete Job********************");
			ooTestutil.printnewLine();

			Response response_job = getServiceResponse("status_of_job_url" + "/" + kpiJobId, ooTestutil.kpiprovideHeaders_2());
			isEqual("Not valid response for Status Job after delete", 400, response_job.statusCode());
            isEqual("KPI JOB not Deleted", true, response_job.asString().contains("Job "+kpiJobId+" not found"));

			//RESPONSE --> {"message":"Job 296 not found."}
			// System.out.println("+++ response2.asString() == " + response2.asString());
			JsonPath jsonPath_job = new JsonPath(response_job.asString());
			String status_job = jsonPath_job.getString("status");
			String message_job = jsonPath_job.getString("message");
			String jobId_job = jsonPath_job.getString("jobId");
			String runtimeJobId_job = jsonPath_job.getString("runtimeJobId");

			System.out.println("After Delete Job +++status== " + status_job);
			System.out.println("After Delete Job +++message== " + message_job);
			System.out.println("After Delete Job +++jobId== " + jobId_job);
			System.out.println("After Delete Job +++runtimeJobId_status== " + runtimeJobId_job);
			ooTestutil.printnewLine();


			Thread.sleep(30000);
		}

	}

	/*
	 * *****************************************************************************************************************
	 * **
	 * 
	 * File based Tests cannot be run on Cluster. Following two tests are for local validation. in runtime.properties
	 * add following keys: apm.assetFileUrl = [absolutepath on machine (repository oo-jobruntime)]/asset/asset.json
	 * apm.tsFileUrl= [absolutepath]/data/ts_apm_to_ingestion.json Path is were file is located.
	 ******************************************************************************************************************* 
	 */
	// @Test(priority = 1, description = "testEnd2EndScenariosFileBasedAssetDataProviders")
	@RallyInfo(UserStory = "US32775")
	public void testEnd2EndScenariosFileBasedAssetDataProviders() throws Exception {

		ooTestutil.printnewLine();

		// Input tags:OO_Tag_Temperature_ID281
		// Output tags:OO_Tag_Temperature_Demo

		System.out.println("*****************Create KPI TEMPLATE*******************");
		ooTestutil.printnewLine();

		// *****************Create KPI TEMPLATE***************************************************//

		final String uri = getTestProperty("kpi_url");

		setSysProperty("setKpiName", "kpiname" + ooTestutil.generateRandomNumber());
		String kpiFile = "src/main/resources/payloads/kpi_templates/kpi_e2e_file_based_asset.json";
		String kpiJson = generateFile(kpiFile, "kpi_e2e");

		File f = new File(kpiJson);
		System.out.println("file path=" + f.getAbsolutePath());

		String path = f.getAbsolutePath().replace('\\', '/');

		// String kpiJson = FileUtils.readFileToString(new
		// java.io.File("src/main/resources/payloads/finale2eScenarios/kpi_e2e.json"));
		String kpiJson_1 = FileUtils.readFileToString(new File(path));
		File analyticFile =
				new java.io.File("src/main/resources/payloads/kpi_analytics/kpi_analytic_asset_ts_int.zip");

		MultiValueMap<String, Object> parameters = new LinkedMultiValueMap<String, Object>();
		parameters.add("uploadfile", new FileSystemResource(analyticFile));
		parameters.add("kpi", new ObjectMapper().readValue(kpiJson_1, KpiDetails.class));

		ResponseEntity<KpiDetails> response = restTemplate.exchange(uri, HttpMethod.POST,
				new HttpEntity<MultiValueMap<String, Object>>(parameters, ooTestutil.kpiprovideHeaders_1()),
				KpiDetails.class);

		Assert.assertEquals(response.getStatusCode(), HttpStatus.CREATED);
		Assert.assertTrue(response.getBody() instanceof KpiDetails);
		KpiDetails kpiDetails = response.getBody();
		// System.out.println("+++ response.asString() == " + response.toString());
		kpi_id = kpiDetails.getId();
		System.out.println("------------->" + kpiDetails.getId());

		// *****************Create KPI JOB***************************************************//

		ooTestutil.printnewLine();
		System.out.println("*****************Create KPI JOB*******************");
		ooTestutil.printnewLine();

		setSysProperty("kpiReferenceId", String.valueOf(kpi_id));

		String kpijobFile = "src/main/resources/payloads/kpi_jobs/kpi_e2e_file_based_asset_job.json";
		String kpijobJson = generateFile(kpijobFile, "kpi_job_e2e");
		System.out.println("+++ kpijobJson== " + kpijobJson);
		Response response1 = postServiceResponse(kpijobJson, "job_url", ooTestutil.kpiprovideHeaders());

		// System.out.println("+++ response.asString() == " +
		// response1.asString());
		JsonPath jsonPath = new JsonPath(response1.asString());
		kpiJobId = jsonPath.getString("id");
		System.out.println("+++ kpiJobId== " + kpiJobId);
		isEqual("Not valid response create KPI Job", 201, response1.statusCode());

		// *****************START JOB***************************************************//
		ooTestutil.printnewLine();
		System.out.println("*****************START KPI JOB*******************");
		ooTestutil.printnewLine();

		Response response2 = getServiceResponse("start_job_url" + "/" + kpiJobId, ooTestutil.kpiprovideHeaders_2());
		isEqual("Not valid response for Start Job", 200, response2.statusCode());

		// System.out.println("+++ response2.asString() == " + response2.asString());
		JsonPath jsonPath1 = new JsonPath(response2.asString());
		String runtimeJobId = jsonPath1.getString("runtimeJobId");
		System.out.println("+++runtimeJobId== " + runtimeJobId);
		ooTestutil.printnewLine();


		Thread.sleep(30000);


	}

	/********************************************************************************************************************/

	// @Test(priority = 2, description = "testEnd2EndScenarioFileBasedTsProvider")
	@RallyInfo(UserStory = "US4776")
	public void testEnd2EndScenarioFileBasedTsProvider() throws Exception {

		ooTestutil.printnewLine();

		// Input tags: OO_Tag_Temperature_ID281
		// Output tags:OO_Tag_Temperature_Demo_tsstream

		System.out.println("*****************Create KPI TEMPLATE*******************");
		ooTestutil.printnewLine();

		// *****************Create KPI TEMPLATE***************************************************//

		final String uri = getTestProperty("kpi_url");

		setSysProperty("setKpiName", "kpiname" + ooTestutil.generateRandomNumber());
		String kpiFile = "src/main/resources/payloads/kpi_templates/kpi_e2e_file_based_ts.json";
		String kpiJson = generateFile(kpiFile, "kpi_e2e");

		File f = new File(kpiJson);
		System.out.println("file path=" + f.getAbsolutePath());

		String path = f.getAbsolutePath().replace('\\', '/');

		// String kpiJson = FileUtils.readFileToString(new
		// java.io.File("src/main/resources/payloads/finale2eScenarios/kpi_e2e.json"));
		String kpiJson_1 = FileUtils.readFileToString(new File(path));
		File analyticFile = new java.io.File("src/main/resources/payloads/kpi_analytics/analytic_oots1.zip");

		MultiValueMap<String, Object> parameters = new LinkedMultiValueMap<String, Object>();
		parameters.add("uploadfile", new FileSystemResource(analyticFile));
		parameters.add("kpi", new ObjectMapper().readValue(kpiJson_1, KpiDetails.class));

		ResponseEntity<KpiDetails> response = restTemplate.exchange(uri, HttpMethod.POST,
				new HttpEntity<MultiValueMap<String, Object>>(parameters, ooTestutil.kpiprovideHeaders_1()),
				KpiDetails.class);

		Assert.assertEquals(response.getStatusCode(), HttpStatus.CREATED);
		Assert.assertTrue(response.getBody() instanceof KpiDetails);
		KpiDetails kpiDetails = response.getBody();
		kpi_id = kpiDetails.getId();
		System.out.println("------------->" + kpiDetails.getId());

		// *****************Create KPI JOB***************************************************//

		ooTestutil.printnewLine();
		System.out.println("*****************Create KPI JOB*******************");
		ooTestutil.printnewLine();

		setSysProperty("kpiReferenceId", String.valueOf(kpi_id));

		String kpijobFile = "src/main/resources/payloads/kpi_jobs/kpi_e2e_file_based_ts_job.json";
		String kpijobJson = generateFile(kpijobFile, "kpi_job_e2e");
		System.out.println("+++ kpijobJson== " + kpijobJson);
		Response response1 = postServiceResponse(kpijobJson, "job_url", ooTestutil.kpiprovideHeaders());

		// System.out.println("+++ response.asString() == " +
		// response1.asString());
		JsonPath jsonPath = new JsonPath(response1.asString());
		kpiJobId = jsonPath.getString("id");
		System.out.println("+++ kpiJobId== " + kpiJobId);
		isEqual("Not valid response create KPI Job", 201, response1.statusCode());

		// *****************START JOB***************************************************//
		ooTestutil.printnewLine();
		System.out.println("*****************START KPI JOB*******************");
		ooTestutil.printnewLine();

		Response response2 = getServiceResponse("start_job_url" + "/" + kpiJobId, ooTestutil.kpiprovideHeaders_2());
		isEqual("Not valid response for Start Job", 200, response2.statusCode());

		// System.out.println("+++ response2.asString() == " +
		// response2.asString());
		JsonPath jsonPath1 = new JsonPath(response2.asString());
		String runtimeJobId = jsonPath1.getString("runtimeJobId");
		System.out.println("+++runtimeJobId== " + runtimeJobId);
		ooTestutil.printnewLine();

	}

	/********************************************************************************************************************/


	// @Test(priority = 3, description = "testEnd2EndScenariosWindmillAnalyticTest")
	public void testEnd2EndScenariosWindmillAnalyticTest() throws Exception {

		ooTestutil.printnewLine();

		System.out.println("*****************Create KPI TEMPLATE*******************");
		ooTestutil.printnewLine();

		// *****************Create KPI TEMPLATE***************************************************//

		final String uri = getTestProperty("kpi_url");

		setSysProperty("setKpiName", "kpiname" + ooTestutil.generateRandomNumber());
		String kpiFile = "src/main/resources/payloads/kpi_templates/kpi_e2e.json";
		String kpiJson = generateFile(kpiFile, "kpi_e2e");

		File f = new File(kpiJson);
		System.out.println("file path=" + f.getAbsolutePath());

		String path = f.getAbsolutePath().replace('\\', '/');

		// String kpiJson = FileUtils.readFileToString(new
		// java.io.File("src/main/resources/payloads/finale2eScenarios/kpi_e2e.json"));
		String kpiJson_1 = FileUtils.readFileToString(new File(path));
		File analyticFile = new java.io.File("src/main/resources/payloads/kpi_analytics/WindmillAnalytic.zip");

		MultiValueMap<String, Object> parameters = new LinkedMultiValueMap<String, Object>();
		parameters.add("uploadfile", new FileSystemResource(analyticFile));
		parameters.add("kpi", new ObjectMapper().readValue(kpiJson_1, KpiDetails.class));

		ResponseEntity<KpiDetails> response = restTemplate.exchange(uri, HttpMethod.POST,
				new HttpEntity<MultiValueMap<String, Object>>(parameters, ooTestutil.kpiprovideHeaders_1()),
				KpiDetails.class);

		Assert.assertEquals(response.getStatusCode(), HttpStatus.CREATED);
		Assert.assertTrue(response.getBody() instanceof KpiDetails);
		KpiDetails kpiDetails = response.getBody();
		kpi_id = kpiDetails.getId();
		System.out.println("------------->" + kpiDetails.getId());

		// *****************Create KPI JOB***************************************************//

		ooTestutil.printnewLine();
		System.out.println("*****************Create KPI JOB*******************");
		ooTestutil.printnewLine();

		setSysProperty("kpiReferenceId", String.valueOf(kpi_id));

		String kpijobFile = "src/main/resources/payloads/kpi_jobs/kpi_e2e_job.json";
		String kpijobJson = generateFile(kpijobFile, "kpi_job_e2e");
		System.out.println("+++ kpijobJson== " + kpijobJson);
		Response response1 = postServiceResponse(kpijobJson, "job_url", ooTestutil.kpiprovideHeaders());

		// System.out.println("+++ response.asString() == " +
		// response1.asString());
		JsonPath jsonPath = new JsonPath(response1.asString());
		kpiJobId = jsonPath.getString("id");
		System.out.println("+++ kpiJobId== " + kpiJobId);
		isEqual("Not valid response create KPI Job", 201, response1.statusCode());

		// *****************START JOB***************************************************//
		ooTestutil.printnewLine();
		System.out.println("*****************START KPI JOB*******************");
		ooTestutil.printnewLine();

		Response response2 = getServiceResponse("start_job_url" + "/" + kpiJobId, ooTestutil.kpiprovideHeaders_2());
		isEqual("Not valid response for Start Job", 200, response2.statusCode());

		// System.out.println("+++ response2.asString() == " +
		// response2.asString());
		JsonPath jsonPath1 = new JsonPath(response2.asString());
		String runtimeJobId = jsonPath1.getString("runtimeJobId");
		System.out.println("+++runtimeJobId== " + runtimeJobId);
		ooTestutil.printnewLine();



		// ****************Stop the Job*************************************************//
		ooTestutil.printnewLine();
		System.out.println("*****************STOP KPI JOB*******************");
		ooTestutil.printnewLine();

		Response response3 = getServiceResponse("stop_job_url" + "/" + kpiJobId, ooTestutil.kpiprovideHeaders_2());
		isEqual("Not valid response for Start Job", 200, response3.statusCode());

		// System.out.println("+++ response2.asString() == " + response3.asString());
		isEqual("KPI JOB not killed", true, response3.asString().contains("KILLED"));
		isEqual("Not valid response create KPI Job", 200, response3.statusCode());

		ooTestutil.printnewLine();
		// *****************Delete KPI***************************************************//

		ooTestutil.printnewLine();

		System.out.println("+++ kpiDeleteUrl == " + uri);
		response1 = deleteServiceResponse("kpi_url" + "/" + kpi_id, ooTestutil.kpiprovideHeaders());
		// System.out.println("+++ response.asString() == " + response1.asString());
		isEqual("Not valid response for Delete Kpi", 200, response1.statusCode());

		ooTestutil.printnewLine();
		Thread.sleep(30000);

	}
	/********************************************************************************************************************/
	@AfterTest
	public void afterTest() {}

	@BeforeSuite
	public void beforeSuite() {

	}

	@AfterSuite
	public void afterSuite() {}
}

package com.ge.automation.OO;

import java.time.Instant;
import java.util.LinkedHashMap;
import java.util.Map;
import java.util.Properties;

import org.springframework.boot.test.TestRestTemplate;
import org.springframework.web.client.RestTemplate;
import org.testng.Assert;
import org.testng.annotations.AfterClass;
import org.testng.annotations.AfterMethod;
import org.testng.annotations.AfterSuite;
import org.testng.annotations.AfterTest;
import org.testng.annotations.BeforeClass;
import org.testng.annotations.BeforeMethod;
import org.testng.annotations.BeforeSuite;
import org.testng.annotations.BeforeTest;
import org.testng.annotations.Test;

import com.ge.microtester.common.utils.RestAssuredUtil;
import com.ge.microtester.rally.RallyInfo;
import com.jayway.restassured.response.Response;

@RallyInfo(ProjectName = "APM Super Optimo")
public class OOe2eScenariosNegativeTests_python extends RestAssuredUtil {

	static String jsonfileName;
	Properties configFile = new Properties();
	String truncateDateTime[];
	String tagName;
	String proxyHost;
	String proxyPort;
	Response responseBody;
	String kpiid;
	String kpiJobId;
	String dataSourceId;
	long kpi_id;
	long kpi_id1;
	String apmTSforIngestionPath;
	boolean apmIngestionDynamicTag;
	String kpiTemplateJsonPath;
	String kpiTemplateAnalyticPath;
	String kpiJobJsonPath;
	String dataIngestionFilePath;
	String inputTag;
	String outputTag;
	String expectedValue;
	String expectedJobStatus;
	boolean createKpiJobWithTag;
	String apmTsUrl = "";
	//"operation=raw&startTime=2015-12-31T00:28:03.000&sampleCount=40&useOnlyGoodData=true&tagList=${var:setInputTagName}";
	String path = "src/main/resources/payloadsEventHub";


	public OOTestUtil ooTestutil = new OOTestUtil();
	RestTemplate restTemplate = new TestRestTemplate();
	// Generating Query Params
	Map<String, Object> values = new LinkedHashMap<String, Object>();

	@BeforeMethod
	public void beforeMethod() {}

	@AfterMethod
	public void afterMethod() {}

	@BeforeClass
	public void beforeClass() {

		System.getProperties().put("proxySet", "true");
		System.getProperties().put("http.proxyHost", "sjc1intproxy01.crd.ge.com");
		System.getProperties().put("http.proxyPort", "8080");
		System.getProperties().put("https.proxyHost", "sjc1intproxy01.crd.ge.com");
		System.getProperties().put("https.proxyPort", "8080");
		//getServiceResponse("alert_profile_base_url");
		setSysProperty("currentTimeStamp", "" + getCurrentTimestamp());// ${sys:currentTimeStamp}

	}// end of beforeClass

	@AfterClass
	public void afterClass() {}

	@BeforeTest
	public void beforeTest() {

	}// end of beforeTest


	/**************************************************************************************************/
	@Test(priority = 1, description = "testE2E_ApmInputs_ApmOutput_IncorrectApmTSUrlInKpiJob")
	@RallyInfo(UserStory = "US81368")
	public void testE2E_ApmInputs_ApmOutput_IncorrectApmTSUrlInKpiJob() throws Exception {

		apmTSforIngestionPath = path+"/data_files/data_ingestion_common.json";
		kpiTemplateJsonPath  = path+"/kpi_templates/kpi_e2e_ooapmts_inputAndOutput_python.json" ;
		kpiTemplateAnalyticPath = path+"/kpi_analytics_1/kpiapmtspy1.zip";
		kpiJobJsonPath = path+"/kpi_jobs/kpiJob_common_python.json";
		dataIngestionFilePath = "";
		inputTag = "OO_Tag_Temperature_ID13";
		outputTag = "OO_Tag_Temperature_ID14";
		expectedValue = "";
		expectedJobStatus = "ERROR";
		apmTsUrl = "operation=IncorrectOne&startTime=2015-12-31T00:28:03.000&sampleCount=40&useOnlyGoodData=true&tagList="+inputTag;
		String asset_filter="assets=sourceKey%3DOO-CA-SIMUL-ASSET-ID1&tags=sourceKeys%3DOO_Tag_Temperature_ID1";
		setSysProperty("asset_filter", asset_filter);
		//ingest test data into apm time series
		ooTestutil.postRandomDataPointToAPMTimeSeries(apmTSforIngestionPath
				,inputTag);



		//create kpi template
		kpi_id = ooTestutil.createKpiTemplate(kpiTemplateJsonPath, 
				kpiTemplateAnalyticPath);
		

		//create kpi job
		kpiJobId = ooTestutil.createKpiJobWithNoRandomBothInputAndOutputTag(kpiJobJsonPath
				,kpi_id,outputTag,inputTag,apmTsUrl);
	

		//start kpi job
		ooTestutil.startKpiJobTwice(kpiJobId);

		//get Status of the Job
		String status = ooTestutil.getStatusOfJob(kpiJobId);
	

		isEqual("Job should end up in error"+status,status,"ERROR");

		//get Status of the Job
		String message = ooTestutil.getMessageOfJob(kpiJobId);

		isEqual("Error message is not matching"+message,message.contains("FAILED"),true);


	}

	/**************************************************************************************************/
	@Test(priority = 1, description = "testE2E_ApmInputs_ApmOutput_AnalyticThrowsNPE")
	@RallyInfo(UserStory = "DE22848")
	public void testE2E_ApmInputs_ApmOutput_AnalyticThrowsNPE() throws Exception {

		apmTSforIngestionPath = path+"/data_files/data_ingestion_common.json";
		kpiTemplateJsonPath  = path+"/kpi_templates/kpi_e2e_ooapmts_inputAndOutput_python.json" ;
		kpiTemplateAnalyticPath = path+"/kpi_analytics_1/kpi_apmts_null.zip";
		kpiJobJsonPath = path+"/kpi_jobs/kpiJob_common_python.json";
		dataIngestionFilePath = "";
		inputTag = "OO_Tag_Temperature_ID15";
		outputTag = "OO_Tag_Temperature_ID16";
		expectedValue = "";
		expectedJobStatus = "ERROR";
		apmTsUrl = "operation=raw&startTime=2015-12-31T00:28:03.000&sampleCount=40&useOnlyGoodData=true&tagList="+inputTag;
		String asset_filter="assets=sourceKey%3DOO-CA-SIMUL-ASSET-ID1&tags=sourceKeys%3DOO_Tag_Temperature_ID15";
		setSysProperty("asset_filter", asset_filter);
		//ingest test data into apm time series
		ooTestutil.postRandomDataPointToAPMTimeSeries(apmTSforIngestionPath
				,inputTag);

		//create kpi template
		kpi_id = ooTestutil.createKpiTemplate(kpiTemplateJsonPath, 
				kpiTemplateAnalyticPath);
		

		//create kpi job
		kpiJobId = ooTestutil.createKpiJobWithNoRandomBothInputAndOutputTag(kpiJobJsonPath
				,kpi_id,outputTag,inputTag,apmTsUrl);
		

		//start kpi job
		ooTestutil.startKpiJobTwice(kpiJobId);

		//get Status of the Job
		String status = ooTestutil.getStatusOfJob(kpiJobId);
		


		isEqual("Job should end up in error"+status,status,"ERROR");

		//get Status of the Job
		String message = ooTestutil.getMessageOfJob(kpiJobId);
		//DEFECT WHERE WE ARE THROWING "SUCCESS" IS INCORRECT
		//isEqual("Error message is not matching"+message,message.contains("ConfigException$Missing"),true);


	}

	/**************************************************************************************************/
	@Test(priority = 1, description = "testE2E_ApmInputs_ApmOutput_IncorrectApmTSUrlInKpiJob")
	@RallyInfo(UserStory = "US81368")
	public void testE2E_ApmInputs_ApmOutput_SpecialCharsInUrlInKpiJob() throws Exception {

		apmTSforIngestionPath = path+"/data_files/data_ingestion_common.json";
		kpiTemplateJsonPath  = path+"/kpi_templates/kpi_e2e_ooapmts_inputAndOutput_python.json" ;
		kpiTemplateAnalyticPath = path+"/kpi_analytics_1/kpiapmtspy1.zip";
		kpiJobJsonPath = path+"/kpi_jobs/kpiJob_common_python.json";
		dataIngestionFilePath = "";
		inputTag = "OO_Tag_Temperature_ID17";
		outputTag = "OO_Tag_Temperature_ID18";
		expectedValue = "";
		expectedJobStatus = "ERROR";
		apmTsUrl = "operation=###$$%%&startTime=2015-12-31T00:28:03.000&sampleCount=40&useOnlyGoodData=true&tagList="+inputTag;
		String asset_filter="assets=sourceKey%3DOO-CA-SIMUL-ASSET-ID1&tags=sourceKeys%3DOO_Tag_Temperature_ID1";
		setSysProperty("asset_filter", asset_filter);
		//ingest test data into apm time series
		ooTestutil.postRandomDataPointToAPMTimeSeries(apmTSforIngestionPath
				,inputTag);

		//create kpi template
		kpi_id = ooTestutil.createKpiTemplate(kpiTemplateJsonPath, 
				kpiTemplateAnalyticPath);
		
		//create kpi job
		kpiJobId = ooTestutil.createKpiJobWithNoRandomBothInputAndOutputTag(kpiJobJsonPath
				,kpi_id,outputTag,inputTag,apmTsUrl);
	

		//start kpi job
		ooTestutil.startKpiJobTwice(kpiJobId);

		//get Status of the Job
		String status = ooTestutil.getStatusOfJob(kpiJobId);
	

		isEqual("Job should end up in error"+status,status,"ERROR");

		//get Status of the Job
		String message = ooTestutil.getMessageOfJob(kpiJobId);
	
		isEqual("Error message is not matching"+message,message.contains("FAILED"),true);

	}



	/*********************************************************************************************************/

	@Test(priority = 6, description = "testE2E_Asset_ApmTSInput_ApmTSOutput_Missing_Filter")
	@RallyInfo(UserStory = "US81368")
	public void testE2E_Asset_ApmTSInput_ApmTSOutput_Missing_Filter() throws Exception {



		String inputTag = "OO_Tag_Temperature_ID0";

		//create kpi template
		kpi_id = ooTestutil.createKpiTemplate(path+"/kpi_templates/kpi_e2e_asset_ooapmts_inputAndOutput.json", 
				//"src/main/resources/payloads/kpi_analytics/kpi_analytic_asset_ts_int.zip");

				path+"/kpi_analytics_1/kpiapmtspy1.zip");
		//Thread.sleep(10000);

		//create kpi job

		String asset_filter="assets=&tags=";
		setSysProperty("asset_filter", asset_filter);
		String language="PYTHON";
		setSysProperty("language", language);
		kpiJobId = ooTestutil.createKpiJobWithNoRandomBothInputAndOutputTag(path+"/kpi_jobs/kpi_e2e_asset_ooapmts_inputAndOutput_job_missing_filter.json"
				,kpi_id,"OO_Tag_Temperature_ID20",inputTag,"");
		//Thread.sleep(10000);

		//start kpi job
		String runtimeJobId = ooTestutil.startKpiJob(kpiJobId);

		String status =null;
		if(runtimeJobId == null)
		{
			runtimeJobId = ooTestutil.startKpiJob(kpiJobId);

		}
		Thread.sleep(30000);
		//get Status of the Job
		status = ooTestutil.getStatusOfJob(kpiJobId);
		if(runtimeJobId != null)
		{
			String message=ooTestutil.getMessageOfJob(kpiJobId);
			Assert.assertEquals(status, "ERROR","job should endup in error");
			Assert.assertEquals(message, "FAILED","job status message is not matching");


		}
		else
		{
			isEqual("Job not Started Successfully.Status of the JOB is --->"+status,true,false);
		}

	}

	/*********************************************************************************************************/

	@Test(priority = 6, description = "testE2E_Asset_ApmTSInput_ApmTSOutput_Missing_AssetNTags")
	@RallyInfo(UserStory = "US81368")
	public void testE2E_Asset_ApmTSInput_ApmTSOutput_Missing_AssetNTags() throws Exception {
		apmTSforIngestionPath = path+"/data_files/data_ingestion_common.json";
		kpiTemplateJsonPath  = path+"/kpi_templates/kpi_e2e_ooapmts_inputAndOutput_python.json" ;
		kpiTemplateAnalyticPath = path+"/kpi_analytics_1/kpiapmtspy1.zip";
		kpiJobJsonPath = path+"/kpi_jobs/kpiJob_common_python.json";
		dataIngestionFilePath = "";
		inputTag = "OO_Tag_Temperature_ID15";
		outputTag = "OO_Tag_Temperature_ID16";
		expectedValue = "";
		expectedJobStatus = "ERROR";
		apmTsUrl = "operation=raw&startTime=2015-12-31T00:28:03.000&sampleCount=40&useOnlyGoodData=true&tagList="+inputTag;
		String asset_filter="assets=&tags=";
		setSysProperty("asset_filter", asset_filter);


		//ingest test data into apm time series
		ooTestutil.postRandomDataPointToAPMTimeSeries(apmTSforIngestionPath
				,inputTag);



		//create kpi template
		kpi_id = ooTestutil.createKpiTemplate(kpiTemplateJsonPath, kpiTemplateAnalyticPath);
	

		//create kpi job
		kpiJobId = ooTestutil.createKpiJobWithNoRandomBothInputAndOutputTag(kpiJobJsonPath,kpi_id,outputTag,inputTag,apmTsUrl);
		


		//start kpi job
		String runtimeJobId = ooTestutil.startKpiJobTwice(kpiJobId);
		
		//get Status of the Job
		String status = ooTestutil.getStatusOfJob(kpiJobId);
		if(runtimeJobId != null)
		{
			String message=ooTestutil.getMessageOfJob(kpiJobId);
			Assert.assertEquals(status, "ERROR","job should endup in error");
			Assert.assertEquals(message, "FAILED","job status message is not matching");


		}
		else
		{
			isEqual("Job not Started Successfully.Status of the JOB is --->"+status,true,false);
		}

	}


	/*********************************************************************************************************/

	@Test(priority = 6, description = "testE2E_Asset_ApmTSInput_ApmTSOutput_SpecialChars_AssetNTags")
	@RallyInfo(UserStory = "US81368")
	public void testE2E_Asset_ApmTSInput_ApmTSOutput_SpecialChars_AssetNTags() throws Exception {

		apmTSforIngestionPath = path+"/data_files/data_ingestion_common.json";
		kpiTemplateJsonPath  = path+"/kpi_templates/kpi_e2e_ooapmts_inputAndOutput_python.json" ;
		kpiTemplateAnalyticPath = path+"/kpi_analytics_1/kpiapmtspy1.zip";
		kpiJobJsonPath = path+"/kpi_jobs/kpiJob_common_python.json";
		dataIngestionFilePath = "";
		inputTag = "OO_Tag_Temperature_ID15";
		outputTag = "OO_Tag_Temperature_ID16";
		expectedValue = "";
		expectedJobStatus = "ERROR";
		apmTsUrl = "operation=raw&startTime=2015-12-31T00:28:03.000&sampleCount=40&useOnlyGoodData=true&tagList="+inputTag;
		String asset_filter="assets=sourceKey%3DOO-CA-SIMUL-ASSET-ID1*%&tags=sourceKeys%3DOO_Tag_Temperature_ID0*%";
		setSysProperty("asset_filter", asset_filter);


		//ingest test data into apm time series
		ooTestutil.postRandomDataPointToAPMTimeSeries(apmTSforIngestionPath
				,inputTag);



		//create kpi template
		kpi_id = ooTestutil.createKpiTemplate(kpiTemplateJsonPath, kpiTemplateAnalyticPath);
		

		//create kpi job
		kpiJobId = ooTestutil.createKpiJobWithNoRandomBothInputAndOutputTag(kpiJobJsonPath,kpi_id,outputTag,inputTag,apmTsUrl);
		



		String runtimeJobId = ooTestutil.startKpiJobTwice(kpiJobId);

		
		//get Status of the Job
		String status = ooTestutil.getStatusOfJob(kpiJobId);
		if(runtimeJobId != null)
		{
			String message=ooTestutil.getMessageOfJob(kpiJobId);
			Assert.assertEquals(status, "ERROR","job should endup in error");
			Assert.assertTrue(message.contains("FAILED"),"job status message is not matching");


		}
		else
		{
			isEqual("Job not Started Successfully.Status of the JOB is --->"+status,true,false);
		}
	}



	/*********************************************************************************************************/

	@Test(priority = 6, description = "testE2E_Asset_ApmTSInput_ApmTSOutput_nonexisting_AssetNTags")
	@RallyInfo(UserStory = "US81368")
	public void testE2E_Asset_ApmTSInput_ApmTSOutput_nonexisting_AssetNTags() throws Exception {

		apmTSforIngestionPath = path+"/data_files/data_ingestion_common.json";
		kpiTemplateJsonPath  = path+"/kpi_templates/kpi_e2e_ooapmts_inputAndOutput_python.json" ;
		kpiTemplateAnalyticPath = path+"/kpi_analytics_1/kpiapmtspy1.zip";
		kpiJobJsonPath = path+"/kpi_jobs/kpiJob_common_python.json";
		dataIngestionFilePath = "";
		inputTag = "OO_Tag_Temperature_ID15";
		outputTag = "OO_Tag_Temperature_ID16";
		expectedValue = "";
		expectedJobStatus = "ERROR";
		apmTsUrl = "operation=raw&startTime=2015-12-31T00:28:03.000&sampleCount=40&useOnlyGoodData=true&tagList="+inputTag;
		String asset_filter="assets=sourceKey%3DOO-CA-SIMU&tags=sourceKeys%3DOO_Tag_Temperatur";
		setSysProperty("asset_filter", asset_filter);


		//ingest test data into apm time series
		ooTestutil.postRandomDataPointToAPMTimeSeries(apmTSforIngestionPath
				,inputTag);



		//create kpi template
		kpi_id = ooTestutil.createKpiTemplate(kpiTemplateJsonPath, kpiTemplateAnalyticPath);
		

		//create kpi job
		kpiJobId = ooTestutil.createKpiJobWithNoRandomBothInputAndOutputTag(kpiJobJsonPath,kpi_id,outputTag,inputTag,apmTsUrl);
		


		//start kpi job
		String runtimeJobId = ooTestutil.startKpiJobTwice(kpiJobId);

		String status =null;
		
		//get Status of the Job
		status = ooTestutil.getStatusOfJob(kpiJobId);
		if(runtimeJobId != null)
		{
			ooTestutil.getMessageOfJob(kpiJobId);
			Assert.assertEquals(status, "ERROR","job should endup in error");
			//Assert.assertEquals(message, "DataProviderError","job status message is not matching");


		}
		else
		{
			isEqual("Job not Started Successfully.Status of the JOB is --->"+status,true,false);
		}

	}
	/**************************************************************************************************/
	@Test(priority = 6, description = "testE2E_HDFS_Asset_ApmTSInput_ApmTSOutput_inValid_file")
	@RallyInfo(UserStory = "US81368")
	public void testE2E_HDFS_Asset_ApmTSInput_ApmTSOutput_inValid_file() throws Exception {

		apmTSforIngestionPath = path+"/data_files/data_ingestion_common.json";
		kpiTemplateJsonPath  = path+"/kpi_templates/kpi_e2e_ooapmts_inputAndOutput_python.json" ;
		kpiTemplateAnalyticPath = path+"/kpi_analytics_1/kpiapmtspy1.zip";
		kpiJobJsonPath = path+"/kpi_jobs/kpiJob_common_hdfs_python.json";
		dataIngestionFilePath = "";
		inputTag = "OO_Tag_Temperature_ID15";
		outputTag = "OO_Tag_Temperature_ID16";
		expectedValue = "";
		expectedJobStatus = "ERROR";
		apmTsUrl = "operation=raw&startTime=2015-12-31T00:28:03.000&sampleCount=40&useOnlyGoodData=true&tagList="+inputTag;

		String hdfs_asset_file="hdfs:///tmp/data/incorrect?assets=assets_basic.json&tags=tags_basic.json";
		String hdfs_ts_file="hdfs:///tmp/data/incorrect/ts_apm_iso.json";
		//String hdfs_asset_file="hdfs:///tmp/data?assets=assets_basic.json&tags=tags_basic.json";
		//String hdfs_ts_file="hdfs:///tmp/data/ts_apm_iso_small7.json";
		setSysProperty("hdfs_asset_file", hdfs_asset_file);
		setSysProperty("hdfs_ts_file", hdfs_ts_file);
		String language="PYTHON";
		setSysProperty("language", language);
		//ingest test data into apm time series
		ooTestutil.postRandomDataPointToAPMTimeSeries(apmTSforIngestionPath
				,inputTag);



		//create kpi template
		kpi_id = ooTestutil.createKpiTemplate(kpiTemplateJsonPath, kpiTemplateAnalyticPath);
		

		//create kpi job
		kpiJobId = ooTestutil.createKpiJobWithNoRandomBothInputAndOutputTag(kpiJobJsonPath,kpi_id,outputTag,inputTag,apmTsUrl);
		String status =null;

		Instant instant = Instant.now ();
		String timestamp=instant.toString();    	
		System.out.println("getCurrent timestamp="+timestamp);
		//start kpi job
		String runtimeJobId = ooTestutil.startKpiJobTwice(kpiJobId);
		
		if(runtimeJobId != null)
		{
			
			//get Status of the Job
			 status = ooTestutil.getStatusOfJob(kpiJobId);
			String message = ooTestutil.getMessageOfJob(kpiJobId);
			//get data from Apm time Series
			//String res=ooTestutil.getDataFromApmTimeSeriesWithTimeFilter("OO_Tag_Temperature_ID25", timestamp);	
			//isEqual("data not found in apm time series:",true,res.contains("132.528"));

			Assert.assertTrue(message.contains("FAILED")," message should contain error message");
			Assert.assertTrue(status.contains("ERROR"),"status should be ERROR");
		}
		else
		{
			isEqual("Job not Started Successfully.",true,false);
		}
	}
	/**************************************************************************************************/
	@Test(priority = 6, description = "testE2E_HDFS_Asset_ApmTSInput_ApmTSOutput_DifferentSchema")
	@RallyInfo(UserStory = "US81368")
	public void testE2E_HDFS_Asset_ApmTSInput_ApmTSOutput_DifferentSchema() throws Exception {
		apmTSforIngestionPath = path+"/data_files/data_ingestion_common.json";
		kpiTemplateJsonPath  = path+"/kpi_templates/kpi_e2e_ooapmts_inputAndOutput_python.json" ;
		kpiTemplateAnalyticPath = path+"/kpi_analytics_1/kpiapmtspy1.zip";
		kpiJobJsonPath = path+"/kpi_jobs/kpiJob_common_hdfs_python.json";
		dataIngestionFilePath = "";
		inputTag = "OO_Tag_Temperature_ID15";
		outputTag = "OO_Tag_Temperature_ID16";
		expectedValue = "";
		expectedJobStatus = "ERROR";
		apmTsUrl = "operation=raw&startTime=2015-12-31T00:28:03.000&sampleCount=40&useOnlyGoodData=true&tagList="+inputTag;
		String hdfs_asset_file="hdfs:///tmp/data?assets=data_file.csv&tags=tags_basic.json";
		String hdfs_ts_file="hdfs:///tmp/data/data_file.csv";
		setSysProperty("hdfs_asset_file", hdfs_asset_file);
		setSysProperty("hdfs_ts_file", hdfs_ts_file);
		String language="PYTHON";
		setSysProperty("language", language);
		//ingest test data into apm time series
		ooTestutil.postRandomDataPointToAPMTimeSeries(apmTSforIngestionPath
				,inputTag);



		//create kpi template
		kpi_id = ooTestutil.createKpiTemplate(kpiTemplateJsonPath, kpiTemplateAnalyticPath);
	

		//create kpi job
		kpiJobId = ooTestutil.createKpiJobWithNoRandomBothInputAndOutputTag(kpiJobJsonPath,kpi_id,outputTag,inputTag,apmTsUrl);
		



		//start kpi job
		String runtimeJobId = ooTestutil.startKpiJobTwice(kpiJobId);
		
		
		if(runtimeJobId != null)
		{
			//get Status of the Job
			String status = ooTestutil.getStatusOfJob(kpiJobId);
			String message = ooTestutil.getMessageOfJob(kpiJobId);

			Assert.assertTrue(message.contains("FAILED")," message should contain error message");
			Assert.assertTrue(status.contains("ERROR"),"status should be ERROR");
		}
		else
		{
			isEqual("Job not Started Successfully.",true,false);
		}
	}
	/**************************************************************************************************/

	@Test(priority = 6, description = "testE2E_HDFS_Asset_ApmTSInput_ApmTSOutput_nonexisting_files")
	@RallyInfo(UserStory = "US81368")
	public void testE2E_HDFS_Asset_ApmTSInput_ApmTSOutput_nonexisting_files() throws Exception {

		apmTSforIngestionPath = path+"/data_files/data_ingestion_common.json";
		kpiTemplateJsonPath  = path+"/kpi_templates/kpi_e2e_ooapmts_inputAndOutput_python.json" ;
		kpiTemplateAnalyticPath = path+"/kpi_analytics_1/kpiapmtspy1.zip";
		kpiJobJsonPath = path+"/kpi_jobs/kpiJob_common_hdfs_python.json";
		dataIngestionFilePath = "";
		inputTag = "OO_Tag_Temperature_ID15";
		outputTag = "OO_Tag_Temperature_ID16";
		expectedValue = "";
		expectedJobStatus = "ERROR";
		apmTsUrl = "operation=raw&startTime=2015-12-31T00:28:03.000&sampleCount=40&useOnlyGoodData=true&tagList="+inputTag;
		String hdfs_asset_file="hdfs:///tmp/data?assets=non-existing.json&tags=non-existing.json";
		String hdfs_ts_file="hdfs:///tmp/data/ts_apm_iso_small7.json";
		setSysProperty("hdfs_asset_file", hdfs_asset_file);
		setSysProperty("hdfs_ts_file", hdfs_ts_file);
		String language="PYTHON";
		setSysProperty("language", language);
		//ingest test data into apm time series
		ooTestutil.postRandomDataPointToAPMTimeSeries(apmTSforIngestionPath
				,inputTag);



		//create kpi template
		kpi_id = ooTestutil.createKpiTemplate(kpiTemplateJsonPath, kpiTemplateAnalyticPath);
		

		//create kpi job
		kpiJobId = ooTestutil.createKpiJobWithNoRandomBothInputAndOutputTag(kpiJobJsonPath,kpi_id,outputTag,inputTag,apmTsUrl);
		



		//start kpi job
		String runtimeJobId = ooTestutil.startKpiJobTwice(kpiJobId);
		String status =null;
		
	
		
		if(runtimeJobId != null)
		{
			//get Status of the Job
			status = ooTestutil.getStatusOfJob(kpiJobId);
			String message=ooTestutil.getMessageOfJob(kpiJobId);
			Assert.assertEquals(status, "ERROR","job should endup in error");
			Assert.assertEquals(message, "FAILED","job status message is not matching");


		}
		else
		{
			isEqual("Job not Started Successfully.",true,false);
		}
	}
	/**************************************************************************************************/
	@Test(priority = 6, description = "testE2E_HDFS_Asset_ApmTSInput_ApmTSOutput_specialchars_assetNTags")
	@RallyInfo(UserStory = "US81368")
	public void testE2E_HDFS_Asset_ApmTSInput_ApmTSOutput_specialchars_assetNTags() throws Exception {

		apmTSforIngestionPath = path+"/data_files/data_ingestion_common.json";
		kpiTemplateJsonPath  = path+"/kpi_templates/kpi_e2e_ooapmts_inputAndOutput_python.json" ;
		kpiTemplateAnalyticPath = path+"/kpi_analytics_1/kpiapmtspy1.zip";
		kpiJobJsonPath = path+"/kpi_jobs/kpiJob_common_hdfs_python.json";
		dataIngestionFilePath = "";
		inputTag = "OO_Tag_Temperature_ID15";
		outputTag = "OO_Tag_Temperature_ID16";
		expectedValue = "";
		expectedJobStatus = "ERROR";
		apmTsUrl = "operation=raw&startTime=2015-12-31T00:28:03.000&sampleCount=40&useOnlyGoodData=true&tagList="+inputTag;
		//String hdfs_asset_file="hdfs:///tmp/data/asset_flat.json";
		String hdfs_asset_file="hdfs:///tmp/data?assets=assets_basic*.json&tags=tags_basic*.json";
		String hdfs_ts_file="hdfs:///tmp/data/ts_apm_iso_small7.json";
		setSysProperty("hdfs_asset_file", hdfs_asset_file);
		setSysProperty("hdfs_ts_file", hdfs_ts_file);
		String language="PYTHON";
		setSysProperty("language", language);
		//ingest test data into apm time series
		ooTestutil.postRandomDataPointToAPMTimeSeries(apmTSforIngestionPath
				,inputTag);



		//create kpi template
		kpi_id = ooTestutil.createKpiTemplate(kpiTemplateJsonPath, kpiTemplateAnalyticPath);
		

		//create kpi job
		kpiJobId = ooTestutil.createKpiJobWithNoRandomBothInputAndOutputTag(kpiJobJsonPath,kpi_id,outputTag,inputTag,apmTsUrl);
	


		
		//start kpi job
		String runtimeJobId = ooTestutil.startKpiJobTwice(kpiJobId);

		String status =null;
		
	
		
		if(runtimeJobId != null)
		{
			//get Status of the Job
			status = ooTestutil.getStatusOfJob(kpiJobId);
			String message=ooTestutil.getMessageOfJob(kpiJobId);
			Assert.assertEquals(status, "ERROR","job should endup in error");
			Assert.assertEquals(message, "FAILED","job status message is not matching");


		}
		else
		{
			isEqual("Job not Started Successfully.",true,false);
		}
	}
	/**************************************************************************************************/
	@Test(priority = 6, description = "testE2E_HDFS_Asset_ApmTSInput_ApmTSOutput_Missing_filter")
	@RallyInfo(UserStory = "US81368")
	public void testE2E_HDFS_Asset_ApmTSInput_ApmTSOutput_Missing_filter() throws Exception {

		apmTSforIngestionPath = path+"/data_files/data_ingestion_common.json";
		kpiTemplateJsonPath  = path+"/kpi_templates/kpi_e2e_ooapmts_inputAndOutput_python.json" ;
		kpiTemplateAnalyticPath = path+"/kpi_analytics_1/kpiapmtspy1.zip";
		kpiJobJsonPath = path+"/kpi_jobs/kpiJob_common_hdfs_python.json";
		dataIngestionFilePath = "";
		inputTag = "OO_Tag_Temperature_ID15";
		outputTag = "OO_Tag_Temperature_ID16";
		expectedValue = "";
		expectedJobStatus = "ERROR";
		apmTsUrl = "operation=raw&startTime=2015-12-31T00:28:03.000&sampleCount=40&useOnlyGoodData=true&tagList="+inputTag;
		String hdfs_asset_file="hdfs:///tmp/data?assets=non-existing.json&tags=non-existing.json";
		String hdfs_ts_file="hdfs:///tmp/data/ts_apm_iso_small7.json";
		setSysProperty("hdfs_asset_file", hdfs_asset_file);
		setSysProperty("hdfs_ts_file", hdfs_ts_file);
		String language="PYTHON";
		setSysProperty("language", language);
		//ingest test data into apm time series
		ooTestutil.postRandomDataPointToAPMTimeSeries(apmTSforIngestionPath
				,inputTag);



		//create kpi template
		kpi_id = ooTestutil.createKpiTemplate(kpiTemplateJsonPath, kpiTemplateAnalyticPath);
		

		//create kpi job
		kpiJobId = ooTestutil.createKpiJobWithNoRandomBothInputAndOutputTag(kpiJobJsonPath,kpi_id,outputTag,inputTag,apmTsUrl);
		


		
		//start kpi job
		String runtimeJobId = ooTestutil.startKpiJobTwice(kpiJobId);

		String status =null;
		
		
		if(runtimeJobId != null)
		{
			//get Status of the Job
			status = ooTestutil.getStatusOfJob(kpiJobId);
			String message=ooTestutil.getMessageOfJob(kpiJobId);
			Assert.assertEquals(status, "ERROR","job should endup in error");
			Assert.assertEquals(message, "FAILED","job status message is not matching");

		}
		else
		{
			isEqual("Job not Started Successfully.",true,false);
		}
	}
	/**************************************************************************************************/
	@Test(priority = 6, description = "testE2E_HDFS_Asset_ApmTSInput_ApmTSOutput_missing_assetNtags")
	@RallyInfo(UserStory = "US81368")
	public void testE2E_HDFS_Asset_ApmTSInput_ApmTSOutput_missing_assetNtags() throws Exception {
		apmTSforIngestionPath = path+"/data_files/data_ingestion_common.json";
		kpiTemplateJsonPath  = path+"/kpi_templates/kpi_e2e_ooapmts_inputAndOutput_python.json" ;
		kpiTemplateAnalyticPath = path+"/kpi_analytics_1/kpiapmtspy1.zip";
		kpiJobJsonPath = path+"/kpi_jobs/kpiJob_common_hdfs_python.json";
		dataIngestionFilePath = "";
		inputTag = "OO_Tag_Temperature_ID15";
		outputTag = "OO_Tag_Temperature_ID16";
		expectedValue = "";
		expectedJobStatus = "ERROR";
		apmTsUrl = "operation=raw&startTime=2015-12-31T00:28:03.000&sampleCount=40&useOnlyGoodData=true&tagList="+inputTag;
		String hdfs_asset_file="hdfs:///tmp/data?assets=&tags=";
		String hdfs_ts_file="hdfs:///tmp/data/ts_apm_iso_small7.json";
		setSysProperty("hdfs_asset_file", hdfs_asset_file);
		setSysProperty("hdfs_ts_file", hdfs_ts_file);
		//String language="PYTHON";
		//ingest test data into apm time series
		ooTestutil.postRandomDataPointToAPMTimeSeries(apmTSforIngestionPath
				,inputTag);

		//create kpi template
		kpi_id = ooTestutil.createKpiTemplate(kpiTemplateJsonPath, kpiTemplateAnalyticPath);
	

		//create kpi job
		kpiJobId = ooTestutil.createKpiJobWithNoRandomBothInputAndOutputTag(kpiJobJsonPath,kpi_id,outputTag,inputTag,apmTsUrl);
		

		//start kpi job
		String runtimeJobId = ooTestutil.startKpiJob(kpiJobId);
		Thread.sleep(10000);
		String status =null;
		
		
		if(runtimeJobId != null)
		{
			//get Status of the Job
			status = ooTestutil.getStatusOfJob(kpiJobId);
			String message=ooTestutil.getMessageOfJob(kpiJobId);
			Assert.assertEquals(status, "ERROR","job should endup in error");
			Assert.assertEquals(message, "FAILED","job status message is not matching");
			isEqual("Job not Started Successfully.Message of the JOB is --->"+message,message.contains("FAILED"),true);



		}
		else
		{
			isEqual("Job not Started Successfully.",true,false);
		}
	}
	/**************************************************************************************************/
	@Test(priority = 6, description = "testE2E_HDFS_Asset_OOFile_ApmTSOutput_wrong_schema")
	@RallyInfo(UserStory = "US81368")
	public void testE2E_HDFS_Asset_OOFile_ApmTSOutput_wrong_schema() throws Exception {

		apmTSforIngestionPath = path+"/data_files/data_ingestion_common.json";
		kpiTemplateJsonPath  = path+"/kpi_templates/kpi_e2e_ooapmts_inputAndOutput_python.json" ;
		kpiTemplateAnalyticPath = path+"/kpi_analytics_1/kpiapmtspy1.zip";
		kpiJobJsonPath = path+"/kpi_jobs/kpiJob_common_hdfs_oofile_python.json";
		dataIngestionFilePath = "";
		inputTag = "OO_Tag_Temperature_ID15";
		outputTag = "OO_Tag_Temperature_ID16";
		expectedValue = "";
		expectedJobStatus = "ERROR";
		apmTsUrl = "operation=raw&startTime=2015-12-31T00:28:03.000&sampleCount=40&useOnlyGoodData=true&tagList="+inputTag;
		String hdfs_asset_file="hdfs:///tmp/data?assets=data_file.csv&tags=tags_basic.json";
		String hdfs_ts_file="hdfs:///tmp/data/ts_apm_iso_small5.json";
		setSysProperty("hdfs_asset_file", hdfs_asset_file);
		setSysProperty("hdfs_ts_file", hdfs_ts_file);
		String language="PYTHON";
		setSysProperty("language", language);
		//ingest test data into apm time series
		ooTestutil.postRandomDataPointToAPMTimeSeries(apmTSforIngestionPath
				,inputTag);



		//create kpi template
		kpi_id = ooTestutil.createKpiTemplate(kpiTemplateJsonPath, kpiTemplateAnalyticPath);
	
		//create kpi job
		kpiJobId = ooTestutil.createKpiJobWithNoRandomBothInputAndOutputTag(kpiJobJsonPath,kpi_id,outputTag,inputTag,apmTsUrl);
	





		Instant instant = Instant.now ();
		String timestamp=instant.toString();     
		System.out.println("getCurrent timestamp="+timestamp);


		//start kpi job
		String runtimeJobId = ooTestutil.startKpiJobTwice(kpiJobId);

		String status =null;
		
		
		if(runtimeJobId != null)
		{
			//get Status of the Job
			status = ooTestutil.getStatusOfJob(kpiJobId);
			ooTestutil.getMessageOfJob(kpiJobId);
			Assert.assertEquals(status, "ERROR","job should endup in error");
			//DE18345: Update once the issue is resolved.
			//Assert.assertEquals(message, "org.apache.spark.sql.AnalysisException: Cannot resolve column name \"sourceKey\" among (_corrupt_record);","job status message is not matching");


		}
		else
		{
			isEqual("Job not Started Successfully.",true,false);
		}

	}
	/**************************************************************************************************/
	@Test(priority = 6, description = "testE2E_HDFS_Asset_OOFile_ApmTSOutput_invalid_filepath")
	@RallyInfo(UserStory = "US81368")
	public void testE2E_HDFS_Asset_OOFile_ApmTSOutput_invalid_filepath() throws Exception {
		apmTSforIngestionPath = path+"/data_files/data_ingestion_common.json";
		kpiTemplateJsonPath  = path+"/kpi_templates/kpi_e2e_ooapmts_inputAndOutput_python.json" ;
		kpiTemplateAnalyticPath = path+"/kpi_analytics_1/kpiapmtspy1.zip";
		kpiJobJsonPath = path+"/kpi_jobs/kpiJob_common_hdfs_oofile_python.json";
		dataIngestionFilePath = "";
		inputTag = "OO_Tag_Temperature_ID15";
		outputTag = "OO_Tag_Temperature_ID16";
		expectedValue = "";
		expectedJobStatus = "ERROR";
		apmTsUrl = "operation=raw&startTime=2015-12-31T00:28:03.000&sampleCount=40&useOnlyGoodData=true&tagList="+inputTag;
		String hdfs_asset_file="hdfs:///tmp?assets=data_file.csv&tags=tags_basic.json";
		String hdfs_ts_file="hdfs:///tmp/data/ts_apm_iso_small5.json";
		setSysProperty("hdfs_asset_file", hdfs_asset_file);
		setSysProperty("hdfs_ts_file", hdfs_ts_file);
		String language="PYTHON";
		setSysProperty("language", language);
		//ingest test data into apm time series
		ooTestutil.postRandomDataPointToAPMTimeSeries(apmTSforIngestionPath
				,inputTag);



		//create kpi template
		kpi_id = ooTestutil.createKpiTemplate(kpiTemplateJsonPath, kpiTemplateAnalyticPath);
	

		//create kpi job
		kpiJobId = ooTestutil.createKpiJobWithNoRandomBothInputAndOutputTag(kpiJobJsonPath,kpi_id,outputTag,inputTag,apmTsUrl);
	






		Instant instant = Instant.now ();
		String timestamp=instant.toString();     
		System.out.println("getCurrent timestamp="+timestamp);


		//start kpi job
		//start kpi job
		String runtimeJobId = ooTestutil.startKpiJobTwice(kpiJobId);
		String status =null;
		
		
		if(runtimeJobId != null)
		{
			//get Status of the Job
			status = ooTestutil.getStatusOfJob(kpiJobId);
			String message=ooTestutil.getMessageOfJob(kpiJobId);
			Assert.assertEquals(status, "ERROR","job should endup in error");
			Assert.assertEquals(message, "FAILED","job status message is not matching");


		}
		else
		{
			isEqual("Job not Started Successfully.",true,false);
		}
	}


	/**************************************************************************************************/
	@AfterTest
	public void afterTest() {}

	@BeforeSuite
	public void beforeSuite() {

	}

	@AfterSuite
	public void afterSuite() {}
}

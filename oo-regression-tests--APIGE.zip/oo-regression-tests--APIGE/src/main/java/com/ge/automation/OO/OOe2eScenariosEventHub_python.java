package com.ge.automation.OO;

import java.util.LinkedHashMap;
import java.util.Map;
import java.util.Properties;

import org.springframework.boot.test.TestRestTemplate;
import org.springframework.web.client.RestTemplate;
import org.testng.annotations.AfterClass;
import org.testng.annotations.AfterMethod;
import org.testng.annotations.AfterSuite;
import org.testng.annotations.AfterTest;
import org.testng.annotations.BeforeClass;
import org.testng.annotations.BeforeMethod;
import org.testng.annotations.BeforeSuite;
import org.testng.annotations.BeforeTest;
import org.testng.annotations.Test;

import com.ge.microtester.common.utils.RestAssuredUtil;
import com.ge.microtester.rally.RallyInfo;
import com.jayway.restassured.response.Response;



@RallyInfo(ProjectName = "APM Super Optimo")
public class OOe2eScenariosEventHub_python extends RestAssuredUtil {

	static String jsonfileName;
	Properties configFile = new Properties();
	String truncateDateTime[];
	String tagName;
	String proxyHost;
	String proxyPort;
	Response responseBody;
	String kpiid;
	String kpiJobId;
	String dataSourceId;
	long kpi_id;
	long kpi_id1;
	String path = "src/main/resources/payloadsEventHub";
	String apmTSforIngestionPath;
	boolean apmIngestionDynamicTag;
	String kpiTemplateJsonPath;
	String kpiTemplateAnalyticPath;
	String kpiJobJsonPath;
	String dataIngestionFilePath;
	String inputTag;
	String outputTag;
	String expectedValue;
	String expectedJobStatus;
	boolean createKpiJobWithTag;
	String apmTsUrl = "";

	public OOTestUtil ooTestutil = new OOTestUtil();
	RestTemplate restTemplate = new TestRestTemplate();
	// Generating Query Params
	Map<String, Object> values = new LinkedHashMap<String, Object>();

	@BeforeMethod
	public void beforeMethod() {}

	@AfterMethod
	public void afterMethod() {}

	@BeforeClass
	public void beforeClass() {

		System.getProperties().put("proxySet", "true");
		System.getProperties().put("http.proxyHost", "sjc1intproxy01.crd.ge.com");
		System.getProperties().put("http.proxyPort", "8080");
		System.getProperties().put("https.proxyHost", "sjc1intproxy01.crd.ge.com");
		System.getProperties().put("https.proxyPort", "8080");
		setSysProperty("currentTimeStamp", "" + getCurrentTimestamp());// ${sys:currentTimeStamp}

	}// end of beforeClass

	@AfterClass
	public void afterClass() {}

	@BeforeTest
	public void beforeTest() {

	}// end of beforeTest


	/*********************************************************************************************************
	 * Python Analytic - Read APM TS as input and write output to APM TS
	 * 
	 *********************************************************************************************************/

	@Test(priority = 1, description = "testE2E_ApmTSInput_ApmTSOutput_Python")
	@RallyInfo(UserStory = "USXXXX")
	public void testE2E_ApmTSInput_ApmTSOutput_Python() throws Exception {

		//ingest test data into apm time series
		String sourcetag = "OO_Tag_Temperature_ID1";
		String targettag = "OO_Tag_Temperature_ID50";
		int valuePosted = ooTestutil.postRandomDataPointToAPMTimeSeries(path+"/data_files/data_ingestion_gen.json"
				,sourcetag);

		//create kpi template
		kpi_id = ooTestutil.createKpiTemplate(path+"/kpi_templates/kpi_e2e_ooapmts_inputAndOutput_python.json", 
				path+"/kpi_analytics_1/kpiapmtspy1.zip");
		Thread.sleep(10000);

		//create kpi job
		kpiJobId = ooTestutil.createKpiJobWithNoRandomBothInputAndOutputTag(path+"/kpi_jobs/kpi_e2e_ooapmts_inputAndOutput_job_python.json"
				,kpi_id,targettag,sourcetag,"");
		Thread.sleep(10000);

		//start kpi job
		String runtimeJobId = ooTestutil.startKpiJobTwice(kpiJobId);

		if(runtimeJobId != null)
		{
			//get Status of the Job
			Thread.sleep(15000);
			//String status = ooTestutil.getStatusOfJob(kpiJobId);
			String message = ooTestutil.getMessageOfJob(kpiJobId);
			
			Thread.sleep(30000);

			if(message.equalsIgnoreCase("SUCCESS"))
			{

				//get data from Apm time Series
				//Thread.sleep(30000);
				ooTestutil.getDataFromApmTimeSeries(targettag, String.valueOf(valuePosted *10));	
				Thread.sleep(30000);

				//delete kpi job
				ooTestutil.deleteKpiJob(kpiJobId);
				Thread.sleep(10000);

				//get status of the job
				ooTestutil.getStatusOfJob(kpiJobId);		
				Thread.sleep(10000);
			}else{
				isEqual("Job not Started Successfully.Status of the JOB is --->"+message,true,false);
			}
		}else{
			isEqual("Job not Started Successfully.runtimeJobId of the JOB is --->"+runtimeJobId,true,false);
		}

	}
	/*********************************************************************************************************
	 * Python Analytic - Analytic depends on module packaged in egg file.
	 * Read APM TS as input and write output to APM TS
	 * 
	 *********************************************************************************************************/
	
	
	
	
	
	/*********************************************************************************************************
	 * Python Analytic - Throw module not available exception.
	 * Read APM TS as input and write output to APM TS
	 * 
	 *********************************************************************************************************/
	
	
	
	
	
	/*********************************************************************************************************/
	@AfterTest
	public void afterTest() {}

	@BeforeSuite
	public void beforeSuite() {

	}

	@AfterSuite
	public void afterSuite() {}
}

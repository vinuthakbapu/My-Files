package com.ge.automation.OO;

import java.io.IOException;
import java.net.URISyntaxException;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;
import java.util.Properties;

import org.springframework.boot.test.TestRestTemplate;
import org.springframework.web.client.RestTemplate;
import org.testng.Assert;
import org.testng.annotations.AfterClass;
import org.testng.annotations.AfterMethod;
import org.testng.annotations.AfterSuite;
import org.testng.annotations.AfterTest;
import org.testng.annotations.BeforeClass;
import org.testng.annotations.BeforeMethod;
import org.testng.annotations.BeforeSuite;
import org.testng.annotations.BeforeTest;
import org.testng.annotations.Test;

import com.ge.microtester.common.utils.ExcelReaderUtil;
import com.ge.microtester.common.utils.RestAssuredUtil;
import com.ge.microtester.rally.RallyInfo;
import com.jayway.jsonpath.JsonPath;
import com.jayway.restassured.response.Response;

@RallyInfo(ProjectName = "APM Super Optimo")
public class OOe2eScenariosNegativeTests2 extends RestAssuredUtil {

	static String jsonfileName;
	Properties configFile = new Properties();
	String truncateDateTime[];
	String tagName;
	String proxyHost;
	String proxyPort;
	Response responseBody;
	String kpiid;
	String kpiJobId;
	String dataSourceId;
	long kpi_id;
	long kpi_id1;
	String apmTSforIngestionPath;
	boolean apmIngestionDynamicTag;
	String kpiTemplateJsonPath;
	String kpiTemplateAnalyticPath;
	String kpiJobJsonPath;
	String dataIngestionFilePath;
	String inputTag;
	String outputTag;
	String expectedValue;
	String expectedJobStatus;
	boolean createKpiJobWithTag;
	

	public OOTestUtil ooTestutil = new OOTestUtil();
	RestTemplate restTemplate = new TestRestTemplate();
	// Generating Query Params
	Map<String, Object> values = new LinkedHashMap<String, Object>();

	@BeforeMethod
	public void beforeMethod() {}

	@AfterMethod
	public void afterMethod() {}

	@BeforeClass
	public void beforeClass() {

		System.getProperties().put("proxySet", "true");
		System.getProperties().put("http.proxyHost", "sjc1intproxy01.crd.ge.com");
		System.getProperties().put("http.proxyPort", "8080");
		System.getProperties().put("https.proxyHost", "sjc1intproxy01.crd.ge.com");
		System.getProperties().put("https.proxyPort", "8080");
		
		setSysProperty("currentTimeStamp", "" + getCurrentTimestamp());// ${sys:currentTimeStamp}

	}// end of beforeClass

	@AfterClass
	public void afterClass() {}

	@BeforeTest
	public void beforeTest() {

	}// end of beforeTest

	/********************************************************************************************************************
    Test Case: StreamTS input data provider
               OOStream as output data provider
    Test Steps:         
     1)  Create Kpi Template.
     2)  Create Kpi Job with kpireference id. 
     3)  Start Job
     4)  Assert data that is written to Kafka topic. 
	specialchars return 0.00
	different schema no output
	capital letters no output
	missing datapoints no output
	
	 /********************************************************************************************************************/
	@Test(dataProvider="MTExcelDataReader",dataProviderClass = ExcelReaderUtil.class,priority = 2, description = "testE2EStreamingNegativeTests")
	//@Test(dataProvider="DP1",priority = 9, description = "testUserAcsGetPositiveTests")
	@RallyInfo(UserStory = "US28339")
	
	public void testE2EStreamingNegativeTests(String testcase,String data_file,String kpi_template,String kpi_analytic,String kpi_job,String expected_job_status,Double expected_data_points)throws IOException, InterruptedException, URISyntaxException
	//String kpi_template,String kpi_analytic, String kpi_job, String expected_job_status
	//Double expected_data_points)throws IOException, InterruptedException, URISyntaxException {
	{	 
		System.out.println("~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~");
		System.out.println("\n"+"testcase="+testcase+"\t"+"data_file="+data_file+"\t"+"kpi_template="+kpi_template+"\t"+"kpi_analytic="+kpi_analytic+"\t"+"kpi_job="+kpi_job+"\t"+"expected_job_status="+expected_job_status+"\t"+"expected_data_points="+expected_data_points);
		data_file="src/main/resources/payloadsEventHub/data_files/data_files_negative/"+data_file;
		kpi_template="src/main/resources/payloadsEventHub/kpi_templates/"+kpi_template;
		kpi_analytic="src/main/resources/payloadsEventHub/kpi_analytics_1/"+kpi_analytic;
		kpi_job="src/main/resources/payloadsEventHub/kpi_jobs/"+kpi_job;
		
		
		
		//create kpi template
		kpi_id = ooTestutil.createKpiTemplate(kpi_template, kpi_analytic);
		
		//create kpi job
		String inputTag = "OO_Tag_LIGHTSPEED";
		kpiJobId = ooTestutil.createKpiJobWithInputAndOutputTag(kpi_job,kpi_id,"Output_OO_LIGHTSPEED",inputTag);
		try{

		//start kpi job
		ooTestutil.startKpiJobTwice(kpiJobId);
		
		//status of the job
		String status = ooTestutil.getStatusOfJob(kpiJobId);
		
		
		if(status.equalsIgnoreCase("Running"))
		{

			//get output tag from Kpi Job response
			String InputtagNamePosted = ooTestutil.getInputtagOfKpiJob(kpiJobId);		
			

			ooTestutil.postDataPointToEventHubNoRandomTag(data_file,InputtagNamePosted);		

			Thread.sleep(30000);

			//get output tag from Kpi Job response
			String OutputtagNamePosted = ooTestutil.getOutputtagOfKpiJob(kpiJobId);		
			

			
			//get status of the job
			status=ooTestutil.getStatusOfJob(kpiJobId);	
			Assert.assertEquals(status, expected_job_status,"streaming job should always be running");
			
			String kResponse = ooTestutil.getResponseFromKafkaTopic(OutputtagNamePosted);
			
			
			
			if(expected_data_points!=-1)
			{
			Assert.assertTrue(kResponse.contains(OutputtagNamePosted), "outputtag not found in data from kafka");
			List<String> value_consumerData =
					com.jayway.jsonpath.JsonPath.read(kResponse, "$..datapoints[*][1]");
			String data_point_from_kafka=String.valueOf(value_consumerData.get(0));
			System.out.println("expected_data="+expected_data_points.toString());
			System.out.println("+++data point from output== " + String.valueOf(value_consumerData.get(0)));
			isContains("data point didnot match",expected_data_points.toString(), data_point_from_kafka);
			}

		}else{
			Assert.assertEquals(status, expected_job_status,"streaming job should always be running");
			
		}
		}catch(Exception e)
		{
			e.printStackTrace();
			throw e;
		}
		finally{
			
			//delete kpi job
			ooTestutil.deleteKpiJob(kpiJobId);
			Thread.sleep(10000);

			//get status of the job
			ooTestutil.getStatusOfJob(kpiJobId);			
			
		}
	}

	
	@AfterTest
	public void afterTest() {}

	@BeforeSuite
	public void beforeSuite() {

	}

	@AfterSuite
	public void afterSuite() {}
}

package com.ge.automation.OO;

import java.io.File;
import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.io.IOException;
import java.net.URISyntaxException;
import java.nio.file.Files;
import java.nio.file.Path;
import java.nio.file.Paths;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.time.Instant;
import java.time.LocalDateTime;
import java.time.temporal.ChronoUnit;
import java.util.ArrayList;
import java.util.Calendar;
import java.util.Date;
import java.util.HashMap;
import java.util.HashSet;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;
import java.util.Random;
import java.util.Set;
import java.util.UUID;
import java.util.concurrent.ConcurrentHashMap;
import java.util.stream.Collectors;
import java.util.zip.ZipEntry;
import java.util.zip.ZipOutputStream;

import com.fasterxml.jackson.databind.ObjectMapper;
import com.jayway.restassured.RestAssured;
import com.jayway.restassured.path.json.JsonPath;
import com.jayway.restassured.response.Response;
import com.jayway.restassured.specification.RequestSpecification;
import com.mongodb.util.JSON;
import net.lingala.zip4j.core.ZipFile;
import net.lingala.zip4j.exception.ZipException;
import net.sf.json.JSONObject;
import org.apache.commons.codec.binary.Base64;
import org.apache.commons.io.FileUtils;
import org.apache.commons.io.FilenameUtils;
import org.apache.commons.lang3.StringUtils;
import org.apache.commons.lang3.tuple.MutablePair;
import org.apache.commons.lang3.tuple.Pair;
import org.quartz.CronExpression;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.boot.test.TestRestTemplate;
import org.springframework.core.io.FileSystemResource;
import org.springframework.http.HttpEntity;
import org.springframework.http.HttpHeaders;
import org.springframework.http.HttpMethod;
import org.springframework.http.HttpStatus;
import org.springframework.http.MediaType;
import org.springframework.http.ResponseEntity;
import org.springframework.util.LinkedMultiValueMap;
import org.springframework.util.MultiValueMap;
import org.springframework.web.client.RestTemplate;
import org.testng.Assert;

import com.ge.automation.OO.dto.KpiDetails;
import com.ge.microtester.common.utils.RestAssuredUtil;

public class OOTestUtil extends RestAssuredUtil {

    private static final Logger log = LoggerFactory.getLogger("OOTestUtil");

    private static final String KPIJOB_SCHEDULE_CRON_EXPRESSION = "0 0/5 * * * ?";

    private String oouaa_token;
    private String apmuaa_token;
    RestTemplate restTemplate = new TestRestTemplate();
    Map<String, String> tokenMap = new ConcurrentHashMap<>();
    private static final String TOKEN_KEY = "oouaa_token";

    /********************************************************************************************************************/
    public String getToken() {
        if (tokenMap.containsKey(OOTestUtil.TOKEN_KEY)) {
            return tokenMap.get(OOTestUtil.TOKEN_KEY);
        } else {
            oouaa_token = getToken("uaaUrl", "grant_type", "username", "password", "clientId", "clientSecret");
            tokenMap.put(OOTestUtil.TOKEN_KEY, oouaa_token);
            return oouaa_token;
        }
    }

    /********************************************************************************************************************/
    public String getApmToken() {
        if (tokenMap.containsKey("apmuaa_token")) {
            return tokenMap.get("apmuaa_token");
        } else {
            apmuaa_token = getToken("tokenRequestURL", "grant_type", "tokenUsername", "tokenPassword", "tokenClientID",
                "tokenClientSecret");
            tokenMap.put("apmuaa_token", apmuaa_token);
            return apmuaa_token;
        }
    }

    /********************************************************************************************************************/
    public void printnewLine() {
        System.out.println("-----------------------------------------------------\n");
    }

    /********************************************************************************************************************/
    public long generateRandomNumber() {

        UUID myuuid = UUID.randomUUID();
        long randomNum = myuuid.getMostSignificantBits();
        return randomNum;
    }

    /********************************************************************************************************************/
    public int generateRandomNumberNonUUID() {
        return (int) (Instant.now().toEpochMilli() % Integer.MAX_VALUE);
    }

    /********************************************************************************************************************/
    public int generateRandomNumber3Digits() {

        Random rn = new Random();
        int maximum = 999;
        int minimum = 0;
        int range = maximum - minimum + 1;
        int randomNum = rn.nextInt(range) + minimum;

        return randomNum;
    }

    /********************************************************************************************************************/
    public Map<String, Object> kpiprovideHeaders() {
        Map<String, Object> headersMap = new LinkedHashMap<String, Object>();
        headersMap.put("Authorization", "Bearer " + getToken());
        headersMap.put("Content-Type", "application/json");
        headersMap.put("tenant", getTestProperty("tenantUUID"));
        return headersMap;
    }

    /********************************************************************************************************************/
    public Map<String, Object> kpiprovideHeaders_5() {
        Map<String, Object> headersMap = new LinkedHashMap<String, Object>();
        headersMap.put("Authorization", "Bearer " + getToken());
        headersMap.put("Content-Type", "application/json");

        return headersMap;
    }

    /********************************************************************************************************************/
    public Map<String, Object> kpiprovideHeaders_6() {
        Map<String, Object> headersMap = new LinkedHashMap<String, Object>();
        headersMap.put("Authorization", "Bearer " + getToken());
        headersMap.put("Content-Type", "application/json");
        headersMap.put("tenant", getTestProperty("tenantUUID"));
        return headersMap;
    }

    /********************************************************************************************************************/
    public MultiValueMap<String, String> kpiprovideHeaders_4() {
        MultiValueMap<String, String> headersMap = new LinkedMultiValueMap<String, String>();
        headersMap.add("Authorization", "Bearer " + getToken());
        headersMap.add("Content-Type", "application/json");
        headersMap.add("tenant", getTestProperty("tenantUUID"));
        return headersMap;
    }

    /********************************************************************************************************************/
    public Map<String, Object> kpiprovideHeaders_2() {
        Map<String, Object> headersMap = new LinkedHashMap<String, Object>();
        headersMap.put("Authorization", "Bearer " + getToken());
        headersMap.put("Content-Type", "multipart/form-data");
        headersMap.put("tenant", getTestProperty("tenantUUID"));
        return headersMap;
    }

    /********************************************************************************************************************/
    public HttpHeaders kpiprovideHeaders_1() {
        HttpHeaders headers = new HttpHeaders();
        headers.set("Authorization", "Bearer " + getToken());
        headers.set("Content-Type", "multipart/form-data");
        headers.set("tenant", getTestProperty("tenantUUID"));
        return headers;
    }

    /********************************************************************************************************************/
    public HttpHeaders kpiprovideHeaders_3() {
        HttpHeaders headers = new HttpHeaders();
        headers.set("Authorization", "Bearer " + getToken());
        headers.set("Content-Type", "application/json");

        return headers;
    }

    public Map<String, Object> runtimeProvisionHeader() {

        String runtime_tenantUUID = getTestProperty("runtime_tenantUUID");

        String token = getToken("stuf_uaa_url", "grant_type", "runtime_username", "runtime_password", "stuf_clientId",
            "stuf_clientSecret");

        Map<String, Object> headers = new LinkedHashMap<>();
        headers.put("Authorization", "Bearer " + token);
        headers.put("Content-Type", "application/json");
        headers.put("tenant", runtime_tenantUUID);

        System.out.println("headers=" + headers);

        return headers;
    }

    public Map<String, Object> runtimeProvisionHeaderWithClientCredentialsToken()
        throws IOException, URISyntaxException {

        String runtime_tenantUUID = getTestProperty("runtime_tenantUUID");

        String runtime_base_uri = getTestProperty("base_uri");

        String runtime_token_url = getTestProperty("token_url");
        String runtime_client_id = getTestProperty("runtime_client_id");
        String runtime_client_secret = getTestProperty("runtime_client_secret");
        String runtime_provision_scope = getTestProperty("runtime_provision_scope");
        String runtime_ingestor_client_id = getTestProperty("tokenClientID");
        String runtime_functional_user = getTestProperty("runtime_functional_user");

        // String runtime_provision_scope =
        // "stuf.0f46b78e-8f72-4f82-a6e1-3807c3b3f985.zone,stuf.write,stuf.read";

        String runtime_provision_grant_type = getTestProperty("runtime_provision_grant_type");
        String tenantCreate = "./src/main/resources/payloadsEventHub/runtime_provision/tenant-create.json";
        String tenantJson = generateFile(tenantCreate, "kpi_e2e");
        System.out.println("**************preparing token for headers*******************");

        String basicDigestHeaderValue = "Basic " + new String(Base64.encodeBase64(new StringBuilder()
            .append(runtime_client_id).append(":").append(runtime_client_secret).toString().getBytes()));

        Map<String, Object> token_headers = new LinkedHashMap<String, Object>();

        token_headers.put("Authorization", basicDigestHeaderValue);
        token_headers.put("Content-Type", MediaType.APPLICATION_FORM_URLENCODED);

        System.out.println("token headers=" + token_headers);

        Map<String, Object> queryParams = new LinkedHashMap<String, Object>();

        queryParams.put("grant_type", runtime_provision_grant_type);
        queryParams.put("scope", runtime_provision_scope);
        System.out.println("query params=" + queryParams);

        Response tokenResponse = postServiceResponse(tenantJson, "tokenRequestURL", queryParams, token_headers);
        System.out.println("tokenResponse=" + tokenResponse.asString());
        JsonPath jsonPath = new JsonPath(tokenResponse.asString());
        System.out.println("**************found token*******************");
        String token = jsonPath.getString("access_token");

        Map<String, Object> headers = new LinkedHashMap<>();
        headers.put("Authorization", "Bearer " + token);
        headers.put("Content-Type", "application/json");
        headers.put("tenant", runtime_tenantUUID);
        headers.put("functionalUser", runtime_functional_user);
        headers.put("ingestorClientId", runtime_ingestor_client_id);

        System.out.println("headers=" + headers);

        return headers;
    }

    public Map<String, Object> runtimeProvisionHeaderInvalidAccess() {

        String runtime_tenantUUID = getTestProperty("runtime_tenantUUID");

        String token = getToken("stuf_uaa_url", "grant_type", "stuf_username", "stuf_password", "stuf_clientId",
            "stuf_clientSecret");

        Map<String, Object> headers = new LinkedHashMap<>();
        headers.put("Authorization", "Bearer " + token);
        headers.put("Content-Type", "application/json");
        headers.put("tenant", getTestProperty("runtime_tenantUUID"));
        System.out.println("headers=" + headers);
        return headers;
    }

    /********************************************************************************************************************/
    public Map<String, Object> ApmProvideHeaders() {
        Map<String, Object> headersMap = new LinkedHashMap<String, Object>();
        headersMap.put("tenant", getTestProperty("tenantUUID"));
        headersMap.put("Authorization", "Bearer " + getApmToken());
        headersMap.put("Content-Type", "application/json");
        return headersMap;
    }

    /********************************************************************************************************************/
    public Map<String, Object> kpi_get_catalogentries_headers() {
        Map<String, Object> headersMap = new LinkedHashMap<>();
        headersMap.put("Authorization", "Bearer " + getToken());
        headersMap.put("Accept", "application/json");
        headersMap.put("tenant", getTestProperty("tenantUUID"));
        return headersMap;
    }

    /********************************************************************************************************************/
    public Map<String, Object> kpi_post_createwithartifact_headers() {
        Map<String, Object> headersMap = new LinkedHashMap<>();
        headersMap.put("Authorization", "Bearer " + getToken());
        headersMap.put("Content-Type", "multipart/form-data");
        headersMap.put("tenant", getTestProperty("tenantUUID"));
        return headersMap;
    }

    /********************************************************************************************************************/
    public HttpHeaders kpi_put_catalogentry_headers() {
        HttpHeaders headers = new HttpHeaders();
        headers.set("Authorization", "Bearer " + getToken());
        headers.set("Content-Type", "multipart/form-data");
        headers.set("tenant", getTestProperty("tenantUUID"));
        return headers;
    }

    /********************************************************************************************************************/
    public HttpHeaders kpi_put_catalogentry_json_headers() {
        HttpHeaders headers = new HttpHeaders();
        headers.set("Authorization", "Bearer " + getToken());
        headers.set("Content-Type", "application/json");
        headers.set("tenant", getTestProperty("tenantUUID"));
        return headers;
    }

    /********************************************************************************************************************/
    public long createKpiTemplate(String kpiTemplate, String kpiAnalytic) throws IOException, URISyntaxException {
        printnewLine();

        System.out.println("*****************Create KPI TEMPLATE*******************");
        printnewLine();

        final String uri = getTestProperty("kpi_url");
        System.out.println("kpi url=" + uri);

        setSysProperty("setKpiName", "kpiname2" + generateRandomNumberNonUUID());
        setSysProperty("tenant", getTestProperty("tenantUUID"));
        String kpiFile = kpiTemplate;
        String kpiJson = generateFile(kpiFile, "kpi_e2e");

        File f = new File(kpiJson);
        System.out.println("file path=" + f.getAbsolutePath());

        String path = f.getAbsolutePath().replace('\\', '/');

        String kpiJson_1 = FileUtils.readFileToString(new File(path));
        File analyticFile = new java.io.File(kpiAnalytic);

        MultiValueMap<String, Object> parameters = new LinkedMultiValueMap<String, Object>();
        parameters.add("uploadfile", new FileSystemResource(analyticFile));
        parameters.add("kpi", new ObjectMapper().readValue(kpiJson_1, KpiDetails.class));

        ResponseEntity<KpiDetails> response = restTemplate.exchange(uri, HttpMethod.POST,
            new HttpEntity<MultiValueMap<String, Object>>(parameters, kpiprovideHeaders_1()), KpiDetails.class);

        // Assert.assertEquals(response.getStatusCode(), HttpStatus.CREATED);

        Assert.assertTrue(response.getBody() instanceof KpiDetails);
        KpiDetails kpiDetails = response.getBody();
        System.out.println(
            "\n\n+++ response.asString() == " + new ObjectMapper().writeValueAsString(kpiDetails) + "\n\n");
        long kpi_id = kpiDetails.getId();
        System.out.println("------------->" + kpiDetails.getId());

        return kpi_id;
    }

    /********************************************************************************************************************/
    public long createKpiTemplate(String kpiTemplate) throws IOException, URISyntaxException {
        printnewLine();

        System.out.println("*****************Create KPI TEMPLATE*******************");
        printnewLine();

        final String uri = getTestProperty("kpi_url");
        System.out.println("kpi url=" + uri);

        setSysProperty("setKpiName", "kpiname2" + generateRandomNumberNonUUID());
        setSysProperty("tenant", getTestProperty("tenantUUID"));
        String kpiFile = kpiTemplate;
        String kpiJson = generateFile(kpiFile, "kpi_e2e");

        File f = new File(kpiJson);
        System.out.println("file path=" + f.getAbsolutePath());

        String path = f.getAbsolutePath().replace('\\', '/');

        String kpiJson_1 = FileUtils.readFileToString(new File(path));

        MultiValueMap<String, Object> parameters = new LinkedMultiValueMap<String, Object>();
        parameters.add("kpi", new ObjectMapper().readValue(kpiJson_1, KpiDetails.class));

        ResponseEntity<KpiDetails> response = restTemplate.exchange(uri, HttpMethod.POST,
            new HttpEntity<MultiValueMap<String, Object>>(parameters, kpiprovideHeaders_1()), KpiDetails.class);

        // Assert.assertEquals(response.getStatusCode(), HttpStatus.CREATED);

        Assert.assertTrue(response.getBody() instanceof KpiDetails);
        KpiDetails kpiDetails = response.getBody();
        System.out.println(
            "\n\n+++ response.asString() == " + new ObjectMapper().writeValueAsString(kpiDetails) + "\n\n");
        long kpi_id = kpiDetails.getId();
        System.out.println("------------->" + kpiDetails.getId());

        return kpi_id;
    }

    // ****************Update kpi Template*************************************************//
    public void updateKpiTemplateAnalyticFile(Long kpiId, String kpiTemplateAnalyticPath)
        throws IOException, URISyntaxException {
        printnewLine();

        System.out.println("*****************Update KPI TEMPLATE*******************");
        printnewLine();
        // Update KPI

        String kpiFile = kpiTemplateAnalyticPath;

        final String uri = getTestProperty("kpi_url");
        File analyticFile_update = new java.io.File(kpiFile);

        MultiValueMap<String, Object> parameters = new LinkedMultiValueMap<String, Object>();
        parameters.add("uploadfile", new FileSystemResource(analyticFile_update));

        String updateKpiAnalyticUrl = uri + "/" + kpiId + "/artifact";
        System.out.println("\nupdateKpiAnalyticUrl------------->" + updateKpiAnalyticUrl + "\n");
        ResponseEntity<KpiDetails> update_response = restTemplate.exchange(updateKpiAnalyticUrl, HttpMethod.PUT,
            new HttpEntity<MultiValueMap<String, Object>>(parameters, kpiprovideHeaders_1()), KpiDetails.class);

        Assert.assertEquals(update_response.getStatusCode(), HttpStatus.OK);
        Assert.assertTrue(update_response.getBody() instanceof KpiDetails);
        KpiDetails kpiDetails = update_response.getBody();
        kpiDetails = update_response.getBody();
        kpiId = kpiDetails.getId();
        System.out.println("------------->" + kpiDetails.getId());
        System.out.println(
            "\n\n+++ response.asString() == " + new ObjectMapper().writeValueAsString(kpiDetails) + "\n\n");

        printnewLine();
    }

    // ****************create Adci
    // Template*************************************************//
    public void getADCIZipFile(String adciZipFile, long kpiId1, long kpiId2)
        throws ZipException, IOException, URISyntaxException {

        log.info("Zip File path =" + adciZipFile);
        //unzip the Adci zip
        String extractedDir = extractZipFile(adciZipFile);

        log.info("Extracted Dir:" + extractedDir);

        //Get json from Adci file
        List<File> folderFiles = (List<File>) FileUtils.listFiles(new File(extractedDir), null /*extensions*/,
            true /*recursive*/);
        folderFiles = folderFiles.stream().filter(file -> !file.isHidden()).collect(Collectors.toList());
        Pair<String, List<File>> filesPair = new MutablePair<>(appendTrailingSlash(extractedDir), folderFiles);
        List<File> files = filesPair.getRight();
        File adciFile = null;
        for (File file : files) {
            if (file.getName().equalsIgnoreCase("Adci.json")) {
                adciFile = file;
                break;
            }
        }

        setSysProperty("template1", String.valueOf(kpiId1));
        setSysProperty("template2", String.valueOf(kpiId2));
        setSysProperty("uri", UUID.randomUUID().toString());

        String adcijson = generateFile(adciFile.getAbsolutePath(), null);

        log.info("adcijson :" + adcijson);
        adciFile = new File(adcijson);
        File newAdciFile = new File("Adci.json");
        adciFile.renameTo(newAdciFile);
        files = files.stream().filter(file -> !file.getName().equalsIgnoreCase("adci.json")).collect(
            Collectors.toList());
        log.info(" After changing file name =" + adciFile.getName());
        log.info(" After changing file name =" + newAdciFile.getName());
        files.add(newAdciFile);
        zipMultipleFiles(files);

        //deleting newly created adci file
        newAdciFile.delete();
    }

    // ****************Delete kpi
    // Template*************************************************//

    public void deleteKpiTemplate(String kpiId) throws InterruptedException, IOException {

        printnewLine();
        System.out.println("*****************DELETE KPI Template*******************");
        printnewLine();

        Response response = deleteServiceResponse("kpi_url" + "/" + kpiId, kpiprovideHeaders());
        isEqual("Not valid response for Delete Kpi", 204, response.statusCode());

        printnewLine();

        return;
    }

    public void stopKpiJob(String kpiJobId) throws InterruptedException, IOException {

        printnewLine();
        System.out.println("*****************STOP KPI JOB*******************");
        printnewLine();
        Response response = postServiceResponse("stop_job_url" + "/" + kpiJobId, kpiprovideHeaders());
        isEqual("Not valid response for Stop Kpi Job", 200, response.statusCode());
        printnewLine();
        return;
    }
    // *****************Create KPI
    // JOB***************************************************//

    public String createKpiJob(String kpijob, long kpi_id) throws IOException, URISyntaxException {

        printnewLine();
        System.out.println("*****************Create KPI JOB*******************");
        printnewLine();

        setSysProperty("kpiReferenceId", String.valueOf(kpi_id));
        setSysProperty("tenant", getTestProperty("tenantUUID"));

        String kpijobFile = kpijob;
        String kpijobJson = generateFile(kpijobFile, "kpi_job_e2e");
        System.out.println("+++ kpijobJson== " + kpijobJson);
        Response response1 = postServiceResponse(kpijobJson, "job_url", kpiprovideHeaders());

        System.out.println("+++ response.asString() == " + response1.asString());
        JsonPath jsonPath = new JsonPath(response1.asString());
        String kpiJobId = jsonPath.getString("id");
        System.out.println("+++ kpiJobId== " + kpiJobId);
        isEqual("Not valid response create KPI Job", 201, response1.statusCode());

        return kpiJobId;
    }

    // *****************UPDATE KPI
    // JOB***************************************************//

    public Response UpdateKpiJob(String kpijob) throws IOException, URISyntaxException {

        printnewLine();
        System.out.println("*****************Update KPI JOB*******************");
        printnewLine();

        setSysProperty("tenant", getTestProperty("tenantUUID"));

        String kpijobFile = kpijob;
        String kpijobJson = generateFile(kpijobFile, "kpi_job_e2e");
        System.out.println("+++ kpijobJson== " + kpijobJson);
        Response response1 = putServiceResponse(kpijobJson, "job_url", kpiprovideHeaders());
        System.out.println("+++ response.statuscode == " + response1.statusCode());
        System.out.println("+++ response.asString() == " + response1.asString());
        JsonPath jsonPath = new JsonPath(response1.asString());
        String kpiJobId = jsonPath.getString("id");
        System.out.println("+++ kpiJobId== " + kpiJobId);
        // isEqual("Not valid response create KPI Job", 201,
        // response1.statusCode());

        return response1;
    }
    // *****************Create KPI
    // JOB***************************************************//

    public String createKpiJobWithTag(String kpijob, long kpi_id, String outputtag)
        throws IOException, URISyntaxException {

        printnewLine();
        System.out.println("*****************Create KPI JOB*******************");
        printnewLine();

        setSysProperty("kpiReferenceId", String.valueOf(kpi_id));
        String outputTag = outputtag + generateRandomNumber();
        setSysProperty("setOutputTagName", outputTag);
        setSysProperty("tenant", getTestProperty("tenantUUID"));

        String kpijobFile = kpijob;
        String kpijobJson = generateFile(kpijobFile, "kpi_job_e2e");
        System.out.println("+++ kpijobJson== " + kpijobJson);
        Response response1 = postServiceResponse(kpijobJson, "job_url", kpiprovideHeaders());

        System.out.println("+++ response.asString() == " + response1.asString());
        JsonPath jsonPath = new JsonPath(response1.asString());
        String kpiJobId = jsonPath.getString("id");
        System.out.println("+++ kpiJobId== " + kpiJobId);
        isEqual("Not valid response create KPI Job", 201, response1.statusCode());

        return kpiJobId;
    }
    // *****************Create KPI
    // JOB***************************************************//

    public String createKpiJobWithInputAndOutputTag(String kpijob, long kpi_id, String outputtag, String inputtag)
        throws IOException, URISyntaxException {

        printnewLine();
        System.out.println("*****************Create KPI JOB*******************");
        printnewLine();

        setSysProperty("kpiReferenceId", String.valueOf(kpi_id));
        String outputTag = outputtag + generateRandomNumber();
        setSysProperty("setOutputTagName", outputTag);
        String inputTag = inputtag + generateRandomNumber();
        setSysProperty("setInputTagName", inputTag);
        setSysProperty("tenant", getTestProperty("tenantUUID"));

        String kpijobFile = kpijob;
        String kpijobJson = generateFile(kpijobFile, "kpi_job_e2e");
        System.out.println("+++ kpijobJson== " + kpijobJson);
        Response response1 = postServiceResponse(kpijobJson, "job_url", kpiprovideHeaders());

        System.out.println("+++ response.asString() == " + response1.asString());
        JsonPath jsonPath = new JsonPath(response1.asString());
        String kpiJobId = jsonPath.getString("id");
        System.out.println("+++ kpiJobId== " + kpiJobId);
        isEqual("Not valid response create KPI Job", 201, response1.statusCode());

        return kpiJobId;
    }
    // *****************Create KPI
    // JOB***************************************************//

    public String createKpiJobWithNoRandomInputAndOutputTag(String kpijob, long kpi_id, String outputtag,
                                                            String inputtag, boolean randomInputTag)
        throws IOException, URISyntaxException {

        printnewLine();
        System.out.println("*****************Create KPI JOB*******************");
        printnewLine();

        setSysProperty("kpiReferenceId", String.valueOf(kpi_id));
        String outputTag = outputtag + generateRandomNumber();
        setSysProperty("setOutputTagName", outputTag);
        setSysProperty("tenant", getTestProperty("tenantUUID"));
        if (randomInputTag) {
            String inputTag = inputtag + generateRandomNumber();
            setSysProperty("setInputTagName", inputTag);
        } else {
            setSysProperty("setInputTagName", inputtag);
        }

        String kpijobFile = kpijob;
        String kpijobJson = generateFile(kpijobFile, "kpi_job_e2e");
        System.out.println("+++ kpijobJson== " + kpijobJson);
        Response response1 = postServiceResponse(kpijobJson, "job_url", kpiprovideHeaders());

        System.out.println("+++ response.asString() == " + response1.asString());
        JsonPath jsonPath = new JsonPath(response1.asString());
        String kpiJobId = jsonPath.getString("id");
        System.out.println("+++ kpiJobId== " + kpiJobId);
        isEqual("Not valid response create KPI Job", 201, response1.statusCode());

        return kpiJobId;
    }

    // *****************Create KPI
    // JOB***************************************************//

    public String createKpiJobWithNoRandomBothInputAndOutputTag(String kpijob, long kpi_id, String outputtag,
                                                                String inputtag, String apmTsUrl)
        throws IOException, URISyntaxException {

        printnewLine();
        System.out.println("*****************Create KPI JOB*******************");
        printnewLine();
        
        System.out.println("assetUUID=" + getTestProperty("asssetUUID"));

        setSysProperty("kpiReferenceId", String.valueOf(kpi_id));
        setSysProperty("setOutputTagName", outputtag);
        setSysProperty("setInputTagName", inputtag);
        setSysProperty("setApmTSUrl", apmTsUrl);
        setSysProperty("tenant", getTestProperty("tenantUUID"));
        setSysProperty("asssetUUID", getTestProperty("asssetUUID"));

        String kpijobFile = kpijob;
        String kpijobJson = generateFile(kpijobFile, "kpi_job_e2e");
        System.out.println("+++ kpijobJson== " + kpijobJson);
        Response response1 = postServiceResponse(kpijobJson, "job_url", kpiprovideHeaders());

        System.out.println("+++ response.asString() == " + response1.asString());
        JsonPath jsonPath = new JsonPath(response1.asString());
        String kpiJobId = jsonPath.getString("id");
        System.out.println("+++ kpiJobId== " + kpiJobId);
        isEqual("Not valid response create KPI Job", 201, response1.statusCode());

        return kpiJobId;
    }

    // *****************Create KPI
    // JOB***************************************************//

    public String createKpiJobForAlertsWithNoRandomBothInputAndOutputTag(String kpijob, long kpi_id, String outputtag,
                                                                         String inputtag, String apmTsUrl,
                                                                         String jobName, String sourceKey)
        throws IOException, URISyntaxException {

        printnewLine();
        System.out.println("*****************Create KPI JOB*******************");
        printnewLine();

        setSysProperty("kpiReferenceId", String.valueOf(kpi_id));
        setSysProperty("setOutputTagName", outputtag);
        setSysProperty("setInputTagName", inputtag);
        setSysProperty("setApmTSUrl", apmTsUrl);
        setSysProperty("setJobName", jobName);
        setSysProperty("setSourceKey", sourceKey);

        setSysProperty("tenant", getTestProperty("tenantUUID"));

        String kpijobFile = kpijob;
        String kpijobJson = generateFile(kpijobFile, "kpi_job_e2e");
        System.out.println("+++ kpijobJson== " + kpijobJson);
        Response response1 = postServiceResponse(kpijobJson, "job_url", kpiprovideHeaders());

        System.out.println("+++ response.asString() == " + response1.asString());
        JsonPath jsonPath = new JsonPath(response1.asString());
        String kpiJobId = jsonPath.getString("id");
        System.out.println("+++ kpiJobId== " + kpiJobId);
        isEqual("Not valid response create KPI Job", 201, response1.statusCode());

        return kpiJobId;
    }

    // *****************Create KPI
    // JOB***************************************************//

    public String getLastAlerts(String kpijob, String jobName) throws IOException, URISyntaxException {

        printnewLine();
        System.out.println("*****************Get Last Alert******************");
        printnewLine();

        setSysProperty("setJobName", jobName);

        setSysProperty("tenant", getTestProperty("tenantUUID"));

        String kpijobFile = kpijob;
        String alertDataJson = generateFile(kpijobFile, "kpi_job_e2e");
        System.out.println("+++ kpijobJson== " + alertDataJson);
        Response response1 = postServiceResponse(alertDataJson, "last_alert_url", kpiprovideHeaders());

        System.out.println("+++ response.asString() == " + response1.asString());
        JsonPath jsonPath = new JsonPath(response1.asString());
        String sourcekey = jsonPath.getString("content");
        System.out.println("+++ sourcekey== " + sourcekey);
        isEqual("Not valid response gte last alerts", 200, response1.statusCode());

        return sourcekey;
    }

    // *****************Create KPI
    // JOB***************************************************//

    public String createPEKpiJobWithNoRandomBothInputAndOutputTag(String kpijob, long kpi_id, String outputtag,
                                                                  String inputtag, String apmTsUrl, String Filter)
        throws IOException, URISyntaxException {

        printnewLine();
        System.out.println("*****************Create KPI JOB*******************");
        printnewLine();

        setSysProperty("kpiReferenceId", String.valueOf(kpi_id));
        setSysProperty("setOutputTagName", outputtag);
        setSysProperty("setInputTagName", inputtag);
        setSysProperty("setFilter", Filter);
        setSysProperty("setApmTSUrl", apmTsUrl);
        setSysProperty("tenant", getTestProperty("tenantUUID"));

        String kpijobFile = kpijob;
        String kpijobJson = generateFile(kpijobFile, "kpi_job_e2e");
        System.out.println("+++ kpijobJson== " + kpijobJson);
        Response response1 = postServiceResponse(kpijobJson, "job_url", kpiprovideHeaders());

        System.out.println("+++ response.asString() == " + response1.asString());
        JsonPath jsonPath = new JsonPath(response1.asString());
        String kpiJobId = jsonPath.getString("id");
        System.out.println("+++ kpiJobId== " + kpiJobId);
        isEqual("Not valid response create KPI Job", 201, response1.statusCode());

        return kpiJobId;
    }

    // ****************Update kpi
    // Template*************************************************//
    public void updateKpiTemplate(String kpiTemplate, Long kpiId) throws IOException, URISyntaxException {
        printnewLine();

        System.out.println("*****************Update KPI TEMPLATE*******************");
        printnewLine();
        // Update KPI

        setSysProperty("setKpiName", "kpiname" + generateRandomNumberNonUUID());
        setSysProperty("tenant", getTestProperty("tenantUUID"));
        String kpiFile = kpiTemplate;
        String kpiJson = generateFile(kpiFile, "kpi_e2e");

        File f = new File(kpiJson);
        System.out.println("file path=" + f.getAbsolutePath());

        String path = f.getAbsolutePath().replace('\\', '/');

        String kpiJson_1 = FileUtils.readFileToString(new File(path));

        final String uri = getTestProperty("kpi_url");
        File analyticFile_update = new java.io.File(
            "src/main/resources/payloads/kpi_analytics/kpi_analytic_asset_ts_int.zip");

        MultiValueMap<String, Object> parameters = new LinkedMultiValueMap<String, Object>();
        parameters.add("uploadfile", new FileSystemResource(analyticFile_update));
        parameters.add("kpi", new ObjectMapper().readValue(kpiJson_1, KpiDetails.class));

        ResponseEntity<KpiDetails> update_response = restTemplate.exchange(uri, HttpMethod.PUT,
            new HttpEntity<MultiValueMap<String, Object>>(parameters, kpiprovideHeaders_1()), KpiDetails.class);

        Assert.assertEquals(update_response.getStatusCode(), HttpStatus.CREATED);
        Assert.assertTrue(update_response.getBody() instanceof KpiDetails);
        KpiDetails kpiDetails = update_response.getBody();
        kpiDetails = update_response.getBody();
        kpiId = kpiDetails.getId();
        System.out.println("------------->" + kpiDetails.getId());
        System.out.println(
            "\n\n+++ response.asString() == " + new ObjectMapper().writeValueAsString(kpiDetails) + "\n\n");

        printnewLine();
    }

    // ****************Update kpi
    // Template*************************************************//
    public void updateKpiTemplateJsonFile(Long kpiId, String kpiName, String kpiTemplateJsonPath)
        throws IOException, URISyntaxException {
        printnewLine();

        System.out.println("*****************Update KPI TEMPLATE*******************");
        printnewLine();
        // Update KPI
        setSysProperty("setKpiName", kpiName);
        setSysProperty("setKpiId", String.valueOf(kpiId));
        setSysProperty("tenant", getTestProperty("tenantUUID"));
        String kpiFile = kpiTemplateJsonPath;
        String kpiJson = generateFile(kpiFile, "kpi_e2e");

        final String uri = getTestProperty("kpi_url");
        File f = new File(kpiJson);
        System.out.println("file path=" + f.getAbsolutePath());
        String path = f.getAbsolutePath().replace('\\', '/');
        String kpiJsonUpdate = FileUtils.readFileToString(new File(path));

        // MultiValueMap<String, Object> parameters = new
        // LinkedMultiValueMap<String, Object>();
        // parameters.add("kpi", new ObjectMapper().readValue(kpiJson,
        // KpiDetails.class));

        String updateKpiJsonUrl = uri + "/" + kpiId;
        System.out.println("\n\nupdateKpiJsonUrl------------->" + updateKpiJsonUrl + "\n");
        ResponseEntity<KpiDetails> update_response = restTemplate.exchange(updateKpiJsonUrl, HttpMethod.PUT,
            new HttpEntity<KpiDetails>(new ObjectMapper().readValue(kpiJsonUpdate, KpiDetails.class),
                kpiprovideHeaders_4()),
            KpiDetails.class);

        Assert.assertEquals(update_response.getStatusCode(), HttpStatus.OK);
        Assert.assertTrue(update_response.getBody() instanceof KpiDetails);
        KpiDetails kpiDetails = update_response.getBody();
        kpiDetails = update_response.getBody();
        kpiId = kpiDetails.getId();
        System.out.println("------------->" + kpiDetails.getId());
        System.out.println(
            "\n\n+++ response.asString() == " + new ObjectMapper().writeValueAsString(kpiDetails) + "\n\n");

        printnewLine();
    }

    public String createKpiJobWithSchedulerInfo(String kpijob, long kpi_id, String outputtag, String inputtag,
                                                String apmTsUrl, String cron) throws IOException, URISyntaxException {
        printnewLine();
        System.out.println("*****************Create KPI JOB*******************");
        printnewLine();

        setSysProperty("kpiReferenceId", String.valueOf(kpi_id));
        setSysProperty("setOutputTagName", outputtag);
        setSysProperty("setInputTagName", inputtag);
        setSysProperty("setApmTSUrl", apmTsUrl);
        setSysProperty("tenant", getTestProperty("tenantUUID"));



      /*  Calendar now = Calendar.getInstance(TimeZone.getTimeZone("UTC"));
        System.out.println("OOTestUtil.createKpiJobWithSchedulerInfo()..."+now.toString());
        now.add(Calendar.SECOND, 60);
        System.out.println("OOTestUtil.createKpiJobWithSchedulerInfo()...added a minute " + "");

        String month = new SimpleDateFormat("MMM").format(now.getTime()).toUpperCase();
        String cron = now.get(Calendar.SECOND) + " " + now.get(Calendar.MINUTE) + " " + now.get(Calendar.HOUR_OF_DAY)
                + " " + now.get(Calendar.DATE) + " " + month + " ? " + now.get(Calendar.YEAR);*/

        System.out.println("cron=" + cron);
        setSysProperty("cron", cron);
        setSysProperty("startTime", LocalDateTime.now().minus(1, ChronoUnit.DAYS).toString());

        String kpijobJson = generateFile(kpijob, "kpi_job_e2e");
        System.out.println("+++ kpijobJson== " + kpijobJson);
        Response response1 = postServiceResponse(kpijobJson, "job_url", kpiprovideHeaders());

        System.out.println("+++ response.asString() == " + response1.asString());
        JsonPath jsonPath = new JsonPath(response1.asString());
        String kpiJobId = jsonPath.getString("id");
        System.out.println("+++ kpiJobId== " + kpiJobId);
        //String kpiSchedulerCron = jsonPath.getString("kpiScheduler.cron");
        isEqual("Not valid response create KPI Job", 201, response1.statusCode());
        //isEqual("cron not returned from response", cron, kpiSchedulerCron);
        return kpiJobId;
    }

    public String createKpiJobWithSchedulerInfo(String kpijob, long kpi_id, String outputtag, String inputtag,
                                                String apmTsUrl, int... seconds)
        throws IOException, URISyntaxException {
        return createKpiJobWithSchedulerInfo(kpijob, kpi_id, outputtag, inputtag, apmTsUrl,
            KPIJOB_SCHEDULE_CRON_EXPRESSION);
    }

    public Response createKpiJobWithSchedulerInfo_errorResponse(String kpijob, long kpi_id, String outputtag,
                                                                String inputtag,
                                                                String apmTsUrl, int... seconds)
        throws IOException, URISyntaxException {
        printnewLine();
        System.out.println("*****************Create KPI JOB*******************");
        printnewLine();

        setSysProperty("kpiReferenceId", String.valueOf(kpi_id));
        setSysProperty("setOutputTagName", outputtag);
        setSysProperty("setInputTagName", inputtag);
        setSysProperty("setApmTSUrl", apmTsUrl);
        setSysProperty("tenant", getTestProperty("tenantUUID"));

        // per 2 min
        String cron = "0 0/2 * 1/1 * ? *";

        System.out.println("cron=" + cron);
        setSysProperty("cron", cron);
        setSysProperty("startTime", LocalDateTime.now().minus(1, ChronoUnit.DAYS).toString());

        String kpijobJson = generateFile(kpijob, "kpi_job_e2e");
        System.out.println("+++ kpijobJson== " + kpijobJson);
        return postServiceResponse(kpijobJson, "job_url", kpiprovideHeaders());
    }

    public String createKpiJobWithSchedulerInfoVersion2(String kpijob, long kpi_id, String outputtag, String inputtag,
                                                        String apmTsUrl, int... seconds)
        throws IOException, URISyntaxException {
        printnewLine();
        System.out.println("*****************Create KPI JOB*******************");
        printnewLine();

        setSysProperty("kpiReferenceId", String.valueOf(kpi_id));
        setSysProperty("setOutputTagName", outputtag);
        setSysProperty("setInputTagName", inputtag);
        setSysProperty("setApmTSUrl", apmTsUrl);
        setSysProperty("tenant", getTestProperty("tenantUUID"));

        setSysProperty("cron", "0/40 0/1 * 1/1 * ? *");
        setSysProperty("startTime", LocalDateTime.now().minus(1, ChronoUnit.DAYS).toString());

        String kpijobJson = generateFile(kpijob, "kpi_job_e2e");
        System.out.println("+++ kpijobJson== " + kpijobJson);
        Response response1 = postServiceResponse(kpijobJson, "job_url", kpiprovideHeaders());

        System.out.println("+++ response.asString() == " + response1.asString());
        JsonPath jsonPath = new JsonPath(response1.asString());
        String kpiJobId = jsonPath.getString("id");
        System.out.println("+++ kpiJobId== " + kpiJobId);
        //String kpiSchedulerCron = jsonPath.getString("kpiScheduler.cron");
        isEqual("Not valid response create KPI Job", 201, response1.statusCode());
        //isEqual("cron not returned from response", cron, kpiSchedulerCron);
        return kpiJobId;
    }

    // *****************Get Kpi
    // Job***************************************************//

    public String getKpiJob(String kpiJobId) throws InterruptedException {

        printnewLine();
        System.out.println("*****************Get Kpi Job*******************");
        printnewLine();

        Response response2 = getServiceResponse("job_url" + "/id/" + kpiJobId, kpiprovideHeaders_2());

        System.out.println("+++response== " + response2.asString());
        System.out.println("+++response status code== " + response2.getStatusCode());
        printnewLine();

        return response2.asString();
    }
    // *****************Get output tag from Kpi
    // Job***************************************************//

    public String getOutputTagFromKpiJob(String kpiJobId) throws InterruptedException {

        printnewLine();
        System.out.println("*****************Get output tag from Kpi Job*******************");
        printnewLine();

        Response response2 = getServiceResponse("job_url" + "/id/" + kpiJobId, kpiprovideHeaders_2());
        isEqual("Not valid response for Start Job", 200, response2.statusCode());

        List<String> list_of_tags = com.jayway.jsonpath.JsonPath.read(response2.asString(), "$..tag");
        String outputTag = String.valueOf(list_of_tags.get(0));

        System.out.println("+++tag== " + outputTag);
        printnewLine();

        return outputTag;
    }
    // *****************Get output tag from Kpi
    // Job***************************************************//

    public String getInputtagOfKpiJob(String kpiJobId) throws InterruptedException {

        printnewLine();
        System.out.println("*****************Get Input tag from Kpi Job*******************");
        printnewLine();

        Response response2 = getServiceResponse("job_url" + "/id/" + kpiJobId, kpiprovideHeaders_2());
        isEqual("Not valid response for Start Job", 200, response2.statusCode());

        List<String> list_of_tags = com.jayway.jsonpath.JsonPath.read(response2.asString(), "$..Inputtag");
        String outputTag = String.valueOf(list_of_tags.get(0));

        System.out.println("+++tag== " + outputTag);
        printnewLine();

        return outputTag;
    }
    // *****************Get output tag from Kpi
    // Job***************************************************//

    public String getOutputtagOfKpiJob(String kpiJobId) throws InterruptedException {

        printnewLine();
        System.out.println("*****************Get output tag from Kpi Job*******************");
        printnewLine();

        Response response2 = getServiceResponse("job_url" + "/id/" + kpiJobId, kpiprovideHeaders_2());
        isEqual("Not valid response for Start Job", 200, response2.statusCode());

        List<String> list_of_tags = com.jayway.jsonpath.JsonPath.read(response2.asString(), "$..Outputtag");
        String outputTag = String.valueOf(list_of_tags.get(0));

        System.out.println("+++tag== " + outputTag);
        printnewLine();

        return outputTag;
    }
    // *****************START
    // JOB***************************************************//

    public String startKpiJob(String kpiJobId) throws InterruptedException, IOException {

        printnewLine();
        System.out.println("*****************START KPI JOB*******************");
        printnewLine();
        System.out.println("+++start_job_url== " + getTestProperty("start_job_url") + "/" + kpiJobId);

        Response response2 = postServiceResponse("start_job_url" + "/" + kpiJobId, kpiprovideHeaders());
        System.out.println("+++response== " + response2.asString());
        System.out.println("+++response status code== " + response2.statusCode());
        // isEqual("Not valid response for Start Job", 200,
        // response2.statusCode());

        JsonPath jsonPath1 = new JsonPath(response2.asString());
        String runtimeJobId = jsonPath1.getString("runtime_jobId");
        System.out.println("+++runtimeJobId== " + runtimeJobId);
        printnewLine();

        return runtimeJobId;
    }
    
    // *****************START
    // JOB***************************************************//

    public String startSecondTimeKpiJob(String kpiJobId) throws InterruptedException, IOException {

        printnewLine();
        System.out.println("*****************START KPI JOB*******************");
        printnewLine();
        System.out.println("+++start_job_url== " + getTestProperty("start_job_url") + "/" + kpiJobId);

        Response response2 = postServiceResponse("start_job_url" + "/" + kpiJobId, kpiprovideHeaders());
        System.out.println("+++response== " + response2.asString());
        System.out.println("+++response status code== " + response2.statusCode());
        isEqual("Not valid response for Start Job", 409,response2.statusCode());

        JsonPath jsonPath1 = new JsonPath(response2.asString());
        String runtimeJobId = jsonPath1.getString("runtime_jobId");
        System.out.println("+++runtimeJobId== " + runtimeJobId);
        printnewLine();

        return runtimeJobId;
    }


    public void startStreamingKpiJob(String kpiJobId) throws InterruptedException, IOException {

 /*       printnewLine();
        System.out.println("*****************START KPI JOB*******************");
        printnewLine();
        System.out.println("+++start_job_url== " + getTestProperty("start_job_url") + "/" + kpiJobId);
        Thread thread = new Thread() {
            @Override
            public void run() {
                System.out.println("Thread Running");
                try {
                    postServiceResponse("start_job_url" + "/" + kpiJobId, kpiprovideHeaders());
                } catch (IOException e) {
                    // TODO Auto-generated catch block
                    e.printStackTrace();
                }
            }
        };
        thread.start();*/

        printnewLine();
        System.out.println("*****************START KPI JOB*******************");
        printnewLine();
        System.out.println("+++start_job_url== " + getTestProperty("start_job_url") + "/" + kpiJobId);

        Response response2 = postServiceResponse("start_job_url" + "/" + kpiJobId, kpiprovideHeaders());
        System.out.println("+++response== " + response2.asString());
        System.out.println("+++response status code== " + response2.statusCode());
        // isEqual("Not valid response for Start Job", 200,
        // response2.statusCode());

        JsonPath jsonPath1 = new JsonPath(response2.asString());
        String runtimeJobId = jsonPath1.getString("runtime_jobId");
        System.out.println("+++runtimeJobId== " + runtimeJobId);
        printnewLine();

        return;
    }

    public String startScheduledKpiJob(String kpiJobId) throws InterruptedException, IOException {

        printnewLine();
        System.out.println("*****************START KPI JOB*******************");
        printnewLine();
        System.out.println("+++start_job_url== " + getTestProperty("start_job_url") + "/" + kpiJobId);
        Response response2 = postServiceResponse("start_job_url" + "/" + kpiJobId, kpiprovideHeaders());
        System.out.println("+++response== " + response2.asString());
        System.out.println("+++response status code== " + response2.statusCode());
        // isEqual("Not valid response for Start Job", 200,
        // response2.statusCode());

        JsonPath jsonPath1 = new JsonPath(response2.asString());
        String schedulerId = "";
        //String schedulerId = jsonPath1.getString("kpiScheduler.id");
        //System.out.println("+++schedulerId== " + schedulerId);
        printnewLine();
        return schedulerId;
    }

    public String startKpiJobTwice(String kpiJobId) throws InterruptedException, IOException {
        String runtimeJobId = startKpiJob(kpiJobId);
        Thread.sleep(30000);
        if (runtimeJobId == null) {
            runtimeJobId = startKpiJob(kpiJobId);
            Thread.sleep(15000);
        }
        return runtimeJobId;
    }

    // *****************Status of
    // JOB***************************************************//
    public String getStatusOfJob(String kpiJobId) {

        printnewLine();
        System.out.println("*****************Status of JOB********************");
        printnewLine();

        System.out.println("+++ status job url== " + getTestProperty("status_of_job_url") + "/" + kpiJobId);

        Response response_job = getServiceResponse("status_of_job_url" + "/" + kpiJobId, kpiprovideHeaders_2());
        /* KNOWN BUG--> DELETE JOB NOT WORKING CONSISTENTLY */
        // isEqual("Not valid response for Start Job", 400,
        // response_job.statusCode());

        System.out.println("+++ response_job.asString() == " + response_job.asString());
        JsonPath jsonPath_job = new JsonPath(response_job.asString());
        String status_job = jsonPath_job.getString("status");
        String message_job = jsonPath_job.getString("message");
        String jobId_job = jsonPath_job.getString("jobId");
        String runtimeJobId_job = jsonPath_job.getString("runtimeJobId");

        System.out.println("Job+++status== " + status_job);
        System.out.println("Job +++message== " + message_job);
        System.out.println("Job +++jobId== " + jobId_job);
        System.out.println("Job +++runtimeJobId_status== " + runtimeJobId_job);

        return status_job;
    }

    public JsonPath getStatusResponseOfJob(String kpiJobId) {

        printnewLine();
        System.out.println("*****************Status of JOB********************");
        printnewLine();
        System.out.println("+++ status job url== " + getTestProperty("status_of_job_url") + "/" + kpiJobId);
        Response response_job = getServiceResponse("status_of_job_url" + "/" + kpiJobId, kpiprovideHeaders_2());
        JsonPath jsonPath_job = new JsonPath(response_job.asString());
        return jsonPath_job;
    }

    // *****************Message of
    // JOB***************************************************//
    public String getMessageOfJob(String kpiJobId) {

        printnewLine();
        System.out.println("*****************Message of JOB********************");
        printnewLine();

        Response response_job = getServiceResponse("status_of_job_url" + "/" + kpiJobId, kpiprovideHeaders_2());
        /* KNOWN BUG--> DELETE JOB NOT WORKING CONSISTENTLY */
        // isEqual("Not valid response for Start Job", 400,
        // response_job.statusCode());

        // System.out.println("+++ response2.asString() == " +
        // response2.asString());
        JsonPath jsonPath_job = new JsonPath(response_job.asString());
        String status_job = jsonPath_job.getString("status");
        String message_job = jsonPath_job.getString("message");
        String jobId_job = jsonPath_job.getString("jobId");
        String runtimeJobId_job = jsonPath_job.getString("runtimeJobId");

        System.out.println("Job+++status== " + status_job);
        System.out.println("Job +++message== " + message_job);
        System.out.println("Job +++jobId== " + jobId_job);
        System.out.println("Job +++runtimeJobId_status== " + runtimeJobId_job);

        return message_job;
    }

    // *****************List of JOB for a kpi
    // id***************************************************//
    public String getListOfJobsForAKpiId(long kpi_id) {

        printnewLine();
        System.out.println("*****************List of JOBs********************");
        printnewLine();

        Response response = getServiceResponse("kpi_url" + "/" + kpi_id + "/jobs", kpiprovideHeaders_2());

        System.out.println("List of Jobs== " + response.asString());

        return "";
    }

    // ****************Post data point to APM TIME
    // SERIES*************************************************//
    public String postDataPointToAPMTimeSeries(String dataToBePosted, String setInputTag)
        throws IOException, URISyntaxException, InterruptedException {

        printnewLine();
        System.out.println("*****************Post data point to APM TIME SERIES******************");

        String tagNamePosted = setInputTag + generateRandomNumber();
        setSysProperty("setTagName", tagNamePosted);
        String d = dataToBePosted;

        String dataIngestionFileJson = generateFile(d, "dataIngestionFile");

        File f1 = new File(dataIngestionFileJson);
        System.out.println("file path=" + f1.getAbsolutePath());
        String path1 = f1.getAbsolutePath().replace('\\', '/');
        String dataIngestionFileJsonAsString = FileUtils.readFileToString(new File(path1));
        System.out.println("dataIngestionFileJsonAsString------->" + dataIngestionFileJsonAsString);
        Response response_apm_ts_post = postServiceResponse(dataIngestionFileJsonAsString, "timeSeriesIngestionURL",
            ApmProvideHeaders());
        Thread.sleep(30000);
        System.out.println("response_apm_ts_post------->" + response_apm_ts_post.asString());
        isEqual("Data not Posted to Apm Time Series", 201, response_apm_ts_post.getStatusCode());
        printnewLine();
        return tagNamePosted;
    }

    // ****************Post data point to APM TIME
    // SERIES*************************************************//
    public void postDataPointToAPMTimeSeries(String dataIngestionFileJson)
        throws IOException, URISyntaxException, InterruptedException {

        printnewLine();
        System.out.println("*****************Post data point to APM TIME SERIES******************");

        File f1 = new File(dataIngestionFileJson);
        System.out.println("file path=" + f1.getAbsolutePath());
        String path1 = f1.getAbsolutePath().replace('\\', '/');
        String dataIngestionFileJsonAsString = FileUtils.readFileToString(new File(path1));
        System.out.println("dataIngestionFileJsonAsString------->" + dataIngestionFileJsonAsString);
        Response response_apm_ts_post = postServiceResponse(dataIngestionFileJsonAsString, "timeSeriesIngestionURL",
            ApmProvideHeaders());
        Thread.sleep(30000);
        System.out.println("response_apm_ts_post------->" + response_apm_ts_post.asString());
        printnewLine();
        isEqual("Data not Posted to Apm Time Series", true, response_apm_ts_post.asString().contains("Success"));

        isEqual("Data not Posted to Apm Time Series", 201, response_apm_ts_post.getStatusCode());

        return;
    }

    // ****************Post data point to APM TIME
    // SERIES*************************************************//
    public int postRandomDataPointToAPMTimeSeries(String dataIngestionFileJson, String apmTsTag)
        throws IOException, URISyntaxException, InterruptedException {

        printnewLine();
        System.out.println("*****************Post data point to APM TIME SERIES******************");

        int apmTsValue = generateRandomNumber3Digits();
        System.out.println("OOTestUtil.postRandomDataPointToAPMTimeSeries() posted " + apmTsValue);
        setSysProperty("setTsValue", String.valueOf(apmTsValue));
        setSysProperty("setTsCurrentTime", getCurrentTime());
        setSysProperty("setTsTag", apmTsTag);

        String dataIngestionFile = generateFile(dataIngestionFileJson, "dataIngestionFile");

        File f1 = new File(dataIngestionFile);
        System.out.println("file path=" + f1.getAbsolutePath());
        String path1 = f1.getAbsolutePath().replace('\\', '/');
        String dataIngestionFileJsonAsString = FileUtils.readFileToString(new File(path1));
        System.out.println("dataIngestionFileJsonAsString------->" + dataIngestionFileJsonAsString);
        Response response_apm_ts_post = postServiceResponse(dataIngestionFileJsonAsString, "timeSeriesIngestionURL",
            ApmProvideHeaders());
        Thread.sleep(30000);
        System.out.println("response_apm_ts_post------->" + response_apm_ts_post.getStatusCode());
        System.out.println("response_apm_ts_post------->" + response_apm_ts_post.asString());
        isEqual("Data not Posted to Apm Time Series", 201, response_apm_ts_post.getStatusCode());
        printnewLine();

        return apmTsValue;
    }

    // ****************Post data point to APM TIME
    // SERIES*************************************************//
    public void postTSdataToAPMTimeSeries(String dataIngestionFileJson)
        throws IOException, URISyntaxException, InterruptedException {

        printnewLine();
        System.out.println("*****************Post data point to APM TIME SERIES******************");

        Response response_apm_ts_post = postServiceResponse(dataIngestionFileJson, "timeSeriesIngestionURL",
            ApmProvideHeaders());
        Thread.sleep(30000);
        System.out.println("response_apm_ts_post------->" + response_apm_ts_post.getStatusCode());
        System.out.println("response_apm_ts_post------->" + response_apm_ts_post.asString());
        isEqual("Data not Posted to Apm Time Series", 201, response_apm_ts_post.getStatusCode());
        printnewLine();

        return;
    }

    public int postRandomDataPointToAPMTimeSeriesWithTimestamp(String dataIngestionFileJson, String apmTsTag,
                                                               String timestamp)
        throws IOException, URISyntaxException, InterruptedException {

        printnewLine();
        System.out.println("****************Post data point to APM TIME SERIES******************");

        int apmTsValue = generateRandomNumber3Digits();
        setSysProperty("setTsValue", String.valueOf(apmTsValue));
        setSysProperty("setTsCurrentTime", timestamp);
        setSysProperty("setTsTag", apmTsTag);

        String dataIngestionFile = generateFile(dataIngestionFileJson, "dataIngestionFile");

        File f1 = new File(dataIngestionFile);
        System.out.println("file path=" + f1.getAbsolutePath());
        String path1 = f1.getAbsolutePath().replace('\\', '/');
        String dataIngestionFileJsonAsString = FileUtils.readFileToString(new File(path1));
        System.out.println("dataIngestionFileJsonAsString------->" + dataIngestionFileJsonAsString);
        Response response_apm_ts_post = postServiceResponse(dataIngestionFileJsonAsString, "timeSeriesIngestionURL",
            ApmProvideHeaders());
        Thread.sleep(30000);
        System.out.println("response_apm_ts_post------->" + response_apm_ts_post.getStatusCode());
        System.out.println("response_apm_ts_post------->" + response_apm_ts_post.asString());
        isEqual("Data not Posted to Apm Time Series", 201, response_apm_ts_post.getStatusCode());
        printnewLine();

        return apmTsValue;
    }

    // ****************Post data point to Kafka
    // Topic*************************************************//
    public String postDataPointToKafkaTopic(String dataToBePosted, String setInputTag)
        throws IOException, InterruptedException, URISyntaxException {

        String tagNamePosted = setInputTag + generateRandomNumber();
        setSysProperty("setTagName", tagNamePosted);
        // String d = dataToBePosted;

        String dataIngestionFileJson = generateFile(dataToBePosted, "dataIngestionFile");

        File f1 = new File(dataIngestionFileJson);
        System.out.println("file path=" + f1.getAbsolutePath());
        String path1 = f1.getAbsolutePath().replace('\\', '/');
        String dataIngestionFileJsonAsString = FileUtils.readFileToString(new File(path1));

        Response response_producer = postServiceResponse(dataIngestionFileJsonAsString, "kafka_producer_url",
            kpiprovideHeaders_5());

        System.out.println("+++ response == " + response_producer.asString());
        /*
         * System.out.println("+++ string of Tag Name == " +
		 * com.jayway.jsonpath.JsonPath.read(response_producer.asString(),
		 * "$..name"));
		 * 
		 * 
		 * System.out.println("+++ string of timestamp == " +
		 * com.jayway.jsonpath.JsonPath.read(response_producer.asString(),
		 * "$..datapoints[*][0]"));
		 * 
		 * List<String> timestamp_producedData =
		 * com.jayway.jsonpath.JsonPath.read(response_producer.asString(),
		 * "$..datapoints[*][0]"); List<String> value_producedData =
		 * com.jayway.jsonpath.JsonPath.read(response_producer.asString(),
		 * "$..datapoints[*][1]"); //String valuePosted =
		 * String.valueOf(value_producedData.get(0));
		 * 
		 * //List<String> list_of_tags
		 * =com.jayway.jsonpath.JsonPath.read(response_producer.asString(),
		 * "$..name"); //String tagNamePosted =
		 * String.valueOf(list_of_tags.get(0));
		 * 
		 * 
		 * System.out.println("+++timestamp_ingestedData== " +
		 * String.valueOf(timestamp_producedData.get(0))); System.out.println(
		 * "+++value_producedData== " +
		 * String.valueOf(value_producedData.get(0)));
		 */
        isEqual("Data not Posted to Kafka Topic", 200, response_producer.getStatusCode());

        return tagNamePosted;
    }

    // ****************Post data point to Kafka
    // Topic*************************************************//
    public String postDataPointToKafkaTopicNoRandomTag(String dataToBePosted, String setInputTag)
        throws IOException, InterruptedException, URISyntaxException {

        String tagNamePosted = setInputTag;
        setSysProperty("setTagName", tagNamePosted);
        // String d = dataToBePosted;

        String dataIngestionFileJson = generateFile(dataToBePosted, "dataIngestionFile");

        File f1 = new File(dataIngestionFileJson);
        System.out.println("file path=" + f1.getAbsolutePath());
        String path1 = f1.getAbsolutePath().replace('\\', '/');
        String dataIngestionFileJsonAsString = FileUtils.readFileToString(new File(path1));

        System.out.println("kafka_producer_url=" + getTestProperty("kafka_producer_url"));
        Response response_producer = postServiceResponse(dataIngestionFileJsonAsString, "kafka_producer_url",
            kpiprovideHeaders_5());

        System.out.println("+++ response == " + response_producer.asString());
        /*
         * System.out.println("+++ string of Tag Name == " +
		 * com.jayway.jsonpath.JsonPath.read(response_producer.asString(),
		 * "$..name"));
		 * 
		 * 
		 * System.out.println("+++ string of timestamp == " +
		 * com.jayway.jsonpath.JsonPath.read(response_producer.asString(),
		 * "$..datapoints[*][0]"));
		 * 
		 * List<String> timestamp_producedData =
		 * com.jayway.jsonpath.JsonPath.read(response_producer.asString(),
		 * "$..datapoints[*][0]"); List<String> value_producedData =
		 * com.jayway.jsonpath.JsonPath.read(response_producer.asString(),
		 * "$..datapoints[*][1]"); //String valuePosted =
		 * String.valueOf(value_producedData.get(0));
		 * 
		 * //List<String> list_of_tags
		 * =com.jayway.jsonpath.JsonPath.read(response_producer.asString(),
		 * "$..name"); //String tagNamePosted =
		 * String.valueOf(list_of_tags.get(0));
		 * 
		 * 
		 * System.out.println("+++timestamp_ingestedData== " +
		 * String.valueOf(timestamp_producedData.get(0))); System.out.println(
		 * "+++value_producedData== " +
		 * String.valueOf(value_producedData.get(0)));
		 */
        isEqual("Data not Posted to Kafka Topic", 200, response_producer.getStatusCode());

        return tagNamePosted;
    }

    // ****************Post data point to Kafka
    // Topic*************************************************//
    public int postDataPointToKafkaTopicGenData(String dataToBePosted, String predixTsTag)
        throws IOException, InterruptedException, URISyntaxException {

        int predixTsValue = generateRandomNumberNonUUID();
        setSysProperty("setTsTag", predixTsTag);
        setSysProperty("setTsValue", String.valueOf(predixTsValue));
        setSysProperty("setTsCurrentTime", String.valueOf(getCurrentTimeInMillisec()));

        String dataIngestionFileJson = generateFile(dataToBePosted, "dataIngestionFile");

        File f1 = new File(dataIngestionFileJson);
        System.out.println("file path=" + f1.getAbsolutePath());
        String path1 = f1.getAbsolutePath().replace('\\', '/');
        String dataIngestionFileJsonAsString = FileUtils.readFileToString(new File(path1));

        Response response_producer = postServiceResponse(dataIngestionFileJsonAsString, "kafka_producer_url",
            kpiprovideHeaders_5());
        System.out.println("+++ response == " + response_producer.asString());

        isEqual("Data not Posted to kafka", 200, response_producer.getStatusCode());
        // isEqual("Data not Posted to kafka", true,
        // response_producer.asString().contains(":0"));

        return predixTsValue;
    }
    // ****************Get data point from Kafka
    // Topic*************************************************//

    public String getDataPointFromKafkaTopic(String tagNamePosted) throws IOException, URISyntaxException {

        printnewLine();
        System.out.println("*****************GET DATA FROM KAFKA TOPIC******************");
        printnewLine();
        System.out.println("+++ consumer url == " + getTestProperty("kafka_consumer_url"));
        Response response_consumer = getServiceResponse("kafka_consumer_url", kpiprovideHeaders_5());
        System.out.println("+++ response_consumer status code == " + response_consumer.getStatusCode());
        System.out.println("+++ response_consumer.asString() == " + response_consumer.asString());

        isEqual("Data not retrieved from Kafka topic", 200, response_consumer.statusCode());

        List<String> list_of_tags_consumed = com.jayway.jsonpath.JsonPath.read(response_consumer.asString(), "$..name");
        String tagNameConsumed = String.valueOf(list_of_tags_consumed.get(0));

        System.out.println("+++ string of timestamp == "
            + com.jayway.jsonpath.JsonPath.read(response_consumer.asString(), "$..datapoints[*][0]"));

        List<String> timestamp_consumerData = com.jayway.jsonpath.JsonPath.read(response_consumer.asString(),
            "$..datapoints[*][0]");
        System.out.println("+++timestamp_ingestedData== " + String.valueOf(timestamp_consumerData.get(0)));

        List<String> value_consumerData = com.jayway.jsonpath.JsonPath.read(response_consumer.asString(),
            "$..datapoints[*][1]");
        System.out.println("+++value_consumerData== " + String.valueOf(value_consumerData.get(0)));
        String calculatedData = String.valueOf(value_consumerData.get(0));

        // isEqual("Data not posted to kafka
        // topic",true,tagNameConsumed.equalsIgnoreCase(tagNamePosted));
        return calculatedData;
    }

    // ****************Get Response from Kafka
    // Topic*************************************************//

    public String getResponseFromKafkaTopic(String tagNamePosted) throws IOException, URISyntaxException {

        printnewLine();
        System.out.println("*****************GET DATA FROM KAFKA TOPIC******************");
        System.out.println("kafka_consumer_url=" + getTestProperty("kafka_consumer_url"));
        printnewLine();
        Response response_consumer = getServiceResponse("kafka_consumer_url", kpiprovideHeaders());
        System.out.println("+++ response_consumer.asString() == " + response_consumer.asString());

        isEqual("Data not retrieved from Kafka topic", 200, response_consumer.statusCode());
        System.out.println("response=" + response_consumer.asString());
        return response_consumer.asString();
    }

    // ***************Get data from APM TIME
    // SERIES*************************************************//
    public void getDataFromApmTimeSeries(String tagNamePosted, String valueExpected) throws InterruptedException {

        printnewLine();
        System.out.println("*****************Get data from APM TIME SERIES******************");

        // check if the tag and data was ingested successfully or not

        Map<String, Object> queryParams = new LinkedHashMap<String, Object>();
        queryParams.put("tagList", tagNamePosted);
        queryParams.put("startTime", getYesterdaysTime());
        
      
        System.out.println("url=" + getTestProperty("timeSeriesGetDataURL"));
        Response response_apm_ts = getServiceResponse("timeSeriesGetDataURL", queryParams, ApmProvideHeaders());
        Thread.sleep(30000);
        System.out.println("+++ string of response_apm_ts == " + response_apm_ts.asString());
        System.out.println("+++ string of response_apm_ts == " + valueExpected);
        
        isEqual("Tag name not found  in APM TS", true, response_apm_ts.asString().contains(tagNamePosted));
   
        isEqual("Calculated data of APM TS is not matching expected value", true,response_apm_ts.asString().contains(valueExpected));
        
        if (response_apm_ts.asString().contains(valueExpected)) {
            System.out.println("+++ TEST PASSED ++++\n" + valueExpected + "is in\n" + response_apm_ts.asString());
        }

        return;
    }

    public String getDataFromApmTimeSeriesWithTimeFilter(String tagNamePosted, String timestamp)
        throws InterruptedException {

        printnewLine();
        System.out.println("*****************Get data from APM TIME SERIES******************");

        // check if the tag and data was ingested successfully or not

        Map<String, Object> queryParams = new LinkedHashMap<String, Object>();
        queryParams.put("tagList", tagNamePosted);
        queryParams.put("startTime", timestamp);
        System.out.println("url=" + getTestProperty("timeSeriesGetDataURL_notime"));
        Response response_apm_ts = getServiceResponse("timeSeriesGetDataURL_notime", queryParams, ApmProvideHeaders());
        Thread.sleep(30000);
        System.out.println("+++ string of response_apm_ts == " + response_apm_ts.asString());
        isEqual("Tag name not found  in APM TS", true, response_apm_ts.asString().contains(tagNamePosted));

        return response_apm_ts.asString();
    }

    // ***************Get data from APM TIME
    // SERIES*************************************************//
    public void getAPMAssets() throws InterruptedException {

        printnewLine();
        System.out.println("*****************Get APM Assets******************");

        Response response_apm_ts = getServiceResponse("assetGetURl", ApmProvideHeaders());
        Thread.sleep(20000);
        //System.out.println("+++ string of response_apm_ts ==" + response_apm_ts.asString());
        //isEqual("Error getting APM Asset Data", true, response_apm_ts.asString().contains("OO-CA-SIMUL-ASSET-ID1"));
        //isEqual("Error getting APM Asset Data", true, response_apm_ts.asString().contains("OO CA Asset Description"));

        return;
    }

    // ****************Post data point to Event
    // Hub*************************************************//
    public void postDataPointToEventHub(String dataToBePosted, String setInputTag)
        throws IOException, InterruptedException, URISyntaxException {
        printnewLine();
        System.out.println("*****************POST DATA TO EVENT HUB*******************");
        printnewLine();

        setSysProperty("setTagName", setInputTag + generateRandomNumber());
        // String d = dataToBePosted;

        String dataIngestionFileJson = generateFile(dataToBePosted, "dataIngestionFile");

        File f1 = new File(dataIngestionFileJson);
        System.out.println("file path=" + f1.getAbsolutePath());
        String path1 = f1.getAbsolutePath().replace('\\', '/');
        String dataIngestionFileJsonAsString = FileUtils.readFileToString(new File(path1));
        System.out.println("+++ dataIngestionFileJsonAsString== " + dataIngestionFileJsonAsString);
        Response response_producer = postServiceResponse(dataIngestionFileJsonAsString, "eventhub_post_data_url",
            kpiprovideHeaders_5());

        isEqual("Data not Posted to Eventhub", 202, response_producer.getStatusCode());
        // isEqual("Data not Posted to Eventhub", true,
        // response_producer.asString().contains(":0"));

        return;
    }

    // ****************Post data point to Event
    // Hub*************************************************//
    public void postDataPointToEventHubNoRandomTag(String dataToBePosted, String setInputTag)
        throws IOException, InterruptedException, URISyntaxException {
        printnewLine();
        System.out.println("*****************POST DATA TO EVENT HUB*******************");
        System.out.println("url=" + getTestProperty("eventhub_post_data_url"));
        printnewLine();

        setSysProperty("setTagName", setInputTag);
        // String d = dataToBePosted;

        String dataIngestionFileJson = generateFile(dataToBePosted, "dataIngestionFile");

        File f1 = new File(dataIngestionFileJson);
        System.out.println("file path=" + f1.getAbsolutePath());
        String path1 = f1.getAbsolutePath().replace('\\', '/');
        String dataIngestionFileJsonAsString = FileUtils.readFileToString(new File(path1));
        System.out.println("+++ dataIngestionFileJsonAsString== " + dataIngestionFileJsonAsString);
        Response response_producer = postServiceResponse(dataIngestionFileJsonAsString, "eventhub_post_data_url",
            kpiprovideHeaders_5());
        System.out.println("response=" + response_producer.asString());
        isEqual("Data not Posted to Eventhub", 202, response_producer.getStatusCode());
        // isEqual("Data not Posted to Eventhub", true,
        // response_producer.asString().contains(":0"));

        return;
    }

    // ****************Post data point to Event
    // Hub*************************************************//
    public int postDataPointToEventHubGenData(String dataToBePosted, String predixTsTag)
        throws IOException, InterruptedException, URISyntaxException {
        printnewLine();
        System.out.println("*****************POST DATA TO EVENT HUB*******************");
        printnewLine();
        System.out.println("url=" + getTestProperty("eventhub_post_data_url"));
        int predixTsValue = generateRandomNumber3Digits();
        System.out.println("OOTestUtil.postDataPointToEventHubGenData() with data=" + predixTsValue);
        setSysProperty("setTsTag", predixTsTag);
        setSysProperty("setTsValue", String.valueOf(predixTsValue));
        setSysProperty("setTsCurrentTime", String.valueOf(getCurrentTimeInMillisec()));

        String dataIngestionFileJson = generateFile(dataToBePosted, "dataIngestionFile");

        File f1 = new File(dataIngestionFileJson);
        System.out.println("file path=" + f1.getAbsolutePath());
        String path1 = f1.getAbsolutePath().replace('\\', '/');
        String dataIngestionFileJsonAsString = FileUtils.readFileToString(new File(path1));
        System.out.println("+++ dataIngestionFileJsonAsString== " + dataIngestionFileJsonAsString);
        Response response_producer = postServiceResponse(dataIngestionFileJsonAsString, "eventhub_post_data_url",
            kpiprovideHeaders_5());

        isEqual("Data not Posted to Eventhub", 200, response_producer.getStatusCode());
        // isEqual("Data not Posted to Eventhub", true,
        // response_producer.asString().contains(":0"));

        return predixTsValue;
    }

    // ****************Post data point to Event
    // Hub*************************************************//
    public int postDataPointToEventHubForecastData(String dataToBePosted, String filter, String appName, String inputag,
                                                   String outputag)
        throws IOException, InterruptedException, URISyntaxException {
        printnewLine();
        System.out.println("*****************POST DATA TO EVENT HUB*******************");
        printnewLine();
        System.out.println("url=" + getTestProperty("eventhub_post_data_url"));
        int predixTsValue = generateRandomNumberNonUUID();
        System.out.println("OOTestUtil.postDataPointToEventHubGenData() with data=" + predixTsValue);
        setSysProperty("setAppName", appName);
        setSysProperty("setTsInputTag", inputag);
        setSysProperty("setTsOutputTag", outputag);
        setSysProperty("setFilter", filter);
        setSysProperty("setTsTag", appName);
        setSysProperty("setTsValue", String.valueOf(predixTsValue));
        setSysProperty("setTsCurrentTime", String.valueOf(getCurrentTimeInMillisec()));

        String dataIngestionFileJson = generateFile(dataToBePosted, "dataIngestionFile");

        File f1 = new File(dataIngestionFileJson);
        System.out.println("file path=" + f1.getAbsolutePath());
        String path1 = f1.getAbsolutePath().replace('\\', '/');
        String dataIngestionFileJsonAsString = FileUtils.readFileToString(new File(path1));
        System.out.println("+++ dataIngestionFileJsonAsString== " + dataIngestionFileJsonAsString);
        Response response_producer = postServiceResponse(dataIngestionFileJsonAsString, "eventhub_post_data_url",
            kpiprovideHeaders_5());

        isEqual("Data not Posted to Eventhub", 200, response_producer.getStatusCode());
        // isEqual("Data not Posted to Eventhub", true,
        // response_producer.asString().contains(":0"));

        return predixTsValue;
    }

    // ****************Post data point to Event Hub*************************************************//
    public String getDataPointToEventHubGenData()
        throws IOException, InterruptedException, URISyntaxException {
        printnewLine();
        System.out.println("*****************GET DATA FROM EVENT HUB*******************");
        printnewLine();
        System.out.println("eventhub_consumer_url=" + getTestProperty("eventhub_get_data_url"));

        Response response_consumer = getServiceResponse("eventhub_consumer_url=", kpiprovideHeaders());
        System.out.println("+++ response_consumer.asString() == " + response_consumer.asString());

        isEqual("Data not retrieved from Eventhub", 200, response_consumer.statusCode());
        System.out.println("response=" + response_consumer.asString());

        return response_consumer.asString();
    }

    public String getDataPointFromEventHub(String outputtag, String value)
        throws IOException, InterruptedException, URISyntaxException {
        printnewLine();
        System.out.println("*****************GET DATA FROM EVENT HUB*******************");
        printnewLine();
        System.out.println("eventhub_consumer_url=" + getTestProperty("eventhub_get_data_url"));

        Response response_consumer = getServiceResponse("eventhub_get_data_url", kpiprovideHeaders());
        // System.out.println("+++ response_consumer.asString() == " + response_consumer.asString());

        isEqual("Data not retrieved from Eventhub", 200, response_consumer.statusCode());
        isContains("data does not contain output tag " + outputtag, outputtag, response_consumer.asString());
        isContains("data does not contain expected output value " + value, value, response_consumer.asString());
        //isContains("data does not contain calculated value ", String.valueOf(value), response_consumer.asString());
        // System.out.println("response=" + response_consumer.asString());

        return response_consumer.asString();
    }

    public String getDataPointFromEventHubPE(String outputtag)
        throws IOException, InterruptedException, URISyntaxException {
        printnewLine();
        System.out.println("*****************GET DATA FROM EVENT HUB*******************");
        printnewLine();
        System.out.println("eventhub_consumer_url=" + getTestProperty("eventhub_get_data_url"));

        Response response_consumer = getServiceResponse("eventhub_get_data_url", kpiprovideHeaders());
        // System.out.println("+++ response_consumer.asString() == " + response_consumer.asString());

        isEqual("Data not retrieved from Eventhub", 200, response_consumer.statusCode());
        isContains("data does not contain output tag " + outputtag, outputtag, response_consumer.asString());

        //isContains("data does not contain calculated value ", String.valueOf(value), response_consumer.asString());
        // System.out.println("response=" + response_consumer.asString());

        return response_consumer.asString();
    }
    // ****************Delete kpi job*************************************************//

    public void deleteKpiJob(String kpiJobId) throws InterruptedException, IOException {

        printnewLine();
        System.out.println("*****************DELETE KPI JOB*******************");
        printnewLine();

        Response response = deleteServiceResponse("job_url" + "/" + kpiJobId, kpiprovideHeaders());
        System.out.println("response.statusCode()" + response.statusCode());
        System.out.println("response.asString()" + response.asString());
        /* KNOWN BUG--> DELETE JOB NOT WORKING CONSISTENTLY */
        // isEqual("Not valid response for Delete job", 200,
        // response.statusCode());
        /*
         * isEqual("KPI JOB not killed", true, response.asString()
		 * .contains("KPI Job with Id " + kpiJobId +
		 * " is marked for deletion. Please check job status"));
		 */
        printnewLine();

        return;
    }

    /********************************************************************************************************************/
    public ResponseEntity<KpiDetails> getResponseFromcreateKpiTemplate(String kpiTemplate, String kpiAnalytic)
        throws IOException, URISyntaxException {
        printnewLine();

        System.out.println("*****************Create KPI TEMPLATE*******************");
        printnewLine();

        final String uri = getTestProperty("kpi_url");

        setSysProperty("setKpiName", "kpiname2" + generateRandomNumber());
        setSysProperty("tenant", getTestProperty("tenantUUID"));
        String kpiFile = kpiTemplate;
        String kpiJson = generateFile(kpiFile, "kpi_e2e");

        File f = new File(kpiJson);
        System.out.println("file path=" + f.getAbsolutePath());

        String path = f.getAbsolutePath().replace('\\', '/');

        String kpiJson_1 = FileUtils.readFileToString(new File(path));
        File analyticFile = new java.io.File(kpiAnalytic);

        MultiValueMap<String, Object> parameters = new LinkedMultiValueMap<String, Object>();
        parameters.add("uploadfile", new FileSystemResource(analyticFile));
        parameters.add("kpi", new ObjectMapper().readValue(kpiJson_1, KpiDetails.class));

        ResponseEntity<KpiDetails> response = restTemplate.exchange(uri, HttpMethod.POST,
            new HttpEntity<MultiValueMap<String, Object>>(parameters, kpiprovideHeaders_1()), KpiDetails.class);

        return response;
    }

    // *****************Create KPI
    // JOB***************************************************//

    public Response getResponseFroCreateKpiJob(String kpijob, long kpi_id) throws IOException, URISyntaxException {

        printnewLine();
        System.out.println("*****************Create KPI JOB*******************");
        printnewLine();

        setSysProperty("kpiReferenceId", String.valueOf(kpi_id));
        setSysProperty("tenant", getTestProperty("tenantUUID"));

        String kpijobFile = kpijob;
        String kpijobJson = generateFile(kpijobFile, "kpi_job_e2e");
        System.out.println("+++ kpijobJson== " + kpijobJson);
        Response response1 = postServiceResponse(kpijobJson, "job_url", kpiprovideHeaders());

        return response1;
    }

    // *****************End to end flow
    // utility***************************************************//

    public void ookpiendToEndFlow(String apmTSforIngestionPath, boolean apmIngestionDynamicTag,
                                  String kpiTemplateJsonPath, String kpiTemplateAnalyticPath, String kpiJobJsonPath,
                                  String dataIngestionFilePath, String inputTag, String outputTag, String expectedValue,
                                  String expectedJobStatus, String createKpiJobOptions, String postDataToEventhub,
                                  boolean isApmOutput,
                                  boolean randomInputTag) throws Exception {

        // ingest test data into apm time series
        if (apmIngestionDynamicTag) {
            inputTag = postDataPointToAPMTimeSeries(apmTSforIngestionPath, inputTag);
        } else {
            postDataPointToAPMTimeSeries(apmTSforIngestionPath);
        }
        Thread.sleep(10000);
        // create kpi template
        Long kpi_id = createKpiTemplate(kpiTemplateJsonPath, kpiTemplateAnalyticPath);
        // create kpijob
        String kpiJobId;
        if (createKpiJobOptions.equalsIgnoreCase("createKpiJobWithTag")) {
            kpiJobId = createKpiJobWithTag(kpiJobJsonPath, kpi_id, outputTag);
        } else if (createKpiJobOptions.equalsIgnoreCase("createKpiJobWithInputAndOutputTag")) {
            kpiJobId = createKpiJobWithInputAndOutputTag(kpiJobJsonPath, kpi_id, outputTag, inputTag);
            Thread.sleep(10000);
            outputTag = getOutputtagOfKpiJob(kpiJobId);
            Thread.sleep(10000);
        } else if (createKpiJobOptions.equalsIgnoreCase("createKpiJobWithNoRandomInputAndOutputTag")) {
            kpiJobId = createKpiJobWithNoRandomInputAndOutputTag(kpiJobJsonPath, kpi_id, outputTag, inputTag,
                randomInputTag);
            Thread.sleep(10000);
            outputTag = getOutputtagOfKpiJob(kpiJobId);
            Thread.sleep(10000);
        } else {
            kpiJobId = createKpiJob(kpiJobJsonPath, kpi_id);
        }

        // start kpi job
        startKpiJob(kpiJobId);
        Thread.sleep(15000);
        // status of the job
        String status = getStatusOfJob(kpiJobId);
        Thread.sleep(15000);
        String message = getMessageOfJob(kpiJobId);
        Thread.sleep(15000);

        if (status.equalsIgnoreCase("Running") && status.equalsIgnoreCase(expectedJobStatus)) {
            // post data to event hub
            if (postDataToEventhub.equalsIgnoreCase("PostDataWithRandomInputTag")) {
                postDataPointToEventHub(kpiJobJsonPath, inputTag);
                Thread.sleep(30000);
            } else if (postDataToEventhub.equalsIgnoreCase("PostDataWithoutRandomInputTag")) {
                postDataPointToEventHubNoRandomTag(kpiJobJsonPath, inputTag);
                Thread.sleep(30000);
            } else {
                System.out.println("Do not post data to Event hub");
            }

            // get data from Kafka topic
            String calculatedData = getDataPointFromKafkaTopic(outputTag);
            Thread.sleep(10000);

            // Assert if the Analytic calculated data posted to event hub
            isEqual("Data not calculated", expectedValue, calculatedData);
            if (calculatedData.equalsIgnoreCase(expectedValue)) {
                System.out.println("+++ Test Passed++");
            }

            // data posted to APM TS by Analytic Consumer
            // ooTestutil.getDataFromApmTimeSeries(OutputtagNamePosted,
            // "180.0303054118169");

            // delete kpi job
            deleteKpiJob(kpiJobId);
            Thread.sleep(15000);

            // get status of the job
            getStatusOfJob(kpiJobId);

            Thread.sleep(15000);
        } else if (status.equalsIgnoreCase("ERROR") && status.equalsIgnoreCase(expectedJobStatus)) {
            isEqual("Job failed with Status Error which is expected result is --->" + status + "----Error message is-->"
                + message, true, true);
        } else if (status.equalsIgnoreCase("FINISHED") && status.equalsIgnoreCase(expectedJobStatus) && !isApmOutput) {
            isEqual("Job failed with Status Error which is expected result is --->" + status + "----Error message is-->"
                + message, true, true);
        } else if (status.equalsIgnoreCase("FINISHED") && status.equalsIgnoreCase(expectedJobStatus) && isApmOutput) {
            isEqual("Job failed with Status Error which is expected result is --->" + status + "----Error message is-->"
                + message, true, true);
            Thread.sleep(15000);
            getDataFromApmTimeSeries(outputTag, expectedValue);
            Thread.sleep(15000);
        } else {
            isEqual("Job not Started Successfully.Status of the JOB is --->" + status + "----Error message is-->"
                + message, true, false);
        }
    }

    // ****************Create KPI
    // Template*************************************************//

    public Long createKpiTemplate(HttpHeaders kpiprovideHeaders, String kpiTemplateJson, String kpiAnalyticPath,
                                  String expectedStatusCode) throws Exception {

        Long kpiId = 0L;

        System.out.println("*****************Create KPI TEMPLATE*******************");
        printnewLine();

        final String uri = getTestProperty("kpi_url");

        setSysProperty("setKpiName", "kpiname2" + generateRandomNumber());
        setSysProperty("tenant", getTestProperty("tenantUUID"));
        String kpiFile = kpiTemplateJson;
        String kpiJson = generateFile(kpiFile, "kpi_e2e");

        File f = new File(kpiJson);
        System.out.println("file path=" + f.getAbsolutePath());
        String path = f.getAbsolutePath().replace('\\', '/');

        String kpiJson_1 = FileUtils.readFileToString(new File(path));
        File analyticFile = new java.io.File(kpiAnalyticPath);

        MultiValueMap<String, Object> parameters = new LinkedMultiValueMap<String, Object>();
        parameters.add("uploadfile", new FileSystemResource(analyticFile));
        parameters.add("kpi", new ObjectMapper().readValue(kpiJson_1, KpiDetails.class));

        ResponseEntity<KpiDetails> response = restTemplate.exchange(uri, HttpMethod.POST,
            new HttpEntity<MultiValueMap<String, Object>>(parameters, kpiprovideHeaders), KpiDetails.class);

        isEqual("Not valid response for Create Kpi Template", expectedStatusCode, response.getStatusCode().toString());
        Assert.assertTrue(response.getBody() instanceof KpiDetails);

        KpiDetails kpiDetails = response.getBody();
        kpiId = kpiDetails.getId();
        System.out.println("------------->" + kpiDetails.getId());

        return kpiId;
    }

    // ****************Get KPI
    // Template*************************************************//

    public String getKpiTemplateByIdOrName(String kpiIdOrName) throws Exception {

        Response get_response = getServiceResponse("kpi_url" + "/" + kpiIdOrName, kpiprovideHeaders_2());

        isEqual("Incorrect tag name", true, get_response.body().asString().contains(String.valueOf(kpiIdOrName)));
        isEqual("Incorrect tag name", true, get_response.body().jsonPath().getList("inputs").size() > 0);
        isEqual("Incorrect tag name", true, get_response.body().jsonPath().getList("outputs").size() > 0);
        //isEqual("Not valid response for Get Kpi Template", expectedStatusCode, get_response.getStatusCode());

        String id = get_response.body().jsonPath().getString("id");
        System.out.println("+++ kpi id== " + id);

        printnewLine();

        return id;
    }
    // ****************Get KPI
    // Template*************************************************//

    public String getKpiNameTemplateById(Long kpiId) throws Exception {

        Response get_response = getServiceResponse("kpi_url" + "/" + kpiId, kpiprovideHeaders_2());

        String name = get_response.body().jsonPath().getString("name");
        System.out.println("+++ kpiname== " + name);
        isEqual("Not valid response for create kpi name", 200, get_response.statusCode());

        printnewLine();

        return name;
    }

    // ****************Update KPI
    // Template*************************************************//

    public Long updateKpiTemplate(HttpHeaders kpiprovideHeaders, Long KpiId, String kpiTemplateJson,
                                  String kpiAnalyticPath, String expectedStatusCode) throws Exception {

        Long kpiId = 0L;

        System.out.println("*****************Update KPI TEMPLATE*******************");
        printnewLine();

        final String uri = getTestProperty("kpi_url");

        setSysProperty("setKpiName", "kpiname" + generateRandomNumberNonUUID());
        setSysProperty("tenant", getTestProperty("tenantUUID"));
        String kpiFile = kpiTemplateJson;
        String kpiJson = generateFile(kpiFile, "kpi_e2e");

        File f = new File(kpiJson);
        System.out.println("file path=" + f.getAbsolutePath());
        String path = f.getAbsolutePath().replace('\\', '/');

        String kpiJson_1 = FileUtils.readFileToString(new File(path));
        File analyticFile = new java.io.File(kpiAnalyticPath);

        MultiValueMap<String, Object> parameters = new LinkedMultiValueMap<String, Object>();
        parameters.add("uploadfile", new FileSystemResource(analyticFile));
        parameters.add("kpi", new ObjectMapper().readValue(kpiJson_1, KpiDetails.class));

        ResponseEntity<KpiDetails> response = restTemplate.exchange(uri, HttpMethod.PUT,
            new HttpEntity<MultiValueMap<String, Object>>(parameters, kpiprovideHeaders), KpiDetails.class);

        isEqual("Not valid response for Create Kpi Template", expectedStatusCode, response.getStatusCode().toString());
        Assert.assertTrue(response.getBody() instanceof KpiDetails);

        KpiDetails kpiDetails = response.getBody();
        kpiId = kpiDetails.getId();
        System.out.println("------------->" + kpiDetails.getId());

        return kpiId;
    }

    // ****************Delete KPI
    // Template*************************************************//

    public void deleteKpiTemplateById(Map<String, Object> kpiprovideHeaders, String kpiId, String expectedStatusCode)
        throws Exception {

        Response delete_response = deleteServiceResponse("kpi_url" + "/" + kpiId, kpiprovideHeaders);
        isEqual("Not valid response for Delete Kpi Template", expectedStatusCode, delete_response.getStatusCode());
    }

    // *******************************************************************************************//
    public String getCurrentTime() {
        String timeStamp = new SimpleDateFormat("yyyy-MM-dd'T'HH:mm:ss.SSS").format(new Date());
        System.out.println("+++ timeStamp 2016-01-01T13:00:00.000-0000== " + timeStamp);
        return timeStamp;
    }
    // *******************************************************************************************//
    public String getYesterdaysTime() {
    	Calendar today = Calendar.getInstance();
    	// Subtract 1 day
    	today.add(Calendar.DATE, -1);
    	// Make an SQL Date out of that
    	java.sql.Date yesterday = new java.sql.Date(today.getTimeInMillis());
    	
        String timeStamp = new SimpleDateFormat("yyyy-MM-dd'T'HH:mm:ss.SSS").format(yesterday);
        System.out.println("+++ timeStamp 2016-01-01T13:00:00.000-0000== " + timeStamp);
        return timeStamp;
    }

    // *******************************************************************************************//
    public Long getCurrentTimeInMillisec() {

        Long timeStamp = System.currentTimeMillis();
        System.out.println("+++ timeStamp 2016-01-01T13:00:00.000-0000== " + timeStamp);
        return timeStamp;
    }

    // *******************************************************************************************//

    /*******************************************************************************************************************/
    public ResponseEntity<Object> getResponseFromcreateKpiTemplate(String token, String tenant, String header_tenant,
                                                                   String httpMethod, String kpiTemplate,
                                                                   String kpiAnalytic)
        throws IOException, URISyntaxException {

        System.out.println("------------------>Create/update KPI template");

        final String uri = getTestProperty("kpi_url");

        System.out.println("kpi_url=" + uri);
        setSysProperty("setKpiName", "kpiname2" + generateRandomNumber());

        setSysProperty("tenant", tenant);
        String kpiFile = kpiTemplate;
        String kpiJson = generateFile(kpiFile, "kpi_e2e");

        File f = new File(kpiJson);

        String path = f.getAbsolutePath().replace('\\', '/');

        String kpiJson_1 = FileUtils.readFileToString(new File(path));
        System.out.println("kpiJson_1=" + kpiJson_1);
        File analyticFile = new java.io.File(kpiAnalytic);

        MultiValueMap<String, Object> parameters = new LinkedMultiValueMap<String, Object>();
        parameters.add("uploadfile", new FileSystemResource(analyticFile));
        parameters.add("kpi", new ObjectMapper().readValue(kpiJson_1, KpiDetails.class));
        HttpHeaders headers = kpiprovideHeaders_3(header_tenant, token);
        ResponseEntity<Object> response = restTemplate.exchange(uri, getHttpMethod(httpMethod),
            new HttpEntity<MultiValueMap<String, Object>>(parameters, headers), Object.class);

        return response;
    }

    /*******************************************************************************************************************/
    public Response getResponseFromUpdateKpiTemplateJson(String uri, String token, String tenant, String header_tenant,
                                                         String httpMethod, String kpiTemplate)
        throws IOException, URISyntaxException {

        System.out.println("------------------>Create/update KPI template");

        System.out.println("kpi_url=" + uri);
        // setSysProperty("setKpiName", "kpiname" +
        // generateRandomNumberNonUUID());

        setSysProperty("tenant", tenant);
        String kpiFile = kpiTemplate;
        String kpiJson = generateFile(kpiFile, "kpi_e2e");

        File f = new File(kpiJson);

        String path = f.getAbsolutePath().replace('\\', '/');

        String kpiJson_1 = FileUtils.readFileToString(new File(path));
        System.out.println("kpiJson_1=" + kpiJson_1);

		/*
         * String updateKpiJsonUrl = uri + "/" + kpiId;
		 * System.out.println("\n\nupdateKpiJsonUrl------------->" +
		 * updateKpiJsonUrl + "\n");
		 * 
		 * ResponseEntity<KpiDetails> update_response =
		 * restTemplate.exchange(uri, HttpMethod.PUT, new
		 * HttpEntity<KpiDetails>(new ObjectMapper().readValue(kpiJson_1,
		 * KpiDetails.class), kpiprovideHeaders_10(header_tenant,token)),
		 * KpiDetails.class);
		 */

        Response response1 = putServiceResponse(kpiJson_1, uri, kpiprovideHeaders_4(header_tenant, token));

        return response1;
    }

    /*******************************************************************************************************************/
    public ResponseEntity<Object> getResponseFromUpdateKpiAnalyticFile(String uri, String token, String header_tenant,
                                                                       String httpMethod, String kpiAnalytic)
        throws IOException, URISyntaxException {

        System.out.println("------------------>update KPI analytic  file");

        System.out.println("------------------>uri" + uri);

        File analyticFile = new java.io.File(kpiAnalytic);

        MultiValueMap<String, Object> parameters = new LinkedMultiValueMap<String, Object>();
        parameters.add("uploadfile", new FileSystemResource(analyticFile));
        HttpHeaders headers = kpiprovideHeaders_3(header_tenant, token);

        ResponseEntity<Object> response = restTemplate.exchange(uri, getHttpMethod(httpMethod),
            new HttpEntity<MultiValueMap<String, Object>>(parameters, headers), Object.class);

        return response;
    }

    // *****************Create KPI
    // JOB***************************************************//

    public Response getResponseFromCreateKpiJob(String token, String payload_tenant, String header_tenant,
                                                String httpMethod, String kpijob, long kpi_id)
        throws IOException, URISyntaxException {

        System.out.println("------------------>Create/update KPI JOB");

        setSysProperty("kpiReferenceId", String.valueOf(kpi_id));
        setSysProperty("tenant", payload_tenant);

        String kpijobFile = kpijob;
        String kpijobJson = generateFile(kpijobFile, "kpi_job_e2e");
        System.out.println("+++ kpijobJson== " + kpijobJson);

        File f = new File(kpijobJson);
        System.out.println("file path=" + f.getAbsolutePath());

        String path = f.getAbsolutePath().replace('\\', '/');

        String kpiJson_1 = FileUtils.readFileToString(new File(path));
        System.out.println("+++ job json== " + kpiJson_1);
        System.out.println("+++ job url== " + getTestProperty("job_url"));

        Map<String, Object> headersMap = kpiprovideHeaders_4(header_tenant, token);
        Response response1 = null;

        if (httpMethod.equals("POST")) {
            response1 = postServiceResponse(kpijobJson, getTestProperty("job_url"), headersMap);
        } else if (httpMethod.equals("PUT")) {
            response1 = putServiceResponse(kpijobJson, getTestProperty("job_url"), headersMap);
        }

        return response1;
    }

    public Response getResponseFromGetOrDelete(String token, String tenant, String httpMethod, String url)
        throws IOException, URISyntaxException {

        System.out.println("+++  url== " + url);
        Map<String, Object> headersMap = new LinkedHashMap<String, Object>();
        headersMap = kpiprovideHeaders_4(tenant, token);
        System.out.println("http Method=" + httpMethod);
        Response response1 = null;

        if (httpMethod.equals("DELETE")) {
            response1 = deleteServiceResponse(url, headersMap);
        } else if (httpMethod.equals("GET")) {
            response1 = getServiceResponse(url, headersMap);
        } else if (httpMethod.equals("POST")) {
            response1 = postServiceResponse(url, headersMap);
        }

        // System.out.println("Printing
        // responseBody.getBody()"+response1.asString());
        return response1;
    }

    public static void printResponseEntity(ResponseEntity responseEntity) {
        System.out.println("Printing responseBody.getBody()");

        String result = "";
        Map<String, ?> map = (Map<String, ?>) responseEntity.getBody();
        if (map != null) {
            for (String key : map.keySet()) {
                result = result + key + ":" + map.get(key) + ",";
                // System.out.println( key+":" +map.get(key)+",");
            }
        }
        System.out.println(result);
        /*
         * System.out.println("Printing responseEntity.getHeaders()");
		 * 
		 * HttpHeaders headers = responseEntity.getHeaders(); Set<String> keys =
		 * headers.keySet(); for (String header : keys) {
		 * System.out.println(header+":"); List<String> values =
		 * headers.get(header); for (String value : values) {
		 * System.out.println( value+","); } }
		 */

    }

    public static String getResponseEntity(ResponseEntity responseEntity) {

        String result = "";
        Map<String, ?> map = (Map<String, ?>) responseEntity.getBody();
        if (map != null) {
            for (String key : map.keySet()) {
                result = result + key + ":" + map.get(key) + ",";
                // System.out.println( key+":" +map.get(key)+",");
            }
        }
        System.out.println(result);
        return result;
        /*
         * System.out.println("Printing responseEntity.getHeaders()");
		 * 
		 * HttpHeaders headers = responseEntity.getHeaders(); Set<String> keys =
		 * headers.keySet(); for (String header : keys) {
		 * System.out.println(header+":"); List<String> values =
		 * headers.get(header); for (String value : values) {
		 * System.out.println( value+","); } }
		 */

    }

    public HttpMethod getHttpMethod(String method) {
        HttpMethod result = null;
        switch (method) {
            case "GET":
                result = HttpMethod.GET;
                break;
            case "POST":
                result = HttpMethod.POST;
                break;
            case "PUT":
                result = HttpMethod.PUT;
                break;
            case "DELETE":
                result = HttpMethod.DELETE;
                break;
            default:
                result = HttpMethod.GET;
        }
        return result;
    }

    /********************************************************************************************************************/
    public HttpHeaders kpiprovideHeaders_3(String tenant, String token) {
        HttpHeaders headers = new HttpHeaders();
        headers.set("Authorization", "Bearer " + token);
        headers.set("Content-Type", "multipart/form-data");
        headers.set("tenant", tenant);
        return headers;
    }

    /********************************************************************************************************************/
    public Map<String, Object> kpiprovideHeaders_4(String tenant, String token) {
        Map<String, Object> headersMap = new LinkedHashMap<String, Object>();

        headersMap.put("Authorization", "Bearer " + token);
        headersMap.put("Content-Type", "application/json");
        headersMap.put("tenant", tenant);
        System.out.println("headers=" + headersMap);
        return headersMap;
    }

    public MultiValueMap<String, String> kpiprovideHeaders_10(String tenant, String token) {
        MultiValueMap<String, String> headersMap = new LinkedMultiValueMap<String, String>();
        headersMap.add("Authorization", "Bearer " + token);
        headersMap.add("Content-Type", "application/json");
        headersMap.add("tenant", tenant);
        System.out.println("headers=" + headersMap);
        return headersMap;
        // *******************************************************************************************//
    }

    // *******************************************************************************************//
    public void DeleteZipFile(String zipFileName) {

        File file = new File(zipFileName + ".zip");
        System.out.println(zipFileName + ".zip");
        if (file.exists()) {
            file.delete();
            System.out.println("Zip file deleted from folder");
        } else {
            System.out.println("File not found");
        }
    }

    // *******************************************************************************************//
    public void ZipFile(String sourceDirectory, String zipFileName) throws IOException {

        File dirObj = new File(sourceDirectory);
        ZipOutputStream out = new ZipOutputStream(new FileOutputStream(zipFileName));
        System.out.println("Creating : " + zipFileName);
        addDir(dirObj, out);
        out.close();
    }

    // *******************************************************************************************//
    static void addDir(File dirObj, ZipOutputStream out) throws IOException {
        File[] files = dirObj.listFiles();
        byte[] tmpBuf = new byte[1024];

        for (int i = 0; i < files.length; i++) {
            if (files[i].isDirectory()) {
                addDir(files[i], out);
                continue;
            }
            FileInputStream in = new FileInputStream(files[i].getPath());
            System.out.println(" Adding: " + files[i].getPath());
            out.putNextEntry(new ZipEntry(files[i].getPath()));
            int len;
            while ((len = in.read(tmpBuf)) > 0) {
                out.write(tmpBuf, 0, len);
            }
            out.closeEntry();
            in.close();
        }
    }
    // *******************************************************************************************//

    public String createKpi(String analyticZipFile, String kpi_url) throws Exception {

        String kpiId = "";
        final String uri = getTestProperty("kpi_url");
        System.out.println("kpi url=" + uri);

        final String FILEPATH = setFilePath();
        final String folderName = FILEPATH + "payloadsAndromeda/kpi_analytics/";
        String analyticFile = folderName + analyticZipFile;

        System.out.println("\nPrint NameOfFile >>>>>>>>>" + analyticFile + "\n");

        Response responseBody = postServiceResponse(analyticFile, uri, kpiprovideHeaders());

        if (responseBody != null) {
            JsonPath jsonPath = new JsonPath(responseBody.asString());
            kpiId = jsonPath.getString("id");
            System.out.println("Print responseBody >>>>>>>>>>>>>" + responseBody.asString());
        }

        return kpiId;
        //utils.DeleteZipFile(fileName);

    }

    // *******************************************************************************************//
    public void ZipAnalyticFile(String jarName, String zipFileName) throws IOException {

        final String FILEPATH = setFilePath();
        final String folderName = FILEPATH + "payloadsAndromeda/kpi_analytics/";
        String filePath = folderName + jarName;
        zipFileName = folderName + zipFileName;

        System.out.println("Incoming file location >>>>>>>:" + filePath);
        byte[] buffer = new byte[1024];
        File givenFile = new File(filePath);
        ZipEntry ze = new ZipEntry(filePath);
        System.out.println("Zip file location >>>>>>>:" + zipFileName + ".zip");
        FileOutputStream fos = new FileOutputStream(zipFileName + ".zip");
        ZipOutputStream zos = new ZipOutputStream(fos);
        zos.putNextEntry(ze);
        FileInputStream in = new FileInputStream(filePath);

        int len;
        while ((len = in.read(buffer)) > 0) {
            zos.write(buffer, 0, len);
        }
        in.close();
        zos.closeEntry();

        // close it
        zos.close();

        System.out.println("Done");
    }

    // *******************************************************************************************//
    public static String setFilePath() throws IOException {

        String current = new java.io.File(".").getCanonicalPath();
        System.out.println("Current dir:" + current);

        String filePath = "src/main/resources/payloadsAndromeda/kpi_analytics/";
        String path = System.getProperty("filePath");

        switch (path) {

            case "local": {
                filePath = "src/main/resources/";
                break;
            }
            case "remote": {
                filePath = "../src/main/resources/";
                break;
            }
            default: {

                filePath = "src/main/resources/";
                System.out.println("No file path is set");
                filePath = "../src/main/resources/";
                System.out.println("No file path is set hence running tests as remote");
                filePath = "../src/main/resources/";
                System.out.println("No file path is set hence running tests as remote");

                break;
            }
        }

        return filePath;
    }
    // *******************************************************************************************//

    public void DeleteAnalyticZipFile(String zipFileName) throws IOException {

        final String FILEPATH = setFilePath();
        final String folderName = FILEPATH + "payloadsAndromeda/kpi_analytics/";
        zipFileName = folderName + "simpleJavaAnalytic_cf1_8";

        File file = new File(zipFileName + ".zip");
        System.out.println(zipFileName + ".zip");
        if (file.exists()) {
            file.delete();
            System.out.println("Zip file deleted from folder");
        } else {
            System.out.println("File not found");
        }
    }

    // *******************************************************************************************//

    public Response queryAudit(long startDate, long endDate, int logcount) throws Exception {

        // query audit data
        setSysProperty("startDate", String.valueOf(startDate));
        setSysProperty("endDate", String.valueOf(endDate));

        Map<String, Object> header = getAuditHeaders();
        String kpijobJson =
            generateFile("src/main/resources/payloadsAndromeda/audit_query/audit_filter.json", "testaudit");
        Response response1 = null;

        boolean flag = false;
        while (endDate > System.currentTimeMillis()) {

            response1 = postServiceResponse(kpijobJson, "audit_query_url", header);
            Thread.sleep(1000);
            System.out.println("--------------attempting to get audit query response---------- - ");
            if (verifyAuditRecordCount(response1, logcount)) {
                flag = true;
                break;
            }
            Thread.sleep(60000);
        }

        if (!flag) {
            throw new RuntimeException("audits are not captured");
        }
        return response1;
    }

    public Response queryAudit(long startDate, long endDate, final Set<String> verificationKeys) throws Exception {

        // query audit data
        setSysProperty("startDate", String.valueOf(startDate));
        setSysProperty("endDate", String.valueOf(endDate));

        Map<String, Object> header = getAuditHeaders();
        String kpijobJson =
            generateFile("src/main/resources/payloadsAndromeda/audit_query/audit_filter.json", "testaudit");
        Response response1 = null;

        boolean flag = false;
        while (endDate > System.currentTimeMillis()) {
            System.out.println("--------------attempting to get audit query response---------- - ");
            response1 = postServiceResponse(kpijobJson, "audit_query_url", header);
            Thread.sleep(1000);

            System.out.println("--------------attempting to verify audit response---------- - ");
            if (verifyAuditRecords(response1, verificationKeys)) {
                flag = true;
                break;
            }
            Thread.sleep(60000);
        }

        if (!flag) {
            throw new RuntimeException("audits are not captured");
        }
        return response1;
    }

    private boolean verifyAuditRecordCount(Response response, int logCount) {
        JsonPath jsonPath = new JsonPath(response.asString());
        ArrayList<Map<String, ?>> records = jsonPath.get("content");
        try {
            return logCount == records.size();
        } catch (NullPointerException e) {
            return false;
        }
    }

    String buildAuditPayloadVerificationKey(String originator, String resource, String actionType, String description,
                                            String username) {
        return new StringBuilder().append(originator).append(":").append(resource).append(":").
            append(actionType).append(":").append(description).append(":").append(username).toString();
    }

    private boolean verifyAuditRecords(Response response, final Set<String> verificationKeys) {
        JsonPath jsonPath = new JsonPath(response.asString());
        ArrayList<Map<String, ?>> records = jsonPath.get("content");

        if (records != null && !records.isEmpty()) {
            Set<String> responseKeys = new HashSet<>(records.size());
            for (Map<String, ?> record : records) {
                String payload = (String) record.get("payload");
                JSONObject jObj = JSONObject.fromObject(payload);
                responseKeys.add(buildAuditPayloadVerificationKey(jObj.getString("originator"),
                    jObj.getString("resource"), jObj.getString("actionType"), jObj.getString("description"),
                    jObj.getString("actorDisplayName")));
            }

            System.out.println("response payload keys - \n");
            responseKeys.stream().forEach(s -> System.out.println(s));

            return responseKeys.containsAll(verificationKeys);
        }

        return false;
    }

    public void verifyAuditDetails(long kpi_id, String runtimeJobId, String jsonResponse) {
        // verifies the meta data
        setSysProperty("tenant", getTestProperty("tenantUUID"));
        setSysProperty("user", getTestProperty("username"));
        setSysProperty("kpi_id", String.valueOf(kpi_id));
        setSysProperty("job_id", runtimeJobId);
        JsonPath json = new JsonPath(jsonResponse);
        List payloads = json.get("content");
        verifyAuditlogs(kpi_id, payloads);
        Map payoload = (Map) payloads.get(0);

        String jsonFile = "src/main/resources/payloadsAndromeda/audit_query/audit.json";

        try {
            jsonFile = generateFile(jsonFile, "auditPayload");
        } catch (IOException e) {
            e.printStackTrace();
        } catch (URISyntaxException e) {
            e.printStackTrace();
        }

        List<String> jsonPath = new ArrayList<String>();
        jsonPath.add("$.content[*].id");
        jsonPath.add("$.content[*].messageId");
        jsonPath.add("$.content[*].auditServiceId");
        jsonPath.add("$.content[*].timestamp");
        jsonPath.add("$.content[*].payload");
        jsonPath.add("$.content[*].correlationId");

        isJsonEqual(new File(jsonFile), jsonResponse, false, jsonPath);
    }

    private void verifyAuditlogs(long kpi_id, List payloads) {
        // verifies the actual message

        ArrayList<String> payloadArray = new ArrayList<>();
        for (int i = 0; i < payloads.size(); i++) {
            String payload = (((Map<String, String>) payloads.get(i)).get("payload"));
            payloadArray.add(payload);
        }

        String jsonFile = null;

        try {
            jsonFile = generateFile("src/main/resources/payloadsAndromeda/audit_query/auditPayload.json",
                "auditPayload");
        } catch (IOException e) {
            e.printStackTrace();
        } catch (URISyntaxException e) {
            e.printStackTrace();
        }

        List<String> jsonPath = new ArrayList<String>();
        jsonPath.add("$[*].eventStartTime");
        jsonPath.add("$[*].actorUuid");
        jsonPath.add("$[*].actor");

        isJsonEqual(new File(jsonFile), payloadArray.toString(), false, jsonPath);
    }

    public Map<String, Object> getAuditHeaders() {
        // return audit headers
        Map<java.lang.String, java.lang.Object> headersMap = new LinkedHashMap<>();
        headersMap.put("Authorization", "Bearer " + getAuditToken());
        headersMap.put("Predix-Zone-Id", getTestProperty("audit_predix_zone_id"));
        headersMap.put("Content-Type", "application/json");
        return headersMap;
    }

    public String getAuditToken() {

        String URL = getTestProperty("audit_token_url");

        Map<String, Object> queryParams = new HashMap<>();
        queryParams.put("grant_type", "client_credentials");

        Map<String, Object> headers = new HashMap<>();

        RestAssured.useRelaxedHTTPSValidation();
        RequestSpecification request = RestAssured.given();
        RestAssured.baseURI = URL;
        if (queryParams != null && !queryParams.isEmpty()) {
            request.queryParameters(queryParams);
        }

        String basicDigestHeaderValue = "Basic " + new String(Base64.encodeBase64(
            (getTestProperty("audit_client_id") + ":" + getTestProperty("audit_client_secret"))
                .getBytes()));

        headers.put("Authorization", basicDigestHeaderValue);
        if (headers != null && !headers.isEmpty()) {
            request.headers(headers);
        }
        Response response = request.when().post(RestAssured.baseURI, new Object[0]);
        String extractTokenKey = null;

        if (response != null) {
            JsonPath jsonPath = new JsonPath(response.asString());
            extractTokenKey = jsonPath.getString("access_token");
        }

        return extractTokenKey;
    }

    public String extractZipFile(String zipFilePath) throws ZipException, IOException {
        String zipFileName = FilenameUtils.getName(zipFilePath);

        ZipFile zipFile = new ZipFile(zipFilePath);

        Path tmpDir = createTmpDir("orchestration");

        String extractDirectory = tmpDir.toString() + "/extractedFiles";

        Files.createDirectories(Paths.get(extractDirectory));

        log.info("Tmp directory =" + extractDirectory);

        zipFile.extractAll(extractDirectory);

        return FilenameUtils.normalize(extractDirectory);
    }

    public Path createTmpDir(String dirPrefix) throws IOException {
        return Files.createTempDirectory(dirPrefix);
    }

    public String formatMessageUsingArguments(String message, Object... arguments) {
        for (int idx = 0; idx < arguments.length; idx++) {
            if (arguments[idx] instanceof String) {
                String argument = (String) arguments[idx];
                arguments[idx] = escapeForStringFormat(argument);
            }
        }

        return arguments.length > 0 ? String.format(message, arguments) : message;
    }

    public String escapeForStringFormat(String argument) {
        if (org.apache.commons.lang.StringUtils.isBlank(argument)) {
            return argument;
        }
        if (argument.contains("%")) {
            // escaping all % symbols to avoid error when ServiceException is using String.format(). If the
            // message values contain % then it will be treated as message format specifier and complains
            // missing format specifier argument.
            return argument.replace("%", "%%");
        }
        return argument;
    }

    public static String appendTrailingSlash(String path) {
        if (StringUtils.isEmpty(path)) {
            return path;
        }
        if (path.charAt(path.length() - 1) != File.separatorChar) {
            path += File.separator;
        }

        return path;
    }

    public void zipMultipleFiles(List<File> files) throws IOException {
        FileOutputStream fos = null;
        ZipOutputStream zipOut = null;
        try {
            fos = new FileOutputStream("adci.zip");
            zipOut = new ZipOutputStream(fos);
            for (File file : files) {
                FileInputStream fis = new FileInputStream(file);
                ZipEntry zipEntry = new ZipEntry(file.getName());
                zipOut.putNextEntry(zipEntry);

                byte[] bytes = new byte[1024];
                int length;
                while ((length = fis.read(bytes)) >= 0) {
                    zipOut.write(bytes, 0, length);
                }
                fis.close();
            }
        } finally {
            zipOut.close();
            fos.close();
        }
    }

    public static void prepareAPMTsDataForObservableAndForecastTag() {

        // OBSERVABLE TAG ID
        String observableTagID = "Plant2Quality2";
        int OBSERVABLE_LOWER_LIMIT = 73;
        int OBSERVABLE_UPPER_LIMIT = 80;

        // FORECAST TAG ID
        String forecastTagID = "Plant1QualityForecast1";
        int FORECAST_LOWER_LIMIT = 73;
        int FORECAST_UPPER_LIMIT = 80;

        // Sample rate in Milli-seconds
        int SAMPLE_RATE = 86400000;

        // Total Number Days Observable & Forecast Data Needed
        long TOTAL_NUMBER_OF_DAYS = 40;

        // Total Number of datapoints needed for Observable & Forecast Data
        long TOTAL_NUMBER_OF_DATAPOINTS = (TOTAL_NUMBER_OF_DAYS * 24 * 60 * 60 * 1000) / SAMPLE_RATE;

        ArrayList<Map<String, ?>> observableData = new ArrayList<>();
        ArrayList<Map<String, ?>> forecastData = new ArrayList<>();
        ArrayList<Map<String, ?>> data = new ArrayList<>();

        Long currTime = System.currentTimeMillis();
        Map<String, Object> datapointForecast;
        Map<String, Object> datapointObservable;
        for (int i = 0; i < TOTAL_NUMBER_OF_DATAPOINTS; i++) {
            datapointObservable = new HashMap<>();
            datapointForecast = new HashMap<>();

            datapointObservable.put("ts", currTime - (SAMPLE_RATE * i));
            datapointObservable
                .put("v", (Math.random() * (OBSERVABLE_UPPER_LIMIT - OBSERVABLE_LOWER_LIMIT) + OBSERVABLE_LOWER_LIMIT));
            datapointObservable.put("q", "3");

            datapointForecast.put("ts", (currTime + (SAMPLE_RATE * (i + 1))));
            datapointForecast
                .put("v", (Math.random() * (FORECAST_UPPER_LIMIT - FORECAST_LOWER_LIMIT) + FORECAST_LOWER_LIMIT));
            datapointForecast.put("q", "3");

            observableData.add(0, datapointObservable);
            forecastData.add(datapointForecast);
        }

        Map<String, Object> forecastPayload = new HashMap<>();
        ArrayList<Object> tags = new ArrayList<>();

        Map<String, Object> observableObject = new HashMap<>();
        observableObject.put("tagId", observableTagID);
        observableObject.put("errorCode", "0");
        observableObject.put("errorMessage", "");
        observableObject.put("data", observableData);

        Map<String, Object> forecastObject = new HashMap<>();
        forecastObject.put("tagId", forecastTagID);
        forecastObject.put("errorCode", "0");
        forecastObject.put("errorMessage", "");
        forecastObject.put("data", forecastData);

        tags.add(observableObject);
        tags.add(forecastObject);

        forecastPayload.put("tags", tags);

        System.out.println(JSON.serialize(forecastPayload));

//    	let forecastPayload = {
//    	  "tags": [
//    	    {
//    	      "tagId": observableTagID,
//    	      "errorCode": "0",
//    	      "errorMessage": "",
//    	      "data": observableData
//    	    },
//    	    {
//    	      "tagId": forecastTagID,
//    	      "errorCode": "0",
//    	      "errorMessage": "",
//    	      "data": forecastData
//    	    }
//    	  ]
//    	}

    }

    public static String prepareAPMTsDataForObservableTag(String observableTagID) {

        // OBSERVABLE TAG ID
        int OBSERVABLE_LOWER_LIMIT = 73;
        int OBSERVABLE_UPPER_LIMIT = 80;

        // Sample rate in Milli-seconds
        int SAMPLE_RATE = 86400000;

        // Total Number Days Observable & Forecast Data Needed
        long TOTAL_NUMBER_OF_DAYS = 40;

        // Total Number of datapoints needed for Observable & Forecast Data
        long TOTAL_NUMBER_OF_DATAPOINTS = (TOTAL_NUMBER_OF_DAYS * 24 * 60 * 60 * 1000) / SAMPLE_RATE;

        ArrayList<Map<String, ?>> observableData = new ArrayList<>();
        ArrayList<Map<String, ?>> forecastData = new ArrayList<>();
        ArrayList<Map<String, ?>> data = new ArrayList<>();

        Long currTime = System.currentTimeMillis();
        Map<String, Object> datapointForecast;
        Map<String, Object> datapointObservable;
        for (int i = 0; i < TOTAL_NUMBER_OF_DATAPOINTS; i++) {
            datapointObservable = new HashMap<>();
            datapointForecast = new HashMap<>();

            datapointObservable.put("ts", currTime - (SAMPLE_RATE * i));
            datapointObservable
                .put("v", (Math.random() * (OBSERVABLE_UPPER_LIMIT - OBSERVABLE_LOWER_LIMIT) + OBSERVABLE_LOWER_LIMIT));
            datapointObservable.put("q", "3");

            observableData.add(0, datapointObservable);
            forecastData.add(datapointForecast);
        }

        Map<String, Object> observablePayload = new HashMap<>();
        ArrayList<Object> tags = new ArrayList<>();

        Map<String, Object> observableObject = new HashMap<>();
        observableObject.put("tagId", observableTagID);
        observableObject.put("errorCode", "0");
        observableObject.put("errorMessage", "");
        observableObject.put("data", observableData);

        tags.add(observableObject);

        observablePayload.put("tags", tags);

        String jsonPayload = JSON.serialize(observablePayload).toString();
        System.out.println(JSON.serialize(observablePayload));

        return jsonPayload;
    }

    long getNextKPIJobScheduleRunMillis() {
        long now = Instant.now().toEpochMilli();
        CronExpression cronExpression;
        try {
            cronExpression = new CronExpression(KPIJOB_SCHEDULE_CRON_EXPRESSION);
        } catch (ParseException e) {
            return now;
        }

        return cronExpression.getNextValidTimeAfter(new Date(now)).getTime();
    }
}
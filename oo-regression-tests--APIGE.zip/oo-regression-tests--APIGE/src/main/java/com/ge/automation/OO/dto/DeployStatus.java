package com.ge.automation.OO.dto;

import java.util.List;
import java.util.stream.Collectors;
import java.util.stream.Stream;

import com.fasterxml.jackson.annotation.JsonCreator;
import com.fasterxml.jackson.annotation.JsonValue;

import com.ge.automation.OO.dto.EnumHelper.IEnumStrValue;

/**
 * Description of ${type_name}
 *
 * @author Danni Shi, 212668341
 * @version 1.0 ${date}
 * @since 1.0
 */
public enum DeployStatus implements IEnumStrValue {
    NOT_DEPLOYED("Not Deployed"),
    IN_PROGRESS("In Progress"),
    FAILED("Failed"),
    DEPLOYED("Deployed"),
    DEPLOY_STOPPED("Deploy Stopped"),
    RUN_ONCE("Run Once"),
    SCHEDULED("Scheduled"),
    STREAMING("Streaming");

    private static EnumHelper<DeployStatus> enumHelper = new EnumHelper<>();

    static {
        enumHelper.initialize(DeployStatus.class);
    }

    private String strValue;

    DeployStatus(String strValue) {
        this.strValue = strValue;
    }

    public static EnumHelper<DeployStatus> getEnumHelper() {
        return enumHelper;
    }

    @JsonCreator
    public static DeployStatus getEnumForValue(String value) {
        if ("NotDeployed".equalsIgnoreCase(value)) {
            value = "Not Deployed";
        }
        return enumHelper.getEnumForStrValue(value);
    }

    @Override
    @JsonValue
    public String getStrValue() {
        return strValue;
    }

    public static List<DeployStatus> getSuccessFullDeployStatuses() {
        return Stream.of(DEPLOYED, RUN_ONCE, SCHEDULED).collect(Collectors.toList());
    }

    public static List<DeployStatus> getCompletedDeployStatuses() {
        return Stream.of(FAILED, DEPLOYED, RUN_ONCE, SCHEDULED, STREAMING).collect(Collectors.toList());
    }

    public static DeployStatus getOverallDeployStatus(DeployStatus currentDeployStatus, DeployStatus newDeployStatus) {

        if (currentDeployStatus == null || currentDeployStatus != DeployStatus.FAILED) {
            return newDeployStatus;
        }

        return currentDeployStatus;
    }
}

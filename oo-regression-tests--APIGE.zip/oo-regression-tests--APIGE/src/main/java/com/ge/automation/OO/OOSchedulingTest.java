package com.ge.automation.OO;

import java.time.LocalDateTime;
import java.time.ZoneId;
import java.time.temporal.ChronoUnit;
import java.util.LinkedHashMap;
import java.util.Map;
import java.util.Properties;

import com.jayway.restassured.path.json.JsonPath;
import com.jayway.restassured.response.Response;
import org.springframework.boot.test.TestRestTemplate;
import org.springframework.web.client.RestTemplate;
import org.testng.annotations.AfterClass;
import org.testng.annotations.AfterMethod;
import org.testng.annotations.AfterSuite;
import org.testng.annotations.AfterTest;
import org.testng.annotations.BeforeClass;
import org.testng.annotations.BeforeMethod;
import org.testng.annotations.BeforeSuite;
import org.testng.annotations.BeforeTest;
import org.testng.annotations.Test;

import com.ge.microtester.common.utils.RestAssuredUtil;
import com.ge.microtester.rally.RallyInfo;

@RallyInfo(ProjectName = "Operations Optimization Execution", FolderPath = "OO/Q4Release")
public class OOSchedulingTest extends RestAssuredUtil {

    static String jsonfileName;
    Properties configFile = new Properties();
    String truncateDateTime[];
    String tagName;
    String proxyHost;
    String proxyPort;
    Response responseBody;
    String kpiid;
    String kpiJobId;
    String dataSourceId;
    long kpi_id;
    long kpi_id1;
    String path = "src/main/resources/payloadsEventHub/";
    String apmTSforIngestionPath;
    boolean apmIngestionDynamicTag;
    String kpiTemplateJsonPath;
    String kpiTemplateAnalyticPath;
    String kpiJobJsonPath;
    String dataIngestionFilePath;
    String inputTag;
    String outputTag;
    String expectedValue;
    String expectedJobStatus;
    boolean createKpiJobWithTag;
    String apmTsUrl = "";

    public OOTestUtil ooTestutil = new OOTestUtil();
    RestTemplate restTemplate = new TestRestTemplate();
    // Generating Query Params
    Map<String, Object> values = new LinkedHashMap<String, Object>();

    @BeforeMethod
    public void beforeMethod() {
    }

    @AfterMethod
    public void afterMethod() {
    }

    @BeforeClass
    public void beforeClass() {

        System.getProperties().put("proxySet", "true");
        System.getProperties().put("http.proxyHost", "sjc1intproxy01.crd.ge.com");
        System.getProperties().put("http.proxyPort", "8080");
        System.getProperties().put("https.proxyHost", "sjc1intproxy01.crd.ge.com");
        System.getProperties().put("https.proxyPort", "8080");
        setSysProperty("currentTimeStamp", "" + getCurrentTimestamp());// ${sys:currentTimeStamp}
    }// end of beforeClass

    @AfterClass
    public void afterClass() {
    }

    @BeforeTest
    public void beforeTest() {

    }// end of beforeTest

    /*********************************************************************************************************/

	@Test(priority = 1, description = "testE2E_ApmTSInput_ApmTSOutput_Scheduling_Python")
    @RallyInfo(UserStory = "US4776")
    public void testE2E_ApmTSInput_ApmTSOutput_Scheduling_Python() throws Exception {
        testE2E_ApmTSInput_ApmTSOutput_SchedulingWithLanguage("PYTHON");
    }

    /*********************************************************************************************************/

	@Test(priority = 1, description = "testE2E_ApmTSInput_ApmTSOutput_Scheduling_Java")
    @RallyInfo(UserStory = "US4776")
    public void testE2E_ApmTSInput_ApmTSOutput_Scheduling_Java() throws Exception {
        testE2E_ApmTSInput_ApmTSOutput_SchedulingWithLanguage("JAVA");
    }

    /*********************************************************************************************************/
	@Test(priority = 1, description = "test_Delete_Running_Scheduled_Job")
    @RallyInfo(UserStory = "US79874")
    public void test_Delete_Running_Scheduled_Job() throws Exception {
        setSysProperty("language", "PYTHON");
        // ingest test data into apm time series
        String inputTag = "OO_Tag_Temperature_ID10";
        String outputTag = "OO_Tag_Temperature_ID11";
        LocalDateTime startTime = LocalDateTime.now(ZoneId.of("UTC"));
        int valuePosted =
            ooTestutil.postRandomDataPointToAPMTimeSeriesWithTimestamp(path + "data_files/data_ingestion_gen.json",
                inputTag, startTime.plus(1, ChronoUnit.MINUTES).toString());

        // create kpi template
        System.out.println(
            "before create kpi template, path=" + path + "/kpi_templates/kpi_e2e_ooapmts_inputAndOutput.json");

        String analyticZipFile = "";
        analyticZipFile = "kpi_analytics_1/kpiapmtspy1.zip";

        kpi_id = ooTestutil.createKpiTemplate(path + "kpi_templates/kpi_e2e_ooapmts_inputAndOutput.json",
            path + analyticZipFile);
        Thread.sleep(10000);

        // create kpi job

        System.out.println("after template. create kpi job with path=" + path
            + "/kpi_jobs/kpi_e2e_ooapmts_inputAndOutput_job_with_scheduler.json");
        kpiJobId = ooTestutil.createKpiJobWithSchedulerInfo(
            path + "kpi_jobs/kpi_e2e_ooapmts_inputAndOutput_job_with_scheduler.json", kpi_id, outputTag, inputTag,
            "");
        ooTestutil.startScheduledKpiJob(kpiJobId);
        Thread.sleep(100000);
        ooTestutil.getStatusOfJob(kpiJobId);

        ooTestutil.deleteKpiJob(kpiJobId);
        ooTestutil.getStatusOfJob(kpiJobId);
        isEqual("KPIJob was not deleted", ooTestutil.getStatusResponseOfJob(kpiJobId).getString("message"),
            "ObjectNotFound");
    }

    /*********************************************************************************************************/
	@Test(priority = 1, description = "test_Delete_Scheduled_Job")
    @RallyInfo(UserStory = "US79874")
    public void test_Delete_Scheduled_Job() throws Exception {
        setSysProperty("language", "PYTHON");
        // ingest test data into apm time series
        String inputTag = "OO_Tag_Temperature_ID10";
        String outputTag = "OO_Tag_Temperature_ID11";
        LocalDateTime startTime = LocalDateTime.now(ZoneId.of("UTC"));
        int valuePosted =
            ooTestutil.postRandomDataPointToAPMTimeSeriesWithTimestamp(path + "data_files/data_ingestion_gen.json",
                inputTag, startTime.plus(1, ChronoUnit.MINUTES).toString());

        // create kpi template
        System.out.println(
            "before create kpi template, path=" + path + "/kpi_templates/kpi_e2e_ooapmts_inputAndOutput.json");

        String analyticZipFile = "";
        analyticZipFile = "kpi_analytics_1/kpiapmtspy1.zip";

        kpi_id = ooTestutil.createKpiTemplate(path + "kpi_templates/kpi_e2e_ooapmts_inputAndOutput.json",
            path + analyticZipFile);
        Thread.sleep(10000);

        // create kpi job

        System.out.println("after template. create kpi job with path=" + path
            + "/kpi_jobs/kpi_e2e_ooapmts_inputAndOutput_job_with_scheduler.json");
        kpiJobId = ooTestutil.createKpiJobWithSchedulerInfo(
            path + "kpi_jobs/kpi_e2e_ooapmts_inputAndOutput_job_with_scheduler.json", kpi_id, outputTag, inputTag,
            "");
        ooTestutil.startScheduledKpiJob(kpiJobId);
        ooTestutil.getStatusOfJob(kpiJobId);
        ooTestutil.deleteKpiJob(kpiJobId);
        ooTestutil.getStatusOfJob(kpiJobId);
        isEqual("KPIJob was not deleted", ooTestutil.getStatusResponseOfJob(kpiJobId).getString("message"),
            "ObjectNotFound");
    }

    /*********************************************************************************************************/
    private void testE2E_ApmTSInput_ApmTSOutput_SchedulingWithLanguage(String language) throws Exception {
        setSysProperty("language", language);
        // ingest test data into apm time series
        String inputTag = "OO_Tag_Temperature_ID10";
        String outputTag = "OO_Tag_Temperature_ID11";
        LocalDateTime startTime = LocalDateTime.now(ZoneId.of("UTC"));
        int valuePosted =
            ooTestutil.postRandomDataPointToAPMTimeSeriesWithTimestamp(path + "data_files/data_ingestion_gen.json",
                inputTag, startTime.plus(1, ChronoUnit.MINUTES).toString());

        // create kpi template
        System.out.println(
            "before create kpi template, path=" + path + "/kpi_templates/kpi_e2e_ooapmts_inputAndOutput.json");

        String analyticZipFile = "";
        if (language.equals("PYTHON")) {
            analyticZipFile = "kpi_analytics_1/kpiapmtspy1.zip";
        } else if (language.equals("JAVA")) {
            analyticZipFile = "kpi_analytics_1/kpi-job-apm-timeseries-mappings-0.8.jar.zip";
        }

        kpi_id = ooTestutil.createKpiTemplate(path + "kpi_templates/kpi_e2e_ooapmts_inputAndOutput.json",
            path + analyticZipFile);
        Thread.sleep(10000);

        // create kpi job

        System.out.println("after template. create kpi job with path=" + path
            + "/kpi_jobs/kpi_e2e_ooapmts_inputAndOutput_job_with_scheduler.json");
        kpiJobId = ooTestutil.createKpiJobWithSchedulerInfo(
            path + "kpi_jobs/kpi_e2e_ooapmts_inputAndOutput_job_with_scheduler.json", kpi_id, outputTag, inputTag,
            "");

        // start kpi job
        String schedulerId = ooTestutil.startScheduledKpiJob(kpiJobId);

        if (schedulerId != null) {

            Thread.sleep(10000);
            JsonPath statusJson =
                ooTestutil.getStatusResponseOfJob(kpiJobId);
            System.out.println("After 10 seconds");
            isEqual("Job should not be running",
                statusJson.getString("message").equals("JobNotRunning"), true);

            Thread.sleep(10000);
            statusJson =
                ooTestutil.getStatusResponseOfJob(kpiJobId);
            System.out.println("After 20 seconds");
            isEqual("Job should not be running",
                statusJson.getString("message").equals("JobNotRunning"), true);

            Thread.sleep(10000);
            statusJson =
                ooTestutil.getStatusResponseOfJob(kpiJobId);
            System.out.println("After 30 seconds");
            isEqual("Job should not be running",
                statusJson.getString("message").equals("JobNotRunning"), true);

            Thread.sleep(10000);
            statusJson =
                ooTestutil.getStatusResponseOfJob(kpiJobId);
            System.out.println("After 40 seconds");
            isEqual("Job should not be running",
                statusJson.getString("message").equals("JobNotRunning"), true);

            Thread.sleep(10000);
            statusJson =
                ooTestutil.getStatusResponseOfJob(kpiJobId);
            System.out.println("After 50 seconds");
            isEqual("Job should not be running",
                statusJson.getString("message").equals("JobNotRunning"), true);

            // get Status of the Job Thread.sleep(10000); statusJson =
            ooTestutil.getStatusResponseOfJob(kpiJobId);
            System.out.println("After 60 seconds");
            isEqual("Job should not be running",
                statusJson.getString("message").equals("JobNotRunning"), true);

            Thread.sleep(80000);
            System.out.println("After 120 seconds");
            String status = ooTestutil.getStatusOfJob(kpiJobId);
            System.out.println("Status of scheduled job is " + status);
            if (status != null) {// && status.equalsIgnoreCase("FINISHED")) {
                String tsResponse = ooTestutil.getDataFromApmTimeSeriesWithTimeFilter(outputTag, startTime.toString());
                System.out.println("Value posted was " + String.valueOf(valuePosted));
                isEqual("Calculated data of APM TS is not matching expected value", true,
                    tsResponse.contains(String.valueOf(valuePosted * 10)));

                // delete kpi job
                ooTestutil.deleteKpiJob(kpiJobId);
            } else {
                fail("Job not Started Successfully.Status of the JOB is --->" + status);
            }
        } else

        {
            fail("Job not scheduled. Scheduler id is null");
        }
    }

    @Test(priority = 1, description = "test_Scheduled_Job_Without_DataRequest")
    @RallyInfo(UserStory = "US205298")
    public void testE2E_apmTSInput_apmTSOutput_scheduled_job_without_dataRequest() throws Exception {
        String language = "PYTHON";
        setSysProperty("language", language);
        // ingest test data into apm time series
        String inputTag = "OO_Tag_Temperature_ID10";
        String outputTag = "OO_Tag_Temperature_ID11";
        LocalDateTime startTime = LocalDateTime.now(ZoneId.of("UTC"));
        int valuePosted =
            ooTestutil.postRandomDataPointToAPMTimeSeriesWithTimestamp(path + "data_files/data_ingestion_gen.json",
                inputTag, startTime.plus(1, ChronoUnit.MINUTES).toString());

        // create kpi template
        System.out.println(
            "before create kpi template, path=" + path + "/kpi_templates/kpi_e2e_ooapmts_inputAndOutput.json");

        String analyticZipFile = "";
        if (language.equals("PYTHON")) {
            analyticZipFile = "kpi_analytics_1/kpiapmtspy1.zip";
        } else if (language.equals("JAVA")) {
            analyticZipFile = "kpi_analytics_1/kpi-job-apm-timeseries-mappings-0.8.jar.zip";
        }

        kpi_id = ooTestutil.createKpiTemplate(path + "kpi_templates/kpi_e2e_ooapmts_inputAndOutput.json",
            path + analyticZipFile);
        Thread.sleep(10000);

        // create kpi job

        System.out.println("after template. create kpi job with path=" + path
            + "/kpi_jobs/kpi_e2e_ooapmts_inputAndOutput_job_with_scheduler_with_missing_dataRequest.json");

        Response response = ooTestutil.createKpiJobWithSchedulerInfo_errorResponse(path +
                "kpi_jobs/kpi_e2e_ooapmts_inputAndOutput_job_with_scheduler_with_missing_dataRequest.json", kpi_id,
            outputTag, inputTag,
            "");

        isEqual("Expected 400 - Bad request", 400, response.getStatusCode());
        isEqual("Expected error message - Missing section 'kpiScheduler.dataRequest' for job payload.", true,
            response.body().asString().contains("Missing section 'kpiScheduler.dataRequest' for job payload."));

        // cleanup for template
        ooTestutil.deleteKpiTemplate(String.valueOf(kpi_id));
    }

    @Test(priority = 1, description = "test_scheduled_nonPredixARF_framework_job")
    @RallyInfo(UserStory = "US205298")
    public void testE2E_apmTSInput_apmTSOutput_nonPredixARF_framework_scheduled_job() throws Exception {
        String language = "PYTHON";
        setSysProperty("language", language);
        // ingest test data into apm time series
        String inputTag = "OO_Tag_Temperature_ID10";
        String outputTag = "OO_Tag_Temperature_ID11";
        LocalDateTime startTime = LocalDateTime.now(ZoneId.of("UTC"));
        int valuePosted =
            ooTestutil.postRandomDataPointToAPMTimeSeriesWithTimestamp(path + "data_files/data_ingestion_gen.json",
                inputTag, startTime.plus(1, ChronoUnit.MINUTES).toString());

        // create kpi template
        System.out.println(
            "before create kpi template, path=" + path + "/kpi_templates/kpi_e2e_ooapmts_inputAndOutput.json");

        String analyticZipFile = "";
        if (language.equals("PYTHON")) {
            analyticZipFile = "kpi_analytics_1/kpiapmtspy1.zip";
        } else if (language.equals("JAVA")) {
            analyticZipFile = "kpi_analytics_1/kpi-job-apm-timeseries-mappings-0.8.jar.zip";
        }

        kpi_id = ooTestutil.createKpiTemplate(path + "kpi_templates/kpi_e2e_ooapmts_inputAndOutput.json",
            path + analyticZipFile);
        Thread.sleep(10000);

        // create kpi job

        System.out.println("after template. create kpi job with path=" + path
            + "/kpi_jobs/kpi_e2e_ooapmts_nonPredixARFFramework_job_with_scheduler.json");

        // per 5 min
        String cron = "0 0/5 * 1/1 * ? *";

        kpiJobId = ooTestutil.createKpiJobWithSchedulerInfo(
            path + "kpi_jobs/kpi_e2e_ooapmts_nonPredixARFFramework_job_with_scheduler.json", kpi_id, outputTag,
            inputTag, cron);
        ooTestutil.startScheduledKpiJob(kpiJobId);
        ooTestutil.getStatusOfJob(kpiJobId);

        short iter = 1, maxtries = 10;
        do {
            Thread.sleep(iter++ * 10000);
        } while (!("ACCEPTED".equals(ooTestutil.getStatusOfJob(kpiJobId)) || "FINISHED"
            .equals(ooTestutil.getStatusOfJob(kpiJobId))) && iter <= maxtries);

        ooTestutil.deleteKpiJob(kpiJobId);

        Thread.sleep(10000);

        ooTestutil.getStatusOfJob(kpiJobId);
        isEqual("KPIJob was not deleted", ooTestutil.getStatusResponseOfJob(kpiJobId).getString("message"),
            "ObjectNotFound");

        // cleanup for template
        ooTestutil.deleteKpiTemplate(String.valueOf(kpi_id));
    }

    /*********************************************************************************************************/
    @AfterTest
    public void afterTest() {
    }

    @BeforeSuite
    public void beforeSuite() {

    }

    @AfterSuite
    public void afterSuite() {
    }
}

package com.ge.automation.OO;

import com.ge.microtester.common.utils.RestAssuredUtil;
import com.ge.microtester.rally.RallyInfo;
import com.ge.oo.commons.utils.StringUtils;
import com.jayway.restassured.response.Response;
import org.apache.http.HttpStatus;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.boot.test.TestRestTemplate;
import org.springframework.web.client.RestTemplate;
import org.testng.Assert;
import org.testng.annotations.AfterClass;
import org.testng.annotations.AfterMethod;
import org.testng.annotations.AfterSuite;
import org.testng.annotations.AfterTest;
import org.testng.annotations.BeforeClass;
import org.testng.annotations.BeforeMethod;
import org.testng.annotations.BeforeSuite;
import org.testng.annotations.BeforeTest;
import org.testng.annotations.Test;
import java.io.IOException;
import java.net.URISyntaxException;
import java.util.LinkedHashMap;
import java.util.Map;
import java.util.Properties;

@RallyInfo(ProjectName ="APM Super Optimo")
public class OOHealthCheckCF1BatchTests extends RestAssuredUtil {
	private static final Logger log = LoggerFactory.getLogger("OOHealthCheckCF1Tests");
	static String jsonfileName;
	Properties configFile = new Properties();
	String truncateDateTime[];
	String tagName;
	String proxyHost;
	String proxyPort;
	Response responseBody;
	String kpiid;
	String kpiJobId;
	String dataSourceId;
	long kpi_id;
	long kpi_id1;
	String path = "src/main/resources/payloadsAndromeda";
	String apmTSforIngestionPath;
	boolean apmIngestionDynamicTag;
	String kpiTemplateJsonPath;
	String kpiTemplateAnalyticPath;
	String kpiJobJsonPath;
	String dataIngestionFilePath;
	String inputTag;
	String outputTag;
	String expectedValue;
	String expectedJobStatus;
	boolean createKpiJobWithTag;
	String apmTsUrl = "";

	public OOTestUtil ooTestutil = new OOTestUtil();
	RestTemplate restTemplate = new TestRestTemplate();
	// Generating Query Params
	Map<String, Object> values = new LinkedHashMap<String, Object>();

	@BeforeMethod
	public void beforeMethod() {
	}

	@AfterMethod
	public void afterMethod() {
	}

	@BeforeClass
	public void beforeClass() {

		/*
		 * System.getProperties().put("proxySet", "true");
		 * System.getProperties().put("http.proxyHost",
		 * "sjc1intproxy01.crd.ge.com");
		 * System.getProperties().put("http.proxyPort", "8080");
		 * System.getProperties().put("https.proxyHost",
		 * "sjc1intproxy01.crd.ge.com");
		 * System.getProperties().put("https.proxyPort", "8080");
		 */
		// getServiceResponse("alert_profile_base_url");
		setSysProperty("currentTimeStamp", "" + getCurrentTimestamp());// ${sys:currentTimeStamp}

	}// end of beforeClass

	@AfterClass
	public void afterClass() {
	}

	@BeforeTest
	public void beforeTest() {

	}// end of beforeTest

	/********************************************************************************************************************/
	@Test
	public void test_ApmTsIngestion_ApmTsRetrieval() {
		// post data to apm
		int valuePosted;
		try {
			valuePosted = ooTestutil.postRandomDataPointToAPMTimeSeries(path + "/data_files/data_ingestion_gen.json",
					"OO_Tag_Temperature_ID2");

			// get data from APM
			Thread.sleep(20000);
			ooTestutil.getDataFromApmTimeSeries("OO_Tag_Temperature_ID2", String.valueOf(valuePosted));
		} catch (IOException | URISyntaxException | InterruptedException e) {
			Assert.fail("test_ApmIngestion_ApmRetrieval failed with message " + e.getMessage());
		}
	}

	/********************************************************************************************************************/
	@Test
	public void test_ApmAssetRetrieval() {
		log.info("Asserting Assets Exists");
		// get Asset data from APM
		try {
			ooTestutil.getAPMAssets();
		} catch (InterruptedException e) {
			Assert.fail("test_ApmAssetRetrieval failed with message " + e.getMessage());
		}
	}
	
	/********************************************************************************************************************/
	@Test(dependsOnMethods={"test_ApmTsIngestion_ApmTsRetrieval","test_ApmAssetRetrieval"})
	@RallyInfo(UserStory ="US223441")
	public void testE2E_ApmTSInput_ApmTSOutput_Java() throws Exception {

		/*
		 * //zip analytic with new name //(String filePath, String zipFileName)
		 * String zipFileName =
		 * " simple_java_kpi"+ooTestutil.generateRandomNumberNonUUID()+".zip";
		 * log.info(
		 * "OOHealthCheckAndromedaTests.testE2E_ApmTSInput_ApmTSOutput_Java()\n"
		 * +zipFileName); ooTestutil.ZipFile(path +
		 * "/kpi_analytics/simple_java_kpi",zipFileName);
		 */

		// ingest test data into apm time series
		String inputTag = "OO_Tag_Temperature_ID14";
		String outputTag = "OO_Tag_Temperature_ID15";

		// create kpi template
		kpi_id = ooTestutil.createKpiTemplate(path + "/kpi_templates/kpi_e2e_ooapmts_inputAndOutput.json",
				path + "/kpi_analytics/simple_java_version2.zip");
		Thread.sleep(10000);

		// create kpi job
		kpiJobId = ooTestutil.createKpiJobWithNoRandomBothInputAndOutputTag(
				path + "/kpi_jobs/kpi_e2e_ooapmts_inputAndOutput_1_job.json", kpi_id, outputTag, inputTag, "");

		int valuePosted = ooTestutil.postRandomDataPointToAPMTimeSeries(path + "/data_files/data_ingestion_gen.json",
				inputTag);

		// start kpi job
		String runtimeJobId = ooTestutil.startKpiJob(kpiJobId);
		Thread.sleep(30000);
		String statusOfJob = ooTestutil.getStatusOfJob(kpiJobId);

		String expectedValue = String.valueOf(valuePosted * 10);
		ooTestutil.getDataFromApmTimeSeries(outputTag, expectedValue);
		log.info("\n+++ Expected Value ----> " + expectedValue);
		log.info("\n+++ Actual Value ----> " + valuePosted);


		// DELETE KPI
		log.info("+++ DELETE KPI+++++++++++++++++++++++++++++++++++");
		String kpiDeleteUrl = getTestProperty("kpi_url") + "/" + kpi_id;
		log.info("+++ kpiDeleteUrl == " + kpiDeleteUrl);
		Response delete_response = deleteServiceResponse("kpi_url" + "/" + kpi_id, values,
				ooTestutil.kpiprovideHeaders());
		log.info("+++ delete_response.asString() == " + delete_response.asString());


		ooTestutil.printnewLine();

		ooTestutil.printnewLine();
	}


	/*********************************************************************************************************
	 * Python Analytic - Read APM TS as input and write output to APM TS
	 * 
	 *********************************************************************************************************/

	@Test(dependsOnMethods={"test_ApmTsIngestion_ApmTsRetrieval","test_ApmAssetRetrieval"})
	@RallyInfo(UserStory ="US223441")
	public void testE2E_ApmTSInput_ApmTSOutput_Python() throws Exception {

		// ingest test data into apm time series
		String sourcetag = "OO_Tag_Temperature_ID16";
		String targettag = "OO_Tag_Temperature_ID17";

		// create kpi template
		kpi_id = ooTestutil.createKpiTemplate(path + "/kpi_templates/kpi_e2e_ooapmts_inputAndOutput_python.json",
				path + "/kpi_analytics/simple_python_version3.zip");
		Thread.sleep(10000);

		// create kpi job
		kpiJobId = ooTestutil.createKpiJobWithNoRandomBothInputAndOutputTag(
				path + "/kpi_jobs/kpi_e2e_ooapmts_inputAndOutput_job_python.json", kpi_id, targettag, sourcetag, "");
		Thread.sleep(10000);

		int valuePosted = ooTestutil.postRandomDataPointToAPMTimeSeries(path + "/data_files/data_ingestion_gen.json",
				sourcetag);
		Thread.sleep(10000);

		// start kpi job
		String runtimeJobId = ooTestutil.startKpiJob(kpiJobId);
		Thread.sleep(30000);
		String statusOfJob = ooTestutil.getStatusOfJob(kpiJobId);

		ooTestutil.getDataFromApmTimeSeries(targettag, String.valueOf(valuePosted * 10));

		// delete kpi job
		Thread.sleep(10000);
		ooTestutil.deleteKpiJob(kpiJobId);
		Thread.sleep(10000);
		// get status of the job
		statusOfJob = ooTestutil.getStatusOfJob(kpiJobId);

		// DELETE KPI
		log.info("+++ DELETE KPI+++++++++++++++++++++++++++++++++++");
		String kpiDeleteUrl = getTestProperty("kpi_url") + "/" + kpi_id;
		log.info("+++ kpiDeleteUrl == " + kpiDeleteUrl);
		Response delete_response = deleteServiceResponse("kpi_url" + "/" + kpi_id, values,
				ooTestutil.kpiprovideHeaders());
		log.info("+++ delete_response.asString() == " + delete_response.asString());
		// isEqual("Delete failed", true, delete_response.getStatusCode() ==
		// HttpStatus.SC_NO_CONTENT);

		ooTestutil.printnewLine();


	}

	/********************************************************************************************************************/
	@Test(dependsOnMethods={"test_ApmTsIngestion_ApmTsRetrieval","test_ApmAssetRetrieval"})
	@RallyInfo(UserStory ="US223441")
	public void testE2E_ApmTSInput_ApmTSOutput_translateDP_Java() throws Exception {

		// ingest test data into apm time series
		String inputTag = "OO_Tag_Temperature_ID18";
		String outputTag = "OO_Tag_Temperature_ID19";

		// create kpi template
		kpi_id = ooTestutil.createKpiTemplate(path + "/kpi_templates/kpi_e2e_ooapmts_inputAndOutput_1_java.json",
				path + "/kpi_analytics/simple_java_version2.zip");
		Thread.sleep(10000);

		// create kpi job

		kpiJobId = ooTestutil.createKpiJobWithNoRandomBothInputAndOutputTag(
				path + "/kpi_jobs/kpi_e2e_ooapmts_inputAndOutput_job_NoAsset_java.json", kpi_id, outputTag, inputTag,
				"");

		int valuePosted = ooTestutil.postRandomDataPointToAPMTimeSeries(path + "/data_files/data_ingestion_gen.json",
				inputTag);
		Thread.sleep(20000);

		// start kpi job
		String runtimeJobId = ooTestutil.startKpiJob(kpiJobId);
		Thread.sleep(30000);
		String statusOfJob = ooTestutil.getStatusOfJob(kpiJobId);

		// if(statusOfJob.equalsIgnoreCase("RUNNING"))
		// {
		ooTestutil.getDataFromApmTimeSeries(outputTag, String.valueOf(valuePosted * 10));

		// delete kpi job
		Thread.sleep(10000);
		ooTestutil.deleteKpiJob(kpiJobId);
		Thread.sleep(10000);
		// get status of the job
		statusOfJob = ooTestutil.getStatusOfJob(kpiJobId);

		// DELETE KPI
		log.info("+++ DELETE KPI+++++++++++++++++++++++++++++++++++");
		String kpiDeleteUrl = getTestProperty("kpi_url") + "/" + kpi_id;
		log.info("+++ kpiDeleteUrl == " + kpiDeleteUrl);
		Response delete_response = deleteServiceResponse("kpi_url" + "/" + kpi_id, values,
				ooTestutil.kpiprovideHeaders());
		log.info("+++ delete_response.asString() == " + delete_response.asString());
		// isEqual("Delete failed", true, delete_response.getStatusCode() ==
		// HttpStatus.SC_NO_CONTENT);

		ooTestutil.printnewLine();

	}

	/*********************************************************************************************************
	 * Python Analytic - Read APM TS as input and write output to APM TS
	 * 
	 *********************************************************************************************************/

	@Test(dependsOnMethods={"test_ApmTsIngestion_ApmTsRetrieval","test_ApmAssetRetrieval"})
	@RallyInfo(UserStory ="US223441")
	public void testE2E_ApmTSInput_ApmTSOutput_translateDP_Python() throws Exception {

		// ingest test data into apm time series
		String sourcetag = "OO_Tag_Temperature_ID35";
		String targettag = "OO_Tag_Temperature_ID36";

		// create kpi template
		kpi_id = ooTestutil.createKpiTemplate(path + "/kpi_templates/kpi_e2e_ooapmts_inputAndOutput_1_python.json",
				path + "/kpi_analytics/simple_python_version3.zip");
		Thread.sleep(10000);

		// create kpi job
		kpiJobId = ooTestutil.createKpiJobWithNoRandomBothInputAndOutputTag(
				path + "/kpi_jobs/kpi_e2e_ooapmts_inputAndOutput_job_NoAsset_python.json", kpi_id, targettag, sourcetag,
				"");
		Thread.sleep(10000);

		int valuePosted = ooTestutil.postRandomDataPointToAPMTimeSeries(path + "/data_files/data_ingestion_gen.json",
				sourcetag);

		Thread.sleep(30000);

		// start kpi job
		String runtimeJobId = ooTestutil.startKpiJob(kpiJobId);
		Thread.sleep(30000);
		String statusOfJob = ooTestutil.getStatusOfJob(kpiJobId);

		// if(statusOfJob.equalsIgnoreCase("RUNNING"))
		// {
		ooTestutil.getDataFromApmTimeSeries(targettag, String.valueOf(valuePosted * 10));

		// delete kpi job
		Thread.sleep(10000);
		ooTestutil.deleteKpiJob(kpiJobId);
		Thread.sleep(10000);
		// get status of the job
		statusOfJob = ooTestutil.getStatusOfJob(kpiJobId);

		// DELETE KPI
		log.info("+++ DELETE KPI+++++++++++++++++++++++++++++++++++");
		String kpiDeleteUrl = getTestProperty("kpi_url") + "/" + kpi_id;
		log.info("+++ kpiDeleteUrl == " + kpiDeleteUrl);
		Response delete_response = deleteServiceResponse("kpi_url" + "/" + kpi_id, values,
				ooTestutil.kpiprovideHeaders());
		log.info("+++ delete_response.asString() == " + delete_response.asString());
		// isEqual("Delete failed", true, delete_response.getStatusCode() ==
		// HttpStatus.SC_NO_CONTENT);

		ooTestutil.printnewLine();

	}

	/********************************************************************************************************************
	 * Delete Kpi: Scenario 0: Create Kpi w/o artifact -> Get Kpi -> Delete Kpi -> Get Kpi
	 *
	 ********************************************************************************************************************/
	@Test(dependsOnMethods={"test_ApmTsIngestion_ApmTsRetrieval","test_ApmAssetRetrieval"})
	@RallyInfo(UserStory ="US223441")
	public void testDeleteKpiScenario0() throws Exception {

		log.info("*****************Create KPI TEMPLATE*******************");
		ooTestutil.printnewLine();

		// create kpi template
		kpi_id = ooTestutil.createKpiTemplate(path + "/kpi_templates/kpiTemplate_2.json");
		// Thread.sleep(10000);

		// *****************Create KPI
		// TEMPLATE***************************************************//

		// GET KPI

		log.info("+++ GET KPI BY ID+++++++++++++++++++++++++++++++++++");
		String getKpiUrl = "kpi_url" + "/id/" + kpi_id;
		log.info("+++ getkpiByIDurl == " + getKpiUrl);
		Response get_response = getServiceResponse(getKpiUrl, ooTestutil.kpiprovideHeaders());
		String kpi_name = get_response.jsonPath().getString("name[0]");
		log.info("+++ kpi_name == " + kpi_name);
		isEqual("Incorrect kpi ID", true, get_response.body().asString().contains(String.valueOf(kpi_id)));
		isEqual("No inputs in response", true, get_response.body().jsonPath().getList("inputs").size() > 0);
		isEqual("No outputs in response", true, get_response.body().jsonPath().getList("outputs").size() > 0);

		ooTestutil.printnewLine();

		// GET KPI BY NAME
		log.info("+++ GET KPI BY NAME+++++++++++++++++++++++++++++++++++");
		String getkpiByNameurl = "kpi_url" + "/name/" + kpi_name;
		log.info("+++ getkpiByNameurl == " + getkpiByNameurl);
		Response get_response_by_name = getServiceResponse(getkpiByNameurl, ooTestutil.kpiprovideHeaders());
		isEqual("Missing kpi name", true, get_response_by_name.body().asString().contains(String.valueOf(kpi_name)));

		ooTestutil.printnewLine();
		// DELETE KPI
		log.info("+++ DELETE KPI+++++++++++++++++++++++++++++++++++");
		String kpiDeleteUrl = getTestProperty("kpi_url") + "/" + kpi_id;
		log.info("+++ kpiDeleteUrl == " + kpiDeleteUrl);
		Response delete_response = deleteServiceResponse("kpi_url" + "/" + kpi_id, values,
				ooTestutil.kpiprovideHeaders());
		log.info("+++ delete_response.asString() == " + delete_response.asString());
		isEqual("Delete failed", true, delete_response.getStatusCode() == HttpStatus.SC_NO_CONTENT);

		ooTestutil.printnewLine();
		// GET KPI
		log.info("+++ GET KPI AFTER DELETE+++++++++++++++++++++++++++++++++++");
		getKpiUrl = "kpi_url" + "/id/" + kpi_id;
		get_response = getServiceResponse(getKpiUrl, ooTestutil.kpiprovideHeaders());
		isEqual("Delete failed", 404, get_response.getStatusCode());
		ooTestutil.printnewLine();
	}

	/********************************************************************************************************************
	 * Delete Kpi: Scenario 1: Create Kpi -> Get Kpi -> Delete Kpi -> Get Kpi
	 * 
	 ********************************************************************************************************************/
	@Test(dependsOnMethods={"test_ApmTsIngestion_ApmTsRetrieval","test_ApmAssetRetrieval"})
	@RallyInfo(UserStory ="US223441")
	public void testDeleteKpiScenario1() throws Exception {

		log.info("*****************Create KPI TEMPLATE*******************");
		ooTestutil.printnewLine();

		// create kpi template
		kpi_id = ooTestutil.createKpiTemplate(path + "/kpi_templates/kpiTemplate_2.json",
				path + "/kpi_analytics/" + "simple_java_version2.zip");
		// Thread.sleep(10000);

		// *****************Create KPI
		// TEMPLATE***************************************************//

		// GET KPI

		log.info("+++ GET KPI BY ID+++++++++++++++++++++++++++++++++++");
		String getKpiUrl = "kpi_url" + "/id/" + kpi_id;
		log.info("+++ getkpiByIDurl == " + getKpiUrl);
		Response get_response = getServiceResponse(getKpiUrl, ooTestutil.kpiprovideHeaders());
		String kpi_name = get_response.jsonPath().getString("name[0]");
		log.info("+++ kpi_name == " + kpi_name);
		isEqual("Incorrect kpi ID", true, get_response.body().asString().contains(String.valueOf(kpi_id)));
		isEqual("No inputs in response", true, get_response.body().jsonPath().getList("inputs").size() > 0);
		isEqual("No outputs in response", true, get_response.body().jsonPath().getList("outputs").size() > 0);

		ooTestutil.printnewLine();

		// GET KPI BY NAME
		log.info("+++ GET KPI BY NAME+++++++++++++++++++++++++++++++++++");
		String getkpiByNameurl = "kpi_url" + "/name/" + kpi_name;
		log.info("+++ getkpiByNameurl == " + getkpiByNameurl);
		Response get_response_by_name = getServiceResponse(getkpiByNameurl, ooTestutil.kpiprovideHeaders());
		isEqual("Missing kpi name", true, get_response_by_name.body().asString().contains(String.valueOf(kpi_name)));

		ooTestutil.printnewLine();
		// DELETE KPI
		log.info("+++ DELETE KPI+++++++++++++++++++++++++++++++++++");
		String kpiDeleteUrl = getTestProperty("kpi_url") + "/" + kpi_id;
		log.info("+++ kpiDeleteUrl == " + kpiDeleteUrl);
		Response delete_response = deleteServiceResponse("kpi_url" + "/" + kpi_id, values,
				ooTestutil.kpiprovideHeaders());
		log.info("+++ delete_response.asString() == " + delete_response.asString());
		isEqual("Delete failed", true, delete_response.getStatusCode() == HttpStatus.SC_NO_CONTENT);

		ooTestutil.printnewLine();
		// GET KPI
		log.info("+++ GET KPI AFTER DELETE+++++++++++++++++++++++++++++++++++");
		getKpiUrl = "kpi_url" + "/id/" + kpi_id;
		get_response = getServiceResponse(getKpiUrl, ooTestutil.kpiprovideHeaders());
		isEqual("Delete failed", 404, get_response.getStatusCode());
		ooTestutil.printnewLine();
	}

	/********************************************************************************************************************
	 * Delete Kpi:
	 * 
	 * Scenario 2: Create Kpi -> Get Kpi -> Create Kpi Job -> Delete Kpi -> Get
	 * Kpi Should not delete kpi unless Kpi job is deleted.
	 * 
	 ********************************************************************************************************************/
	@Test(dependsOnMethods={"test_ApmTsIngestion_ApmTsRetrieval","test_ApmAssetRetrieval"})
	@RallyInfo(UserStory ="US223441")
	public void testDeleteKpiScenario2() throws Exception {

		log.info("*****************Create KPI TEMPLATE*******************");
		ooTestutil.printnewLine();

		// create kpi template
		kpi_id = ooTestutil.createKpiTemplate(path + "/kpi_templates/kpiTemplate_2.json",
				path + "/kpi_analytics/" + "simple_java_version2.zip");

		log.info("+++ CREATE KPI JOB+++++++++++++++++++++++++++++++++++");
		String inputTag = "OO_Tag_Temperature_ID14";
		String outputTag = "OO_Tag_Temperature_ID15";
		// create kpi job
		kpiJobId = ooTestutil.createKpiJobWithNoRandomBothInputAndOutputTag(
				path + "/kpi_jobs/kpi_e2e_ooapmts_inputAndOutput_1_job.json", kpi_id, outputTag, inputTag, "");

		ooTestutil.printnewLine();

		// ooTestutil.printnewLine();
		// DELETE KPI
		String kpiDeleteUrl = getTestProperty("kpi_url") + "/" + kpi_id;
		log.info("+++ DELETE KPI AND CACSCADE DELETE KPI JOB +++++++++++++++++++++++++++++++++++");
		kpiDeleteUrl = getTestProperty("kpi_url") + "/" + kpi_id;
		log.info("+++ kpiDeleteUrl == " + kpiDeleteUrl);
		Response delete_response = deleteServiceResponse("kpi_url" + "/" + kpi_id, values,
				ooTestutil.kpiprovideHeaders());
		log.info("+++ delete_response.asString() == " + delete_response.asString());
		isEqual("we should be able to delete kpi", true, delete_response.getStatusCode() == HttpStatus.SC_NO_CONTENT);

		// GET KPI
		ooTestutil.printnewLine();
		log.info("+++ GET KPI BY ID+++++++++++++++++++++++++++++++++++");
		String getKpiUrl = "kpi_url" + "/id/" + kpi_id;
		Response get_response = getServiceResponse(getKpiUrl, ooTestutil.kpiprovideHeaders());
		isEqual("Delete failed", 404, get_response.getStatusCode());
		if (get_response.getBody().asString().equals("")) {
			log.info("testDeleteKpiScenario2 Passed. KPI was deleted successfully");
		}
		ooTestutil.printnewLine();

	}

	/********************************************************************************************************************
	 * Delete Kpi::
	 * 
	 * Scenario: Create Kpi -> Get Kpi -> Create Kpi Job -> Start Kpi Job -> Job
	 * in Running State -> Delete Kpi -> Get Kpi
	 * 
	 ********************************************************************************************************************/
	@Test(dependsOnMethods={"test_ApmTsIngestion_ApmTsRetrieval","test_ApmAssetRetrieval"})
	@RallyInfo(UserStory ="US223441")
	public void testDeleteKpiScenario3() throws Exception {

		log.info("*****************Create KPI TEMPLATE*******************");
		ooTestutil.printnewLine();

		// create kpi template
		kpi_id = ooTestutil.createKpiTemplate(path + "/kpi_templates/kpiTemplate_2.json",
				path + "/kpi_analytics/" + "simple_java_version2.zip");

		log.info("+++ CREATE KPI JOB+++++++++++++++++++++++++++++++++++");
		String inputTag = "OO_Tag_Temperature_ID14";
		String outputTag = "OO_Tag_Temperature_ID15";

		// create kpi job
		kpiJobId = ooTestutil.createKpiJobWithNoRandomBothInputAndOutputTag(
				path + "/kpi_jobs/kpi_e2e_ooapmts_inputAndOutput_1_job.json", kpi_id, outputTag, inputTag, "");

		log.info("+++Start KPI JOB+++++++++++++++++++++++++++++++++++");
		// start job
		ooTestutil.startKpiJob(kpiJobId);
		ooTestutil.printnewLine();
		Thread.sleep(10000);

		log.info("+++GET STATUS OF KPI JOB+++++++++++++++++++++++++++++++++++");
		// get status of the job
		String status = ooTestutil.getStatusOfJob(kpiJobId);
		ooTestutil.printnewLine();

		if (status.equalsIgnoreCase("RUNNING")) {

			// DELETE KPI
			log.info("+++DELETE KPI+++++++++++++++++++++++++++++++++++");
			String kpiDeleteUrl = getTestProperty("kpi_url") + "/" + kpi_id;
			log.info("+++ kpiDeleteUrl == " + kpiDeleteUrl);
			Response delete_response = deleteServiceResponse("kpi_url" + "/" + kpi_id, values,
					ooTestutil.kpiprovideHeaders());
			log.info("+++ delete_response.asString() == " + delete_response.asString());
			isEqual("we should not be able to delete kpi", true,
					delete_response.asString().contains("JobsAssociatedWithTemplate"));
			ooTestutil.printnewLine();

			// delete/Stop kpi job
			log.info("+++DELETE KPI JOB+++++++++++++++++++++++++++++++++++");
			ooTestutil.deleteKpiJob(kpiJobId);

			short waitTries = 10;
			for (int i = waitTries; i > 0; i--) {
				Thread.sleep(20000);
				ooTestutil.printnewLine();

				// get status of the job
				status = ooTestutil.getStatusOfJob(kpiJobId);
				ooTestutil.printnewLine();
				log.info("Job status post DELETE trigger - " + status);

				if (!org.apache.commons.lang.StringUtils.isEmpty(status) && status.equalsIgnoreCase("RUNNING")) {
					log.info("Job still RUNNING post DELETE trigger, waiting...");
				} else {
					break;
				}
			}

			ooTestutil.printnewLine();

			// DELETE KPI

			log.info("+++DELETE KPI AFTER DELETE JOB+++++++++++++++++++++++++++++++++++");
			kpiDeleteUrl = getTestProperty("kpi_url") + "/" + kpi_id;
			log.info("+++ kpiDeleteUrl == " + kpiDeleteUrl);
			delete_response = deleteServiceResponse("kpi_url" + "/" + kpi_id, values, ooTestutil.kpiprovideHeaders());
			log.info("+++ delete_response.asString() == " + delete_response.asString());
			isEqual("we should be able to delete kpi", true,
					delete_response.getStatusCode() == HttpStatus.SC_NO_CONTENT);
			ooTestutil.printnewLine();

			// GET KPI
			log.info("+++GET KPI AFTER DELETE KPI+++++++++++++++++++++++++++++++++++");
			String getKpiUrl = "kpi_url" + "/id/" + kpi_id;
			Response get_response = getServiceResponse(getKpiUrl, ooTestutil.kpiprovideHeaders());
			isEqual("Delete Failed", 404, get_response.getStatusCode());
			log.info("testDeleteKpiScenario3 Passed. KPI was deleted successfully");
		}

	}

	/********************************************************************************************************************
	 * Delete Kpi::
	 * 
	 * Scenario: Create Kpi -> Get Kpi -> Create Kpi Job -> Start 2-3 Kpi Job ->
	 * Start jobs -> Jobs in Running State -> Delete Kpi -> Get Kpi
	 * 
	 ********************************************************************************************************************/
	@Test(dependsOnMethods={"test_ApmTsIngestion_ApmTsRetrieval","test_ApmAssetRetrieval"})
	@RallyInfo(UserStory ="US223441")
	public void testDeleteKpiScenario4() throws Exception {

		log.info("*****************Create KPI TEMPLATE*******************");
		ooTestutil.printnewLine();

		// create kpi template
		kpi_id = ooTestutil.createKpiTemplate(path + "/kpi_templates/kpiTemplate_2.json",
				path + "/kpi_analytics/" + "simple_java_version2.zip");

		log.info("+++ CREATE KPI JOB+++++++++++++++++++++++++++++++++++");
		String inputTag = "OO_Tag_Temperature_ID14";
		String outputTag = "OO_Tag_Temperature_ID15";

		// create kpi job
		log.info("+++ Create KPI JOB*******************");
		String kpiJobId_1 = ooTestutil.createKpiJobWithNoRandomBothInputAndOutputTag(
				path + "/kpi_jobs/kpi_e2e_ooapmts_inputAndOutput_1_job.json", kpi_id, outputTag, inputTag, "");
		ooTestutil.printnewLine();

		String kpiJobId_2 = ooTestutil.createKpiJobWithNoRandomBothInputAndOutputTag(
				path + "/kpi_jobs/kpi_e2e_ooapmts_inputAndOutput_1_job.json", kpi_id, outputTag, inputTag, "");
		ooTestutil.printnewLine();

		String kpiJobId_3 = ooTestutil.createKpiJobWithNoRandomBothInputAndOutputTag(
				path + "/kpi_jobs/kpi_e2e_ooapmts_inputAndOutput_1_job.json", kpi_id, outputTag, inputTag, "");
		ooTestutil.printnewLine();

		// start job
		log.info("*****************START KPI JOB*******************");
		ooTestutil.printnewLine();
		ooTestutil.startKpiJob(kpiJobId_1);
		log.info("*****************START KPI JOB*******************");
		ooTestutil.printnewLine();
		ooTestutil.startKpiJob(kpiJobId_2);
		log.info("*****************START KPI JOB*******************");
		ooTestutil.printnewLine();
		ooTestutil.startKpiJob(kpiJobId_3);
		Thread.sleep(15000);

		// get list of jobs running
		log.info("*****************LIST OF JOBS*******************");
		ooTestutil.printnewLine();
		String list = ooTestutil.getListOfJobsForAKpiId(kpi_id);
		// TBD ASSERT list with list of jobs

		// get status of the job
		log.info("\n*****************GET STATUS OF JOBS*******************");
		ooTestutil.printnewLine();
		String status1 = ooTestutil.getStatusOfJob(kpiJobId_1);
		String status2 = ooTestutil.getStatusOfJob(kpiJobId_2);
		String status3 = ooTestutil.getStatusOfJob(kpiJobId_3);
		String kpiDeleteUrl ="";
		Response delete_response = null;
		if (status1.equalsIgnoreCase("Running") || status2.equalsIgnoreCase("Running")
				|| status3.equalsIgnoreCase("Running")) {

			// DELETE KPI
			log.info("+++DELETE KPI+++++++++++++++++++++++++++++++++++");
			kpiDeleteUrl = getTestProperty("kpi_url") + "/" + kpi_id;
			log.info("+++ kpiDeleteUrl == " + kpiDeleteUrl);
			delete_response = deleteServiceResponse("kpi_url" + "/" + kpi_id, values,
					ooTestutil.kpiprovideHeaders());
			log.info("+++ delete_response.asString() == " + delete_response.asString());
			isEqual("we should not be able to delete kpi", true,
					delete_response.getStatusCode() == HttpStatus.SC_FAILED_DEPENDENCY);
			ooTestutil.printnewLine();
			Thread.sleep(20000);

			/*// delete/Stop kpi job
			log.info("*****************DELETE JOB*******************");
			ooTestutil.printnewLine();
			ooTestutil.deleteKpiJob(kpiJobId_1);
			log.info("*****************DELETE JOB*******************");
			ooTestutil.printnewLine();
			ooTestutil.deleteKpiJob(kpiJobId_2);
			log.info("*****************DELETE JOB*******************");
			ooTestutil.printnewLine();
			ooTestutil.deleteKpiJob(kpiJobId_3);
			Thread.sleep(40000);*/
		}

		if (status1.equalsIgnoreCase("FINISHED") && status2.equalsIgnoreCase("FINISHED")
				&& status3.equalsIgnoreCase("FINISHED")) {
			// DELETE KPI

			log.info("*****************DELETE KPI*******************");
			kpiDeleteUrl = getTestProperty("kpi_url") + "/" + kpi_id;
			log.info("+++ kpiDeleteUrl == " + kpiDeleteUrl);
			delete_response = deleteServiceResponse("kpi_url" + "/" + kpi_id, values, ooTestutil.kpiprovideHeaders());
			log.info("+++ delete_response.asString() == " + delete_response.asString());
			isEqual("we should  be able to delete kpi", true,
					delete_response.getStatusCode() == HttpStatus.SC_NO_CONTENT);
			ooTestutil.printnewLine();
			// GET KPI

			log.info("+++GET KPI AFTER DELETE KPI+++++++++++++++++++++++++++++++++++");
			String getKpiUrl = "kpi_url" + "/id/" + kpi_id;
			Response get_response = getServiceResponse(getKpiUrl, ooTestutil.kpiprovideHeaders());
			isEqual("Delete Failed", 404, get_response.getStatusCode());
			log.info("testDeleteKpiScenario4 Passed. KPI was deleted successfully");

		}

	}

	/********************************************************************************************************************
	 * Delete Kpi::
	 * 
	 * Scenario: Create Kpi -> Get Kpi -> Create Kpi Job -> Start Kpi Job -> Job
	 * in Finished State -> Delete Kpi -> Get Kpi
	 * 
	 ********************************************************************************************************************/
	@Test(dependsOnMethods={"test_ApmTsIngestion_ApmTsRetrieval","test_ApmAssetRetrieval"})
	@RallyInfo(UserStory ="US223441")
	public void testDeleteKpiScenario5() throws Exception {

		log.info("*****************Create KPI TEMPLATE*******************");
		ooTestutil.printnewLine();

		// create kpi template
		kpi_id = ooTestutil.createKpiTemplate(path + "/kpi_templates/kpiTemplate_2.json",
				path + "/kpi_analytics/" + "simple_java_version2.zip");

		log.info("+++ CREATE KPI JOB+++++++++++++++++++++++++++++++++++");
		String inputTag = "OO_Tag_Temperature_ID14";
		String outputTag = "OO_Tag_Temperature_ID15";

		// create kpi job
		log.info("+++ Create KPI JOB*******************");
		String kpiJobId = ooTestutil.createKpiJobWithNoRandomBothInputAndOutputTag(
				path + "/kpi_jobs/kpi_e2e_ooapmts_inputAndOutput_1_job.json", kpi_id, outputTag, inputTag, "");
		ooTestutil.printnewLine();

		// start job
		log.info("+++START JOB+++++++++++++++++++++++++++++++++++");
		ooTestutil.printnewLine();
		ooTestutil.startKpiJob(kpiJobId);
		Thread.sleep(60000);

		// get status of the job
		log.info("+++GET STATUS OF JOB+++++++++++++++++++++++++++++++++++");
		ooTestutil.printnewLine();
		String status = ooTestutil.getStatusOfJob(kpiJobId);

		if (status.equalsIgnoreCase("FINISHED")) {

			// DELETE KPI
			String kpiDeleteUrl = getTestProperty("kpi_url") + "/" + kpi_id;
			log.info("+++ DELETE KPI AND CACSCADE DELETE KPI JOB +++++++++++++++++++++++++++++++++++");
			kpiDeleteUrl = getTestProperty("kpi_url") + "/" + kpi_id;
			log.info("+++ kpiDeleteUrl == " + kpiDeleteUrl);
			Response delete_response = deleteServiceResponse("kpi_url" + "/" + kpi_id, values,
					ooTestutil.kpiprovideHeaders());
			log.info("+++ delete_response.asString() == " + delete_response.asString());
			isEqual("we should be able to delete kpi", true,
					delete_response.getStatusCode() == HttpStatus.SC_NO_CONTENT);

			// GET KPI
			ooTestutil.printnewLine();
			log.info("+++ GET KPI BY ID+++++++++++++++++++++++++++++++++++");
			String getKpiUrl = "kpi_url" + "/id/" + kpi_id;
			Response get_response = getServiceResponse(getKpiUrl, ooTestutil.kpiprovideHeaders());
			isEqual("Delete failed", 404, get_response.getStatusCode());
			if (get_response.getBody().asString().equals("")) {
				log.info("testDeleteKpiScenario5 Passed. KPI was deleted successfully");
			}

			// get status of the job
			String response = ooTestutil.getStatusOfJob(kpiJobId);
			isEqual("Delete Failed", true, StringUtils.isNullOrEmpty(response));
		}
	}

	/********************************************************************************************************************
	 * Delete Kpi::
	 * 
	 * Scenario: Create Kpi -> Get Kpi -> Create Kpi Job -> Start Kpi Job -> Job
	 * in Failed State -> Delete Kpi -> Get Kpi
	 * 
	 ********************************************************************************************************************/
	//@Test(priority = 1, description = "testDeleteKpiScenario6")
	@RallyInfo(UserStory ="US223441")
	public void testDeleteKpiScenario6() throws Exception {

		log.info("*****************Create KPI TEMPLATE*******************");
		ooTestutil.printnewLine();

		// create kpi template
		kpi_id = ooTestutil.createKpiTemplate(path + "/kpi_templates/kpiTemplate_2.json",
				path + "/kpi_analytics/" + "simple_python_version3.zip");

		log.info("+++ CREATE KPI JOB+++++++++++++++++++++++++++++++++++");  
		String inputTag = "OO_Tag_Temperature_ID14";
		String outputTag = "OO_Tag_Temperature_ID15";

		// create kpi job
		log.info("+++ Create KPI JOB*******************");
		String kpiJobId = ooTestutil.createKpiJobWithNoRandomBothInputAndOutputTag(
				path + "/kpi_jobs/kpi_e2e_ooapmts_inputAndOutput_error_job.json", kpi_id, outputTag, inputTag, "");
		ooTestutil.printnewLine();

		// start job
		log.info("+++START JOB+++++++++++++++++++++++++++++++++++");
		ooTestutil.printnewLine();
		ooTestutil.startKpiJob(kpiJobId);
		Thread.sleep(40000);

		// get status of the job
		log.info("+++GET STATUS OF JOB+++++++++++++++++++++++++++++++++++");
		ooTestutil.printnewLine();
		String status = ooTestutil.getStatusOfJob(kpiJobId);

		if (status.equalsIgnoreCase("Killed")) {

			// DELETE KPI
			String kpiDeleteUrl = getTestProperty("kpi_url") + "/" + kpi_id;
			log.info("+++ DELETE KPI AND CACSCADE DELETE KPI JOB +++++++++++++++++++++++++++++++++++");
			kpiDeleteUrl = getTestProperty("kpi_url") + "/" + kpi_id;
			log.info("+++ kpiDeleteUrl == " + kpiDeleteUrl);
			Response delete_response = deleteServiceResponse("kpi_url" + "/" + kpi_id, values,
					ooTestutil.kpiprovideHeaders());
			log.info("+++ delete_response.asString() == " + delete_response.asString());
			isEqual("we should be able to delete kpi", true,
					delete_response.getStatusCode() == HttpStatus.SC_NO_CONTENT);

			// GET KPI
			ooTestutil.printnewLine();
			log.info("+++ GET KPI BY ID+++++++++++++++++++++++++++++++++++");
			String getKpiUrl = "kpi_url" + "/id/" + kpi_id;
			Response get_response = getServiceResponse(getKpiUrl, ooTestutil.kpiprovideHeaders());
			isEqual("Delete failed", 404, get_response.getStatusCode());
			if (get_response.getBody().asString().equals("")) {
				log.info("testDeleteKpiScenario5 Passed. KPI was deleted successfully");
			}

		}

	}

	/********************************************************************************************************************/

	//@Test(dependsOnMethods={"test_ApmTsIngestion_ApmTsRetrieval","test_ApmAssetRetrieval"})
	//@RallyInfo(UserStory = "US127041")
	public void testUpdateKpiTemplate_Java() throws Exception {

		// create kpi template
		kpi_id = ooTestutil.createKpiTemplate(path + "/kpi_templates/kpi_e2e_ooapmts_inputAndOutput.json",""
				);
		Thread.sleep(10000);

		ooTestutil.updateKpiTemplateAnalyticFile(kpi_id,path + "/kpi_analytics/simple_python_version3.zip");

		// DELETE KPI
		log.info("+++ DELETE KPI+++++++++++++++++++++++++++++++++++");
		String kpiDeleteUrl = getTestProperty("kpi_url") + "/" + kpi_id;
		log.info("+++ kpiDeleteUrl == " + kpiDeleteUrl);
		Response delete_response = deleteServiceResponse("kpi_url" + "/" + kpi_id, values,
				ooTestutil.kpiprovideHeaders());
		log.info("+++ delete_response.asString() == " + delete_response.asString());

		ooTestutil.printnewLine();
	}

	/********************************************************************************************************************/


	@AfterTest
	public void afterTest() {
	}

	@BeforeSuite
	public void beforeSuite() {

	}

	@AfterSuite
	public void afterSuite() {
	}
}


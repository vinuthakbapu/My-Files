package com.ge.automation.OO;

import java.io.File;
import java.util.LinkedHashMap;
import java.util.Map;

import org.apache.commons.io.FileUtils;
import org.apache.commons.logging.Log;
import org.apache.commons.logging.LogFactory;
import org.springframework.boot.test.TestRestTemplate;
import org.springframework.core.io.FileSystemResource;
import org.springframework.http.HttpEntity;
import org.springframework.http.HttpMethod;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.util.LinkedMultiValueMap;
import org.springframework.util.MultiValueMap;
import org.springframework.web.client.RestTemplate;
import org.testng.Assert;
import org.testng.SkipException;
import org.testng.annotations.BeforeClass;
import org.testng.annotations.Test;

import com.fasterxml.jackson.databind.ObjectMapper;

import com.ge.automation.OO.dto.KpiDetails;
import com.ge.microtester.common.utils.RestAssuredUtil;
import com.ge.microtester.rally.RallyInfo;
import com.jayway.restassured.path.json.JsonPath;
import com.jayway.restassured.response.Response;

@RallyInfo(ProjectName ="APM Super Optimo")
public class OOKpiManagementTests  extends RestAssuredUtil{

	String kpiid;
	String kpiJobId;
	String dataSourceId;
	long kpi_id;
	long kpi_id1;
	public OOTestUtil ooTestutil = new OOTestUtil();
	RestTemplate restTemplate = new TestRestTemplate();
	private static Log _OOlogger = LogFactory.getLog(OOKpiManagementTests.class);
	// Generating Query Params
	Map<String, Object> values = new LinkedHashMap<String, Object>();
	@BeforeClass
	public void beforeClass() {

		System.getProperties().put("proxySet", "true");
		System.getProperties().put("http.proxyHost", "sjc1intproxy01.crd.ge.com");
		System.getProperties().put("http.proxyPort", "8080");
		System.getProperties().put("https.proxyHost", "sjc1intproxy01.crd.ge.com");
		System.getProperties().put("https.proxyPort", "8080");
		//getServiceResponse("alert_profile_base_url");
		setSysProperty("currentTimeStamp", "" + getCurrentTimestamp());// ${sys:currentTimeStamp}

	}// end o

	/********************************************************************************************************************/

	
	/********************************************************************************************************************/

	@Test(priority = 2, description = "testGetAllKpiJobs")
	@RallyInfo(UserStory ="US223441")
	public void testGetAllKpiJobsByKpiReferenceId() throws Exception  {

		throw new SkipException("Skipping this exception");

	}

	/********************************************************************************************************************/
	@Test(priority = 2, description = "testGetAllKpiJobs")
	@RallyInfo(UserStory ="US223441")
	public void testGetAllKpiJobs() throws Exception {

		// GET ALl KPI Jobs

		Response get_response = getServiceResponse("job_url", ooTestutil.kpiprovideHeaders());

		isEqual("All jobs not retrieved", true, get_response.body().asString().contains(String.valueOf("id")));
		isEqual("All jobs not retrieved", true, get_response.body().jsonPath().getList("id").size() > 0);

		ooTestutil.printnewLine();

	}

	/********************************************************************************************************************/
	//@Test(priority = 3, description = "testCreateDatasource")
	public void testCreateDatasource() throws Exception {

		ooTestutil.printnewLine();
		// Generating Query Params
		Map<String, Object> values = new LinkedHashMap<String, Object>();
		values.put("", "");
		String kpiDataSourceFile = "./src/main/resources/payloads/datasource-create.json";
		Response response = postServiceResponse(kpiDataSourceFile, "datasource_url", values, ooTestutil.kpiprovideHeaders());

		//System.out.println("+++ response.asString() == " + response.asString());
		JsonPath jsonPath = new JsonPath(response.asString());
		dataSourceId = jsonPath.getString("id");

		// isEqual("Incorrect tag name", true,
		// response.body().jsonPath().getString("id") != null);
		// isEqual("Incorrect tag name", true,
		// response.body().jsonPath().get("name")=="PREDIX_ASSET_DS");
		isEqual("Incorrect tag name", true, response.body().asString().contains("APM_ASSET_DS"));

		//System.out.println("+++ response.asString() == " + response.asString());
		ooTestutil.printnewLine();

	}

	/********************************************************************************************************************/
	//@Test(priority = 4, description = "testGetDataSource")
	public void testGetDataSource() throws Exception {

		ooTestutil.printnewLine();
		// Generating Query Params
		Map<String, Object> values = new LinkedHashMap<String, Object>();
		values.put("", "");
		Response response = getServiceResponse("datasource_url", values, ooTestutil.kpiprovideHeaders());
		//System.out.println("+++ response.asString() == " + response.asString());
		isEqual("Incorrect tag name", true, response.body().asString().contains("APM_ASSET_DS"));
		// isEqual("Incorrect tag name", true,
		// response.body().jsonPath().get("name")=="PREDIX_ASSET_DS");
		ooTestutil.printnewLine();

	}

	/********************************************************************************************************************/
	//@Test(priority = 5, description = "testGetDataSourceByType")
	public void testGetDataSourceByType()  throws Exception {

		ooTestutil.printnewLine();
		// Generating Query Params
		Map<String, Object> values = new LinkedHashMap<String, Object>();
		values.put("", "");
		Response response = getServiceResponse("datasource_url" + "/Type/APM_ASSET_DS", values, ooTestutil.kpiprovideHeaders());
		//System.out.println("+++ response.asString() == " + response.asString());
		isEqual("Incorrect tag name", true, response.body().asString().contains("APM_ASSET_DS"));
		// isEqual("Incorrect tag name", true,
		// response.body().jsonPath().get("name")=="PREDIX_ASSET_DS");
		ooTestutil.printnewLine();

	}

	/********************************************************************************************************************/

	//@Test(priority = 6, description = "testUpdateDataSourceFile")
	public void testUpdateDataSourceFile() throws Exception  {

		ooTestutil.printnewLine(); // Generating Query Params

		String kpiUpdateDataSourceFile = "./src/main/resources/payloads/kpi_templates/datasource-update.json";
		Response response = putServiceResponse(kpiUpdateDataSourceFile, "datasource_url", ooTestutil.kpiprovideHeaders());
		//System.out.println("+++ response.asString() == " + response.asString());
		isEqual("Incorrect tag name", true, response.body().asString().contains("APM_ASSET_DS_UPDATE"));
		ooTestutil.printnewLine();

		ooTestutil.printnewLine();
	}

	/********************************************************************************************************************/

	//@Test(priority = 7, description = "testUpdateDataSourceFileWithNoDataSource")
	public void testUpdateDataSourceFileWithNoDataSource()
			 throws Exception {

		ooTestutil.printnewLine(); // Generating Query Params

		String kpiUpdateDataSourceFile = "./src/main/resources/payloads/kpi_templates/datasource-update.json";
		Response response = putServiceResponse(kpiUpdateDataSourceFile, "datasource_url", ooTestutil.kpiprovideHeaders());
		//System.out.println("+++ response.asString() == " + response.asString());
		isEqual("Incorrect tag name", true, response.body().asString().contains("APM_ASSET_DS_UPDATE"));
		ooTestutil.printnewLine();

		ooTestutil.printnewLine();
	}

	/********************************************************************************************************************/
	//@Test(priority = 8, description = "testDeleteAllDataSource")
	public void testDeleteAllDataSource()  throws Exception {

		ooTestutil.printnewLine();
		// Generating Query Params
		Map<String, Object> values = new LinkedHashMap<String, Object>();
		values.put("", "");

		Response response = deleteServiceResponse("datasource_url", values, ooTestutil.kpiprovideHeaders());
		//System.out.println("+++ response.asString() == " + response.asString());
		isEqual("Incorrect tag name", 200, response.getStatusCode());
		ooTestutil.printnewLine();

	}

	/********************************************************************************************************************/
	@Test(priority = 9, description = "testCreateKpiErrorValidationNameField")
	@RallyInfo(UserStory ="US223441")
	public void testCreateKpiErrorValidationNameField() throws Exception {

		ooTestutil.printnewLine();

		final String uri = getTestProperty("kpi_url");

		String kpiJson = FileUtils.readFileToString(
				new java.io.File("src/main/resources/payloads/kpi_templates/kpi_e2e_without_name.json"));
		File analyticFile = new java.io.File(
				"src/main/resources/payloads/kpi_analytics/kpi_analytic_asset_ts_int.zip");

		MultiValueMap<String, Object> parameters = new LinkedMultiValueMap<String, Object>();
		parameters.add("uploadfile", new FileSystemResource(analyticFile));
		parameters.add("kpi", new ObjectMapper().readValue(kpiJson, KpiDetails.class));

		ResponseEntity<KpiDetails> response = restTemplate.exchange(uri, HttpMethod.POST,
				new HttpEntity<MultiValueMap<String, Object>>(parameters, ooTestutil.kpiprovideHeaders_1()), KpiDetails.class);
		isEqual("Not valid response for Start Job for Error validation Name field missing", 400,
				response.getStatusCode().value());
	}

	/********************************************************************************************************************/

	@Test(priority = 10, description = "testCreateKpiErrorValidationWithoutInputOutput")
	@RallyInfo(UserStory ="US223441")
	public void testCreateKpiErrorValidationWithoutInputOutput() throws Exception {

		ooTestutil.printnewLine();

		final String uri = getTestProperty("kpi_url");

		String kpiJson = FileUtils.readFileToString(new java.io.File(
				"src/main/resources/payloads/kpi_templates/kpi_e2e_without_inout_and_output.json"));
		File analyticFile = new java.io.File(
				"src/main/resources/payloads/kpi_analytics/kpi_analytic_asset_ts_int.zip");

		MultiValueMap<String, Object> parameters = new LinkedMultiValueMap<String, Object>();
		parameters.add("uploadfile", new FileSystemResource(analyticFile));
		parameters.add("kpi", new ObjectMapper().readValue(kpiJson, KpiDetails.class));

		ResponseEntity<KpiDetails> response = restTemplate.exchange(uri, HttpMethod.POST,
				new HttpEntity<MultiValueMap<String, Object>>(parameters, ooTestutil.kpiprovideHeaders_1()), KpiDetails.class);
		isEqual("Not valid response for Start Job for Error validation Name field missing", 400,
				response.getStatusCode().value());
	}

	/********************************************************************************************************************/
	@Test(priority = 11, description = "testCreateKpiErrorValidationWithEmptyFields")
	@RallyInfo(UserStory ="US223441")
	public void testCreateKpiErrorValidationWithEmptyFields() throws Exception {

		ooTestutil.printnewLine();

		final String uri = getTestProperty("kpi_url");

		String kpiJson = FileUtils.readFileToString(
				new java.io.File("src/main/resources/payloads/kpi_templates/kpi_e2e_empty_fields.json"));
		File analyticFile = new java.io.File(
				"src/main/resources/payloads/kpi_analytics/kpi_analytic_asset_ts_int.zip");

		MultiValueMap<String, Object> parameters = new LinkedMultiValueMap<String, Object>();
		parameters.add("uploadfile", new FileSystemResource(analyticFile));
		parameters.add("kpi", new ObjectMapper().readValue(kpiJson, KpiDetails.class));

		ResponseEntity<KpiDetails> response = restTemplate.exchange(uri, HttpMethod.POST,
				new HttpEntity<MultiValueMap<String, Object>>(parameters, ooTestutil.kpiprovideHeaders_1()), KpiDetails.class);
		isEqual("Not valid response for Start Job for Error validation Name field missing", 400,
				response.getStatusCode().value());
	}

	/********************************************************************************************************************/
	@Test(priority = 12, description = "testCreateKpiErrorValidationWithEmptyPayload")
	@RallyInfo(UserStory ="US223441")
	public void testCreateKpiErrorValidationWithEmptyPayload() throws Exception {

		ooTestutil.printnewLine();

		final String uri = getTestProperty("kpi_url");

		String kpiJson = FileUtils.readFileToString(
				new java.io.File("src/main/resources/payloads/kpi_templates/kpi_e2e_empty_payload.json"));
		File analyticFile = new java.io.File(
				"src/main/resources/payloads/kpi_analytics/kpi_analytic_asset_ts_int.zip");

		MultiValueMap<String, Object> parameters = new LinkedMultiValueMap<String, Object>();
		parameters.add("uploadfile", new FileSystemResource(analyticFile));
		parameters.add("kpi", new ObjectMapper().readValue(kpiJson, KpiDetails.class));

		ResponseEntity<KpiDetails> response = restTemplate.exchange(uri, HttpMethod.POST,
				new HttpEntity<MultiValueMap<String, Object>>(parameters, ooTestutil.kpiprovideHeaders_1()), KpiDetails.class);
		isEqual("Not valid response for Start Job for Error validation Name field missing", 400,
				response.getStatusCode().value());
	}

	/********************************************************************************************************************/
	@Test(priority = 13, description = "testCreateJobWithoutJobId")
	@RallyInfo(UserStory ="US223441")
	public void testCreateJobWithoutJobId() throws Exception {

		// *****************Create KPI JOB***************************************************//

		ooTestutil.printnewLine();
		System.out.println("*****************Create KPI JOB*******************");
		ooTestutil.printnewLine();

		String kpijobFile = "src/main/resources/payloads/kpi_jobs/kpi_e2e_job_withoutJobId.json";
		Response response1 = postServiceResponse(kpijobFile, "job_url", ooTestutil.kpiprovideHeaders());

		 System.out.println("+++ response.asString() == " +
		 response1.asString());
		JsonPath jsonPath = new JsonPath(response1.asString());
		kpiJobId = jsonPath.getString("id");
		System.out.println("+++ kpiJobId== " + kpiJobId);

		isEqual("Not valid response create KPI Job", 400, response1.statusCode());

	}

	/********************************************************************************************************************/
	@Test(priority = 14, description = "testCreateJobWithEmptyPayload")
	@RallyInfo(UserStory ="US223441")
	public void testCreateJobWithEmptyPayload() throws Exception {

		// *****************Create KPI JOB***************************************************//

		ooTestutil.printnewLine();
		System.out.println("*****************Create KPI JOB*******************");
		ooTestutil.printnewLine();

		String kpijobFile = "src/main/resources/payloads/kpi_jobs/kpi_e2e_job_withoutJobId.json";
		Response response1 = postServiceResponse(kpijobFile, "job_url", ooTestutil.kpiprovideHeaders());

		// System.out.println("+++ response.asString() == " +
		// response1.asString());
		JsonPath jsonPath = new JsonPath(response1.asString());
		kpiJobId = jsonPath.getString("id");
		System.out.println("+++ kpiJobId== " + kpiJobId);

		isEqual("Not valid response create KPI Job", 400, response1.statusCode());

	}

	/********************************************************************************************************************/
	@Test(priority = 15, description = "testUpdateKpiJobWhichDoesNotExists")
	@RallyInfo(UserStory ="US223441")
	public void testUpdateKpiJobWhichDoesNotExists() throws Exception {

		// *****************Create KPI JOB***************************************************//

		ooTestutil.printnewLine();
		System.out.println("*****************Create KPI JOB*******************");
		ooTestutil.printnewLine();

		String kpijobFile = "src/main/resources/payloads/kpi_jobs/kpi_e2e_job_withoutJobId.json";
		Response response1 = postServiceResponse(kpijobFile, "job_url", ooTestutil.kpiprovideHeaders());

		// System.out.println("+++ response.asString() == " +
		// response1.asString());
		JsonPath jsonPath = new JsonPath(response1.asString());
		kpiJobId = jsonPath.getString("id");
		System.out.println("+++ kpiJobId== " + kpiJobId);

		isEqual("Not valid response create KPI Job", 400, response1.statusCode());

	}

	/********************************************************************************************************************/
	//@Test(priority = 16, description = "testCreateKpiFileUploadingInvalidAnalytic")
	//https://rally1.rallydev.com/#/53445838461d/detail/defect/67740728016
	public void testCreateKpiFileUploadingInvalidAnalytic() throws Exception {

		final String uri = getTestProperty("kpi_url");

		String kpiJson = FileUtils.readFileToString(
				new java.io.File("src/main/resources/payloads/kpi_templates/kpi_e2e-for-file-upload.json"));

		MultiValueMap<String, Object> parameters = new LinkedMultiValueMap<String, Object>();
		parameters.add("uploadfile",
				new FileSystemResource(new java.io.File("src/main/resources/payloads/kpi_analytics/invalid.zip")));
		parameters.add("kpi", new ObjectMapper().readValue(kpiJson, KpiDetails.class));

		ResponseEntity<KpiDetails> response = restTemplate.exchange(uri, HttpMethod.POST,
				new HttpEntity<MultiValueMap<String, Object>>(parameters, ooTestutil.kpiprovideHeaders_1()), KpiDetails.class);

		isEqual("Not valid response create KPI Job", 400, response.getStatusCode().value());
	}

	/********************************************************************************************************************/

	//@Test(priority = 17, description = "testCreateKpiFileUploadingEmptyaAnalytic")
	public void testCreateKpiFileUploadingEmptyaAnalytic() throws Exception {

		final String uri = getTestProperty("kpi_url");

		String kpiJson = FileUtils.readFileToString(
				new java.io.File("src/main/resources/payloads/kpi_templates/kpi_e2e-for-file-upload.json"));

		MultiValueMap<String, Object> parameters = new LinkedMultiValueMap<String, Object>();
		parameters.add("uploadfile",
				new FileSystemResource(new java.io.File("src/main/resources/payloads/kpi_analytics/empty.zip")));
		parameters.add("kpi", new ObjectMapper().readValue(kpiJson, KpiDetails.class));

		ResponseEntity<KpiDetails> response = restTemplate.exchange(uri, HttpMethod.POST,
				new HttpEntity<MultiValueMap<String, Object>>(parameters, ooTestutil.kpiprovideHeaders_1()), KpiDetails.class);

		isEqual("Not valid response create KPI Job", 500, response.getStatusCode().value());
	}



	/********************************************************************************************************************/

	@Test(priority = 20, description = "testOOUAAInstance")
	@RallyInfo(UserStory ="US223441")
	public void testOOUAAInstance()  throws Exception {

		ooTestutil.printnewLine();
		String token = getToken("uaaUrl", "grant_type", "username", "password", "clientId", "clientSecret");
		System.out.println("oouaa_token-------------->" + token);

	}

	/********************************************************************************************************************/
	@Test(priority = 21, description = "testOOLogger")
	@RallyInfo(UserStory ="US223441")
	public void testOOLogger() throws Exception {

		ooTestutil.printnewLine();
		_OOlogger.error("Testing logger Error message");
		_OOlogger.info("Testing logger info message");
		_OOlogger.fatal("Testing logger fatal message");
		_OOlogger.debug("Testing logger debug message");
		_OOlogger.warn("Testing logger warn message");
		_OOlogger.trace("Testing logger trace message");

	}

	/********************************************************************************************************************/
	//@Test(priority = 23, description = "testFileUploadingInvalidanalytic")
//tbd
	public void testFileUploadingInvalidanalytic() throws Exception {

		final String uri = getTestProperty("kpi_url");

		String kpiJson = FileUtils
				.readFileToString(new java.io.File("src/main/resources/payloads/kpi_templates/kpi_e2e.json"));

		MultiValueMap<String, Object> parameters = new LinkedMultiValueMap<String, Object>();
		parameters.add("uploadfile",
				new FileSystemResource(new java.io.File("src/main/resources/payloads/kpi_analytics/invalid.zip")));
		parameters.add("kpi", new ObjectMapper().readValue(kpiJson, KpiDetails.class));

		ResponseEntity<KpiDetails> response = restTemplate.exchange(uri, HttpMethod.POST,
				new HttpEntity<MultiValueMap<String, Object>>(parameters, ooTestutil.kpiprovideHeaders_1()), KpiDetails.class);

		Assert.assertEquals(response.getStatusCode(), HttpStatus.BAD_REQUEST);
	}

	/********************************************************************************************************************/

	//@Test(priority = 24, description = "testFileUploadingEmptyanalytic")
	//tbd
	public void testFileUploadingEmptyanalytic() throws Exception {

		final String uri = getTestProperty("kpi_url");

		String kpiJson = FileUtils
				.readFileToString(new java.io.File("src/main/resources/payloads/kpi_templates/kpi_e2e.json"));

		MultiValueMap<String, Object> parameters = new LinkedMultiValueMap<String, Object>();
		parameters.add("uploadfile", new FileSystemResource(new java.io.File("src/main/resources/payloads/kpi_analytics/empty.zip")));
		parameters.add("kpi", new ObjectMapper().readValue(kpiJson, KpiDetails.class));

		ResponseEntity<KpiDetails> response = restTemplate.exchange(uri, HttpMethod.POST,
				new HttpEntity<MultiValueMap<String, Object>>(parameters, ooTestutil.kpiprovideHeaders_1()), KpiDetails.class);

		Assert.assertEquals(response.getStatusCode(), HttpStatus.BAD_REQUEST);
	}

	/********************************************************************************************************************/


}

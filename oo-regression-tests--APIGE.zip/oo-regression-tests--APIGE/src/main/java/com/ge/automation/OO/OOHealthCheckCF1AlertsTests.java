package com.ge.automation.OO;

import com.ge.microtester.common.utils.RestAssuredUtil;
import com.ge.microtester.rally.RallyInfo;
import com.ge.oo.commons.utils.StringUtils;
import com.jayway.restassured.response.Response;



import org.apache.http.HttpStatus;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.boot.test.TestRestTemplate;
import org.springframework.web.client.RestTemplate;
import org.testng.Assert;
import org.testng.annotations.AfterClass;
import org.testng.annotations.AfterMethod;
import org.testng.annotations.AfterSuite;
import org.testng.annotations.AfterTest;
import org.testng.annotations.BeforeClass;
import org.testng.annotations.BeforeMethod;
import org.testng.annotations.BeforeSuite;
import org.testng.annotations.BeforeTest;
import org.testng.annotations.Test;

import java.io.IOException;
import java.net.URISyntaxException;
import java.time.LocalDateTime;
import java.time.ZoneId;
import java.time.temporal.ChronoUnit;
import java.util.LinkedHashMap;
import java.util.Map;
import java.util.Properties;

@RallyInfo(ProjectName ="APM Super Optimo")
public class OOHealthCheckCF1AlertsTests extends RestAssuredUtil {
	private static final Logger log = LoggerFactory.getLogger("OOHealthCheckCF1Tests");
	static String jsonfileName;
	Properties configFile = new Properties();
	String truncateDateTime[];
	String tagName;
	String proxyHost;
	String proxyPort;
	Response responseBody;
	String kpiid;
	String kpiJobId;
	String dataSourceId;
	long kpi_id;
	long kpi_id1;
	String path = "src/main/resources/payloadsAndromeda";
	String apmTSforIngestionPath;
	boolean apmIngestionDynamicTag;
	String kpiTemplateJsonPath;
	String kpiTemplateAnalyticPath;
	String kpiJobJsonPath;
	String dataIngestionFilePath;
	String inputTag;
	String outputTag;
	String expectedValue;
	String expectedJobStatus;
	boolean createKpiJobWithTag;
	String apmTsUrl = "";

	public OOTestUtil ooTestutil = new OOTestUtil();
	RestTemplate restTemplate = new TestRestTemplate();
	// Generating Query Params
	Map<String, Object> values = new LinkedHashMap<String, Object>();

	@BeforeMethod
	public void beforeMethod() {
	}

	@AfterMethod
	public void afterMethod() {
	}

	@BeforeClass
	public void beforeClass() {

		/*
		 * System.getProperties().put("proxySet", "true");
		 * System.getProperties().put("http.proxyHost",
		 * "sjc1intproxy01.crd.ge.com");
		 * System.getProperties().put("http.proxyPort", "8080");
		 * System.getProperties().put("https.proxyHost",
		 * "sjc1intproxy01.crd.ge.com");
		 * System.getProperties().put("https.proxyPort", "8080");
		 */
		// getServiceResponse("alert_profile_base_url");
		setSysProperty("currentTimeStamp", "" + getCurrentTimestamp());// ${sys:currentTimeStamp}

	}// end of beforeClass

	@AfterClass
	public void afterClass() {
	}

	@BeforeTest
	public void beforeTest() {

	}// end of beforeTest

	
	/********************************************************************************************************************/
	@Test()
	@RallyInfo(UserStory ="US223441")
	public void testE2E_AlertsBatch_Python() throws Exception {

		// ingest test data into apm time series
		String inputTag = "OO_Tag_Temperature_ID14";
		String outputTag = "OO_Tag_Temperature_ID15";
		String jobName = "testJobName";
		String sourceKey ="testSourceKey"+ooTestutil.generateRandomNumber3Digits();

		// create kpi template
		kpi_id = ooTestutil.createKpiTemplate(path + "/kpi_templates/kpi_e2e_ooapmts_inputAndOutputForAlerts.json",
				path + "/kpi_analytics/PythonSimpleAnalytic.zip");
		Thread.sleep(10000);

		// create kpi job
		kpiJobId = ooTestutil.createKpiJobForAlertsWithNoRandomBothInputAndOutputTag(
				path + "/kpi_jobs/kpi_e2e_ooapmts_inputAndOutput_Alerts_job.json", kpi_id, outputTag, inputTag, "",jobName,sourceKey);

	

		// start kpi job
		String runtimeJobId = ooTestutil.startKpiJob(kpiJobId);
		Thread.sleep(20000);
		String statusOfJob = ooTestutil.getStatusOfJob(kpiJobId);

		String kpiname = ooTestutil.getKpiNameTemplateById(kpi_id);
		
		// get alert
		Thread.sleep(60000);
		String lastsourceKeys = ooTestutil.getLastAlerts(path + "/data_files/alert_data.json",kpiname);
		System.out.println("lastsourceKeys" + lastsourceKeys);
	    isEqual("Alerts not generated", true, lastsourceKeys.contains(sourceKey));

		ooTestutil.printnewLine();
	}
	
	/********************************************************************************************************************/
	@AfterTest
	public void afterTest() {
	}

	@BeforeSuite
	public void beforeSuite() {

	}

	@AfterSuite
	public void afterSuite() {
	}
}

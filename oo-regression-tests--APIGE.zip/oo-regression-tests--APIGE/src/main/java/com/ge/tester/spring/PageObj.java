package com.ge.tester.spring;

import java.util.List;
import java.util.Map;

import com.fasterxml.jackson.annotation.JsonIgnoreProperties;

// Spring sample - keep it for now
@JsonIgnoreProperties(ignoreUnknown = true)
public class PageObj
{
	private String name;
	private String about;
	private String phone;
	private String website;
	
	private String city;
	private String country;
	private String latitude;
	private String longitude;
	private Map<String, String> location;
	private List category_list;
	//private Object category_list;

	private String catID;
	private String catName;
	
	/**
	 * @return the catID
	 */
	public String getCatID()
	{
		Map tmp = (Map)category_list.get(0);
		//String strObject = (String)category_list;
		System.out.println( "list - id - " + tmp.get("id"));
		System.out.println("list - name - " + tmp.get("name"));
	
		return catID;
	}
	
	/**
	 * @return the catName
	 */
	public String getCatName()
	{
		return catName;
	}

	public String getName()
	{
		return name;
	}

	public String getAbout()
	{
		return about;
	}

	public String getPhone()
	{
		return phone;
	}

	public String getWebsite()
	{
		return website;
	}
	
	public String getCountry()
	{
		return country;
	}

	public String getCity()
	{
		city = this.location.get("city");
		return city;
	}

	public String getLatitude()
	{
		latitude = this.location.get("latitude");
		return latitude;
	}
	
	/**
	 * @return the category_list
	 */
	public List getCategory_list()
	//public Object getCategory_list()
	{
		return category_list;
	}

	public String getLongitude()
	{
		longitude = this.location.get("longitude");
		return longitude;
	}

	/**
	 * @return the location
	 */
	public Map<String, String> getLocation()
	{
		return location;
	}
}


export JAVA_HOME=${JAVA_HOME_OPENJDK8}
export PATH=${JAVA_HOME}/bin:${PATH}

mvn clean test -DenvType=qa_stuf4 -Dlocal=true -DignoreTestProperty="false" -Dsuite=E2EPythonScenariosTestSuite -s ./mvnsettings.xml


export JAVA_HOME=${JAVA_HOME_OPENJDK8}
export PATH=${JAVA_HOME}/bin:${PATH}

 
mvn clean test -DenvType=preprod_cf1 -Dlocal=true -DignoreTestProperty="false" -Dsuite=HealthCheckCF1BatchTestSuite -s menlo_settings.xml -DfilePath=local -Dhttps.proxyHost=grc-americas-sanra-pitc-wkcz.proxy.corporate.gtm.ge.com -Dhttps.proxyPort=80 -Dhttp.nonProxyHosts=*.ge.com

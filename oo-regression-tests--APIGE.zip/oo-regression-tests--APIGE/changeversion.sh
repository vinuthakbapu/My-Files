function updateVersion()
{
	version=$1
	echo -e "changing the version of this project to ${version}"
	mvn versions:set -DnewVersion="${version}"
	sed -i -e "s/<oo.libs.version>.*<\/oo.libs.version>/<oo.libs.version>${version}<\/oo.libs.version>/g" pom.xml
	echo -e "\n~~~~~~~~~~~~~~~~~~~~~~version updated in pom, rebuilding the project~~~~~~~~~~~~~~~~~~~~~~"
	mvn clean install
	echo -e "\n~~~~~~~~~~~~~~~~~~~~~~running the build~~~~~~~~~~~~~~~~~~~~~~"
	./build.sh
	echo -e "\n~~~~~~~~~~~~~~~~~~~~~~finished the build~~~~~~~~~~~~~~~~~~~~~~"
}
function main()
{
	echo "This will change the version of parent and child pom.xml and update oo.libs version inside pom."
	if [  -z "$1" ]
	then
		echo "Please provide new version string in cmd line argument. Example usage ./changeversion.sh 0.9.3-SNAPSHOT->>new version."
		exit 1
	fi
	updateVersion $1
}
main $1